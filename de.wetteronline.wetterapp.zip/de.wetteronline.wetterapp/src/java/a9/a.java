/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.RecentlyNonNull
 *  com.android.billingclient.api.l
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.util.concurrent.Executors
 *  java.util.concurrent.ThreadFactory
 */
package a9;

import androidx.annotation.RecentlyNonNull;
import com.android.billingclient.api.l;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class a
implements ThreadFactory {
    public final String b;
    public final ThreadFactory c = Executors.defaultThreadFactory();

    public a(@RecentlyNonNull String string) {
        this.b = string;
    }

    @RecentlyNonNull
    public final Thread newThread(@RecentlyNonNull Runnable runnable) {
        Thread thread = this.c.newThread((Runnable)new l(runnable));
        thread.setName(this.b);
        return thread;
    }
}

