/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IInterface
 *  android.os.RemoteException
 *  java.lang.Object
 */
package a;

import a.a;
import android.os.IInterface;
import android.os.RemoteException;

public interface b
extends IInterface {
    public boolean L0(a var1) throws RemoteException;

    public boolean d1(long var1) throws RemoteException;
}

