/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.IInterface
 *  android.os.RemoteException
 *  java.lang.Object
 *  java.lang.String
 */
package a;

import android.os.Bundle;
import android.os.IInterface;
import android.os.RemoteException;

public interface a
extends IInterface {
    public void K2(String var1, Bundle var2) throws RemoteException;

    public void P2(Bundle var1) throws RemoteException;
}

