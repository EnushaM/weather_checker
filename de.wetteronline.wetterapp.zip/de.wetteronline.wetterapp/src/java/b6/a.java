/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a6.g
 *  android.graphics.drawable.Drawable
 *  b6.c
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package b6;

import a6.g;
import android.graphics.drawable.Drawable;
import b6.b;
import b6.c;
import e6.j;

public abstract class a<T>
implements c<T> {
    public final int b;
    public final int c;
    public a6.b d;

    public a() {
        if (j.h(Integer.MIN_VALUE, Integer.MIN_VALUE)) {
            this.b = Integer.MIN_VALUE;
            this.c = Integer.MIN_VALUE;
            return;
        }
        throw new IllegalArgumentException("Width and height must both be > 0 or Target#SIZE_ORIGINAL, but given width: -2147483648 and height: -2147483648");
    }

    public final a6.b a() {
        return this.d;
    }

    public final void b(a6.b b2) {
        this.d = b2;
    }

    public final void c(b b2) {
        int n2 = this.b;
        int n3 = this.c;
        ((g)b2).o(n2, n3);
    }

    public void d(Drawable drawable) {
    }

    public final void f(b b2) {
    }

    public void g(Drawable drawable) {
    }

    public void onDestroy() {
    }

    public void onStart() {
    }

    public void onStop() {
    }
}

