/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  c6.b
 *  java.lang.Object
 */
package b6;

import android.graphics.drawable.Drawable;
import b6.b;
import x5.h;

public interface c<R>
extends h {
    public a6.b a();

    public void b(a6.b var1);

    public void c(b var1);

    public void d(Drawable var1);

    public void e(R var1, c6.b<? super R> var2);

    public void f(b var1);

    public void g(Drawable var1);

    public void h(Drawable var1);
}

