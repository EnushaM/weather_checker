/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  an.e
 *  android.view.View
 *  android.view.View$OnClickListener
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.fragment.app.Fragment
 *  de.wetteronline.components.application.ToolsActivity
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 */
package an;

import an.e;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import de.wetteronline.components.application.ToolsActivity;

public final class d
implements View.OnClickListener {
    public final /* synthetic */ String[] b;
    public final /* synthetic */ int c;
    public final /* synthetic */ ToolsActivity d;
    public final /* synthetic */ Fragment e;

    public /* synthetic */ d(String[] arrstring, int n2, ToolsActivity toolsActivity, Fragment fragment) {
        this.b = arrstring;
        this.c = n2;
        this.d = toolsActivity;
        this.e = fragment;
    }

    public final void onClick(View view) {
        String[] arrstring = this.b;
        int n2 = this.c;
        ToolsActivity toolsActivity = this.d;
        Fragment fragment = this.e;
        ma.e.f((Object)arrstring, (String)"$permissions");
        e.b.h(arrstring, n2, (AppCompatActivity)toolsActivity, fragment);
    }
}

