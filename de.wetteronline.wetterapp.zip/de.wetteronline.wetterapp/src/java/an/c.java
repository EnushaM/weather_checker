/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  hr.m
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 */
package an;

import hr.m;
import ma.e;

public interface c {
    public void Q(b var1);

    public void S(b var1);

    public boolean W();

    public boolean y();

    public static final class a {
        public static void a(c c2, int[] arrn, String string, int n2) {
            e.f((Object)arrn, (String)"receiver");
            e.f((Object)string, (String)"tag");
            m.P((int[])arrn);
        }
    }

    public static interface b {
        public void a(int var1, String[] var2, int[] var3);

        public boolean b(int var1, String[] var2, int[] var3);
    }

}

