/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.view.View
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.l
 *  androidx.lifecycle.LifecycleCoroutineScopeImpl
 *  androidx.lifecycle.x
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  zm.a
 */
package an;

import an.c;
import an.e;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.l;
import androidx.lifecycle.LifecycleCoroutineScopeImpl;
import androidx.lifecycle.x;
import ds.g0;
import e.d;
import jr.f;

public class a
extends l
implements g0,
c {
    public c.b N0;

    public void B0(int n2, String[] arrstring, int[] arrn) {
        ma.e.f((Object)arrstring, (String)"permissions");
        ma.e.f((Object)arrn, (String)"grantResults");
        c.a.a(this, arrn, this.getClass().getSimpleName(), n2);
        c.b b3 = this.N0;
        if (b3 == null) {
            return;
        }
        View view = ((Fragment)this).I;
        if (view == null) {
            return;
        }
        e.b.b(b3, view, n2, arrstring, arrn, (Activity)this.w());
    }

    @Override
    public void Q(c.b b3) {
        this.N0 = b3;
        View view = ((Fragment)this).I;
        if (view == null) {
            return;
        }
        e.f(e.b, view, null, (Fragment)this, 2);
    }

    @Override
    public void S(c.b b3) {
        this.N0 = b3;
        e.b.j(null, (Fragment)this);
    }

    @Override
    public boolean W() {
        Context context = this.C();
        if (context == null) {
            return false;
        }
        return zm.a.b((Context)context);
    }

    @Override
    public f t0() {
        return ((LifecycleCoroutineScopeImpl)d.p((x)this)).c;
    }

    @Override
    public boolean y() {
        Context context = this.C();
        if (context == null) {
            return false;
        }
        return zm.a.c((Context)context);
    }
}

