/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.y
 *  com.google.android.material.snackbar.BaseTransientBottomBar
 *  com.google.android.material.snackbar.BaseTransientBottomBar$i
 *  com.google.android.material.snackbar.Snackbar
 *  de.wetteronline.components.application.ToolsActivity
 *  hr.j
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Objects
 *  m9.e
 *  ma.e
 *  rh.l0
 *  rh.l0$a
 *  rh.n
 *  tn.a
 *  zm.b
 */
package an;

import an.c;
import an.d;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.y;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import de.wetteronline.components.application.ToolsActivity;
import hr.j;
import i2.b;
import java.util.Objects;
import rh.l0;
import rh.n;
import tn.a;

public final class e
implements l0 {
    public static final e b = new e();
    public static final String[] c;
    public static final String[] d;
    public static final String[] e;
    public static final String[] f;
    public static final String[] g;

    public static {
        Object[] arrobject = new String[]{"android.permission.ACCESS_FINE_LOCATION"};
        c = arrobject;
        Object[] arrobject2 = new String[]{"android.permission.ACCESS_COARSE_LOCATION"};
        d = arrobject2;
        e = (String[])j.K((Object[])arrobject, (Object[])arrobject2);
        f = new String[]{"android.permission.ACCESS_BACKGROUND_LOCATION"};
        g = new String[]{"android.permission.CAMERA"};
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static void f(e var0, View var1_1, ToolsActivity var2_2, Fragment var3_3, int var4_4) {
        block12 : {
            block13 : {
                if ((var4_4 & 2) != 0) {
                    var2_2 = null;
                }
                if ((var4_4 & 4) != 0) {
                    var3_3 = null;
                }
                var5_5 = e.e;
                var6_6 = l0.a.a((l0)var0, (int)2131821194);
                if (var2_2 == null) break block13;
                var19_7 = var5_5.length;
                var20_8 = 0;
                do {
                    var9_10 = false;
                    if (var20_8 >= var19_7) break block12;
                    var21_9 = var5_5[var20_8];
                    if (!var2_2.shouldShowRequestPermissionRationale(var21_9)) {
                        ++var20_8;
                        continue;
                    }
                    ** GOTO lbl29
                    break;
                } while (true);
            }
            if (var3_3 == null) throw new IllegalArgumentException("Activity or Fragment must not be null");
            var7_11 = var5_5.length;
            var8_12 = 0;
            do {
                block14 : {
                    var9_10 = false;
                    if (var8_12 >= var7_11) break;
                    var16_13 = var5_5[var8_12];
                    var17_14 = var3_3.u;
                    var18_15 = var17_14 != null ? var17_14.i(var16_13) : false;
                    if (!var18_15) break block14;
lbl29: // 2 sources:
                    var9_10 = true;
                    break;
                }
                ++var8_12;
            } while (true);
        }
        if (!var9_10) {
            var0.h(var5_5, 101, (AppCompatActivity)var2_2, var3_3);
            return;
        }
        if (var2_2 != null) {
            var12_16 = var2_2;
        } else {
            if (var3_3 == null) throw new IllegalArgumentException("Context must be either ToolsActivity or v4.Fragment with ToolsActivity Parent");
            var10_17 = var3_3.w();
            Objects.requireNonNull((Object)var10_17, (String)"null cannot be cast to non-null type de.wetteronline.components.application.ToolsActivity");
            var12_16 = (ToolsActivity)var10_17;
        }
        var12_16.x0();
        var13_18 = var0.a(var1_1, var6_6);
        var14_19 = new d(var5_5, 101, var2_2, var3_3);
        var13_18.k(var13_18.b.getText(2131821740), (View.OnClickListener)var14_19);
        var13_18.l();
    }

    public final Snackbar a(View view, String string) {
        Snackbar snackbar = Snackbar.j((View)view, (CharSequence)string, (int)8000);
        TextView textView = (TextView)snackbar.c.findViewById(2131297248);
        textView.setTextColor(-1);
        textView.setMaxLines(3);
        return snackbar;
    }

    public final void b(c.b b3, View view, int n2, String[] arrstring, int[] arrn, Activity activity) {
        switch (n2) {
            default: {
                return;
            }
            case 101: 
            case 102: 
            case 103: 
        }
        if (m9.e.u((int[])arrn)) {
            b3.a(n2, arrstring, arrn);
            return;
        }
        if (!b3.b(n2, arrstring, arrn)) {
            String string;
            switch (n2) {
                default: {
                    throw new IllegalStateException(ma.e.l((String)"Requested Permission was unknown ", (Object)n2));
                }
                case 103: {
                    string = l0.a.a((l0)this, (int)2131821191);
                    break;
                }
                case 102: {
                    Object[] arrobject = new Object[]{l0.a.a((l0)this, (int)2131820611)};
                    string = l0.a.b((l0)this, (int)2131820610, (Object[])arrobject);
                    break;
                }
                case 101: {
                    string = l0.a.a((l0)this, (int)2131821193);
                }
            }
            Snackbar snackbar = this.a(view, string);
            n n3 = new n(activity);
            snackbar.k(snackbar.b.getText(2131821415), (View.OnClickListener)n3);
            snackbar.l();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final void h(String[] arrstring, int n2, AppCompatActivity appCompatActivity, Fragment fragment) {
        if (appCompatActivity != null) {
            b.b((Activity)appCompatActivity, arrstring, n2);
            return;
        }
        if (fragment == null) throw new IllegalArgumentException("Activity or Fragment must not be null");
        try {
            fragment.N0(arrstring, n2);
            return;
        }
        catch (IllegalStateException illegalStateException) {
            a.A((Throwable)illegalStateException);
            return;
        }
    }

    public final void j(AppCompatActivity appCompatActivity, Fragment fragment) {
        if (zm.b.a) {
            this.h(f, 102, appCompatActivity, fragment);
            return;
        }
        this.h(e, 101, appCompatActivity, fragment);
    }

    public String q(int n2) {
        return l0.a.a((l0)this, (int)n2);
    }
}

