/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Base64
 *  androidx.activity.result.c
 *  androidx.compose.runtime.b
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package b5;

import android.content.Context;
import android.os.Build;
import android.util.Base64;
import androidx.activity.result.c;
import androidx.compose.runtime.b;
import java.io.Serializable;
import org.json.JSONException;
import org.json.JSONObject;

public class a
implements Serializable {
    public String b;
    public String c;
    public long d;
    public int e;
    public String f = "";
    public String g = "";
    public int h;
    public String i = "";
    public String j = "";
    public String k = "";
    public String l = "";

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public a(Context context, int n2, String string) {
        try {
            this.b = "1.0";
            this.g = "Android";
            this.h = Build.VERSION.SDK_INT;
            this.i = Build.MANUFACTURER;
            this.j = Build.MODEL;
            this.d = System.currentTimeMillis();
            String string2 = context == null ? "unknown" : context.getPackageName();
            this.f = string2;
            this.e = n2;
            this.c = string;
            return;
        }
        catch (RuntimeException runtimeException) {}
    }

    /*
     * Exception decompiling
     */
    public a a(Exception var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public String b() {
        String string;
        string = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("sdkVersion", (Object)this.b);
            jSONObject.put("eventType", (Object)this.c);
            jSONObject.put("eventTimestamp", this.d);
            jSONObject.put("severity", (Object)b.k((int)this.e));
            jSONObject.put("appId", (Object)this.f);
            jSONObject.put("osName", (Object)this.g);
            jSONObject.put("osVersion", this.h);
            jSONObject.put("deviceManufacturer", (Object)this.i);
            jSONObject.put("deviceModel", (Object)this.j);
            jSONObject.put("configVersion", (Object)string);
            jSONObject.put("otherDetails", (Object)this.k);
            jSONObject.put("exceptionDetails", (Object)this.l);
            string = Base64.encodeToString((byte[])jSONObject.toString().getBytes(), (int)0).replace((CharSequence)"\n", (CharSequence)string);
        }
        catch (RuntimeException | JSONException throwable) {}
        StringBuilder stringBuilder = c.a((String)"{\"Data\": \"", (String)string, (String)"\",\"PartitionKey\": \"");
        stringBuilder.append(this.d);
        stringBuilder.append("\"}");
        return stringBuilder.toString();
    }
}

