/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ds.g0
 *  e0.x
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  jr.f
 *  jr.h
 *  ma.e
 *  o0.g
 *  rr.q
 *  sr.m
 */
package b1;

import b1.a;
import b1.d;
import b1.f;
import ds.g0;
import e0.f0;
import e0.g;
import e0.x;
import jr.h;
import ma.e;
import rr.q;
import sr.m;

public final class g
extends m
implements q<o0.g, e0.g, Integer, o0.g> {
    public final /* synthetic */ d c;
    public final /* synthetic */ a d;

    public g(d d3, a a3) {
        this.c = d3;
        this.d = a3;
        super(3);
    }

    public Object r(Object object, Object object2, Object object3) {
        o0.g g3 = (o0.g)object;
        e0.g g5 = (e0.g)object2;
        ((Number)object3).intValue();
        e.f((Object)g3, (String)"$this$composed");
        g5.d(100476458);
        g5.d(-723524056);
        g5.d(-3687241);
        Object object4 = g5.e();
        Object object5 = g.a.b;
        if (object4 == object5) {
            x x3 = new x(f0.d((jr.f)h.b, g5));
            g5.E((Object)x3);
            object4 = x3;
        }
        g5.I();
        g0 g02 = ((x)object4).a;
        g5.I();
        d d3 = this.c;
        if (d3 == null) {
            g5.d(100476585);
            g5.d(-3687241);
            Object object6 = g5.e();
            if (object6 == object5) {
                object6 = new d();
                g5.E(object6);
            }
            g5.I();
            d3 = (d)object6;
        } else {
            g5.d(100476571);
        }
        g5.I();
        a a3 = this.d;
        g5.d(-3686095);
        boolean bl = g5.M(a3) | g5.M(d3) | g5.M((Object)g02);
        Object object7 = g5.e();
        if (bl || object7 == object5) {
            object7 = new f(d3, a3, g02);
            g5.E(object7);
        }
        g5.I();
        f f3 = (f)object7;
        g5.I();
        return f3;
    }
}

