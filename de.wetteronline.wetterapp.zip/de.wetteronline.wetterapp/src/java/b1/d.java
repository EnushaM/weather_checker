/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b1.d$a
 *  b1.d$b
 *  b1.d$c
 *  co.a
 *  ds.g0
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  jr.d
 *  kr.a
 *  rr.a
 *  x1.k
 */
package b1;

import b1.d;
import ds.g0;
import x1.k;

public final class d {
    public rr.a<? extends g0> a = new a(this);
    public g0 b;
    public b1.a c;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final Object a(long var1_1, long var3_2, jr.d<? super k> var5_3) {
        if (!(var5_3 instanceof b)) ** GOTO lbl-1000
        var6_4 = (b)var5_3;
        var15_5 = var6_4.g;
        if ((var15_5 & Integer.MIN_VALUE) != 0) {
            var6_4.g = var15_5 + Integer.MIN_VALUE;
        } else lbl-1000: // 2 sources:
        {
            var6_4 = new b(this, var5_3);
        }
        var7_6 = var6_4;
        var8_7 = var7_6.e;
        var9_8 = kr.a.b;
        var10_9 = var7_6.g;
        if (var10_9 != 0) {
            if (var10_9 != 1) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            co.a.L((Object)var8_7);
        } else {
            co.a.L((Object)var8_7);
            var11_10 = this.c;
            if (var11_10 == null) {
                var12_11 = k.c;
                return new k(var12_11);
            }
            var7_6.g = 1;
            var8_7 = var11_10.a(var1_1, var3_2, (jr.d<? super k>)var7_6);
            if (var8_7 == var9_8) {
                return var9_8;
            }
        }
        var12_11 = ((k)var8_7).a;
        return new k(var12_11);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final Object b(long var1_1, jr.d<? super k> var3_2) {
        if (!(var3_2 instanceof c)) ** GOTO lbl-1000
        var4_3 = (c)var3_2;
        var12_4 = var4_3.g;
        if ((var12_4 & Integer.MIN_VALUE) != 0) {
            var4_3.g = var12_4 + Integer.MIN_VALUE;
        } else lbl-1000: // 2 sources:
        {
            var4_3 = new c(this, var3_2);
        }
        var5_5 = var4_3.e;
        var6_6 = kr.a.b;
        var7_7 = var4_3.g;
        if (var7_7 != 0) {
            if (var7_7 != 1) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            co.a.L((Object)var5_5);
        } else {
            co.a.L((Object)var5_5);
            var8_8 = this.c;
            if (var8_8 == null) {
                var9_9 = k.c;
                return new k(var9_9);
            }
            var4_3.g = 1;
            var5_5 = var8_8.b(var1_1, (jr.d<? super k>)var4_3);
            if (var5_5 == var6_6) {
                return var6_6;
            }
        }
        var9_9 = ((k)var5_5).a;
        return new k(var9_9);
    }
}

