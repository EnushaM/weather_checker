/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b1.c$a
 *  java.lang.Object
 */
package b1;

import b1.c;

public final class c {
    public static final b1.a a = new a();
}

