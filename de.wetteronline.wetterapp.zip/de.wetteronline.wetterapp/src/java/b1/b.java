/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.runtime.collection.b
 *  b1.i
 *  ds.g0
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  ma.e
 *  o0.g
 *  rr.a
 */
package b1;

import b1.b;
import b1.c;
import b1.d;
import b1.e;
import b1.i;
import ds.g0;
import f1.a0;
import f1.f;
import f1.l;
import java.util.Objects;
import o0.g;

public final class b
extends f1.b<e> {
    public b1.a A;
    public e B;
    public final i C;
    public final androidx.compose.runtime.collection.b<b> D;

    public b(l l2, e e2) {
        super(l2, e2);
        b1.a a3 = this.A;
        if (a3 == null) {
            a3 = c.a;
        }
        this.C = new i(a3, e2.g());
        this.D = new androidx.compose.runtime.collection.b((Object[])new b[16], 0);
    }

    @Override
    public void H0() {
        l.super.H0();
        i i2 = this.C;
        b1.a a3 = ((e)this.x).g();
        Objects.requireNonNull((Object)i2);
        ma.e.f((Object)a3, (String)"<set-?>");
        i2.b = a3;
        ((e)this.x).V().c = this.A;
        this.V0();
    }

    @Override
    public g.c P0() {
        return (e)this.x;
    }

    @Override
    public void Q0(g.c c3) {
        e e2 = (e)c3;
        this.B = (e)this.x;
        this.x = e2;
    }

    public final rr.a<g0> S0() {
        return ((e)this.x).V().a;
    }

    public final void T0(androidx.compose.runtime.collection.b<f> b3) {
        int n3 = b3.d;
        if (n3 > 0) {
            int n4 = 0;
            Object[] arrobject = b3.b;
            do {
                f f2 = (f)arrobject[n4];
                b b4 = f2.C.g.n0();
                if (b4 != null) {
                    this.D.b((Object)b4);
                    continue;
                }
                this.T0(f2.n());
            } while (++n4 < n3);
        }
    }

    public final void U0(b1.a a3) {
        this.D.f();
        b b3 = this.w.n0();
        if (b3 != null) {
            this.D.b((Object)b3);
        } else {
            this.T0(this.f.n());
        }
        boolean bl = this.D.l();
        int n3 = 0;
        b b4 = bl ? (b)this.D.b[0] : null;
        androidx.compose.runtime.collection.b<b> b5 = this.D;
        int n4 = b5.d;
        if (n4 > 0) {
            Object[] arrobject = b5.b;
            do {
                b b6 = (b)arrobject[n3];
                b6.W0(a3);
                Object object = a3 != null ? new rr.a<g0>(this){
                    public final /* synthetic */ b c;
                    {
                        this.c = b3;
                        super(0);
                    }

                    public Object s() {
                        return (g0)this.c.S0().s();
                    }
                } : new rr.a<g0>(b4){
                    public final /* synthetic */ b c;
                    {
                        this.c = b3;
                        super(0);
                    }

                    public Object s() {
                        b b3 = this.c;
                        if (b3 == null) {
                            return null;
                        }
                        d d3 = ((e)b3.x).V();
                        if (d3 == null) {
                            return null;
                        }
                        return d3.b;
                    }
                };
                d d3 = ((e)b6.x).V();
                Objects.requireNonNull((Object)d3);
                d3.a = object;
            } while (++n3 < n4);
        }
    }

    public final void V0() {
        e e2 = this.B;
        boolean bl = e2 == null || e2.g() != ((e)this.x).g() || e2.V() != ((e)this.x).V();
        if (bl && this.t()) {
            b b3 = super.s0();
            i i2 = b3 == null ? null : b3.C;
            this.W0((b1.a)i2);
            rr.a<g0> a3 = b3 == null ? this.S0() : b3.S0();
            d d3 = ((e)this.x).V();
            Objects.requireNonNull((Object)d3);
            ma.e.f(a3, (String)"<set-?>");
            d3.a = a3;
            this.U0((b1.a)this.C);
            this.B = (e)this.x;
        }
    }

    public final void W0(b1.a a3) {
        ((e)this.x).V().c = a3;
        i i2 = this.C;
        b1.a a4 = a3 == null ? c.a : a3;
        Objects.requireNonNull((Object)i2);
        i2.a = a4;
        this.A = a3;
    }

    @Override
    public void e0() {
        l.super.e0();
        this.V0();
    }

    @Override
    public void g0() {
        l.super.g0();
        this.U0(this.A);
        this.B = null;
    }

    @Override
    public b n0() {
        return this;
    }

    @Override
    public b s0() {
        return this;
    }
}

