/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  o0.g
 */
package b1;

import b1.a;
import b1.d;
import o0.g;

public interface e
extends g.c {
    public d V();

    public a g();
}

