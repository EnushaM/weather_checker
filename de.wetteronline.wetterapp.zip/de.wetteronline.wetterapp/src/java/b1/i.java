/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  co.a
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  s0.c
 */
package b1;

import b1.i;
import jr.d;
import ma.e;
import s0.c;
import x1.k;

public final class i
implements b1.a {
    public b1.a a;
    public b1.a b;

    public i(b1.a a2, b1.a a3) {
        e.f(a3, "self");
        this.a = a2;
        this.b = a3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public Object a(long var1_1, long var3_2, d<? super k> var5_3) {
        if (!(var5_3 instanceof a)) ** GOTO lbl-1000
        var6_4 = var5_3;
        var29_5 = var6_4.j;
        if ((var29_5 & Integer.MIN_VALUE) != 0) {
            var6_4.j = var29_5 + Integer.MIN_VALUE;
        } else lbl-1000: // 2 sources:
        {
            var6_4 = new lr.c(this, var5_3){
                public Object e;
                public long f;
                public long g;
                public /* synthetic */ Object h;
                public final /* synthetic */ i i;
                public int j;
                {
                    this.i = i2;
                    super(d2);
                }

                public final Object h(Object object) {
                    this.h = object;
                    this.j = Integer.MIN_VALUE | this.j;
                    return this.i.a(0L, 0L, this);
                }
            };
        }
        var7_6 = var6_4.h;
        var8_7 = kr.a.b;
        var9_8 = var6_4.j;
        if (var9_8 != 0) {
            if (var9_8 != 1) {
                if (var9_8 != 2) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                var23_9 = var6_4.f;
                co.a.L((Object)var7_6);
                return new k(k.d(var23_9, ((k)var7_6).a));
            }
            var25_10 = var6_4.g;
            var27_11 = var6_4.f;
            var15_12 = (i)var6_4.e;
            co.a.L((Object)var7_6);
            var13_13 = var25_10;
            var11_14 = var27_11;
        } else {
            co.a.L((Object)var7_6);
            var10_15 = this.b;
            var6_4.e = this;
            var6_4.f = var11_14 = var1_1;
            var6_4.g = var13_13 = var3_2;
            var6_4.j = 1;
            var7_6 = var10_15.a(var1_1, var3_2, var6_4);
            if (var7_6 == var8_7) {
                return var8_7;
            }
            var15_12 = this;
        }
        var16_16 = ((k)var7_6).a;
        var18_17 = var15_12.a;
        var19_18 = k.d(var11_14, var16_16);
        var21_19 = k.c(var13_13, var16_16);
        var6_4.e = null;
        var6_4.f = var16_16;
        var6_4.j = 2;
        var7_6 = var18_17.a(var19_18, var21_19, var6_4);
        if (var7_6 == var8_7) {
            return var8_7;
        }
        var23_9 = var16_16;
        return new k(k.d(var23_9, ((k)var7_6).a));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public Object b(long var1_1, d<? super k> var3_2) {
        if (!(var3_2 instanceof b)) ** GOTO lbl-1000
        var4_3 = var3_2;
        var17_4 = var4_3.i;
        if ((var17_4 & Integer.MIN_VALUE) != 0) {
            var4_3.i = var17_4 + Integer.MIN_VALUE;
        } else lbl-1000: // 2 sources:
        {
            var4_3 = new lr.c(this, var3_2){
                public Object e;
                public long f;
                public /* synthetic */ Object g;
                public final /* synthetic */ i h;
                public int i;
                {
                    this.h = i2;
                    super(d2);
                }

                public final Object h(Object object) {
                    this.g = object;
                    this.i = Integer.MIN_VALUE | this.i;
                    return this.h.b(0L, this);
                }
            };
        }
        var5_5 = var4_3.g;
        var6_6 = kr.a.b;
        var7_7 = var4_3.i;
        if (var7_7 != 0) {
            if (var7_7 != 1) {
                if (var7_7 != 2) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                var15_8 = var4_3.f;
                co.a.L((Object)var5_5);
                return new k(k.d(var15_8, ((k)var5_5).a));
            }
            var1_1 = var4_3.f;
            var9_9 = (i)var4_3.e;
            co.a.L((Object)var5_5);
        } else {
            co.a.L((Object)var5_5);
            var8_10 = this.a;
            var4_3.e = this;
            var4_3.f = var1_1;
            var4_3.i = 1;
            var5_5 = var8_10.b(var1_1, var4_3);
            if (var5_5 == var6_6) {
                return var6_6;
            }
            var9_9 = this;
        }
        var10_11 = ((k)var5_5).a;
        var12_12 = var9_9.b;
        var13_13 = k.c(var1_1, var10_11);
        var4_3.e = null;
        var4_3.f = var10_11;
        var4_3.i = 2;
        var5_5 = var12_12.b(var13_13, var4_3);
        if (var5_5 == var6_6) {
            return var6_6;
        }
        var15_8 = var10_11;
        return new k(k.d(var15_8, ((k)var5_5).a));
    }

    @Override
    public long c(long l2, int n2) {
        long l3 = this.a.c(l2, n2);
        return c.g((long)l3, (long)this.b.c(c.f((long)l2, (long)l3), n2));
    }

    @Override
    public long d(long l2, long l3, int n2) {
        long l4 = this.b.d(l2, l3, n2);
        return c.g((long)l4, (long)this.a.d(c.g((long)l2, (long)l4), c.f((long)l3, (long)l4), n2));
    }
}

