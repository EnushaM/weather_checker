/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b1;

public final class h {
    public static final boolean a(int n2, int n3) {
        return n2 == n3;
    }
}

