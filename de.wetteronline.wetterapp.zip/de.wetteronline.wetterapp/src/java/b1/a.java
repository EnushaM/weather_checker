/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  jr.d
 *  x1.k
 */
package b1;

import jr.d;
import x1.k;

public interface a {
    public Object a(long var1, long var3, d<? super k> var5);

    public Object b(long var1, d<? super k> var3);

    public long c(long var1, int var3);

    public long d(long var1, long var3, int var5);
}

