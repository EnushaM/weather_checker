/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ds.g0
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  o0.g
 *  o0.g$c$a
 *  rr.l
 *  rr.p
 */
package b1;

import b1.a;
import b1.d;
import b1.e;
import ds.g0;
import o0.g;
import rr.l;
import rr.p;

public final class f
implements e {
    public final d b;
    public final a c;
    public final /* synthetic */ a d;
    public final /* synthetic */ g0 e;

    public f(d d3, a a3, g0 g02) {
        this.d = a3;
        this.e = g02;
        d3.b = g02;
        this.b = d3;
        this.c = a3;
    }

    public <R> R E(R r4, p<? super g.c, ? super R, ? extends R> p4) {
        ma.e.f((Object)this, (String)"this");
        ma.e.f(p4, (String)"operation");
        return (R)g.c.a.c((g.c)this, r4, p4);
    }

    @Override
    public d V() {
        return this.b;
    }

    @Override
    public a g() {
        return this.c;
    }

    public g r(g g3) {
        ma.e.f((Object)this, (String)"this");
        ma.e.f((Object)g3, (String)"other");
        return g.c.a.d((g.c)this, (g)g3);
    }

    public boolean y(l<? super g.c, Boolean> l2) {
        ma.e.f((Object)this, (String)"this");
        ma.e.f(l2, (String)"predicate");
        return g.c.a.a((g.c)this, l2);
    }

    public <R> R z(R r4, p<? super R, ? super g.c, ? extends R> p4) {
        ma.e.f((Object)this, (String)"this");
        ma.e.f(p4, (String)"operation");
        return (R)g.c.a.b((g.c)this, r4, p4);
    }
}

