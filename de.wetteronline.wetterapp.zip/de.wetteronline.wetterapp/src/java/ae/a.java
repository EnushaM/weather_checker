/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  vd.a
 *  vd.d
 *  vd.e
 *  vd.e$a
 */
package ae;

import vd.d;
import vd.e;

public final class a
implements e.a {
    public String a(d d2) {
        block6 : {
            String string;
            block3 : {
                block5 : {
                    block4 : {
                        block2 : {
                            if (!d2.c().equals((Object)vd.a.c)) break block2;
                            string = "/agcgw_all/CN";
                            break block3;
                        }
                        if (!d2.c().equals((Object)vd.a.e)) break block4;
                        string = "/agcgw_all/RU";
                        break block3;
                    }
                    if (!d2.c().equals((Object)vd.a.d)) break block5;
                    string = "/agcgw_all/DE";
                    break block3;
                }
                if (!d2.c().equals((Object)vd.a.f)) break block6;
                string = "/agcgw_all/SG";
            }
            return d2.b(string);
        }
        return null;
    }
}

