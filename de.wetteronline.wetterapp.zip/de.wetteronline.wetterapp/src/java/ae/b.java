/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  vd.a
 *  vd.d
 *  vd.e
 *  vd.e$a
 */
package ae;

import vd.a;
import vd.d;
import vd.e;

public final class b
implements e.a {
    public String a(d d2) {
        block6 : {
            String string;
            block3 : {
                block5 : {
                    block4 : {
                        block2 : {
                            if (!d2.c().equals((Object)a.c)) break block2;
                            string = "/agcgw_all/CN_back";
                            break block3;
                        }
                        if (!d2.c().equals((Object)a.e)) break block4;
                        string = "/agcgw_all/RU_back";
                        break block3;
                    }
                    if (!d2.c().equals((Object)a.d)) break block5;
                    string = "/agcgw_all/DE_back";
                    break block3;
                }
                if (!d2.c().equals((Object)a.f)) break block6;
                string = "/agcgw_all/SG_back";
            }
            return d2.b(string);
        }
        return null;
    }
}

