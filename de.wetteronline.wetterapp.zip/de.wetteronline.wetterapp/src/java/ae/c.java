/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  vd.c
 *  vd.d
 *  vd.e
 *  zd.a
 */
package ae;

import ae.a;
import ae.b;
import ae.d;
import android.content.Context;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import k5.s;
import vd.e;

public class c
extends vd.c {
    public static List<zd.a> d;
    public static final Object e;
    public static final Map<String, vd.c> f;
    public final vd.d a;
    public final s b;
    public final s c;

    public static {
        e = new Object();
        f = new HashMap();
    }

    public c(vd.d d2) {
        s s3;
        this.a = d2;
        this.b = new s(d);
        this.c = s3 = new s(null);
        if (d2 instanceof yd.b) {
            s3.d(((yd.b)d2).g);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static vd.c f(vd.d d2, boolean bl) {
        Object object;
        Object object2 = object = e;
        synchronized (object2) {
            Map<String, vd.c> map = f;
            String string = d2.a();
            vd.c c3 = (vd.c)((HashMap)map).get((Object)string);
            if (c3 == null || bl) {
                c3 = new c(d2);
                String string2 = d2.a();
                ((HashMap)map).put((Object)string2, (Object)c3);
            }
            return c3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void g(Context context, vd.d d2) {
        Class<c> class_ = c.class;
        synchronized (c.class) {
            Context context2 = context.getApplicationContext();
            if (context2 != null) {
                context = context2;
            }
            yd.a.a(context);
            if (d == null) {
                d = new d(context).a();
            }
            a a2 = new a();
            Map map = e.a;
            ((HashMap)map).put((Object)"/agcgw/url", (Object)a2);
            b b2 = new b();
            ((HashMap)map).put((Object)"/agcgw/backurl", (Object)b2);
            c.f(d2, true);
            // ** MonitorExit[var11_2] (shouldn't be in output)
            return;
        }
    }

    public Context a() {
        return this.a.getContext();
    }

    public vd.d c() {
        return this.a;
    }

    public <T> T d(Class<? super T> class_) {
        Object t3 = this.c.a(this, class_);
        if (t3 != null) {
            return t3;
        }
        return this.b.a(this, class_);
    }
}

