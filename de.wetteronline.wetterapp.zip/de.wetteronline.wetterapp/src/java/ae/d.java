/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ServiceInfo
 *  android.os.Bundle
 *  android.support.v4.media.b
 *  com.huawei.agconnect.core.ServiceDiscovery
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.InstantiationException
 *  java.lang.Integer
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Comparator
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  zd.a
 *  zd.b
 */
package ae;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import com.huawei.agconnect.core.ServiceDiscovery;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class d {
    public final Context a;

    public d(Context context) {
        this.a = context;
    }

    public List<zd.a> a() {
        Bundle bundle;
        ArrayList arrayList;
        block17 : {
            block16 : {
                arrayList = new ArrayList();
                PackageManager packageManager = this.a.getPackageManager();
                if (packageManager != null) {
                    ServiceInfo serviceInfo = packageManager.getServiceInfo(new ComponentName(this.a, ServiceDiscovery.class), 128);
                    if (serviceInfo == null) break block16;
                    try {
                        bundle = serviceInfo.metaData;
                        break block17;
                    }
                    catch (PackageManager.NameNotFoundException nameNotFoundException) {
                        nameNotFoundException.getLocalizedMessage();
                    }
                }
            }
            bundle = null;
        }
        if (bundle != null) {
            HashMap hashMap = new HashMap(10);
            for (String string : bundle.keySet()) {
                if (!"com.huawei.agconnect.core.ServiceRegistrar".equals((Object)bundle.getString(string))) continue;
                String[] arrstring = string.split(":");
                if (arrstring.length == 2) {
                    try {
                        hashMap.put((Object)arrstring[0], (Object)Integer.valueOf((String)arrstring[1]));
                    }
                    catch (NumberFormatException numberFormatException) {
                        numberFormatException.getMessage();
                    }
                    continue;
                }
                if (arrstring.length != 1) continue;
                hashMap.put((Object)arrstring[0], (Object)1000);
            }
            ArrayList arrayList2 = new ArrayList((Collection)hashMap.entrySet());
            Collections.sort((List)arrayList2, (Comparator)new b(null));
            Iterator iterator = arrayList2.iterator();
            while (iterator.hasNext()) {
                arrayList.add(((Map.Entry)iterator.next()).getKey());
            }
        }
        ArrayList arrayList3 = new ArrayList();
        for (String string : arrayList) {
            zd.b b2;
            block19 : {
                block18 : {
                    try {
                        Class class_ = Class.forName((String)string);
                        if (!zd.b.class.isAssignableFrom(class_)) {
                            class_.toString();
                            break block18;
                        }
                        b2 = (zd.b)Class.forName((String)string).newInstance();
                        break block19;
                    }
                    catch (IllegalAccessException illegalAccessException) {
                        illegalAccessException.getLocalizedMessage();
                    }
                    catch (InstantiationException instantiationException) {
                        instantiationException.getLocalizedMessage();
                    }
                    catch (ClassNotFoundException classNotFoundException) {
                        classNotFoundException.getMessage();
                    }
                }
                b2 = null;
            }
            if (b2 == null) continue;
            b2.initialize(this.a);
            List list = b2.getServices(this.a);
            if (list == null) continue;
            arrayList3.addAll((Collection)list);
        }
        android.support.v4.media.b.a((String)"services:").append((Object)arrayList3.size());
        return arrayList3;
    }

    public static class b
    implements Serializable,
    Comparator<Map.Entry<String, Integer>> {
        public b(a a3) {
        }

        public int compare(Object object, Object object2) {
            Map.Entry entry = (Map.Entry)object;
            Map.Entry entry2 = (Map.Entry)object2;
            return (Integer)entry.getValue() - (Integer)entry2.getValue();
        }
    }

}

