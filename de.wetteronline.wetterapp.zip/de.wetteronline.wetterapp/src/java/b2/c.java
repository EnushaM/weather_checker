/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b2.g
 *  java.lang.Object
 *  java.util.ArrayList
 *  z1.b
 *  z1.b$a
 *  z1.c
 *  z1.f
 */
package b2;

import b2.d;
import b2.e;
import b2.f;
import b2.g;
import java.util.ArrayList;
import z1.b;

public class c {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static void a(g var0, z1.c var1_1, ArrayList<f> var2_2, int var3_3) {
        var4_4 = var0;
        var5_5 = var1_1;
        var6_6 = var2_2;
        var7_7 = 2;
        if (var3_3 == 0) {
            var228_8 = var4_4.z0;
            var229_9 = var4_4.C0;
            var10_10 = var228_8;
            var11_11 = var229_9;
            var12_12 = 0;
        } else {
            var8_13 = var4_4.A0;
            var9_14 = var4_4.B0;
            var10_10 = var8_13;
            var11_11 = var9_14;
            var12_12 = var7_7;
        }
        var13_15 = 0;
        while (var13_15 < var10_10) {
            block103 : {
                block123 : {
                    block126 : {
                        block122 : {
                            block125 : {
                                block124 : {
                                    block120 : {
                                        block121 : {
                                            block108 : {
                                                block107 : {
                                                    block104 : {
                                                        block102 : {
                                                            block99 : {
                                                                block98 : {
                                                                    var14_16 = var11_11[var13_15];
                                                                    var15_17 = var14_16.t;
                                                                    var16_18 = 8;
                                                                    var17_19 = 1;
                                                                    if (!var15_17) break block98;
                                                                    var18_20 = var17_19;
                                                                    break block99;
                                                                }
                                                                var201_209 = var7_7 * var14_16.o;
                                                                var203_211 = var202_210 = var14_16.a;
                                                                var204_212 = false;
                                                                while (!var204_212) {
                                                                    block101 : {
                                                                        block100 : {
                                                                            var14_16.i = var17_19 + var14_16.i;
                                                                            var208_216 = var202_210.n0;
                                                                            var209_217 = var14_16.o;
                                                                            var208_216[var209_217] = null;
                                                                            var202_210.m0[var209_217] = null;
                                                                            if (var202_210.h0 != var16_18) {
                                                                                var14_16.l = var17_19 + var14_16.l;
                                                                                if (var202_210.k(var209_217) != 3) {
                                                                                    var225_232 = var14_16.m;
                                                                                    var226_233 = var14_16.o;
                                                                                    var227_234 = var226_233 == 0 ? var202_210.r() : (var226_233 == var17_19 ? var202_210.l() : 0);
                                                                                    var14_16.m = var225_232 + var227_234;
                                                                                }
                                                                                var14_16.m = var213_221 = var14_16.m + var202_210.Q[var201_209].d();
                                                                                var214_222 = var202_210.Q;
                                                                                var215_223 = var201_209 + 1;
                                                                                var14_16.m = var213_221 + var214_222[var215_223].d();
                                                                                var14_16.n = var216_224 = var14_16.n + var202_210.Q[var201_209].d();
                                                                                var14_16.n = var216_224 + var202_210.Q[var215_223].d();
                                                                                if (var14_16.b == null) {
                                                                                    var14_16.b = var202_210;
                                                                                }
                                                                                var14_16.d = var202_210;
                                                                                var217_225 = var202_210.T;
                                                                                var218_226 = var14_16.o;
                                                                                if (var217_225[var218_226] == 3 && ((var219_227 = var202_210.s)[var218_226] == 0 || var219_227[var218_226] == 3 || var219_227[var218_226] == var7_7)) {
                                                                                    var14_16.j = 1 + var14_16.j;
                                                                                    var220_228 = var202_210.l0;
                                                                                    var221_229 = var220_228[var218_226];
                                                                                    if (var221_229 > 0.0f) {
                                                                                        var14_16.k += var220_228[var218_226];
                                                                                    }
                                                                                    if (var222_230 = var202_210.h0 != 8 && var217_225[var218_226] == 3 && (var219_227[var218_226] == 0 || var219_227[var218_226] == 3)) {
                                                                                        if (var221_229 < 0.0f) {
                                                                                            var14_16.q = true;
                                                                                        } else {
                                                                                            var14_16.r = true;
                                                                                        }
                                                                                        if (var14_16.h == null) {
                                                                                            var14_16.h = new ArrayList();
                                                                                        }
                                                                                        var14_16.h.add((Object)var202_210);
                                                                                    }
                                                                                    if (var14_16.f == null) {
                                                                                        var14_16.f = var202_210;
                                                                                    }
                                                                                    if ((var223_231 = var14_16.g) != null) {
                                                                                        var223_231.m0[var14_16.o] = var202_210;
                                                                                    }
                                                                                    var14_16.g = var202_210;
                                                                                }
                                                                            }
                                                                            if (var203_211 != var202_210) {
                                                                                var203_211.n0[var14_16.o] = var202_210;
                                                                            }
                                                                            if ((var210_218 = var202_210.Q[var201_209 + 1].f) == null) break block100;
                                                                            var211_219 = var210_218.d;
                                                                            var212_220 = var211_219.Q;
                                                                            if (var212_220[var201_209].f != null && var212_220[var201_209].f.d == var202_210) break block101;
                                                                        }
                                                                        var211_219 = null;
                                                                    }
                                                                    if (var211_219 == null) {
                                                                        var211_219 = var202_210;
                                                                        var204_212 = true;
                                                                    }
                                                                    var203_211 = var202_210;
                                                                    var17_19 = 1;
                                                                    var16_18 = 8;
                                                                    var7_7 = 2;
                                                                    var202_210 = var211_219;
                                                                }
                                                                var205_213 = var14_16.b;
                                                                if (var205_213 != null) {
                                                                    var14_16.m -= var205_213.Q[var201_209].d();
                                                                }
                                                                if ((var206_214 = var14_16.d) != null) {
                                                                    var14_16.m -= var206_214.Q[var201_209 + 1].d();
                                                                }
                                                                var14_16.c = var202_210;
                                                                var14_16.e = var14_16.o == 0 && var14_16.p != false ? var202_210 : var14_16.a;
                                                                var207_215 = var14_16.r != false && var14_16.q != false;
                                                                var14_16.s = var207_215;
                                                                var18_20 = 1;
                                                            }
                                                            var14_16.t = var18_20;
                                                            if (var6_6 == null || var6_6.contains((Object)var14_16.a)) break block102;
                                                            var41_43 = var13_15;
                                                            var52_54 = var5_5;
                                                            var35_37 = var10_10;
                                                            var36_38 = var11_11;
                                                            break block103;
                                                        }
                                                        var19_21 = var14_16.a;
                                                        var20_22 = var14_16.c;
                                                        var21_23 = var14_16.b;
                                                        var22_24 = var14_16.d;
                                                        var23_25 = var14_16.e;
                                                        var24_26 = var14_16.k;
                                                        var25_27 = var4_4.T[var3_3] == 2;
                                                        if (var3_3 != 0) break block104;
                                                        var198_206 = var23_25.j0;
                                                        var199_207 = var198_206 == 0;
                                                        if (var198_206 == 1) {
                                                            var29_31 = true;
                                                            var200_208 = 2;
                                                        } else {
                                                            var200_208 = 2;
                                                            var29_31 = false;
                                                        }
                                                        var27_29 = var199_207;
                                                        if (var198_206 != var200_208) ** GOTO lbl-1000
                                                        ** GOTO lbl-1000
                                                    }
                                                    var26_28 = var23_25.k0;
                                                    var27_29 = var26_28 == 0;
                                                    if (var26_28 == 1) {
                                                        var28_30 = 2;
                                                        var29_31 = true;
                                                    } else {
                                                        var28_30 = 2;
                                                        var29_31 = false;
                                                    }
                                                    if (var26_28 == var28_30) lbl-1000: // 2 sources:
                                                    {
                                                        var30_32 = true;
                                                    } else lbl-1000: // 2 sources:
                                                    {
                                                        var30_32 = false;
                                                    }
                                                    var31_33 = var19_21;
                                                    var32_34 = false;
                                                    while (!var32_34) {
                                                        block106 : {
                                                            block105 : {
                                                                var179_188 = var31_33.Q[var12_12];
                                                                var180_189 = var30_32 != false ? 1 : 4;
                                                                var181_190 = var179_188.d();
                                                                var182_191 = var13_15;
                                                                var183_192 = var31_33.T[var3_3] == 3 && var31_33.s[var3_3] == 0;
                                                                var184_193 = var179_188.f;
                                                                if (var184_193 != null && var31_33 != var19_21) {
                                                                    var181_190 += var184_193.d();
                                                                }
                                                                var185_194 = var181_190;
                                                                if (var30_32 && var31_33 != var19_21 && var31_33 != var21_23) {
                                                                    var186_195 = var10_10;
                                                                    var180_189 = 8;
                                                                } else {
                                                                    var186_195 = var10_10;
                                                                }
                                                                var187_196 = var179_188.f;
                                                                if (var187_196 != null) {
                                                                    if (var31_33 == var21_23) {
                                                                        var189_198 = var11_11;
                                                                        var196_204 = var179_188.i;
                                                                        var197_205 = var187_196.i;
                                                                        var188_197 = var23_25;
                                                                        var5_5.f(var196_204, var197_205, var185_194, 6);
                                                                    } else {
                                                                        var188_197 = var23_25;
                                                                        var189_198 = var11_11;
                                                                        var5_5.f(var179_188.i, var187_196.i, var185_194, 8);
                                                                    }
                                                                    if (var183_192 && !var30_32) {
                                                                        var180_189 = 5;
                                                                    }
                                                                    var194_203 = var31_33 == var21_23 && var30_32 != false && var31_33.S[var3_3] != false ? 5 : var180_189;
                                                                    var5_5.d(var179_188.i, var179_188.f.i, var185_194, var194_203);
                                                                } else {
                                                                    var188_197 = var23_25;
                                                                    var189_198 = var11_11;
                                                                }
                                                                if (var25_27) {
                                                                    if (var31_33.h0 != 8 && var31_33.T[var3_3] == 3) {
                                                                        var193_202 = var31_33.Q;
                                                                        var5_5.f(var193_202[var12_12 + 1].i, var193_202[var12_12].i, 0, 5);
                                                                    }
                                                                    var5_5.f(var31_33.Q[var12_12].i, var4_4.Q[var12_12].i, 0, 8);
                                                                }
                                                                if ((var190_199 = var31_33.Q[var12_12 + 1].f) == null) break block105;
                                                                var191_200 = var190_199.d;
                                                                var192_201 = var191_200.Q;
                                                                if (var192_201[var12_12].f != null && var192_201[var12_12].f.d == var31_33) break block106;
                                                            }
                                                            var191_200 = null;
                                                        }
                                                        if (var191_200 != null) {
                                                            var31_33 = var191_200;
                                                        } else {
                                                            var32_34 = true;
                                                        }
                                                        var10_10 = var186_195;
                                                        var13_15 = var182_191;
                                                        var11_11 = var189_198;
                                                        var23_25 = var188_197;
                                                    }
                                                    var33_35 = var23_25;
                                                    var34_36 = var13_15;
                                                    var35_37 = var10_10;
                                                    var36_38 = var11_11;
                                                    if (var22_24 == null) break block107;
                                                    var171_182 = var20_22.Q;
                                                    var172_183 = var12_12 + 1;
                                                    if (var171_182[var172_183].f == null) break block107;
                                                    var173_184 = var22_24.Q[var172_183];
                                                    var174_185 = var22_24.T[var3_3] == 3 && var22_24.s[var3_3] == 0;
                                                    if (!var174_185 || var30_32) ** GOTO lbl-1000
                                                    var177_187 = var173_184.f;
                                                    if (var177_187.d == var4_4) {
                                                        var5_5.d(var173_184.i, var177_187.i, -var173_184.d(), 5);
                                                    } else if (var30_32) {
                                                        var175_186 = var173_184.f;
                                                        if (var175_186.d == var4_4) {
                                                            var5_5.d(var173_184.i, var175_186.i, -var173_184.d(), 4);
                                                        }
                                                    }
                                                    var5_5.g(var173_184.i, var20_22.Q[var172_183].f.i, -var173_184.d(), 6);
                                                }
                                                if (var25_27) {
                                                    var167_178 = var4_4.Q;
                                                    var168_179 = var12_12 + 1;
                                                    var169_180 = var167_178[var168_179].i;
                                                    var170_181 = var20_22.Q;
                                                    var5_5.f(var169_180, var170_181[var168_179].i, var170_181[var168_179].d(), 8);
                                                }
                                                if ((var37_39 = var14_16.h) == null || (var139_152 = var37_39.size()) <= 1) break block108;
                                                var140_153 = var14_16.q != false && var14_16.s == false ? (float)var14_16.j : var24_26;
                                                var141_154 = null;
                                                var142_155 = 0.0f;
                                                for (var143_156 = 0; var143_156 < var139_152; ++var143_156) {
                                                    block114 : {
                                                        block119 : {
                                                            block115 : {
                                                                block118 : {
                                                                    block116 : {
                                                                        block117 : {
                                                                            block113 : {
                                                                                block111 : {
                                                                                    block112 : {
                                                                                        block109 : {
                                                                                            block110 : {
                                                                                                var144_157 = (f)var37_39.get(var143_156);
                                                                                                var145_158 = var144_157.l0[var3_3];
                                                                                                if (!(var145_158 < 0.0f)) break block109;
                                                                                                if (!var14_16.s) break block110;
                                                                                                var163_175 = var144_157.Q;
                                                                                                var164_176 = var163_175[var12_12 + 1].i;
                                                                                                var165_177 = var163_175[var12_12].i;
                                                                                                var146_159 = var37_39;
                                                                                                var5_5.d(var164_176, var165_177, 0, 4);
                                                                                                break block111;
                                                                                            }
                                                                                            var146_159 = var37_39;
                                                                                            var145_158 = 1.0f;
                                                                                            break block112;
                                                                                        }
                                                                                        var146_159 = var37_39;
                                                                                    }
                                                                                    var147_160 = var145_158 FCMPL 0.0f;
                                                                                    if (var147_160 != false) break block113;
                                                                                    var161_174 = var144_157.Q;
                                                                                    var5_5.d(var161_174[var12_12 + 1].i, var161_174[var12_12].i, 0, 8);
                                                                                }
                                                                                var148_161 = var14_16;
                                                                                var149_162 = var139_152;
                                                                                var151_164 = var140_153;
                                                                                break block114;
                                                                            }
                                                                            if (var141_154 == null) break block115;
                                                                            var152_165 = var141_154.Q;
                                                                            var153_166 = var152_165[var12_12].i;
                                                                            var154_167 = var12_12 + 1;
                                                                            var155_168 = var152_165[var154_167].i;
                                                                            var156_169 = var144_157.Q;
                                                                            var149_162 = var139_152;
                                                                            var157_170 = var156_169[var12_12].i;
                                                                            var158_171 = var156_169[var154_167].i;
                                                                            var150_163 = var144_157;
                                                                            var159_172 = var1_1.m();
                                                                            var148_161 = var14_16;
                                                                            var159_172.b = 0.0f;
                                                                            if (var140_153 == 0.0f || var142_155 == var145_158) break block116;
                                                                            if (var142_155 != 0.0f) break block117;
                                                                            var159_172.d.f(var153_166, 1.0f);
                                                                            var159_172.d.f(var155_168, -1.0f);
                                                                            ** GOTO lbl280
                                                                        }
                                                                        if (var147_160 == false) {
                                                                            var159_172.d.f(var157_170, 1.0f);
                                                                            var159_172.d.f(var158_171, -1.0f);
lbl280: // 2 sources:
                                                                            var151_164 = var140_153;
                                                                        } else {
                                                                            var160_173 = var142_155 / var140_153 / (var145_158 / var140_153);
                                                                            var151_164 = var140_153;
                                                                            var159_172.d.f(var153_166, 1.0f);
                                                                            var159_172.d.f(var155_168, -1.0f);
                                                                            var159_172.d.f(var158_171, var160_173);
                                                                            var159_172.d.f(var157_170, -var160_173);
                                                                        }
                                                                        break block118;
                                                                    }
                                                                    var151_164 = var140_153;
                                                                    var159_172.d.f(var153_166, 1.0f);
                                                                    var159_172.d.f(var155_168, -1.0f);
                                                                    var159_172.d.f(var158_171, 1.0f);
                                                                    var159_172.d.f(var157_170, -1.0f);
                                                                }
                                                                var5_5.c(var159_172);
                                                                break block119;
                                                            }
                                                            var148_161 = var14_16;
                                                            var149_162 = var139_152;
                                                            var150_163 = var144_157;
                                                            var151_164 = var140_153;
                                                        }
                                                        var142_155 = var145_158;
                                                        var141_154 = var150_163;
                                                    }
                                                    var37_39 = var146_159;
                                                    var140_153 = var151_164;
                                                    var139_152 = var149_162;
                                                    var14_16 = var148_161;
                                                }
                                            }
                                            var38_40 = var14_16;
                                            if (var21_23 == null || var21_23 != var22_24 && !var30_32) break block120;
                                            var124_137 = var19_21.Q[var12_12];
                                            var125_138 = var20_22.Q;
                                            var126_139 = var12_12 + 1;
                                            var127_140 = var125_138[var126_139];
                                            var128_141 = var124_137.f;
                                            var129_142 = var128_141 != null ? var128_141.i : null;
                                            var130_143 = var127_140.f;
                                            var131_144 = var130_143 != null ? var130_143.i : null;
                                            var132_145 = var21_23.Q[var12_12];
                                            if (var22_24 != null) {
                                                var127_140 = var22_24.Q[var126_139];
                                            }
                                            if (var129_142 == null || var131_144 == null) break block121;
                                            var133_146 = var3_3 == 0 ? var33_35.e0 : var33_35.f0;
                                            var134_147 = var133_146;
                                            var135_148 = var132_145.d();
                                            var136_149 = var127_140.d();
                                            var137_150 = var132_145.i;
                                            var138_151 = var127_140.i;
                                            var39_41 = var22_24;
                                            var40_42 = var21_23;
                                            var41_43 = var34_36;
                                            var1_1.b(var137_150, var129_142, var135_148, var134_147, var131_144, var138_151, var136_149, 7);
                                            break block122;
                                        }
                                        var39_41 = var22_24;
                                        var40_42 = var21_23;
                                        var41_43 = var34_36;
                                        var52_54 = var5_5;
                                        break block123;
                                    }
                                    var39_41 = var22_24;
                                    var40_42 = var21_23;
                                    var41_43 = var34_36;
                                    if (!var27_29 || var40_42 == null) break block124;
                                    var96_100 = var38_40.j;
                                    var97_101 = var96_100 > 0 && var38_40.i == var96_100;
                                    var99_103 = var98_102 = var40_42;
                                    break block125;
                                }
                                if (!var29_31 || var40_42 == null) break block122;
                                var42_44 = var38_40.j;
                                var43_45 = var42_44 > 0 && var38_40.i == var42_44;
                                var45_47 = var44_46 = var40_42;
                                break block126;
                            }
                            while (var99_103 != null) {
                                block97 : {
                                    var100_104 = var99_103.n0[var3_3];
                                    while (var100_104 != null) {
                                        var123_136 = var100_104.h0;
                                        var101_105 = 8;
                                        if (var123_136 == var101_105) {
                                            var100_104 = var100_104.n0[var3_3];
                                            continue;
                                        }
                                        break block97;
                                    }
                                    var101_105 = 8;
                                }
                                if (var100_104 == null && var99_103 != var39_41) {
                                    var116_129 = var101_105;
                                    var114_127 = var100_104;
                                    var115_128 = var98_102;
                                } else {
                                    var102_106 = var99_103.Q[var12_12];
                                    var103_107 = var102_106.i;
                                    var104_108 = var102_106.f;
                                    if (var104_108 != null) {
                                        var105_110 = var104_108.i;
                                    } else {
                                        var105_111 = null;
                                    }
                                    if (var98_102 != var99_103) {
                                        var105_113 = var98_102.Q[var12_12 + 1].i;
                                    } else if (var99_103 == var40_42) {
                                        var122_135 = var19_21.Q;
                                        if (var122_135[var12_12].f != null) {
                                            var105_114 = var122_135[var12_12].f.i;
                                        } else {
                                            var105_115 = null;
                                        }
                                    }
                                    var106_116 = var102_106.d();
                                    var107_117 = var99_103.Q;
                                    var108_118 = var12_12 + 1;
                                    var109_119 = var107_117[var108_118].d();
                                    if (var100_104 != null) {
                                        var110_120 = var100_104.Q[var12_12];
                                        var111_122 = var110_120.i;
                                    } else {
                                        var110_120 = var20_22.Q[var108_118].f;
                                        if (var110_120 != null) {
                                            var111_123 = var110_120.i;
                                        } else {
                                            var111_124 = null;
                                        }
                                    }
                                    var112_125 = var99_103.Q[var108_118].i;
                                    if (var110_120 != null) {
                                        var109_119 += var110_120.d();
                                    }
                                    var113_126 = var106_116 + var98_102.Q[var108_118].d();
                                    if (var103_107 != null && var105_109 != null && var111_121 != null && var112_125 != null) {
                                        if (var99_103 == var40_42) {
                                            var113_126 = var40_42.Q[var12_12].d();
                                        }
                                        var117_130 = var99_103 == var39_41 ? var39_41.Q[var108_118].d() : var109_119;
                                        var118_131 = var97_101 != false ? 8 : 5;
                                        var119_132 = var113_126;
                                        var120_133 = var111_121;
                                        var114_127 = var100_104;
                                        var116_129 = 8;
                                        var121_134 = var117_130;
                                        var115_128 = var98_102;
                                        var1_1.b(var103_107, (z1.f)var105_109, var119_132, 0.5f, (z1.f)var120_133, var112_125, var121_134, var118_131);
                                    } else {
                                        var114_127 = var100_104;
                                        var115_128 = var98_102;
                                        var116_129 = 8;
                                    }
                                }
                                var98_102 = var99_103.h0 != var116_129 ? var99_103 : var115_128;
                                var99_103 = var114_127;
                            }
                        }
                        var52_54 = var1_1;
                        break block123;
                    }
                    while (var44_46 != null) {
                        var75_75 = var44_46.n0[var3_3];
                        while (var75_75 != null && var75_75.h0 == 8) {
                            var75_75 = var75_75.n0[var3_3];
                        }
                        if (var44_46 != var40_42 && var44_46 != var39_41 && var75_75 != null) {
                            var77_77 = var75_75 == var39_41 ? null : var75_75;
                            var78_78 = var44_46.Q[var12_12];
                            var79_79 = var78_78.i;
                            var80_80 = var45_47.Q;
                            var81_81 = var12_12 + 1;
                            var82_82 = var80_80[var81_81].i;
                            var83_83 = var78_78.d();
                            var84_84 = var44_46.Q[var81_81].d();
                            if (var77_77 != null) {
                                var85_85 = var77_77.Q[var12_12];
                                var86_87 = var85_85.i;
                                var95_99 = var85_85.f;
                                var87_91 = var95_99 != null ? var95_99.i : null;
                            } else {
                                var85_85 = var39_41.Q[var12_12];
                                if (var85_85 != null) {
                                    var86_88 = var85_85.i;
                                } else {
                                    var86_89 = null;
                                }
                                var87_91 = var44_46.Q[var81_81].i;
                            }
                            var88_92 = var85_85 != null ? var84_84 + var85_85.d() : var84_84;
                            var89_93 = var83_83 + var45_47.Q[var81_81].d();
                            var90_94 = var43_45 != false ? 8 : 4;
                            if (var79_79 != null && var82_82 != null && var86_86 != null && var87_91 != null) {
                                var92_96 = var86_86;
                                var93_97 = var87_91;
                                var94_98 = var88_92;
                                var91_95 = var77_77;
                                var1_1.b(var79_79, var82_82, var89_93, 0.5f, (z1.f)var92_96, var93_97, var94_98, var90_94);
                            } else {
                                var91_95 = var77_77;
                            }
                            var76_76 = var91_95;
                        } else {
                            var76_76 = var75_75;
                        }
                        if (var44_46.h0 != 8) {
                            var45_47 = var44_46;
                        }
                        var44_46 = var76_76;
                    }
                    var46_48 = var40_42.Q[var12_12];
                    var47_49 = var19_21.Q[var12_12].f;
                    var48_50 = var39_41.Q;
                    var49_51 = var12_12 + 1;
                    var50_52 = var48_50[var49_51];
                    var51_53 = var20_22.Q[var49_51].f;
                    if (var47_49 != null) {
                        if (var40_42 != var39_41) {
                            var71_72 = var46_48.i;
                            var72_73 = var47_49.i;
                            var73_74 = var46_48.d();
                            var52_54 = var1_1;
                            var53_55 = 5;
                            var52_54.d(var71_72, var72_73, var73_74, var53_55);
                        } else {
                            var52_54 = var1_1;
                            var53_55 = 5;
                            if (var51_53 != null) {
                                var1_1.b(var46_48.i, var47_49.i, var46_48.d(), 0.5f, var50_52.i, var51_53.i, var50_52.d(), 5);
                            }
                        }
                    } else {
                        var52_54 = var1_1;
                        var53_55 = 5;
                    }
                    if (var51_53 != null && var40_42 != var39_41) {
                        var52_54.d(var50_52.i, var51_53.i, -var50_52.d(), var53_55);
                    }
                }
                if ((var27_29 || var29_31) && var40_42 != null && var40_42 != var39_41) {
                    var54_56 = var40_42.Q;
                    var55_57 = var54_56[var12_12];
                    var56_58 = var39_41 == null ? var40_42 : var39_41;
                    var57_59 = var56_58.Q;
                    var58_60 = var12_12 + 1;
                    var59_61 = var57_59[var58_60];
                    var60_62 = var55_57.f;
                    var61_63 = var60_62 != null ? var60_62.i : null;
                    var62_64 = var59_61.f;
                    var63_65 = var62_64 != null ? var62_64.i : null;
                    if (var20_22 != var56_58) {
                        var68_70 = var20_22.Q[var58_60].f;
                        var69_71 = null;
                        if (var68_70 != null) {
                            var69_71 = var68_70.i;
                        }
                        var63_65 = var69_71;
                    }
                    if (var40_42 == var56_58) {
                        var55_57 = var54_56[var12_12];
                        var59_61 = var54_56[var58_60];
                    }
                    if (var61_63 != null && var63_65 != null) {
                        var64_66 = var55_57.d();
                        var65_67 = var56_58.Q[var58_60].d();
                        var66_68 = var55_57.i;
                        var67_69 = var59_61.i;
                        var1_1.b(var66_68, var61_63, var64_66, 0.5f, var63_65, var67_69, var65_67, 5);
                    }
                }
            }
            var13_15 = var41_43 + 1;
            var4_4 = var0;
            var6_6 = var2_2;
            var5_5 = var52_54;
            var10_10 = var35_37;
            var11_11 = var36_38;
            var7_7 = 2;
        }
    }
}

