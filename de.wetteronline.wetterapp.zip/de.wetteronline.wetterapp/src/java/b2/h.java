/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 *  z1.b$a
 *  z1.c
 *  z1.f
 */
package b2;

import b2.e;
import b2.f;
import b2.g;
import java.util.ArrayList;
import z1.b;
import z1.c;

public class h
extends f {
    public float q0 = -1.0f;
    public int r0 = -1;
    public int s0 = -1;
    public e t0 = this.J;
    public int u0 = 0;
    public boolean v0;

    public h() {
        this.R.clear();
        this.R.add((Object)this.t0);
        int n2 = this.Q.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            this.Q[i2] = this.t0;
        }
    }

    @Override
    public boolean A() {
        return this.v0;
    }

    @Override
    public boolean B() {
        return this.v0;
    }

    @Override
    public void P(c c3, boolean bl) {
        if (this.U == null) {
            return;
        }
        int n2 = c3.o((Object)this.t0);
        if (this.u0 == 1) {
            this.Z = n2;
            this.a0 = 0;
            this.I(this.U.l());
            this.N(0);
            return;
        }
        this.Z = 0;
        this.a0 = n2;
        this.N(this.U.r());
        this.I(0);
    }

    public void Q(int n2) {
        e e2 = this.t0;
        e2.b = n2;
        e2.c = true;
        this.v0 = true;
    }

    public void R(int n2) {
        if (this.u0 == n2) {
            return;
        }
        this.u0 = n2;
        this.R.clear();
        this.t0 = this.u0 == 1 ? this.I : this.J;
        this.R.add((Object)this.t0);
        int n3 = this.Q.length;
        for (int i2 = 0; i2 < n3; ++i2) {
            this.Q[i2] = this.t0;
        }
    }

    @Override
    public void d(c c3, boolean bl) {
        g g3 = (g)this.U;
        if (g3 == null) {
            return;
        }
        e e2 = g3.i(e.a.b);
        e e3 = g3.i(e.a.d);
        f f2 = this.U;
        int n2 = 1;
        int n3 = f2 != null && f2.T[0] == 2 ? n2 : 0;
        if (this.u0 == 0) {
            e2 = g3.i(e.a.c);
            e3 = g3.i(e.a.e);
            f f3 = this.U;
            if (f3 == null || f3.T[n2] != 2) {
                n2 = 0;
            }
            n3 = n2;
        }
        if (this.v0) {
            e e5 = this.t0;
            if (e5.c) {
                z1.f f4 = c3.l((Object)e5);
                c3.e(f4, this.t0.c());
                if (this.r0 != -1) {
                    if (n3 != 0) {
                        c3.f(c3.l((Object)e3), f4, 0, 5);
                    }
                } else if (this.s0 != -1 && n3 != 0) {
                    z1.f f5 = c3.l((Object)e3);
                    c3.f(f4, c3.l((Object)e2), 0, 5);
                    c3.f(f5, f4, 0, 5);
                }
                this.v0 = false;
                return;
            }
        }
        if (this.r0 != -1) {
            z1.f f6 = c3.l((Object)this.t0);
            c3.d(f6, c3.l((Object)e2), this.r0, 8);
            if (n3 != 0) {
                c3.f(c3.l((Object)e3), f6, 0, 5);
                return;
            }
        } else if (this.s0 != -1) {
            z1.f f7 = c3.l((Object)this.t0);
            z1.f f8 = c3.l((Object)e3);
            c3.d(f7, f8, -this.s0, 8);
            if (n3 != 0) {
                c3.f(f7, c3.l((Object)e2), 0, 5);
                c3.f(f8, f7, 0, 5);
                return;
            }
        } else if (this.q0 != -1.0f) {
            z1.f f9 = c3.l((Object)this.t0);
            z1.f f10 = c3.l((Object)e3);
            float f11 = this.q0;
            b b3 = c3.m();
            b3.d.f(f9, -1.0f);
            b3.d.f(f10, f11);
            c3.c(b3);
        }
    }

    @Override
    public boolean e() {
        return true;
    }

    @Override
    public e i(e.a a2) {
        block7 : {
            block5 : {
                block6 : {
                    int n2 = a2.ordinal();
                    if (n2 == 1) break block5;
                    if (n2 == 2) break block6;
                    if (n2 == 3) break block5;
                    if (n2 != 4) break block7;
                }
                if (this.u0 == 0) {
                    return this.t0;
                }
                break block7;
            }
            if (this.u0 == 1) {
                return this.t0;
            }
        }
        return null;
    }
}

