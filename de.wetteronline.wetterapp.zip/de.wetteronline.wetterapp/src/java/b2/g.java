/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a4.g
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  androidx.constraintlayout.widget.ConstraintLayout$a
 *  b2.h
 *  b2.j
 *  b2.m
 *  c2.b
 *  c2.b$a
 *  c2.b$b
 *  c2.e
 *  c2.f
 *  c2.h
 *  c2.i
 *  c2.o
 *  c2.p
 *  java.io.PrintStream
 *  java.lang.Exception
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.ref.WeakReference
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Objects
 *  z1.c
 *  z1.f
 */
package b2;

import androidx.constraintlayout.widget.ConstraintLayout;
import b2.b;
import b2.c;
import b2.d;
import b2.e;
import b2.f;
import b2.h;
import b2.j;
import b2.k;
import b2.l;
import b2.m;
import c2.b;
import c2.i;
import c2.n;
import c2.o;
import c2.p;
import java.io.PrintStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;

public class g
extends m {
    public int A0 = 0;
    public d[] B0 = new d[4];
    public d[] C0 = new d[4];
    public int D0 = 257;
    public boolean E0 = false;
    public boolean F0 = false;
    public WeakReference<e> G0 = null;
    public WeakReference<e> H0 = null;
    public WeakReference<e> I0 = null;
    public WeakReference<e> J0 = null;
    public HashSet<f> K0 = new HashSet();
    public b.a L0 = new b.a();
    public c2.b r0 = new c2.b(this);
    public c2.e s0 = new c2.e(this);
    public int t0;
    public b.b u0 = null;
    public boolean v0 = false;
    public z1.c w0 = new z1.c();
    public int x0;
    public int y0;
    public int z0 = 0;

    public static boolean Z(f f2, b.b b2, b.a a2, int n2) {
        if (b2 == null) {
            return false;
        }
        if (f2.h0 != 8 && !(f2 instanceof h) && !(f2 instanceof b)) {
            a2.a = f2.m();
            a2.b = f2.q();
            a2.c = f2.r();
            a2.d = f2.l();
            a2.i = false;
            a2.j = n2;
            boolean bl = a2.a == 3;
            boolean bl2 = a2.b == 3;
            boolean bl3 = bl && f2.X > 0.0f;
            boolean bl4 = bl2 && f2.X > 0.0f;
            if (bl && f2.u(0) && f2.q == 0 && !bl3) {
                a2.a = 2;
                if (bl2 && f2.r == 0) {
                    a2.a = 1;
                }
                bl = false;
            }
            if (bl2 && f2.u(1) && f2.r == 0 && !bl4) {
                a2.b = 2;
                if (bl && f2.q == 0) {
                    a2.b = 1;
                }
                bl2 = false;
            }
            if (f2.A()) {
                a2.a = 1;
                bl = false;
            }
            if (f2.B()) {
                a2.b = 1;
                bl2 = false;
            }
            if (bl3) {
                if (f2.s[0] == 4) {
                    a2.a = 1;
                } else if (!bl2) {
                    int n3;
                    if (a2.b == 1) {
                        n3 = a2.d;
                    } else {
                        a2.a = 2;
                        ((ConstraintLayout.a)b2).b(f2, a2);
                        n3 = a2.f;
                    }
                    a2.a = 1;
                    a2.c = (int)(f2.X * (float)n3);
                }
            }
            if (bl4) {
                if (f2.s[1] == 4) {
                    a2.b = 1;
                } else if (!bl) {
                    int n4;
                    if (a2.a == 1) {
                        n4 = a2.c;
                    } else {
                        a2.b = 2;
                        ((ConstraintLayout.a)b2).b(f2, a2);
                        n4 = a2.e;
                    }
                    a2.b = 1;
                    a2.d = f2.Y == -1 ? (int)((float)n4 / f2.X) : (int)(f2.X * (float)n4);
                }
            }
            ((ConstraintLayout.a)b2).b(f2, a2);
            f2.N(a2.e);
            f2.I(a2.f);
            f2.D = a2.h;
            f2.F(a2.g);
            a2.j = 0;
            return a2.i;
        }
        a2.e = 0;
        a2.f = 0;
        return false;
    }

    public void C() {
        this.w0.u();
        this.x0 = 0;
        this.y0 = 0;
        super.C();
    }

    public void O(boolean bl, boolean bl2) {
        f.super.O(bl, bl2);
        int n2 = this.q0.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            ((f)this.q0.get(i2)).O(bl, bl2);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void Q() {
        block137 : {
            block127 : {
                block128 : {
                    block136 : {
                        block135 : {
                            block133 : {
                                block134 : {
                                    block132 : {
                                        block131 : {
                                            block129 : {
                                                block130 : {
                                                    block126 : {
                                                        this.Z = 0;
                                                        this.a0 = 0;
                                                        this.E0 = false;
                                                        this.F0 = false;
                                                        var1_1 = this.q0.size();
                                                        var2_2 = Math.max((int)0, (int)this.r());
                                                        var3_3 = Math.max((int)0, (int)this.l());
                                                        var4_4 = this.T;
                                                        var5_5 = var4_4[1];
                                                        var6_6 = var4_4[0];
                                                        var7_7 = this.t0;
                                                        var8_8 = -1;
                                                        if (var7_7 == 0 && k.b(this.D0, 1)) {
                                                            var179_9 = this.u0;
                                                            var180_10 = this.m();
                                                            var181_11 = this.q();
                                                            c2.h.b = 0;
                                                            c2.h.c = 0;
                                                            this.D();
                                                            var182_12 = this.q0;
                                                            var183_13 = var182_12.size();
                                                            for (var184_14 = 0; var184_14 < var183_13; ++var184_14) {
                                                                ((f)var182_12.get(var184_14)).D();
                                                            }
                                                            var185_15 = this.v0;
                                                            if (var180_10 == 1) {
                                                                this.G(0, this.r());
                                                            } else {
                                                                var186_16 = this.I;
                                                                var186_16.b = 0;
                                                                var186_16.c = true;
                                                                this.Z = 0;
                                                            }
                                                            var188_18 = false;
                                                            var189_19 = false;
                                                            for (var187_17 = 0; var187_17 < var183_13; ++var187_17) {
                                                                var219_20 = (f)var182_12.get(var187_17);
                                                                if (var219_20 instanceof h) {
                                                                    var220_21 = (h)var219_20;
                                                                    if (var220_21.u0 == 1) {
                                                                        var221_22 = var220_21.r0;
                                                                        if (var221_22 != var8_8) {
                                                                            var220_21.Q(var221_22);
                                                                        } else if (var220_21.s0 != var8_8 && this.A()) {
                                                                            var220_21.Q(this.r() - var220_21.s0);
                                                                        } else if (this.A()) {
                                                                            var220_21.Q((int)(0.5f + var220_21.q0 * (float)this.r()));
                                                                        }
                                                                        var188_18 = true;
                                                                    }
                                                                } else if (var219_20 instanceof b && ((b)var219_20).S() == 0) {
                                                                    var189_19 = true;
                                                                }
                                                                var8_8 = -1;
                                                            }
                                                            if (var188_18) {
                                                                for (var216_23 = 0; var216_23 < var183_13; ++var216_23) {
                                                                    var217_24 = (f)var182_12.get(var216_23);
                                                                    if (!(var217_24 instanceof h)) continue;
                                                                    var218_25 = (h)var217_24;
                                                                    if (var218_25.u0 != 1) continue;
                                                                    c2.h.b((int)0, (f)var218_25, (b.b)var179_9, (boolean)var185_15);
                                                                }
                                                            }
                                                            c2.h.b((int)0, (f)this, (b.b)var179_9, (boolean)var185_15);
                                                            if (var189_19) {
                                                                for (var213_26 = 0; var213_26 < var183_13; ++var213_26) {
                                                                    var214_27 = (f)var182_12.get(var213_26);
                                                                    if (!(var214_27 instanceof b) || (var215_28 = (b)var214_27).S() != 0 || !var215_28.R()) continue;
                                                                    c2.h.b((int)1, (f)var215_28, (b.b)var179_9, (boolean)var185_15);
                                                                }
                                                            }
                                                            if (var181_11 == 1) {
                                                                this.H(0, this.l());
                                                            } else {
                                                                var190_29 = this.J;
                                                                var190_29.b = 0;
                                                                var190_29.c = true;
                                                                this.a0 = 0;
                                                            }
                                                            var192_31 = false;
                                                            var193_32 = false;
                                                            for (var191_30 = 0; var191_30 < var183_13; ++var191_30) {
                                                                var210_33 = (f)var182_12.get(var191_30);
                                                                if (var210_33 instanceof h) {
                                                                    var211_34 = (h)var210_33;
                                                                    if (var211_34.u0 != 0) continue;
                                                                    var212_35 = var211_34.r0;
                                                                    if (var212_35 != -1) {
                                                                        var211_34.Q(var212_35);
                                                                    } else if (var211_34.s0 != -1 && this.B()) {
                                                                        var211_34.Q(this.l() - var211_34.s0);
                                                                    } else if (this.B()) {
                                                                        var211_34.Q((int)(0.5f + var211_34.q0 * (float)this.l()));
                                                                    }
                                                                    var192_31 = true;
                                                                    continue;
                                                                }
                                                                if (!(var210_33 instanceof b) || ((b)var210_33).S() != 1) continue;
                                                                var193_32 = true;
                                                            }
                                                            if (var192_31) {
                                                                for (var207_36 = 0; var207_36 < var183_13; ++var207_36) {
                                                                    var208_37 = (f)var182_12.get(var207_36);
                                                                    if (!(var208_37 instanceof h)) continue;
                                                                    var209_38 = (h)var208_37;
                                                                    if (var209_38.u0 != 0) continue;
                                                                    c2.h.g((int)1, (f)var209_38, (b.b)var179_9);
                                                                }
                                                            }
                                                            c2.h.g((int)0, (f)this, (b.b)var179_9);
                                                            if (var193_32) {
                                                                for (var204_39 = 0; var204_39 < var183_13; ++var204_39) {
                                                                    var205_40 = (f)var182_12.get(var204_39);
                                                                    if (!(var205_40 instanceof b) || (var206_41 = (b)var205_40).S() != 1 || !var206_41.R()) continue;
                                                                    c2.h.g((int)1, (f)var206_41, (b.b)var179_9);
                                                                }
                                                            }
                                                            for (var194_42 = 0; var194_42 < var183_13; ++var194_42) {
                                                                var202_43 = (f)var182_12.get(var194_42);
                                                                if (!var202_43.z() || !c2.h.a((f)var202_43)) continue;
                                                                g.Z(var202_43, var179_9, c2.h.a, 0);
                                                                if (var202_43 instanceof h) {
                                                                    if (((h)var202_43).u0 == 0) {
                                                                        c2.h.g((int)0, (f)var202_43, (b.b)var179_9);
                                                                        continue;
                                                                    }
                                                                    c2.h.b((int)0, (f)var202_43, (b.b)var179_9, (boolean)var185_15);
                                                                    continue;
                                                                }
                                                                c2.h.b((int)0, (f)var202_43, (b.b)var179_9, (boolean)var185_15);
                                                                c2.h.g((int)0, (f)var202_43, (b.b)var179_9);
                                                            }
                                                            for (var195_44 = 0; var195_44 < var1_1; ++var195_44) {
                                                                var196_45 = (f)this.q0.get(var195_44);
                                                                if (!var196_45.z() || var196_45 instanceof h || var196_45 instanceof b || var196_45 instanceof l || var196_45.F) continue;
                                                                var197_46 = var196_45.k(0);
                                                                var198_47 = var196_45.k(1);
                                                                var199_48 = var197_46 == 3 && var196_45.q != 1 && var198_47 == 3 && var196_45.r != 1;
                                                                if (var199_48) continue;
                                                                var200_49 = new b.a();
                                                                g.Z(var196_45, this.u0, var200_49, 0);
                                                            }
                                                        }
                                                        if (var1_1 > 2 && (var6_6 == 2 || var5_5 == 2) && k.b(this.D0, 1024)) break block126;
                                                        var9_57 = var1_1;
                                                        var10_127 = var6_6;
                                                        var11_136 = var2_2;
                                                        var12_135 = var3_3;
                                                        var13_131 = var5_5;
                                                        break block127;
                                                    }
                                                    var76_50 = this.u0;
                                                    var77_51 = e.a.g;
                                                    var78_52 = this.q0;
                                                    var79_53 = var78_52.size();
                                                    for (var80_54 = 0; var80_54 < var79_53; ++var80_54) {
                                                        var178_55 = (f)var78_52.get(var80_54);
                                                        if (i.c((int)this.m(), (int)this.q(), (int)var178_55.m(), (int)var178_55.q())) continue;
                                                        var88_56 = var2_2;
                                                        var9_57 = var1_1;
                                                        var89_58 = var3_3;
                                                        var90_59 = var6_6;
                                                        var91_60 = var5_5;
                                                        ** GOTO lbl-1000
                                                    }
                                                    var81_61 = null;
                                                    var83_63 = null;
                                                    var84_64 = null;
                                                    var85_65 = null;
                                                    var86_66 = null;
                                                    var87_67 = null;
                                                    for (var82_62 = 0; var82_62 < var79_53; ++var82_62) {
                                                        var154_68 = var78_52.get(var82_62);
                                                        var155_69 = var1_1;
                                                        var156_70 = (f)var154_68;
                                                        var157_71 = var3_3;
                                                        var158_72 = this.m();
                                                        var159_73 = var5_5;
                                                        var160_74 = this.q();
                                                        var161_75 = var2_2;
                                                        var162_76 = var156_70.m();
                                                        var163_77 = var6_6;
                                                        if (!i.c((int)var158_72, (int)var160_74, (int)var162_76, (int)var156_70.q())) {
                                                            g.Z(var156_70, var76_50, this.L0, 0);
                                                        }
                                                        if (var164_78 = var156_70 instanceof h) {
                                                            var174_82 = (h)var156_70;
                                                            if (var174_82.u0 == 0) {
                                                                if (var84_64 == null) {
                                                                    var84_64 = new ArrayList();
                                                                }
                                                                var84_64.add((Object)var174_82);
                                                            }
                                                            if (var174_82.u0 == 1) {
                                                                if (var81_61 == null) {
                                                                    var81_61 = new ArrayList();
                                                                }
                                                                var81_61.add((Object)var174_82);
                                                            }
                                                        }
                                                        if (var156_70 instanceof j) {
                                                            if (var156_70 instanceof b) {
                                                                var171_81 = (b)var156_70;
                                                                if (var171_81.S() == 0) {
                                                                    if (var83_63 == null) {
                                                                        var83_63 = new ArrayList();
                                                                    }
                                                                    var83_63.add((Object)var171_81);
                                                                }
                                                                if (var171_81.S() == 1) {
                                                                    if (var85_65 == null) {
                                                                        var85_65 = new ArrayList();
                                                                    }
                                                                    var85_65.add((Object)var171_81);
                                                                }
                                                            } else {
                                                                var168_80 = (j)var156_70;
                                                                if (var83_63 == null) {
                                                                    var83_63 = new ArrayList();
                                                                }
                                                                var83_63.add((Object)var168_80);
                                                                if (var85_65 == null) {
                                                                    var85_65 = new ArrayList();
                                                                }
                                                                var85_65.add((Object)var168_80);
                                                            }
                                                        }
                                                        if (var156_70.I.f == null && var156_70.K.f == null && !var164_78 && !(var156_70 instanceof b)) {
                                                            if (var86_66 == null) {
                                                                var86_66 = new ArrayList();
                                                            }
                                                            var86_66.add((Object)var156_70);
                                                        }
                                                        if (var156_70.J.f == null && var156_70.L.f == null && var156_70.M.f == null && !var164_78 && !(var156_70 instanceof b)) {
                                                            if (var87_67 == null) {
                                                                var87_67 = new ArrayList();
                                                            }
                                                            var165_79 = var87_67;
                                                            var165_79.add((Object)var156_70);
                                                            var87_67 = var165_79;
                                                        }
                                                        var3_3 = var157_71;
                                                        var1_1 = var155_69;
                                                        var5_5 = var159_73;
                                                        var2_2 = var161_75;
                                                        var6_6 = var163_77;
                                                    }
                                                    var88_56 = var2_2;
                                                    var9_57 = var1_1;
                                                    var89_58 = var3_3;
                                                    var90_59 = var6_6;
                                                    var91_60 = var5_5;
                                                    var92_83 = new ArrayList();
                                                    if (var81_61 != null) {
                                                        var152_84 = var81_61.iterator();
                                                        while (var152_84.hasNext()) {
                                                            i.a((f)((h)var152_84.next()), (int)0, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    if (var83_63 != null) {
                                                        for (j var150_86 : var83_63) {
                                                            var151_87 = i.a((f)var150_86, (int)0, (ArrayList)var92_83, null);
                                                            var150_86.Q(var92_83, 0, var151_87);
                                                            var151_87.b(var92_83);
                                                        }
                                                    }
                                                    if ((var93_88 = this.i((e.a)e.a.b).a) != null) {
                                                        var147_89 = var93_88.iterator();
                                                        while (var147_89.hasNext()) {
                                                            i.a((f)((e)var147_89.next()).d, (int)0, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    if ((var94_90 = this.i((e.a)e.a.d).a) != null) {
                                                        var145_91 = var94_90.iterator();
                                                        while (var145_91.hasNext()) {
                                                            i.a((f)((e)var145_91.next()).d, (int)0, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    if ((var95_92 = this.i((e.a)var77_51).a) != null) {
                                                        var143_93 = var95_92.iterator();
                                                        while (var143_93.hasNext()) {
                                                            i.a((f)((e)var143_93.next()).d, (int)0, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    if (var86_66 != null) {
                                                        var141_94 = var86_66.iterator();
                                                        while (var141_94.hasNext()) {
                                                            i.a((f)((f)var141_94.next()), (int)0, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    if (var84_64 != null) {
                                                        var139_95 = var84_64.iterator();
                                                        while (var139_95.hasNext()) {
                                                            i.a((f)((h)var139_95.next()), (int)1, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    var96_96 = 1;
                                                    if (var85_65 != null) {
                                                        for (j var137_98 : var85_65) {
                                                            var138_99 = i.a((f)var137_98, (int)var96_96, (ArrayList)var92_83, null);
                                                            var137_98.Q(var92_83, var96_96, var138_99);
                                                            var138_99.b(var92_83);
                                                            var96_96 = 1;
                                                        }
                                                    }
                                                    if ((var97_100 = this.i((e.a)e.a.c).a) != null) {
                                                        var134_101 = var97_100.iterator();
                                                        while (var134_101.hasNext()) {
                                                            i.a((f)((e)var134_101.next()).d, (int)1, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    if ((var98_102 = this.i((e.a)e.a.f).a) != null) {
                                                        var132_103 = var98_102.iterator();
                                                        while (var132_103.hasNext()) {
                                                            i.a((f)((e)var132_103.next()).d, (int)1, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    if ((var99_104 = this.i((e.a)e.a.e).a) != null) {
                                                        var130_105 = var99_104.iterator();
                                                        while (var130_105.hasNext()) {
                                                            i.a((f)((e)var130_105.next()).d, (int)1, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    if ((var100_106 = this.i((e.a)var77_51).a) != null) {
                                                        var128_107 = var100_106.iterator();
                                                        while (var128_107.hasNext()) {
                                                            i.a((f)((e)var128_107.next()).d, (int)1, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    var101_108 = 1;
                                                    if (var87_67 != null) {
                                                        var126_109 = var87_67.iterator();
                                                        while (var126_109.hasNext()) {
                                                            i.a((f)((f)var126_109.next()), (int)var101_108, (ArrayList)var92_83, null);
                                                        }
                                                    }
                                                    for (var102_110 = 0; var102_110 < var79_53; ++var102_110) {
                                                        var120_111 = (f)var78_52.get(var102_110);
                                                        var121_112 = var120_111.T;
                                                        var122_113 = var121_112[0] == 3 && var121_112[var101_108] == 3;
                                                        if (var122_113) {
                                                            var123_114 = i.b((ArrayList)var92_83, (int)var120_111.o0);
                                                            var124_115 = i.b((ArrayList)var92_83, (int)var120_111.p0);
                                                            if (var123_114 != null && var124_115 != null) {
                                                                var123_114.d(0, var124_115);
                                                                var124_115.c = 2;
                                                                var92_83.remove((Object)var123_114);
                                                            }
                                                        }
                                                        var101_108 = 1;
                                                    }
                                                    if (var92_83.size() <= 1) ** GOTO lbl-1000
                                                    if (this.m() != 2) ** GOTO lbl-1000
                                                    var116_116 = var92_83.iterator();
                                                    var103_117 = null;
                                                    var117_118 = 0;
                                                    while (var116_116.hasNext()) {
                                                        var118_119 = (o)var116_116.next();
                                                        if (var118_119.c == 1 || (var119_120 = var118_119.c(this.w0, 0)) <= var117_118) continue;
                                                        var103_117 = var118_119;
                                                        var117_118 = var119_120;
                                                    }
                                                    if (var103_117 != null) {
                                                        this.T[0] = 1;
                                                        this.N(var117_118);
                                                    } else lbl-1000: // 2 sources:
                                                    {
                                                        var103_117 = null;
                                                    }
                                                    if (this.q() != 2) ** GOTO lbl-1000
                                                    var112_121 = var92_83.iterator();
                                                    var104_122 = null;
                                                    var113_123 = 0;
                                                    while (var112_121.hasNext()) {
                                                        var114_124 = (o)var112_121.next();
                                                        if (var114_124.c == 0 || (var115_125 = var114_124.c(this.w0, 1)) <= var113_123) continue;
                                                        var104_122 = var114_124;
                                                        var113_123 = var115_125;
                                                    }
                                                    if (var104_122 != null) {
                                                        this.T[1] = 1;
                                                        this.I(var113_123);
                                                    } else lbl-1000: // 2 sources:
                                                    {
                                                        var104_122 = null;
                                                    }
                                                    if (var103_117 == null && var104_122 == null) lbl-1000: // 3 sources:
                                                    {
                                                        var105_126 = false;
                                                    } else {
                                                        var105_126 = true;
                                                    }
                                                    if (!var105_126) break block128;
                                                    var10_127 = var90_59;
                                                    if (var10_127 != 2) break block129;
                                                    var106_129 = var88_56;
                                                    var111_128 = this.r();
                                                    if (var106_129 >= var111_128 || var106_129 <= 0) break block130;
                                                    this.N(var106_129);
                                                    this.E0 = true;
                                                    break block131;
                                                }
                                                var107_130 = this.r();
                                                break block132;
                                            }
                                            var106_129 = var88_56;
                                        }
                                        var107_130 = var106_129;
                                    }
                                    var13_131 = var91_60;
                                    if (var13_131 != 2) break block133;
                                    var108_133 = var89_58;
                                    var110_132 = this.l();
                                    if (var108_133 >= var110_132 || var108_133 <= 0) break block134;
                                    this.I(var108_133);
                                    this.F0 = true;
                                    break block135;
                                }
                                var109_134 = this.l();
                                break block136;
                            }
                            var108_133 = var89_58;
                        }
                        var109_134 = var108_133;
                    }
                    var12_135 = var109_134;
                    var11_136 = var107_130;
                    var14_137 = 1;
                    break block137;
                }
                var12_135 = var89_58;
                var13_131 = var91_60;
                var11_136 = var88_56;
                var10_127 = var90_59;
            }
            var14_137 = 0;
        }
        var15_138 = this.a0(64) || this.a0(128);
        var16_139 = this.w0;
        Objects.requireNonNull((Object)var16_139);
        var16_139.g = false;
        if (this.D0 != 0 && var15_138) {
            var16_139.g = true;
        }
        var18_140 = this.q0;
        var19_141 = this.m() == 2 || this.q() == 2;
        this.z0 = 0;
        this.A0 = 0;
        var20_142 = var9_57;
        for (var21_143 = 0; var21_143 < var20_142; ++var21_143) {
            var75_144 = (f)this.q0.get(var21_143);
            if (!(var75_144 instanceof m)) continue;
            ((m)var75_144).Q();
        }
        var22_145 = this.a0(64);
        var23_146 = var14_137;
        var24_147 = 0;
        var25_148 = 1;
        do {
            block125 : {
                block139 : {
                    block138 : {
                        if (var25_148 == 0) ** GOTO lbl419
                        var27_149 = var24_147 + 1;
                        this.w0.u();
                        this.z0 = 0;
                        this.A0 = 0;
                        this.g(this.w0);
                        break block138;
lbl419: // 1 sources:
                        this.q0 = var18_140;
                        if (var23_146 != 0) {
                            var26_197 = this.T;
                            var26_197[0] = var10_127;
                            var26_197[1] = var13_131;
                        }
                        this.E(this.w0.l);
                        return;
                    }
                    for (var57_180 = 0; var57_180 < var20_142; ++var57_180) {
                        ((f)this.q0.get(var57_180)).g(this.w0);
                    }
                    this.S(this.w0);
                    try {
                        var59_181 = this.G0;
                        if (var59_181 != null && var59_181.get() != null) {
                            var72_194 = (e)this.G0.get();
                            var73_195 = this.w0.l((Object)this.J);
                            var74_196 = this.w0.l((Object)var72_194);
                            this.w0.f(var74_196, var73_195, 0, 5);
                            this.G0 = null;
                        }
                        if ((var60_182 = this.I0) != null && var60_182.get() != null) {
                            var69_191 = (e)this.I0.get();
                            var70_192 = this.w0.l((Object)this.L);
                            var71_193 = this.w0.l((Object)var69_191);
                            this.w0.f(var70_192, var71_193, 0, 5);
                            this.I0 = null;
                        }
                        if ((var61_183 = this.H0) != null && var61_183.get() != null) {
                            var66_188 = (e)this.H0.get();
                            var67_189 = this.w0.l((Object)this.I);
                            var68_190 = this.w0.l((Object)var66_188);
                            this.w0.f(var68_190, var67_189, 0, 5);
                            this.H0 = null;
                        }
                        if ((var62_184 = this.J0) == null || var62_184.get() == null) ** GOTO lbl459
                        var63_185 = (e)this.J0.get();
                        var64_186 = this.w0.l((Object)this.K);
                        var65_187 = this.w0.l((Object)var63_185);
                        this.w0.f(var64_186, var65_187, 0, 5);
                    }
                    catch (Exception var28_153) {}
                    try {
                        this.J0 = null;
lbl459: // 2 sources:
                        this.w0.q();
                        var25_148 = 1;
                        break block125;
                    }
                    catch (Exception var28_151) {}
                    ** GOTO lbl-1000
                    catch (Exception var28_152) {
                        // empty catch block
                    }
                    break block139;
lbl-1000: // 2 sources:
                    {
                        var25_148 = 1;
                    }
                }
                var28_150.printStackTrace();
                var29_154 = System.out;
                var30_155 = new StringBuilder();
                var30_155.append("EXCEPTION : ");
                var30_155.append((Object)var28_150);
                var29_154.println(var30_155.toString());
            }
            if (var25_148 == 0) {
                this.P(this.w0, var22_145);
                for (var33_156 = 0; var33_156 < var20_142; ++var33_156) {
                    ((f)this.q0.get(var33_156)).P(this.w0, var22_145);
                }
                var34_157 = 0;
            } else {
                var48_171 = this.w0;
                k.a[2] = false;
                var49_172 = this.a0(64);
                this.P(var48_171, var49_172);
                var50_173 = this.q0.size();
                var34_157 = 0;
                for (var51_174 = 0; var51_174 < var50_173; ++var51_174) {
                    var52_175 = (f)this.q0.get(var51_174);
                    var52_175.P(var48_171, var49_172);
                    var53_176 = var48_171;
                    var54_177 = var52_175.h;
                    var55_178 = var49_172;
                    var56_179 = var54_177 != -1 || var52_175.i != -1;
                    if (var56_179) {
                        var34_157 = 1;
                    }
                    var48_171 = var53_176;
                    var49_172 = var55_178;
                }
            }
            if (var19_141 && var27_149 < 8 && k.a[2]) {
                var43_166 = 0;
                var44_167 = 0;
                for (var42_165 = 0; var42_165 < var20_142; ++var42_165) {
                    var47_170 = (f)this.q0.get(var42_165);
                    var43_166 = Math.max((int)var43_166, (int)(var47_170.Z + var47_170.r()));
                    var44_167 = Math.max((int)var44_167, (int)(var47_170.a0 + var47_170.l()));
                }
                var45_168 = Math.max((int)this.c0, (int)var43_166);
                var46_169 = Math.max((int)this.d0, (int)var44_167);
                if (var10_127 == 2 && this.r() < var45_168) {
                    this.N(var45_168);
                    this.T[0] = 2;
                    var23_146 = 1;
                    var34_157 = 1;
                }
                if (var13_131 == 2 && this.l() < var46_169) {
                    this.I(var46_169);
                    this.T[1] = 2;
                    var23_146 = 1;
                    var34_157 = 1;
                }
            }
            if ((var35_158 = Math.max((int)this.c0, (int)this.r())) > this.r()) {
                this.N(var35_158);
                var41_164 = this.T;
                var41_164[0] = var36_159 = 1;
                var37_160 = var34_157 = var36_159;
            } else {
                var36_159 = 1;
                var37_160 = var23_146;
            }
            var38_161 = Math.max((int)this.d0, (int)this.l());
            if (var38_161 > this.l()) {
                this.I(var38_161);
                this.T[var36_159] = var36_159;
                var34_157 = var39_162 = var36_159;
            } else {
                var39_162 = var37_160;
            }
            if (var39_162 != 0) ** GOTO lbl-1000
            if (this.T[0] == 2 && var11_136 > 0 && this.r() > var11_136) {
                this.E0 = var36_159;
                this.T[0] = var36_159;
                this.N(var11_136);
                var34_157 = var39_162 = var36_159;
            }
            if (this.T[var36_159] == 2 && var12_135 > 0 && this.l() > var12_135) {
                this.F0 = var36_159;
                this.T[var36_159] = var36_159;
                this.I(var12_135);
                var40_163 = 8;
                var23_146 = 1;
                var34_157 = 1;
            } else lbl-1000: // 2 sources:
            {
                var23_146 = var39_162;
                var40_163 = 8;
            }
            if (var27_149 > var40_163) {
                var34_157 = 0;
            }
            var24_147 = var27_149;
            var25_148 = var34_157;
        } while (true);
    }

    public void R(f f2, int n2) {
        if (n2 == 0) {
            int n3 = 1 + this.z0;
            Object[] arrobject = this.C0;
            if (n3 >= arrobject.length) {
                this.C0 = (d[])Arrays.copyOf((Object[])arrobject, (int)(2 * arrobject.length));
            }
            d[] arrd = this.C0;
            int n4 = this.z0;
            arrd[n4] = new d(f2, 0, this.v0);
            this.z0 = n4 + 1;
            return;
        }
        if (n2 == 1) {
            int n5 = 1 + this.A0;
            Object[] arrobject = this.B0;
            if (n5 >= arrobject.length) {
                this.B0 = (d[])Arrays.copyOf((Object[])arrobject, (int)(2 * arrobject.length));
            }
            d[] arrd = this.B0;
            int n6 = this.A0;
            arrd[n6] = new d(f2, 1, this.v0);
            this.A0 = n6 + 1;
        }
    }

    public boolean S(z1.c c2) {
        boolean bl = this.a0(64);
        ((f)((Object)this)).d(c2, bl);
        int n2 = this.q0.size();
        boolean bl2 = false;
        for (int i2 = 0; i2 < n2; ++i2) {
            f f2 = (f)this.q0.get(i2);
            boolean[] arrbl = f2.S;
            arrbl[0] = false;
            arrbl[1] = false;
            if (!(f2 instanceof b)) continue;
            bl2 = true;
        }
        if (bl2) {
            for (int i3 = 0; i3 < n2; ++i3) {
                f f3 = (f)this.q0.get(i3);
                if (!(f3 instanceof b)) continue;
                b b2 = (b)((Object)f3);
                for (int i4 = 0; i4 < b2.r0; ++i4) {
                    f f4 = b2.q0[i4];
                    if (!b2.t0 && !f4.e()) continue;
                    int n3 = b2.s0;
                    if (n3 != 0 && n3 != 1) {
                        if (n3 != 2 && n3 != 3) continue;
                        f4.S[1] = true;
                        continue;
                    }
                    f4.S[0] = true;
                }
            }
        }
        this.K0.clear();
        for (int i5 = 0; i5 < n2; ++i5) {
            f f5 = (f)this.q0.get(i5);
            if (!f5.c()) continue;
            if (f5 instanceof l) {
                this.K0.add((Object)f5);
                continue;
            }
            f5.d(c2, bl);
        }
        while (this.K0.size() > 0) {
            int n4 = this.K0.size();
            Iterator iterator = this.K0.iterator();
            while (iterator.hasNext()) {
                l l2;
                boolean bl3;
                block22 : {
                    l2 = (l)((Object)((f)iterator.next()));
                    HashSet<f> hashSet = this.K0;
                    for (int i6 = 0; i6 < l2.r0; ++i6) {
                        if (!hashSet.contains((Object)l2.q0[i6])) continue;
                        bl3 = true;
                        break block22;
                    }
                    bl3 = false;
                }
                if (!bl3) continue;
                ((f)((Object)l2)).d(c2, bl);
                this.K0.remove((Object)l2);
                break;
            }
            if (n4 != this.K0.size()) continue;
            Iterator iterator2 = this.K0.iterator();
            while (iterator2.hasNext()) {
                ((f)iterator2.next()).d(c2, bl);
            }
            this.K0.clear();
        }
        if (z1.c.p) {
            HashSet hashSet = new HashSet();
            for (int i7 = 0; i7 < n2; ++i7) {
                f f6 = (f)this.q0.get(i7);
                if (f6.c()) continue;
                hashSet.add((Object)f6);
            }
            int n5 = ((f)((Object)this)).m() == 2 ? 0 : 1;
            ((f)((Object)this)).b(this, c2, (HashSet<f>)hashSet, n5, false);
            for (f f7 : hashSet) {
                k.a(this, c2, f7);
                f7.d(c2, bl);
            }
        } else {
            for (int i8 = 0; i8 < n2; ++i8) {
                f f8 = (f)this.q0.get(i8);
                if (f8 instanceof g) {
                    int[] arrn = f8.T;
                    int n6 = arrn[0];
                    int n7 = arrn[1];
                    if (n6 == 2) {
                        arrn[0] = 1;
                    }
                    if (n7 == 2) {
                        arrn[1] = 1;
                    }
                    f8.d(c2, bl);
                    if (n6 == 2) {
                        f8.J(n6);
                    }
                    if (n7 != 2) continue;
                    f8.M(n7);
                    continue;
                }
                k.a(this, c2, f8);
                if (f8.c()) continue;
                f8.d(c2, bl);
            }
        }
        if (this.z0 > 0) {
            c.a(this, c2, null, 0);
        }
        if (this.A0 > 0) {
            c.a(this, c2, null, 1);
        }
        return true;
    }

    public void T(e e2) {
        WeakReference<e> weakReference = this.J0;
        if (weakReference == null || weakReference.get() == null || e2.c() > ((e)this.J0.get()).c()) {
            this.J0 = new WeakReference((Object)e2);
        }
    }

    public void U(e e2) {
        WeakReference<e> weakReference = this.H0;
        if (weakReference == null || weakReference.get() == null || e2.c() > ((e)this.H0.get()).c()) {
            this.H0 = new WeakReference((Object)e2);
        }
    }

    public void V(e e2) {
        WeakReference<e> weakReference = this.I0;
        if (weakReference == null || weakReference.get() == null || e2.c() > ((e)this.I0.get()).c()) {
            this.I0 = new WeakReference((Object)e2);
        }
    }

    public void W(e e2) {
        WeakReference<e> weakReference = this.G0;
        if (weakReference == null || weakReference.get() == null || e2.c() > ((e)this.G0.get()).c()) {
            this.G0 = new WeakReference((Object)e2);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean X(boolean var1_1, int var2_2) {
        block10 : {
            var3_3 = this.s0;
            var4_4 = 1;
            var5_5 = var1_1 & var4_4;
            var6_6 = var3_3.a.k(0);
            var7_7 = var3_3.a.k(var4_4);
            var8_8 = var3_3.a.s();
            var9_9 = var3_3.a.t();
            if (var5_5 && (var6_6 == 2 || var7_7 == 2)) {
                for (p var26_11 : var3_3.e) {
                    if (var26_11.f != var2_2 || var26_11.k()) continue;
                    var5_5 = false;
                    break;
                }
                if (var2_2 == 0) {
                    if (var5_5 && var6_6 == 2) {
                        var24_12 = var3_3.a;
                        var24_12.T[0] = var4_4;
                        var24_12.N(var3_3.d(var24_12, 0));
                        var25_13 = var3_3.a;
                        var25_13.d.e.c(var25_13.r());
                    }
                } else if (var5_5 && var7_7 == 2) {
                    var22_14 = var3_3.a;
                    var22_14.T[var4_4] = var4_4;
                    var22_14.I(var3_3.d(var22_14, var4_4));
                    var23_15 = var3_3.a;
                    var23_15.e.e.c(var23_15.l());
                }
            }
            if (var2_2 != 0) break block10;
            var18_16 = var3_3.a;
            var19_17 = var18_16.T;
            if (var19_17[0] != var4_4 && var19_17[0] != 4) ** GOTO lbl-1000
            var20_18 = var8_8 + var18_16.r();
            var3_3.a.d.i.c(var20_18);
            var3_3.a.d.e.c(var20_18 - var8_8);
            ** GOTO lbl44
        }
        var10_19 = var3_3.a;
        var11_20 = var10_19.T;
        if (var11_20[var4_4] != var4_4 && var11_20[var4_4] != 4) lbl-1000: // 2 sources:
        {
            var13_21 = 0;
        } else {
            var12_22 = var9_9 + var10_19.l();
            var3_3.a.e.i.c(var12_22);
            var3_3.a.e.e.c(var12_22 - var9_9);
lbl44: // 2 sources:
            var13_21 = var4_4;
        }
        var3_3.g();
        for (p var17_24 : var3_3.e) {
            if (var17_24.f != var2_2 || var17_24.b == var3_3.a && !var17_24.g) continue;
            var17_24.e();
        }
        for (p var16_26 : var3_3.e) {
            if (var16_26.f != var2_2 || var13_21 == 0 && var16_26.b == var3_3.a || var16_26.h.j && var16_26.i.j && (var16_26 instanceof c2.c || var16_26.e.j)) continue;
            var4_4 = 0;
            break;
        }
        var3_3.a.J(var6_6);
        var3_3.a.M(var7_7);
        return (boolean)var4_4;
    }

    public void Y() {
        this.s0.b = true;
    }

    public boolean a0(int n2) {
        return (n2 & this.D0) == n2;
    }

    public void b0(int n2) {
        this.D0 = n2;
        z1.c.p = this.a0(512);
    }
}

