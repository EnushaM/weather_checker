/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c2.i
 *  c2.o
 *  java.util.ArrayList
 */
package b2;

import b2.f;
import b2.g;
import b2.i;
import c2.o;
import java.util.ArrayList;

public class j
extends f
implements i {
    public f[] q0 = new f[4];
    public int r0 = 0;

    public void Q(ArrayList<o> arrayList, int n2, o o2) {
        int n3 = 0;
        do {
            int n4 = this.r0;
            if (n3 >= n4) break;
            o2.a(this.q0[n3]);
            ++n3;
        } while (true);
        for (int i2 = 0; i2 < this.r0; ++i2) {
            c2.i.a((f)this.q0[i2], (int)n2, arrayList, (o)o2);
        }
    }

    @Override
    public void a(g g3) {
    }
}

