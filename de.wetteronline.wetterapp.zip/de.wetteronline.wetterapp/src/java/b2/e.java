/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b2.h
 *  c2.i
 *  c2.o
 *  java.lang.AssertionError
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashSet
 *  java.util.Iterator
 *  z1.f
 */
package b2;

import b2.f;
import b2.h;
import c2.i;
import c2.o;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class e {
    public HashSet<e> a = null;
    public int b;
    public boolean c;
    public final f d;
    public final a e;
    public e f;
    public int g = 0;
    public int h = Integer.MIN_VALUE;
    public z1.f i;

    public e(f f2, a a3) {
        this.d = f2;
        this.e = a3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public boolean a(e var1_1, int var2_2, int var3_3, boolean var4_4) {
        block18 : {
            block20 : {
                block19 : {
                    if (var1_1 == null) {
                        this.h();
                        return true;
                    }
                    if (var4_4) break block18;
                    var7_5 = a.i;
                    var8_6 = a.d;
                    var9_7 = a.h;
                    var10_8 = a.b;
                    var11_9 = a.f;
                    var12_10 = var1_1.e;
                    var13_11 = this.e;
                    if (var12_10 != var13_11) break block19;
                    if (var13_11 == var11_9) {
                        if (var1_1.d.D == false) return false;
                        if (!this.d.D) {
                            return false;
                        }
                    }
                    ** GOTO lbl43
                }
                switch (var13_11.ordinal()) {
                    default: {
                        throw new AssertionError((Object)this.e.name());
                    }
                    case 6: {
                        if (var12_10 == var11_9) return false;
                        if (var12_10 == var9_7) return false;
                        if (var12_10 == var7_5) return false;
                        ** GOTO lbl43
                    }
                    case 5: {
                        if (var12_10 == var10_8) return false;
                        if (var12_10 == var8_6) {
                            return false;
                        }
                        ** GOTO lbl43
                    }
                    case 2: 
                    case 4: {
                        var14_12 = var12_10 == a.c || var12_10 == a.e;
                        if (!(var1_1.d instanceof h)) break block20;
                        if (!var14_12) {
                            if (var12_10 != var7_5) return false;
                        }
                        ** GOTO lbl43
                    }
                    case 1: 
                    case 3: {
                        var14_12 = var12_10 == var10_8 || var12_10 == var8_6;
                        if (!(var1_1.d instanceof h)) break block20;
                        if (!var14_12) {
                            if (var12_10 != var9_7) return false;
                        }
lbl43: // 7 sources:
                        var14_12 = true;
                        break block20;
                    }
                    case 0: 
                    case 7: 
                    case 8: 
                }
                return false;
            }
            if (!var14_12) {
                return false;
            }
        }
        this.f = var1_1;
        if (var1_1.a == null) {
            var1_1.a = new HashSet();
        }
        if ((var5_13 = this.f.a) != null) {
            var5_13.add((Object)this);
        }
        this.g = var2_2;
        this.h = var3_3;
        return true;
    }

    public void b(int n2, ArrayList<o> arrayList, o o2) {
        HashSet<e> hashSet = this.a;
        if (hashSet != null) {
            Iterator iterator = hashSet.iterator();
            while (iterator.hasNext()) {
                i.a((f)((e)iterator.next()).d, (int)n2, arrayList, (o)o2);
            }
        }
    }

    public int c() {
        if (!this.c) {
            return 0;
        }
        return this.b;
    }

    public int d() {
        e e2;
        if (this.d.h0 == 8) {
            return 0;
        }
        int n2 = this.h;
        if (n2 != Integer.MIN_VALUE && (e2 = this.f) != null && e2.d.h0 == 8) {
            return n2;
        }
        return this.g;
    }

    public boolean e() {
        HashSet<e> hashSet = this.a;
        if (hashSet == null) {
            return false;
        }
        for (e e2 : hashSet) {
            e e3;
            switch (e2.e.ordinal()) {
                default: {
                    throw new AssertionError((Object)e2.e.name());
                }
                case 4: {
                    e3 = e2.d.J;
                    break;
                }
                case 3: {
                    e3 = e2.d.I;
                    break;
                }
                case 2: {
                    e3 = e2.d.L;
                    break;
                }
                case 1: {
                    e3 = e2.d.K;
                    break;
                }
                case 0: 
                case 5: 
                case 6: 
                case 7: 
                case 8: {
                    e3 = null;
                }
            }
            if (!e3.g()) continue;
            return true;
        }
        return false;
    }

    public boolean f() {
        HashSet<e> hashSet = this.a;
        if (hashSet == null) {
            return false;
        }
        int n2 = hashSet.size();
        boolean bl = false;
        if (n2 > 0) {
            bl = true;
        }
        return bl;
    }

    public boolean g() {
        return this.f != null;
    }

    public void h() {
        HashSet<e> hashSet;
        e e2 = this.f;
        if (e2 != null && (hashSet = e2.a) != null) {
            hashSet.remove((Object)this);
            if (this.f.a.size() == 0) {
                this.f.a = null;
            }
        }
        this.a = null;
        this.f = null;
        this.g = 0;
        this.h = Integer.MIN_VALUE;
        this.c = false;
        this.b = 0;
    }

    public void i() {
        z1.f f2 = this.i;
        if (f2 == null) {
            this.i = new z1.f(1);
            return;
        }
        f2.c();
    }

    public void j(int n2) {
        this.b = n2;
        this.c = true;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.d.i0);
        stringBuilder.append(":");
        stringBuilder.append(this.e.toString());
        return stringBuilder.toString();
    }

    public static final class a
    extends Enum<a> {
        public static final /* enum */ a b;
        public static final /* enum */ a c;
        public static final /* enum */ a d;
        public static final /* enum */ a e;
        public static final /* enum */ a f;
        public static final /* enum */ a g;
        public static final /* enum */ a h;
        public static final /* enum */ a i;
        public static final /* synthetic */ a[] j;

        public static {
            a a3;
            a a4;
            a a5;
            a a6;
            a a7;
            a a8;
            a a9;
            a a10;
            a a11 = new a();
            b = a6 = new a();
            c = a3 = new a();
            d = a8 = new a();
            e = a9 = new a();
            f = a5 = new a();
            g = a4 = new a();
            h = a10 = new a();
            i = a7 = new a();
            j = new a[]{a11, a6, a3, a8, a9, a5, a4, a10, a7};
        }

        public static a valueOf(String string) {
            return (a)Enum.valueOf(a.class, (String)string);
        }

        public static a[] values() {
            return (a[])j.clone();
        }
    }

}

