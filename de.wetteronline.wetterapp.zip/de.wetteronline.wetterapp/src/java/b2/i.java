/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b2.g
 *  java.lang.Object
 */
package b2;

import b2.g;

public interface i {
    public void a(g var1);
}

