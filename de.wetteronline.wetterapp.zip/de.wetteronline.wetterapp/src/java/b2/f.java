/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a4.g
 *  android.support.v4.media.b
 *  androidx.compose.runtime.b
 *  androidx.compose.ui.platform.m
 *  b2.b
 *  b2.g
 *  b2.h
 *  b2.l
 *  c2.c
 *  c2.f
 *  c2.l
 *  c2.n
 *  c2.p
 *  java.lang.AssertionError
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  z1.b
 *  z1.c
 *  z1.f
 */
package b2;

import androidx.compose.ui.platform.m;
import b2.a;
import b2.b;
import b2.e;
import b2.g;
import b2.h;
import b2.k;
import b2.l;
import c2.c;
import c2.n;
import c2.p;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class f {
    public float A;
    public int[] B;
    public float C;
    public boolean D;
    public boolean E;
    public boolean F;
    public int G;
    public int H;
    public e I;
    public e J;
    public e K;
    public e L;
    public e M;
    public e N;
    public e O;
    public e P;
    public e[] Q;
    public ArrayList<e> R;
    public boolean[] S;
    public int[] T;
    public f U;
    public int V;
    public int W;
    public float X;
    public int Y;
    public int Z;
    public boolean a = false;
    public int a0;
    public c b;
    public int b0;
    public c c;
    public int c0;
    public c2.l d = null;
    public int d0;
    public n e = null;
    public float e0;
    public boolean[] f = new boolean[]{true, true};
    public float f0;
    public boolean g = true;
    public Object g0;
    public int h = -1;
    public int h0;
    public int i = -1;
    public String i0;
    public boolean j;
    public int j0;
    public boolean k;
    public int k0;
    public boolean l;
    public float[] l0;
    public boolean m;
    public f[] m0;
    public int n;
    public f[] n0;
    public int o;
    public int o0;
    public int p;
    public int p0;
    public int q;
    public int r;
    public int[] s;
    public int t;
    public int u;
    public float v;
    public int w;
    public int x;
    public float y;
    public int z;

    public f() {
        e e2;
        ArrayList arrayList;
        e e3;
        e e4;
        e e5;
        e e6;
        e e7;
        new HashMap();
        this.j = false;
        this.k = false;
        this.l = false;
        this.m = false;
        this.n = -1;
        this.o = -1;
        this.p = 0;
        this.q = 0;
        this.r = 0;
        this.s = new int[2];
        this.t = 0;
        this.u = 0;
        this.v = 1.0f;
        this.w = 0;
        this.x = 0;
        this.y = 1.0f;
        this.z = -1;
        this.A = 1.0f;
        this.B = new int[]{Integer.MAX_VALUE, Integer.MAX_VALUE};
        this.C = 0.0f;
        this.D = false;
        this.F = false;
        this.G = 0;
        this.H = 0;
        this.I = e4 = new e(this, e.a.b);
        this.J = e6 = new e(this, e.a.c);
        this.K = e5 = new e(this, e.a.d);
        this.L = e2 = new e(this, e.a.e);
        this.M = e7 = new e(this, e.a.f);
        this.N = new e(this, e.a.h);
        this.O = new e(this, e.a.i);
        this.P = e3 = new e(this, e.a.g);
        this.Q = new e[]{e4, e5, e6, e2, e7, e3};
        this.R = arrayList = new ArrayList();
        this.S = new boolean[2];
        this.T = new int[]{1, 1};
        this.U = null;
        this.V = 0;
        this.W = 0;
        this.X = 0.0f;
        this.Y = -1;
        this.Z = 0;
        this.a0 = 0;
        this.b0 = 0;
        this.e0 = 0.5f;
        this.f0 = 0.5f;
        this.h0 = 0;
        this.i0 = null;
        this.j0 = 0;
        this.k0 = 0;
        this.l0 = new float[]{-1.0f, -1.0f};
        this.m0 = new f[]{null, null};
        this.n0 = new f[]{null, null};
        this.o0 = -1;
        this.p0 = -1;
        arrayList.add((Object)this.I);
        this.R.add((Object)this.J);
        this.R.add((Object)this.K);
        this.R.add((Object)this.L);
        this.R.add((Object)this.N);
        this.R.add((Object)this.O);
        this.R.add((Object)this.P);
        this.R.add((Object)this.M);
    }

    public boolean A() {
        return this.j || this.I.c && this.K.c;
        {
        }
    }

    public boolean B() {
        return this.k || this.J.c && this.L.c;
        {
        }
    }

    public void C() {
        this.I.h();
        this.J.h();
        this.K.h();
        this.L.h();
        this.M.h();
        this.N.h();
        this.O.h();
        this.P.h();
        this.U = null;
        this.C = 0.0f;
        this.V = 0;
        this.W = 0;
        this.X = 0.0f;
        this.Y = -1;
        this.Z = 0;
        this.a0 = 0;
        this.b0 = 0;
        this.c0 = 0;
        this.d0 = 0;
        this.e0 = 0.5f;
        this.f0 = 0.5f;
        int[] arrn = this.T;
        arrn[0] = 1;
        arrn[1] = 1;
        this.g0 = null;
        this.h0 = 0;
        this.j0 = 0;
        this.k0 = 0;
        float[] arrf = this.l0;
        arrf[0] = -1.0f;
        arrf[1] = -1.0f;
        this.n = -1;
        this.o = -1;
        int[] arrn2 = this.B;
        arrn2[0] = Integer.MAX_VALUE;
        arrn2[1] = Integer.MAX_VALUE;
        this.q = 0;
        this.r = 0;
        this.v = 1.0f;
        this.y = 1.0f;
        this.u = Integer.MAX_VALUE;
        this.x = Integer.MAX_VALUE;
        this.t = 0;
        this.w = 0;
        this.z = -1;
        this.A = 1.0f;
        boolean[] arrbl = this.f;
        arrbl[0] = true;
        arrbl[1] = true;
        this.F = false;
        boolean[] arrbl2 = this.S;
        arrbl2[0] = false;
        arrbl2[1] = false;
        this.g = true;
        int[] arrn3 = this.s;
        arrn3[0] = 0;
        arrn3[1] = 0;
        this.h = -1;
        this.i = -1;
    }

    public void D() {
        this.j = false;
        this.k = false;
        this.l = false;
        this.m = false;
        int n2 = this.R.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            e e2 = (e)this.R.get(i2);
            e2.c = false;
            e2.b = 0;
        }
    }

    public void E(a4.g g3) {
        this.I.i();
        this.J.i();
        this.K.i();
        this.L.i();
        this.M.i();
        this.P.i();
        this.N.i();
        this.O.i();
    }

    public void F(int n2) {
        this.b0 = n2;
        boolean bl = n2 > 0;
        this.D = bl;
    }

    public void G(int n2, int n3) {
        if (this.j) {
            return;
        }
        e e2 = this.I;
        e2.b = n2;
        e2.c = true;
        e e3 = this.K;
        e3.b = n3;
        e3.c = true;
        this.Z = n2;
        this.V = n3 - n2;
        this.j = true;
    }

    public void H(int n2, int n3) {
        if (this.k) {
            return;
        }
        e e2 = this.J;
        e2.b = n2;
        e2.c = true;
        e e3 = this.L;
        e3.b = n3;
        e3.c = true;
        this.a0 = n2;
        this.W = n3 - n2;
        if (this.D) {
            this.M.j(n2 + this.b0);
        }
        this.k = true;
    }

    public void I(int n2) {
        this.W = n2;
        int n3 = this.d0;
        if (n2 < n3) {
            this.W = n3;
        }
    }

    public void J(int n2) {
        this.T[0] = n2;
    }

    public void K(int n2) {
        if (n2 < 0) {
            this.d0 = 0;
            return;
        }
        this.d0 = n2;
    }

    public void L(int n2) {
        if (n2 < 0) {
            this.c0 = 0;
            return;
        }
        this.c0 = n2;
    }

    public void M(int n2) {
        this.T[1] = n2;
    }

    public void N(int n2) {
        this.V = n2;
        int n3 = this.c0;
        if (n2 < n3) {
            this.V = n3;
        }
    }

    public void O(boolean bl, boolean bl2) {
        c2.l l3 = this.d;
        boolean bl3 = bl & l3.g;
        n n2 = this.e;
        boolean bl4 = bl2 & n2.g;
        int n3 = l3.h.g;
        int n4 = n2.h.g;
        int n5 = l3.i.g;
        int n6 = n2.i.g;
        int n7 = n5 - n3;
        int n8 = n6 - n4;
        if (n7 < 0 || n8 < 0 || n3 == Integer.MIN_VALUE || n3 == Integer.MAX_VALUE || n4 == Integer.MIN_VALUE || n4 == Integer.MAX_VALUE || n5 == Integer.MIN_VALUE || n5 == Integer.MAX_VALUE || n6 == Integer.MIN_VALUE || n6 == Integer.MAX_VALUE) {
            n5 = 0;
            n6 = 0;
            n3 = 0;
            n4 = 0;
        }
        int n9 = n5 - n3;
        int n10 = n6 - n4;
        if (bl3) {
            this.Z = n3;
        }
        if (bl4) {
            this.a0 = n4;
        }
        if (this.h0 == 8) {
            this.V = 0;
            this.W = 0;
            return;
        }
        if (bl3) {
            int n11;
            if (this.T[0] == 1 && n9 < (n11 = this.V)) {
                n9 = n11;
            }
            this.V = n9;
            int n12 = this.c0;
            if (n9 < n12) {
                this.V = n12;
            }
        }
        if (bl4) {
            int n13;
            if (this.T[1] == 1 && n10 < (n13 = this.W)) {
                n10 = n13;
            }
            this.W = n10;
            int n14 = this.d0;
            if (n10 < n14) {
                this.W = n14;
            }
        }
    }

    public void P(z1.c c3, boolean bl) {
        c2.l l3;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        n n8;
        int n9;
        int n10 = c3.o((Object)this.I);
        int n11 = c3.o((Object)this.J);
        int n12 = c3.o((Object)this.K);
        int n13 = c3.o((Object)this.L);
        if (bl && (l3 = this.d) != null) {
            c2.f f2 = l3.h;
            if (f2.j) {
                c2.f f3 = l3.i;
                if (f3.j) {
                    n10 = f2.g;
                    n12 = f3.g;
                }
            }
        }
        if (bl && (n8 = this.e) != null) {
            c2.f f4 = n8.h;
            if (f4.j) {
                c2.f f5 = n8.i;
                if (f5.j) {
                    n11 = f4.g;
                    n13 = f5.g;
                }
            }
        }
        int n14 = n12 - n10;
        int n15 = n13 - n11;
        if (n14 < 0 || n15 < 0 || n10 == Integer.MIN_VALUE || n10 == Integer.MAX_VALUE || n11 == Integer.MIN_VALUE || n11 == Integer.MAX_VALUE || n12 == Integer.MIN_VALUE || n12 == Integer.MAX_VALUE || n13 == Integer.MIN_VALUE || n13 == Integer.MAX_VALUE) {
            n13 = 0;
            n10 = 0;
            n11 = 0;
            n12 = 0;
        }
        int n16 = n12 - n10;
        int n17 = n13 - n11;
        this.Z = n10;
        this.a0 = n11;
        if (this.h0 == 8) {
            this.V = 0;
            this.W = 0;
            return;
        }
        int[] arrn = this.T;
        if (arrn[0] == 1 && n16 < (n5 = this.V)) {
            n16 = n5;
        }
        if (arrn[1] == 1 && n17 < (n6 = this.W)) {
            n17 = n6;
        }
        this.V = n16;
        this.W = n17;
        int n18 = this.d0;
        if (n17 < n18) {
            this.W = n18;
        }
        if (n16 < (n9 = this.c0)) {
            this.V = n9;
        }
        if ((n3 = this.u) > 0 && arrn[0] == 3) {
            this.V = Math.min((int)this.V, (int)n3);
        }
        if ((n2 = this.x) > 0 && this.T[1] == 3) {
            this.W = Math.min((int)this.W, (int)n2);
        }
        if (n16 != (n4 = this.V)) {
            this.h = n4;
        }
        if (n17 != (n7 = this.W)) {
            this.i = n7;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void b(g g3, z1.c c3, HashSet<f> hashSet, int n2, boolean bl) {
        HashSet<e> hashSet4;
        HashSet<e> hashSet5;
        if (bl) {
            if (!hashSet.contains((Object)this)) {
                return;
            }
            k.a(g3, c3, this);
            hashSet.remove((Object)this);
            this.d(c3, g3.a0(64));
        }
        if (n2 == 0) {
            HashSet<e> hashSet2;
            HashSet<e> hashSet3 = this.I.a;
            if (hashSet3 != null) {
                Iterator iterator = hashSet3.iterator();
                while (iterator.hasNext()) {
                    ((e)iterator.next()).d.b(g3, c3, hashSet, n2, true);
                }
            }
            if ((hashSet2 = this.K.a) == null) return;
            Iterator iterator = hashSet2.iterator();
            while (iterator.hasNext()) {
                ((e)iterator.next()).d.b(g3, c3, hashSet, n2, true);
            }
            return;
        }
        HashSet<e> hashSet6 = this.J.a;
        if (hashSet6 != null) {
            Iterator iterator = hashSet6.iterator();
            while (iterator.hasNext()) {
                ((e)iterator.next()).d.b(g3, c3, hashSet, n2, true);
            }
        }
        if ((hashSet4 = this.L.a) != null) {
            Iterator iterator = hashSet4.iterator();
            while (iterator.hasNext()) {
                ((e)iterator.next()).d.b(g3, c3, hashSet, n2, true);
            }
        }
        if ((hashSet5 = this.M.a) == null) return;
        Iterator iterator = hashSet5.iterator();
        while (iterator.hasNext()) {
            f f2 = ((e)iterator.next()).d;
            f2.b(g3, c3, hashSet, n2, true);
        }
    }

    public boolean c() {
        return this instanceof l || this instanceof h;
        {
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void d(z1.c var1_1, boolean var2_2) {
        block82 : {
            block81 : {
                block79 : {
                    block80 : {
                        block77 : {
                            block78 : {
                                block76 : {
                                    block75 : {
                                        block74 : {
                                            block72 : {
                                                block71 : {
                                                    block65 : {
                                                        block64 : {
                                                            block73 : {
                                                                block67 : {
                                                                    block69 : {
                                                                        block70 : {
                                                                            block66 : {
                                                                                block68 : {
                                                                                    block63 : {
                                                                                        block60 : {
                                                                                            block61 : {
                                                                                                block62 : {
                                                                                                    var3_3 = var1_1.l((Object)this.I);
                                                                                                    var4_4 = var1_1.l((Object)this.K);
                                                                                                    var5_5 = var1_1.l((Object)this.J);
                                                                                                    var6_6 = var1_1.l((Object)this.L);
                                                                                                    var7_7 = var1_1.l((Object)this.M);
                                                                                                    var8_8 = this.U;
                                                                                                    if (var8_8 == null) break block60;
                                                                                                    var163_9 = var8_8.T;
                                                                                                    var164_10 = var163_9[0] == 2;
                                                                                                    var165_11 = var163_9[1] == 2;
                                                                                                    var166_12 = this.p;
                                                                                                    if (var166_12 == 1) break block61;
                                                                                                    if (var166_12 == 2) break block62;
                                                                                                    if (var166_12 == 3) break block60;
                                                                                                    var9_13 = var165_11;
                                                                                                    var10_14 = var164_10;
                                                                                                    break block63;
                                                                                                }
                                                                                                var9_13 = var165_11;
                                                                                                var10_14 = false;
                                                                                                break block63;
                                                                                            }
                                                                                            var10_14 = var164_10;
                                                                                            var9_13 = false;
                                                                                            break block63;
                                                                                        }
                                                                                        var9_13 = false;
                                                                                        var10_14 = false;
                                                                                    }
                                                                                    if (this.h0 == 8) {
                                                                                        block59 : {
                                                                                            var159_15 = this.R.size();
                                                                                            for (var160_16 = 0; var160_16 < var159_15; ++var160_16) {
                                                                                                if (!((e)this.R.get(var160_16)).f()) continue;
                                                                                                var161_17 = true;
                                                                                                break block59;
                                                                                            }
                                                                                            var161_17 = false;
                                                                                        }
                                                                                        if (!(var161_17 || (var162_18 = this.S)[0] || var162_18[1])) {
                                                                                            return;
                                                                                        }
                                                                                    }
                                                                                    if ((var11_19 = this.j) || this.k) {
                                                                                        if (var11_19) {
                                                                                            var1_1.e(var3_3, this.Z);
                                                                                            var1_1.e(var4_4, this.Z + this.V);
                                                                                            if (var10_14 && (var157_20 = this.U) != null) {
                                                                                                var158_21 = (g)var157_20;
                                                                                                var158_21.U(this.I);
                                                                                                var158_21.T(this.K);
                                                                                            }
                                                                                        }
                                                                                        if (this.k) {
                                                                                            var1_1.e(var5_5, this.a0);
                                                                                            var1_1.e(var6_6, this.a0 + this.W);
                                                                                            if (this.M.f()) {
                                                                                                var1_1.e(var7_7, this.a0 + this.b0);
                                                                                            }
                                                                                            if (var9_13 && (var155_22 = this.U) != null) {
                                                                                                var156_23 = (g)var155_22;
                                                                                                var156_23.W(this.J);
                                                                                                var156_23.V(this.L);
                                                                                            }
                                                                                        }
                                                                                        if (this.j && this.k) {
                                                                                            this.j = false;
                                                                                            this.k = false;
                                                                                            return;
                                                                                        }
                                                                                    }
                                                                                    if (var2_2 && (var152_24 = this.d) != null && (var153_25 = this.e) != null) {
                                                                                        var154_26 = var152_24.h;
                                                                                        if (var154_26.j && var152_24.i.j && var153_25.h.j && var153_25.i.j) {
                                                                                            var1_1.e(var3_3, var154_26.g);
                                                                                            var1_1.e(var4_4, this.d.i.g);
                                                                                            var1_1.e(var5_5, this.e.h.g);
                                                                                            var1_1.e(var6_6, this.e.i.g);
                                                                                            var1_1.e(var7_7, this.e.k.g);
                                                                                            if (this.U != null) {
                                                                                                if (var10_14 && this.f[0] && !this.x()) {
                                                                                                    var1_1.f(var1_1.l((Object)this.U.K), var4_4, 0, 8);
                                                                                                }
                                                                                                if (var9_13 && this.f[1] && !this.y()) {
                                                                                                    var1_1.f(var1_1.l((Object)this.U.L), var6_6, 0, 8);
                                                                                                }
                                                                                            }
                                                                                            this.j = false;
                                                                                            this.k = false;
                                                                                            return;
                                                                                        }
                                                                                    }
                                                                                    if (this.U != null) {
                                                                                        if (this.w(0)) {
                                                                                            ((g)this.U).R(this, 0);
                                                                                            var150_27 = true;
                                                                                        } else {
                                                                                            var150_27 = this.x();
                                                                                        }
                                                                                        if (this.w(1)) {
                                                                                            ((g)this.U).R(this, 1);
                                                                                            var151_28 = true;
                                                                                        } else {
                                                                                            var151_28 = this.y();
                                                                                        }
                                                                                        if (!var150_27 && var10_14 && this.h0 != 8 && this.I.f == null && this.K.f == null) {
                                                                                            var1_1.f(var1_1.l((Object)this.U.K), var4_4, 0, 1);
                                                                                        }
                                                                                        if (!var151_28 && var9_13 && this.h0 != 8 && this.J.f == null && this.L.f == null && this.M == null) {
                                                                                            var1_1.f(var1_1.l((Object)this.U.L), var6_6, 0, 1);
                                                                                        }
                                                                                        var13_29 = var150_27;
                                                                                        var12_30 = var151_28;
                                                                                    } else {
                                                                                        var12_30 = false;
                                                                                        var13_29 = false;
                                                                                    }
                                                                                    var14_31 = this.V;
                                                                                    var15_32 = this.c0;
                                                                                    if (var14_31 >= var15_32) {
                                                                                        var15_32 = var14_31;
                                                                                    }
                                                                                    var16_33 = this.W;
                                                                                    var17_34 = this.d0;
                                                                                    if (var16_33 >= var17_34) {
                                                                                        var17_34 = var16_33;
                                                                                    }
                                                                                    var18_35 = this.T;
                                                                                    var19_36 = var18_35[0] != 3;
                                                                                    var20_37 = var18_35[1] != 3;
                                                                                    this.z = var21_38 = this.Y;
                                                                                    this.A = var22_39 = this.X;
                                                                                    var23_40 = var15_32;
                                                                                    var24_41 = this.q;
                                                                                    var25_42 = var17_34;
                                                                                    var26_43 = this.r;
                                                                                    if (!(var22_39 > 0.0f)) break block64;
                                                                                    var146_44 = this.h0;
                                                                                    var27_45 = var6_6;
                                                                                    if (var146_44 == 8) break block65;
                                                                                    if (var18_35[0] == 3 && var24_41 == 0) {
                                                                                        var24_41 = 3;
                                                                                    }
                                                                                    var28_46 = var5_5;
                                                                                    if (var18_35[1] == 3 && var26_43 == 0) {
                                                                                        var26_43 = 3;
                                                                                    }
                                                                                    if (var18_35[0] != 3 || var18_35[1] != 3 || var24_41 != 3 || var26_43 != 3) break block66;
                                                                                    if (var21_38 == -1) {
                                                                                        if (var19_36 && !var20_37) {
                                                                                            this.z = 0;
                                                                                        } else if (!var19_36 && var20_37) {
                                                                                            this.z = 1;
                                                                                            if (var21_38 == -1) {
                                                                                                this.A = 1.0f / var22_39;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    if (!(this.z != 0 || this.J.g() && this.L.g())) {
                                                                                        this.z = 1;
                                                                                    } else if (!(this.z != 1 || this.I.g() && this.K.g())) {
                                                                                        this.z = 0;
                                                                                    }
                                                                                    if (!(this.z != -1 || this.J.g() && this.L.g() && this.I.g() && this.K.g())) {
                                                                                        if (this.J.g() && this.L.g()) {
                                                                                            this.z = 0;
                                                                                        } else if (this.I.g() && this.K.g()) {
                                                                                            this.A = 1.0f / this.A;
                                                                                            this.z = 1;
                                                                                        }
                                                                                    }
                                                                                    if (this.z != -1) break block67;
                                                                                    var149_47 = this.t;
                                                                                    if (var149_47 <= 0 || this.w != 0) break block68;
                                                                                    this.z = 0;
                                                                                    break block67;
                                                                                }
                                                                                if (var149_47 != 0 || this.w <= 0) break block67;
                                                                                this.A = 1.0f / this.A;
                                                                                this.z = 1;
                                                                                break block67;
                                                                            }
                                                                            if (var18_35[0] != 3 || var24_41 != 3) break block69;
                                                                            this.z = 0;
                                                                            var148_48 = (int)(var22_39 * (float)var16_33);
                                                                            if (var18_35[1] == 3) break block70;
                                                                            var31_49 = var148_48;
                                                                            var30_50 = var26_43;
                                                                            var32_51 = var25_42;
                                                                            var29_52 = 4;
                                                                            break block71;
                                                                        }
                                                                        var29_52 = var24_41;
                                                                        var33_53 = true;
                                                                        var30_50 = var26_43;
                                                                        var32_51 = var25_42;
                                                                        var31_49 = var148_48;
                                                                        break block72;
                                                                    }
                                                                    if (var18_35[1] != 3 || var26_43 != 3) break block67;
                                                                    this.z = 1;
                                                                    if (var21_38 == -1) {
                                                                        this.A = 1.0f / var22_39;
                                                                    }
                                                                    var147_54 = (int)(this.A * (float)var14_31);
                                                                    if (var18_35[0] == 3) break block73;
                                                                    var32_51 = var147_54;
                                                                    var29_52 = var24_41;
                                                                    var31_49 = var23_40;
                                                                    var30_50 = 4;
                                                                    break block71;
                                                                }
                                                                var147_54 = var25_42;
                                                            }
                                                            var32_51 = var147_54;
                                                            var29_52 = var24_41;
                                                            var30_50 = var26_43;
                                                            var31_49 = var23_40;
                                                            var33_53 = true;
                                                            break block72;
                                                        }
                                                        var27_45 = var6_6;
                                                    }
                                                    var28_46 = var5_5;
                                                    var29_52 = var24_41;
                                                    var30_50 = var26_43;
                                                    var31_49 = var23_40;
                                                    var32_51 = var25_42;
                                                }
                                                var33_53 = false;
                                            }
                                            var34_55 = this.s;
                                            var34_55[0] = var29_52;
                                            var34_55[1] = var30_50;
                                            if (!var33_53) break block74;
                                            var145_56 = this.z;
                                            var35_57 = -1;
                                            if (var145_56 != 0 && var145_56 != var35_57) break block75;
                                            var36_58 = true;
                                            break block76;
                                        }
                                        var35_57 = -1;
                                    }
                                    var36_58 = false;
                                }
                                var37_60 = var33_53 != false && ((var144_59 = this.z) == 1 || var144_59 == var35_57);
                                var38_61 = this.T[0] == 2 && this instanceof g != false;
                                var39_62 = var38_61 != false ? 0 : var31_49;
                                var40_63 = true ^ this.P.g();
                                var41_64 = this.S;
                                var42_65 = var41_64[0];
                                var43_66 = var41_64[1];
                                if (this.n == 2 || this.j) ** GOTO lbl233
                                if (!var2_2 || (var142_67 = this.d) == null) ** GOTO lbl-1000
                                var143_68 = var142_67.h;
                                if (var143_68.j && var142_67.i.j) {
                                    if (var2_2) {
                                        var1_1.e(var3_3, var143_68.g);
                                        var1_1.e(var4_4, this.d.i.g);
                                        if (this.U != null && var10_14 && this.f[0] && !this.x()) {
                                            var1_1.f(var1_1.l((Object)this.U.K), var4_4, 0, 8);
                                        }
                                    }
lbl233: // 6 sources:
                                    var44_69 = var7_7;
                                    var45_70 = var27_45;
                                    var46_71 = var28_46;
                                    var47_72 = var4_4;
                                    var48_73 = var3_3;
                                } else lbl-1000: // 2 sources:
                                {
                                    var124_75 = (var123_74 = this.U) != null ? var1_1.l((Object)var123_74.K) : null;
                                    var125_76 = this.U;
                                    var126_77 = var125_76 != null ? var1_1.l((Object)var125_76.I) : null;
                                    var127_78 = this.f[0];
                                    var128_79 = this.T;
                                    var129_80 = var128_79[0];
                                    var130_81 = this.I;
                                    var131_82 = this.K;
                                    var132_83 = this.Z;
                                    var133_84 = this.c0;
                                    var134_85 = this.B[0];
                                    var135_86 = this.e0;
                                    var136_87 = var128_79[1] == 3;
                                    var137_88 = this.t;
                                    var138_89 = this.u;
                                    var139_90 = this.v;
                                    var140_91 = var10_14;
                                    var141_92 = var9_13;
                                    var45_70 = var27_45;
                                    var44_69 = var7_7;
                                    var46_71 = var28_46;
                                    var47_72 = var4_4;
                                    var48_73 = var3_3;
                                    this.f(var1_1, true, var140_91, var141_92, var127_78, var126_77, var124_75, var129_80, var38_61, var130_81, var131_82, var132_83, var39_62, var133_84, var134_85, var135_86, var36_58, var136_87, var13_29, var12_30, var42_65, var29_52, var30_50, var137_88, var138_89, var139_90, var40_63);
                                }
                                if (!var2_2) break block77;
                                var51_93 = this;
                                var115_94 = var51_93.e;
                                if (var115_94 == null) break block78;
                                var116_95 = var115_94.h;
                                if (!var116_95.j || !var115_94.i.j) break block78;
                                var117_96 = var116_95.g;
                                var52_97 = var1_1;
                                var54_98 = var46_71;
                                var52_97.e(var54_98, var117_96);
                                var118_99 = var51_93.e.i.g;
                                var53_100 = var45_70;
                                var52_97.e(var53_100, var118_99);
                                var119_101 = var51_93.e.k.g;
                                var55_102 = var44_69;
                                var52_97.e(var55_102, var119_101);
                                var120_103 = var51_93.U;
                                if (var120_103 != null && !var12_30 && var9_13) {
                                    var121_104 = var51_93.f;
                                    var50_105 = true;
                                    if (var121_104[var50_105]) {
                                        var122_106 = var52_97.l((Object)var120_103.L);
                                        var49_107 = 8;
                                        var52_97.f(var122_106, var53_100, 0, var49_107);
                                    } else {
                                        var49_107 = 8;
                                    }
                                } else {
                                    var49_107 = 8;
                                    var50_105 = true;
                                }
                                var56_108 = false;
                                break block79;
                            }
                            var52_97 = var1_1;
                            var53_100 = var45_70;
                            var54_98 = var46_71;
                            var55_102 = var44_69;
                            var49_107 = 8;
                            var50_105 = true;
                            break block80;
                        }
                        var49_107 = 8;
                        var50_105 = true;
                        var51_93 = this;
                        var52_97 = var1_1;
                        var53_100 = var45_70;
                        var54_98 = var46_71;
                        var55_102 = var44_69;
                    }
                    var56_108 = var50_105;
                }
                var57_109 = var51_93.o == 2 ? false : var56_108;
                if (!var57_109 || var51_93.k) break block81;
                var88_110 = var51_93.T[var50_105] == 2 && var51_93 instanceof g != false ? var50_105 : false;
                if (var88_110) {
                    var32_51 = 0;
                }
                var90_112 = (var89_111 = var51_93.U) != null ? var52_97.l((Object)var89_111.L) : null;
                var91_113 = var51_93.U;
                var92_114 = var91_113 != null ? var52_97.l((Object)var91_113.J) : null;
                var93_115 = var51_93.b0;
                if (var93_115 <= 0 && var51_93.h0 != var49_107) ** GOTO lbl335
                var94_116 = var51_93.M;
                if (var94_116.f != null) {
                    var52_97.d(var55_102, var54_98, var93_115, var49_107);
                    var52_97.d(var55_102, var52_97.l((Object)var51_93.M.f), var51_93.M.d(), var49_107);
                    if (var9_13) {
                        var52_97.f(var90_112, var52_97.l((Object)var51_93.L), 0, 5);
                    }
                    var96_117 = false;
                } else {
                    if (var51_93.h0 == var49_107) {
                        var52_97.d(var55_102, var54_98, var94_116.d(), var49_107);
                    } else {
                        var52_97.d(var55_102, var54_98, var93_115, var49_107);
                    }
lbl335: // 3 sources:
                    var96_117 = var40_63;
                }
                var97_118 = var51_93.f[var50_105];
                var98_119 = var51_93.T;
                var99_120 = var98_119[var50_105];
                var100_121 = var51_93.J;
                var101_122 = var51_93.L;
                var102_123 = var51_93.a0;
                var103_124 = var51_93.d0;
                var104_125 = var51_93.B[var50_105];
                var105_126 = var51_93.f0;
                var106_127 = var98_119[0] == 3;
                var107_128 = var51_93.w;
                var108_129 = var51_93.x;
                var109_130 = var51_93.y;
                var110_131 = var9_13;
                var111_132 = var10_14;
                var58_133 = var53_100;
                var59_134 = var54_98;
                this.f(var1_1, false, var110_131, var111_132, var97_118, var92_114, var90_112, var99_120, var88_110, var100_121, var101_122, var102_123, var32_51, var103_124, var104_125, var105_126, var37_60, var106_127, var12_30, var13_29, var43_66, var30_50, var29_52, var107_128, var108_129, var109_130, var96_117);
                break block82;
            }
            var58_133 = var53_100;
            var59_134 = var54_98;
        }
        if (var33_53) {
            var60_135 = this;
            if (var60_135.z == 1) {
                var87_136 = var60_135.A;
                var1_1.h(var58_133, var59_134, var47_72, var48_73, var87_136, 8);
            } else {
                var86_137 = var60_135.A;
                var1_1.h(var47_72, var48_73, var58_133, var59_134, var86_137, 8);
            }
        } else {
            var60_135 = this;
        }
        if (var60_135.P.g()) {
            var61_138 = var60_135.P.f.d;
            var62_139 = (float)Math.toRadians((double)(90.0f + var60_135.C));
            var63_140 = var60_135.P.d();
            var64_141 = e.a.b;
            var65_142 = var1_1.l((Object)var60_135.i(var64_141));
            var66_143 = e.a.c;
            var67_144 = var1_1.l((Object)var60_135.i(var66_143));
            var68_145 = e.a.d;
            var69_146 = var1_1.l((Object)var60_135.i(var68_145));
            var70_147 = e.a.e;
            var71_148 = var1_1.l((Object)var60_135.i(var70_147));
            var72_149 = var1_1.l((Object)var61_138.i(var64_141));
            var73_150 = var1_1.l((Object)var61_138.i(var66_143));
            var74_151 = var1_1.l((Object)var61_138.i(var68_145));
            var75_152 = var1_1.l((Object)var61_138.i(var70_147));
            var76_153 = var1_1.m();
            var77_154 = var62_139;
            var79_155 = Math.sin((double)var77_154);
            var81_156 = var63_140;
            var76_153.g(var67_144, var71_148, var73_150, var75_152, (float)(var79_155 * var81_156));
            var1_1.c(var76_153);
            var84_157 = var1_1.m();
            var84_157.g(var65_142, var69_146, var72_149, var74_151, (float)(var81_156 * Math.cos((double)var77_154)));
            var1_1.c(var84_157);
        }
        this.j = false;
        this.k = false;
    }

    public boolean e() {
        return this.h0 != 8;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void f(z1.c var1_1, boolean var2_2, boolean var3_3, boolean var4_4, boolean var5_5, z1.f var6_6, z1.f var7_7, int var8_8, boolean var9_9, e var10_10, e var11_11, int var12_12, int var13_13, int var14_14, int var15_15, float var16_16, boolean var17_17, boolean var18_18, boolean var19_19, boolean var20_20, boolean var21_21, int var22_22, int var23_23, int var24_24, int var25_25, float var26_26, boolean var27_27) {
        block78 : {
            block76 : {
                block82 : {
                    block108 : {
                        block85 : {
                            block80 : {
                                block84 : {
                                    block107 : {
                                        block106 : {
                                            block105 : {
                                                block88 : {
                                                    block86 : {
                                                        block95 : {
                                                            block104 : {
                                                                block102 : {
                                                                    block103 : {
                                                                        block101 : {
                                                                            block97 : {
                                                                                block100 : {
                                                                                    block99 : {
                                                                                        block98 : {
                                                                                            block96 : {
                                                                                                block94 : {
                                                                                                    block93 : {
                                                                                                        block91 : {
                                                                                                            block92 : {
                                                                                                                block89 : {
                                                                                                                    block90 : {
                                                                                                                        block87 : {
                                                                                                                            block83 : {
                                                                                                                                block81 : {
                                                                                                                                    block79 : {
                                                                                                                                        block77 : {
                                                                                                                                            block70 : {
                                                                                                                                                block72 : {
                                                                                                                                                    block68 : {
                                                                                                                                                        block75 : {
                                                                                                                                                            block74 : {
                                                                                                                                                                block73 : {
                                                                                                                                                                    block71 : {
                                                                                                                                                                        block69 : {
                                                                                                                                                                            block67 : {
                                                                                                                                                                                block66 : {
                                                                                                                                                                                    block64 : {
                                                                                                                                                                                        block65 : {
                                                                                                                                                                                            var28_28 = var24_24;
                                                                                                                                                                                            var29_29 = var25_25;
                                                                                                                                                                                            var30_30 = e.a.e;
                                                                                                                                                                                            var31_31 = var1_1.l((Object)var10_10);
                                                                                                                                                                                            var32_32 = var1_1.l((Object)var11_11);
                                                                                                                                                                                            var33_33 = var1_1.l((Object)var10_10.f);
                                                                                                                                                                                            var34_34 = var1_1.l((Object)var11_11.f);
                                                                                                                                                                                            var35_35 = var10_10.g();
                                                                                                                                                                                            var36_36 = var11_11.g();
                                                                                                                                                                                            var37_37 = this.P.g();
                                                                                                                                                                                            var38_38 = var36_36 != false ? var35_35 + 1 : var35_35;
                                                                                                                                                                                            if (var37_37) {
                                                                                                                                                                                                ++var38_38;
                                                                                                                                                                                            }
                                                                                                                                                                                            var39_39 = var38_38;
                                                                                                                                                                                            var40_40 = var17_17 != false ? 3 : var22_22;
                                                                                                                                                                                            var41_41 = androidx.compose.runtime.b.h((int)var8_8);
                                                                                                                                                                                            var42_42 = var41_41 != 0 && var41_41 != 1 && var41_41 == 2 && var40_40 != 4;
                                                                                                                                                                                            var43_43 = this.h;
                                                                                                                                                                                            if (var43_43 != -1 && var2_2) {
                                                                                                                                                                                                this.h = -1;
                                                                                                                                                                                                var13_13 = var43_43;
                                                                                                                                                                                                var42_42 = false;
                                                                                                                                                                                            }
                                                                                                                                                                                            if ((var44_44 = this.i) != -1 && !var2_2) {
                                                                                                                                                                                                this.i = -1;
                                                                                                                                                                                                var42_42 = false;
                                                                                                                                                                                            } else {
                                                                                                                                                                                                var44_44 = var13_13;
                                                                                                                                                                                            }
                                                                                                                                                                                            var45_45 = this.h0;
                                                                                                                                                                                            var46_46 = var42_42;
                                                                                                                                                                                            if (var45_45 == 8) {
                                                                                                                                                                                                var47_47 = false;
                                                                                                                                                                                                var44_44 = 0;
                                                                                                                                                                                            } else {
                                                                                                                                                                                                var47_47 = var46_46;
                                                                                                                                                                                            }
                                                                                                                                                                                            if (!var27_27) break block64;
                                                                                                                                                                                            if (var35_35 != 0 || var36_36 || var37_37) break block65;
                                                                                                                                                                                            var1_1.e(var31_31, var12_12);
                                                                                                                                                                                            ** GOTO lbl-1000
                                                                                                                                                                                        }
                                                                                                                                                                                        if (var35_35 != 0 && !var36_36) {
                                                                                                                                                                                            var148_48 = var10_10.d();
                                                                                                                                                                                            var48_49 = var37_37;
                                                                                                                                                                                            var49_50 = 8;
                                                                                                                                                                                            var1_1.d(var31_31, var33_33, var148_48, var49_50);
                                                                                                                                                                                        } else lbl-1000: // 2 sources:
                                                                                                                                                                                        {
                                                                                                                                                                                            var48_49 = var37_37;
                                                                                                                                                                                            var49_50 = 8;
                                                                                                                                                                                        }
                                                                                                                                                                                        break block66;
                                                                                                                                                                                    }
                                                                                                                                                                                    var48_49 = var37_37;
                                                                                                                                                                                    var49_50 = 8;
                                                                                                                                                                                }
                                                                                                                                                                                if (var47_47) break block67;
                                                                                                                                                                                if (var9_9) {
                                                                                                                                                                                    var50_51 = 3;
                                                                                                                                                                                    var1_1.d(var32_32, var31_31, 0, var50_51);
                                                                                                                                                                                    if (var14_14 > 0) {
                                                                                                                                                                                        var147_52 = 8;
                                                                                                                                                                                        var1_1.f(var32_32, var31_31, var14_14, var147_52);
                                                                                                                                                                                    } else {
                                                                                                                                                                                        var147_52 = 8;
                                                                                                                                                                                    }
                                                                                                                                                                                    if (var15_15 < Integer.MAX_VALUE) {
                                                                                                                                                                                        var1_1.g(var32_32, var31_31, var15_15, var147_52);
                                                                                                                                                                                    }
                                                                                                                                                                                } else {
                                                                                                                                                                                    var50_51 = 3;
                                                                                                                                                                                    var1_1.d(var32_32, var31_31, var44_44, var49_50);
                                                                                                                                                                                }
                                                                                                                                                                                break block68;
                                                                                                                                                                            }
                                                                                                                                                                            var50_51 = 3;
                                                                                                                                                                            if (var39_39 == 2 || var17_17 || var40_40 != 1 && var40_40 != 0) break block69;
                                                                                                                                                                            var143_56 = Math.max((int)var28_28, (int)var44_44);
                                                                                                                                                                            if (var29_29 > 0) {
                                                                                                                                                                                var143_56 = Math.min((int)var29_29, (int)var143_56);
                                                                                                                                                                            }
                                                                                                                                                                            var1_1.d(var32_32, var31_31, var143_56, 8);
                                                                                                                                                                            var54_53 = var5_5;
                                                                                                                                                                            var52_54 = var28_28;
                                                                                                                                                                            var53_55 = false;
                                                                                                                                                                            break block70;
                                                                                                                                                                        }
                                                                                                                                                                        if (var28_28 == -2) {
                                                                                                                                                                            var28_28 = var44_44;
                                                                                                                                                                        }
                                                                                                                                                                        if (var29_29 == -2) {
                                                                                                                                                                            var29_29 = var44_44;
                                                                                                                                                                        }
                                                                                                                                                                        if (var44_44 > 0 && var40_40 != 1) {
                                                                                                                                                                            var44_44 = 0;
                                                                                                                                                                        }
                                                                                                                                                                        if (var28_28 > 0) {
                                                                                                                                                                            var1_1.f(var32_32, var31_31, var28_28, 8);
                                                                                                                                                                            var44_44 = Math.max((int)var44_44, (int)var28_28);
                                                                                                                                                                        }
                                                                                                                                                                        if (var29_29 > 0) {
                                                                                                                                                                            var142_57 = var3_3 == false || var40_40 != 1;
                                                                                                                                                                            if (var142_57) {
                                                                                                                                                                                var51_58 = 8;
                                                                                                                                                                                var1_1.g(var32_32, var31_31, var29_29, var51_58);
                                                                                                                                                                            } else {
                                                                                                                                                                                var51_58 = 8;
                                                                                                                                                                            }
                                                                                                                                                                            var44_44 = Math.min((int)var44_44, (int)var29_29);
                                                                                                                                                                        } else {
                                                                                                                                                                            var51_58 = 8;
                                                                                                                                                                        }
                                                                                                                                                                        if (var40_40 != 1) break block71;
                                                                                                                                                                        if (var3_3) {
                                                                                                                                                                            var1_1.d(var32_32, var31_31, var44_44, var51_58);
                                                                                                                                                                        } else if (var19_19) {
                                                                                                                                                                            var1_1.d(var32_32, var31_31, var44_44, 5);
                                                                                                                                                                            var1_1.g(var32_32, var31_31, var44_44, var51_58);
                                                                                                                                                                        } else {
                                                                                                                                                                            var1_1.d(var32_32, var31_31, var44_44, 5);
                                                                                                                                                                            var1_1.g(var32_32, var31_31, var44_44, var51_58);
                                                                                                                                                                        }
                                                                                                                                                                        break block68;
                                                                                                                                                                    }
                                                                                                                                                                    if (var40_40 != 2) break block72;
                                                                                                                                                                    var130_59 = var10_10.e;
                                                                                                                                                                    var131_60 = e.a.c;
                                                                                                                                                                    if (var130_59 == var131_60) break block73;
                                                                                                                                                                    var132_61 = var30_30;
                                                                                                                                                                    if (var130_59 == var132_61) break block74;
                                                                                                                                                                    var133_62 = var1_1.l((Object)this.U.i(e.a.b));
                                                                                                                                                                    var134_63 = var1_1.l((Object)this.U.i(e.a.d));
                                                                                                                                                                    break block75;
                                                                                                                                                                }
                                                                                                                                                                var132_61 = var30_30;
                                                                                                                                                            }
                                                                                                                                                            var133_62 = var1_1.l((Object)this.U.i(var131_60));
                                                                                                                                                            var134_63 = var1_1.l((Object)this.U.i(var132_61));
                                                                                                                                                        }
                                                                                                                                                        var135_64 = var133_62;
                                                                                                                                                        var136_65 = var134_63;
                                                                                                                                                        var137_66 = var1_1.m();
                                                                                                                                                        var137_66.d(var32_32, var31_31, var136_65, var135_64, var26_26);
                                                                                                                                                        var1_1.c(var137_66);
                                                                                                                                                        if (var3_3) {
                                                                                                                                                            var47_47 = false;
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                    var54_53 = var5_5;
                                                                                                                                                    var52_54 = var28_28;
                                                                                                                                                    var53_55 = var47_47;
                                                                                                                                                    break block70;
                                                                                                                                                }
                                                                                                                                                var52_54 = var28_28;
                                                                                                                                                var53_55 = var47_47;
                                                                                                                                                var54_53 = true;
                                                                                                                                            }
                                                                                                                                            if (!var27_27) break block76;
                                                                                                                                            if (!var19_19) break block77;
                                                                                                                                            var55_67 = var6_6;
                                                                                                                                            var56_68 = var39_39;
                                                                                                                                            var57_69 = var32_32;
                                                                                                                                            var58_70 = var31_31;
                                                                                                                                            var59_71 = var50_51;
                                                                                                                                            var60_72 = var54_53;
                                                                                                                                            var63_73 = 2;
                                                                                                                                            var61_74 = 1;
                                                                                                                                            var62_75 = var7_7;
                                                                                                                                            break block78;
                                                                                                                                        }
                                                                                                                                        if (var35_35 != 0 || var36_36 || var48_49) break block79;
                                                                                                                                        var70_76 = var32_32;
                                                                                                                                        var71_77 = var54_53;
                                                                                                                                        var69_78 = var34_34;
                                                                                                                                        break block80;
                                                                                                                                    }
                                                                                                                                    if (var35_35 == 0 || var36_36) break block81;
                                                                                                                                    var129_80 = var10_10.f.d;
                                                                                                                                    var74_81 = var3_3 != false && var129_80 instanceof b != false ? 8 : 5;
                                                                                                                                    var73_82 = var3_3;
                                                                                                                                    var70_76 = var32_32;
                                                                                                                                    var71_77 = var54_53;
                                                                                                                                    var69_78 = var34_34;
                                                                                                                                    break block82;
                                                                                                                                }
                                                                                                                                if (var35_35 != 0 || !var36_36) break block83;
                                                                                                                                var127_83 = -var11_11.d();
                                                                                                                                var68_84 = var34_34;
                                                                                                                                var1_1.d(var32_32, var68_84, var127_83, 8);
                                                                                                                                if (!var3_3) break block84;
                                                                                                                                var1_1.f(var31_31, var6_6, 0, 5);
                                                                                                                                var72_79 = 5;
                                                                                                                                var69_78 = var68_84;
                                                                                                                                var70_76 = var32_32;
                                                                                                                                var71_77 = var54_53;
                                                                                                                                break block85;
                                                                                                                            }
                                                                                                                            var68_84 = var34_34;
                                                                                                                            if (var35_35 == 0 || !var36_36) break block84;
                                                                                                                            var77_85 = var10_10.f.d;
                                                                                                                            var79_86 = var11_11.f.d;
                                                                                                                            var80_87 = this.U;
                                                                                                                            var81_88 = 6;
                                                                                                                            if (!var53_55) break block86;
                                                                                                                            if (var40_40 != 0) break block87;
                                                                                                                            if (var29_29 == 0 && var52_54 == 0) {
                                                                                                                                if (var33_33.g && var68_84.g) {
                                                                                                                                    var1_1.d(var31_31, var33_33, var10_10.d(), 8);
                                                                                                                                    var1_1.d(var32_32, var68_84, -var11_11.d(), 8);
                                                                                                                                    return;
                                                                                                                                }
                                                                                                                                var121_89 = 8;
                                                                                                                                var122_90 = 8;
                                                                                                                                var123_91 = 1;
                                                                                                                                var124_92 = 0;
                                                                                                                                var85_93 = 0;
                                                                                                                            } else {
                                                                                                                                var121_89 = 5;
                                                                                                                                var122_90 = 5;
                                                                                                                                var123_91 = 0;
                                                                                                                                var124_92 = 1;
                                                                                                                                var85_93 = 1;
                                                                                                                            }
                                                                                                                            if (!(var77_85 instanceof b) && !(var79_86 instanceof b)) {
                                                                                                                                var88_94 = var121_89;
                                                                                                                                var84_95 = var7_7;
                                                                                                                                var90_96 = var123_91;
                                                                                                                                var86_97 = var124_92;
                                                                                                                                var87_98 = var81_88;
                                                                                                                                var89_99 = var122_90;
                                                                                                                                var82_100 = var40_40;
                                                                                                                                var83_101 = 1;
                                                                                                                            } else {
                                                                                                                                var88_94 = var121_89;
                                                                                                                                var84_95 = var7_7;
                                                                                                                                var82_100 = var40_40;
                                                                                                                                var90_96 = var123_91;
                                                                                                                                var86_97 = var124_92;
                                                                                                                                var83_101 = 1;
                                                                                                                                var89_99 = 4;
                                                                                                                                var87_98 = var81_88;
                                                                                                                            }
                                                                                                                            break block88;
                                                                                                                        }
                                                                                                                        if (var40_40 != 2) break block89;
                                                                                                                        if (var77_85 instanceof b || var79_86 instanceof b) break block90;
                                                                                                                        var84_95 = var7_7;
                                                                                                                        var82_100 = var40_40;
                                                                                                                        var87_98 = var81_88;
                                                                                                                        var88_94 = 5;
                                                                                                                        var83_101 = 1;
                                                                                                                        var89_99 = 5;
                                                                                                                        break block91;
                                                                                                                    }
                                                                                                                    var84_95 = var7_7;
                                                                                                                    var82_100 = var40_40;
                                                                                                                    var87_98 = var81_88;
                                                                                                                    var88_94 = 5;
                                                                                                                    break block92;
                                                                                                                }
                                                                                                                if (var40_40 != 1) break block93;
                                                                                                                var84_95 = var7_7;
                                                                                                                var82_100 = var40_40;
                                                                                                                var87_98 = var81_88;
                                                                                                                var88_94 = 8;
                                                                                                            }
                                                                                                            var83_101 = 1;
                                                                                                            var89_99 = 4;
                                                                                                        }
                                                                                                        var85_93 = 1;
                                                                                                        var90_96 = 0;
                                                                                                        break block94;
                                                                                                    }
                                                                                                    if (var40_40 != 3) break block95;
                                                                                                    var118_102 = this.z;
                                                                                                    var82_100 = var40_40;
                                                                                                    if (var118_102 != -1) break block96;
                                                                                                    var84_95 = var7_7;
                                                                                                    var88_94 = 8;
                                                                                                    var83_101 = 1;
                                                                                                    var87_98 = var20_20 ? (var3_3 ? 5 : 4) : 8;
                                                                                                    var89_99 = 5;
                                                                                                    var85_93 = 1;
                                                                                                    var90_96 = 1;
                                                                                                }
                                                                                                var86_97 = 1;
                                                                                                break block88;
                                                                                            }
                                                                                            if (!var17_17) break block97;
                                                                                            if (var23_23 == 2) break block98;
                                                                                            var83_101 = 1;
                                                                                            if (var23_23 == var83_101) break block99;
                                                                                            var119_103 = 0;
                                                                                            break block100;
                                                                                        }
                                                                                        var83_101 = 1;
                                                                                    }
                                                                                    var119_103 = var83_101;
                                                                                }
                                                                                if (var119_103 == 0) {
                                                                                    var88_94 = 8;
                                                                                    var120_104 = 5;
                                                                                } else {
                                                                                    var88_94 = 5;
                                                                                    var120_104 = 4;
                                                                                }
                                                                                var89_99 = var120_104;
                                                                                var86_97 = var90_96 = (var85_93 = var83_101);
                                                                                var87_98 = var81_88;
                                                                                var84_95 = var7_7;
                                                                                break block88;
                                                                            }
                                                                            var83_101 = 1;
                                                                            if (var29_29 <= 0) break block101;
                                                                            var84_95 = var7_7;
                                                                            var86_97 = var90_96 = (var85_93 = var83_101);
                                                                            var87_98 = var81_88;
                                                                            var88_94 = 5;
                                                                            var89_99 = 5;
                                                                            break block88;
                                                                        }
                                                                        if (var29_29 != 0 || var52_54 != 0) break block102;
                                                                        if (var20_20) break block103;
                                                                        var84_95 = var7_7;
                                                                        var86_97 = var90_96 = (var85_93 = var83_101);
                                                                        var87_98 = var81_88;
                                                                        var88_94 = 5;
                                                                        var89_99 = 8;
                                                                        break block88;
                                                                    }
                                                                    var88_94 = var77_85 != var80_87 && var79_86 != var80_87 ? 4 : 5;
                                                                    var84_95 = var7_7;
                                                                    var86_97 = var90_96 = (var85_93 = var83_101);
                                                                    var87_98 = var81_88;
                                                                    break block104;
                                                                }
                                                                var84_95 = var7_7;
                                                                var86_97 = var90_96 = (var85_93 = var83_101);
                                                                var87_98 = var81_88;
                                                                var88_94 = 5;
                                                            }
                                                            var89_99 = 4;
                                                            break block88;
                                                        }
                                                        var82_100 = var40_40;
                                                        var83_101 = 1;
                                                        var84_95 = var7_7;
                                                        var87_98 = var81_88;
                                                        var88_94 = 5;
                                                        var89_99 = 4;
                                                        var85_93 = 0;
                                                        var90_96 = 0;
                                                        var86_97 = 0;
                                                        break block88;
                                                    }
                                                    var82_100 = var40_40;
                                                    var83_101 = 1;
                                                    if (var33_33.g && var68_84.g) {
                                                        var114_105 = var10_10.d();
                                                        var115_106 = var11_11.d();
                                                        var1_1.b(var31_31, var33_33, var114_105, var16_16, var68_84, var32_32, var115_106, 8);
                                                        if (var3_3 == false) return;
                                                        if (var54_53 == false) return;
                                                        if (var11_11.f != null) {
                                                            var117_107 = var11_11.d();
                                                            var116_108 = var7_7;
                                                        } else {
                                                            var116_108 = var7_7;
                                                            var117_107 = 0;
                                                        }
                                                        if (var68_84 == var116_108) return;
                                                        var1_1.f(var116_108, var32_32, var117_107, 5);
                                                        return;
                                                    }
                                                    var84_95 = var7_7;
                                                    var86_97 = var85_93 = var83_101;
                                                    var87_98 = var81_88;
                                                    var88_94 = 5;
                                                    var89_99 = 4;
                                                    var90_96 = 0;
                                                }
                                                if (var86_97 != 0 && var33_33 == var68_84 && var77_85 != var80_87) {
                                                    var91_109 = 0;
                                                    var86_97 = 0;
                                                } else {
                                                    var91_109 = var83_101;
                                                }
                                                if (var85_93 != 0) {
                                                    if (!(var53_55 || var18_18 || var20_20 || var33_33 != var6_6 || var68_84 != var84_95)) {
                                                        var109_110 = 8;
                                                        var111_111 = 8;
                                                        var73_82 = false;
                                                        var110_112 = 0;
                                                    } else {
                                                        var109_110 = var88_94;
                                                        var110_112 = var91_109;
                                                        var111_111 = var87_98;
                                                        var73_82 = var3_3;
                                                    }
                                                    var112_113 = var10_10.d();
                                                    var113_114 = var11_11.d();
                                                    var93_115 = var77_85;
                                                    var71_77 = var54_53;
                                                    var99_116 = var79_86;
                                                    var94_117 = var68_84;
                                                    var98_118 = 4;
                                                    var97_119 = 1;
                                                    var95_120 = var33_33;
                                                    var96_121 = var32_32;
                                                    var92_122 = var80_87;
                                                    var100_123 = var31_31;
                                                    var1_1.b(var31_31, var33_33, var112_113, var16_16, var68_84, var32_32, var113_114, var111_111);
                                                    var88_94 = var109_110;
                                                    var101_124 = var110_112;
                                                } else {
                                                    var92_122 = var80_87;
                                                    var93_115 = var77_85;
                                                    var94_117 = var68_84;
                                                    var95_120 = var33_33;
                                                    var96_121 = var32_32;
                                                    var71_77 = var54_53;
                                                    var97_119 = var83_101;
                                                    var98_118 = 4;
                                                    var99_116 = var79_86;
                                                    var100_123 = var31_31;
                                                    var73_82 = var3_3;
                                                    var101_124 = var91_109;
                                                }
                                                if (this.h0 == 8 && !var11_11.f()) {
                                                    return;
                                                }
                                                if (var86_97 != 0) {
                                                    if (var73_82) {
                                                        var69_78 = var94_117;
                                                        if (var95_120 != var69_78 && !var53_55 && (var93_115 instanceof b || var99_116 instanceof b)) {
                                                            var88_94 = var81_88;
                                                        }
                                                    } else {
                                                        var69_78 = var94_117;
                                                    }
                                                    var1_1.f(var100_123, var95_120, var10_10.d(), var88_94);
                                                    var1_1.g(var96_121, var69_78, -var11_11.d(), var88_94);
                                                } else {
                                                    var69_78 = var94_117;
                                                }
                                                if (!var73_82 || !var21_21 || var93_115 instanceof b || var99_116 instanceof b) break block105;
                                                var102_125 = var92_122;
                                                if (var99_116 == var102_125) break block106;
                                                var88_94 = var103_126 = var81_88;
                                                var101_124 = var97_119;
                                                break block107;
                                            }
                                            var102_125 = var92_122;
                                        }
                                        var103_126 = var89_99;
                                    }
                                    if (var101_124 != 0) {
                                        if (var90_96 != 0 && (!var20_20 || var4_4)) {
                                            if (var93_115 != var102_125 && var99_116 != var102_125) {
                                                var81_88 = var103_126;
                                            }
                                            if (var93_115 instanceof h || var99_116 instanceof h) {
                                                var81_88 = 5;
                                            }
                                            if (var93_115 instanceof b || var99_116 instanceof b) {
                                                var81_88 = 5;
                                            }
                                            var108_127 = var20_20 != false ? 5 : var81_88;
                                            var103_126 = Math.max((int)var108_127, (int)var103_126);
                                        }
                                        var105_128 = var103_126;
                                        if (var73_82) {
                                            var105_128 = Math.min((int)var88_94, (int)var105_128);
                                            if (var17_17 && !var20_20 && (var93_115 == var102_125 || var99_116 == var102_125)) {
                                                var105_128 = var98_118;
                                            }
                                        }
                                        var1_1.d(var100_123, var95_120, var10_10.d(), var105_128);
                                        var1_1.d(var96_121, var69_78, -var11_11.d(), var105_128);
                                    }
                                    if (var73_82) {
                                        var70_76 = var96_121;
                                        var104_129 = var6_6 == var95_120 ? var10_10.d() : 0;
                                        if (var95_120 != var6_6) {
                                            var1_1.f(var100_123, var6_6, var104_129, 5);
                                        }
                                    } else {
                                        var70_76 = var96_121;
                                    }
                                    if (!var73_82 || !var53_55 || var14_14 != 0 || var52_54 != 0) ** GOTO lbl459
                                    if (!var53_55 || var82_100 != 3) {
                                        var72_79 = 5;
                                        var1_1.f(var70_76, var100_123, 0, var72_79);
                                    } else {
                                        var1_1.f(var70_76, var100_123, 0, 8);
lbl459: // 2 sources:
                                        var72_79 = 5;
                                    }
                                    break block108;
                                }
                                var69_78 = var68_84;
                                var70_76 = var32_32;
                                var71_77 = var54_53;
                            }
                            var72_79 = 5;
                        }
                        var73_82 = var3_3;
                    }
                    var74_81 = var72_79;
                }
                if (var73_82 == false) return;
                if (var71_77 == false) return;
                if (var11_11.f != null) {
                    var76_130 = var11_11.d();
                    var75_131 = var7_7;
                } else {
                    var75_131 = var7_7;
                    var76_130 = 0;
                }
                if (var69_78 == var75_131) return;
                var1_1.f(var75_131, var70_76, var76_130, var74_81);
                return;
            }
            var55_67 = var6_6;
            var56_68 = var39_39;
            var57_69 = var32_32;
            var58_70 = var31_31;
            var59_71 = var50_51;
            var60_72 = var54_53;
            var61_74 = 1;
            var62_75 = var7_7;
            var63_73 = 2;
        }
        if (var56_68 >= var63_73) return;
        if (var3_3 == false) return;
        if (var60_72 == false) return;
        var1_1.f(var58_70, var55_67, 0, 8);
        var64_132 = !var2_2 && this.M.f != null ? 0 : var61_74;
        if (!var2_2 && (var65_133 = this.M.f) != null) {
            var66_134 = var65_133.d;
            var64_132 = var66_134.X != 0.0f && (var67_135 = var66_134.T)[0] == var59_71 && var67_135[var61_74] == var59_71 ? var61_74 : 0;
        }
        if (var64_132 == 0) return;
        var1_1.f(var62_75, var57_69, 0, 8);
    }

    public void g(z1.c c3) {
        c3.l((Object)this.I);
        c3.l((Object)this.J);
        c3.l((Object)this.K);
        c3.l((Object)this.L);
        if (this.b0 > 0) {
            c3.l((Object)this.M);
        }
    }

    public void h() {
        if (this.d == null) {
            this.d = new c2.l(this);
        }
        if (this.e == null) {
            this.e = new n(this);
        }
    }

    public e i(e.a a3) {
        switch (a3.ordinal()) {
            default: {
                throw new AssertionError((Object)a3.name());
            }
            case 8: {
                return this.O;
            }
            case 7: {
                return this.N;
            }
            case 6: {
                return this.P;
            }
            case 5: {
                return this.M;
            }
            case 4: {
                return this.L;
            }
            case 3: {
                return this.K;
            }
            case 2: {
                return this.J;
            }
            case 1: {
                return this.I;
            }
            case 0: 
        }
        return null;
    }

    public int j() {
        return this.t() + this.W;
    }

    public int k(int n2) {
        if (n2 == 0) {
            return this.m();
        }
        if (n2 == 1) {
            return this.q();
        }
        return 0;
    }

    public int l() {
        if (this.h0 == 8) {
            return 0;
        }
        return this.W;
    }

    public int m() {
        return this.T[0];
    }

    public f n(int n2) {
        if (n2 == 0) {
            e e2 = this.K;
            e e3 = e2.f;
            if (e3 != null && e3.f == e2) {
                return e3.d;
            }
        } else if (n2 == 1) {
            e e4 = this.L;
            e e5 = e4.f;
            if (e5 != null && e5.f == e4) {
                return e5.d;
            }
        }
        return null;
    }

    public f o(int n2) {
        if (n2 == 0) {
            e e2 = this.I;
            e e3 = e2.f;
            if (e3 != null && e3.f == e2) {
                return e3.d;
            }
        } else if (n2 == 1) {
            e e4 = this.J;
            e e5 = e4.f;
            if (e5 != null && e5.f == e4) {
                return e5.d;
            }
        }
        return null;
    }

    public int p() {
        return this.s() + this.V;
    }

    public int q() {
        return this.T[1];
    }

    public int r() {
        if (this.h0 == 8) {
            return 0;
        }
        return this.V;
    }

    public int s() {
        f f2 = this.U;
        if (f2 != null && f2 instanceof g) {
            return ((g)f2).x0 + this.Z;
        }
        return this.Z;
    }

    public int t() {
        f f2 = this.U;
        if (f2 != null && f2 instanceof g) {
            return ((g)f2).y0 + this.a0;
        }
        return this.a0;
    }

    public String toString() {
        String string = "";
        StringBuilder stringBuilder = android.support.v4.media.b.a((String)string);
        if (this.i0 != null) {
            string = a.a(android.support.v4.media.b.a((String)"id: "), this.i0, " ");
        }
        stringBuilder.append(string);
        stringBuilder.append("(");
        stringBuilder.append(this.Z);
        stringBuilder.append(", ");
        stringBuilder.append(this.a0);
        stringBuilder.append(") - (");
        stringBuilder.append(this.V);
        stringBuilder.append(" x ");
        return m.a((StringBuilder)stringBuilder, (int)this.W, (String)")");
    }

    public boolean u(int n2) {
        int n3;
        int n4;
        if (n2 == 0) {
            int n5;
            int n6 = this.I.f != null ? 1 : 0;
            return n6 + (n5 = this.K.f != null ? 1 : 0) < 2;
        }
        int n7 = this.J.f != null ? 1 : 0;
        int n8 = n7 + (n3 = this.L.f != null ? 1 : 0);
        return n8 + (n4 = this.M.f != null ? 1 : 0) < 2;
    }

    public boolean v(int n2, int n3) {
        if (n2 == 0) {
            e e2;
            e e3 = this.I.f;
            if (e3 != null && e3.c && (e2 = this.K.f) != null && e2.c) {
                return e2.c() - this.K.d() - (this.I.f.c() + this.I.d()) >= n3;
            }
        } else {
            e e4;
            e e5 = this.J.f;
            if (e5 != null && e5.c && (e4 = this.L.f) != null && e4.c) {
                return e4.c() - this.L.d() - (this.J.f.c() + this.J.d()) >= n3;
            }
        }
        return false;
    }

    public final boolean w(int n2) {
        int n3 = n2 * 2;
        e[] arre = this.Q;
        if (arre[n3].f != null && arre[n3].f.f != arre[n3]) {
            int n4 = n3 + 1;
            if (arre[n4].f != null && arre[n4].f.f == arre[n4]) {
                return true;
            }
        }
        return false;
    }

    public boolean x() {
        block3 : {
            block2 : {
                e e2 = this.I;
                e e3 = e2.f;
                if (e3 != null && e3.f == e2) break block2;
                e e4 = this.K;
                e e5 = e4.f;
                if (e5 == null || e5.f != e4) break block3;
            }
            return true;
        }
        return false;
    }

    public boolean y() {
        block3 : {
            block2 : {
                e e2 = this.J;
                e e3 = e2.f;
                if (e3 != null && e3.f == e2) break block2;
                e e4 = this.L;
                e e5 = e4.f;
                if (e5 == null || e5.f != e4) break block3;
            }
            return true;
        }
        return false;
    }

    public boolean z() {
        return this.g && this.h0 != 8;
    }
}

