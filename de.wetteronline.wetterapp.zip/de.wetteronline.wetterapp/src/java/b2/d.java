/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 */
package b2;

import b2.f;
import java.util.ArrayList;

public class d {
    public f a;
    public f b;
    public f c;
    public f d;
    public f e;
    public f f;
    public f g;
    public ArrayList<f> h;
    public int i;
    public int j;
    public float k = 0.0f;
    public int l;
    public int m;
    public int n;
    public int o;
    public boolean p = false;
    public boolean q;
    public boolean r;
    public boolean s;
    public boolean t;

    public d(f f2, int n2, boolean bl) {
        this.a = f2;
        this.o = n2;
        this.p = bl;
    }
}

