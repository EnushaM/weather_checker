/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b2.j
 */
package b2;

import b2.f;
import b2.g;
import b2.j;

public class l
extends j {
    public void a(g g2) {
        for (int i2 = 0; i2 < this.r0; ++i2) {
            f f2 = this.q0[i2];
            if (f2 == null) continue;
            f2.F = true;
        }
    }
}

