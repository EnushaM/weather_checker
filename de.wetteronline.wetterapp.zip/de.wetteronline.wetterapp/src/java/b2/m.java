/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 */
package b2;

import a4.g;
import b2.f;
import java.util.ArrayList;

public class m
extends f {
    public ArrayList<f> q0 = new ArrayList();

    @Override
    public void C() {
        this.q0.clear();
        super.C();
    }

    @Override
    public void E(g g3) {
        super.E(g3);
        int n2 = this.q0.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            ((f)this.q0.get(i2)).E(g3);
        }
    }

    public void Q() {
        ArrayList<f> arrayList = this.q0;
        if (arrayList == null) {
            return;
        }
        int n2 = arrayList.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            f f2 = (f)this.q0.get(i2);
            if (!(f2 instanceof m)) continue;
            ((m)f2).Q();
        }
    }
}

