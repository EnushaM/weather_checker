/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  androidx.appcompat.app.n
 *  b2.j
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  z1.c
 *  z1.f
 */
package b2;

import androidx.appcompat.app.n;
import b2.a;
import b2.e;
import b2.f;
import b2.j;
import z1.c;

public class b
extends j {
    public int s0 = 0;
    public boolean t0 = true;
    public int u0 = 0;
    public boolean v0 = false;

    public boolean A() {
        return this.v0;
    }

    public boolean B() {
        return this.v0;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean R() {
        boolean bl;
        int n2;
        int n3;
        e.a a2 = e.a.e;
        e.a a3 = e.a.c;
        e.a a4 = e.a.d;
        e.a a5 = e.a.b;
        int n4 = 0;
        boolean bl2 = true;
        for (int i2 = 0; i2 < (n3 = this.r0); ++i2) {
            int n5;
            int n6;
            f f2 = this.q0[i2];
            if (!this.t0 && !f2.e() || ((n6 = this.s0) != 0 && n6 != 1 || f2.A()) && ((n5 = this.s0) != 2 && n5 != 3 || f2.B())) continue;
            bl2 = false;
        }
        if (bl2 && n3 > 0) {
            n2 = 0;
            bl = false;
        } else {
            return false;
        }
        while (n4 < this.r0) {
            f f3 = this.q0[n4];
            if (this.t0 || f3.e()) {
                int n7;
                if (!bl) {
                    int n8 = this.s0;
                    if (n8 == 0) {
                        n2 = f3.i(a5).c();
                    } else if (n8 == 1) {
                        n2 = f3.i(a4).c();
                    } else if (n8 == 2) {
                        n2 = f3.i(a3).c();
                    } else if (n8 == 3) {
                        n2 = f3.i(a2).c();
                    }
                    bl = true;
                }
                if ((n7 = this.s0) == 0) {
                    n2 = Math.min((int)n2, (int)f3.i(a5).c());
                } else if (n7 == 1) {
                    n2 = Math.max((int)n2, (int)f3.i(a4).c());
                } else if (n7 == 2) {
                    n2 = Math.min((int)n2, (int)f3.i(a3).c());
                } else if (n7 == 3) {
                    n2 = Math.max((int)n2, (int)f3.i(a2).c());
                }
            }
            ++n4;
        }
        int n9 = n2 + this.u0;
        int n10 = this.s0;
        if (n10 != 0 && n10 != 1) {
            ((f)((Object)this)).H(n9, n9);
        } else {
            ((f)((Object)this)).G(n9, n9);
        }
        this.v0 = true;
        return true;
    }

    public int S() {
        int n2 = this.s0;
        if (n2 != 0 && n2 != 1) {
            if (n2 != 2 && n2 != 3) {
                return -1;
            }
            return 1;
        }
        return 0;
    }

    public void d(c c2, boolean bl) {
        e[] arre;
        e[] arre2 = ((f)this).Q;
        arre2[0] = ((f)this).I;
        arre2[2] = ((f)this).J;
        arre2[1] = ((f)this).K;
        arre2[3] = ((f)this).L;
        for (int i2 = 0; i2 < (arre = ((f)this).Q).length; ++i2) {
            arre[i2].i = c2.l((Object)arre[i2]);
        }
        int n2 = this.s0;
        if (n2 >= 0 && n2 < 4) {
            boolean bl2;
            int n3;
            e e2;
            block16 : {
                e2 = arre[n2];
                if (!this.v0) {
                    this.R();
                }
                if (this.v0) {
                    this.v0 = false;
                    int n4 = this.s0;
                    if (n4 != 0 && n4 != 1) {
                        if (n4 == 2 || n4 == 3) {
                            c2.e(this.J.i, ((f)this).a0);
                            c2.e(this.L.i, ((f)this).a0);
                            return;
                        }
                    } else {
                        c2.e(this.I.i, ((f)this).Z);
                        c2.e(this.K.i, ((f)this).Z);
                    }
                    return;
                }
                for (int i3 = 0; i3 < this.r0; ++i3) {
                    int n5;
                    int n6;
                    f f2 = this.q0[i3];
                    if (!this.t0 && !f2.e() || ((n5 = this.s0) != 0 && n5 != 1 || f2.m() != 3 || f2.I.f == null || f2.K.f == null) && ((n6 = this.s0) != 2 && n6 != 3 || f2.q() != 3 || f2.J.f == null || f2.L.f == null)) continue;
                    bl2 = true;
                    break block16;
                }
                bl2 = false;
            }
            boolean bl3 = ((f)this).I.e() || ((f)this).K.e();
            boolean bl4 = ((f)this).J.e() || ((f)this).L.e();
            boolean bl5 = !bl2 && ((n3 = this.s0) == 0 && bl3 || n3 == 2 && bl4 || n3 == 1 && bl3 || n3 == 3 && bl4);
            int n7 = 5;
            if (!bl5) {
                n7 = 4;
            }
            for (int i4 = 0; i4 < this.r0; ++i4) {
                f f3 = this.q0[i4];
                if (!this.t0 && !f3.e()) continue;
                z1.f f4 = c2.l((Object)f3.Q[this.s0]);
                e[] arre3 = f3.Q;
                int n8 = this.s0;
                arre3[n8].i = f4;
                int n9 = arre3[n8].f != null && arre3[n8].f.d == this ? 0 + arre3[n8].g : 0;
                if (n8 != 0 && n8 != 2) {
                    z1.f f5 = e2.i;
                    int n10 = n9 + this.u0;
                    z1.b b2 = c2.m();
                    z1.f f6 = c2.n();
                    f6.e = 0;
                    b2.e(f5, f4, f6, n10);
                    c2.c(b2);
                } else {
                    z1.f f7 = e2.i;
                    int n11 = this.u0 - n9;
                    z1.b b3 = c2.m();
                    z1.f f8 = c2.n();
                    f8.e = 0;
                    b3.f(f7, f4, f8, n11);
                    c2.c(b3);
                }
                c2.d(e2.i, f4, n9 + this.u0, n7);
            }
            int n12 = this.s0;
            if (n12 == 0) {
                c2.d(this.K.i, this.I.i, 0, 8);
                c2.d(this.I.i, this.U.K.i, 0, 4);
                c2.d(this.I.i, this.U.I.i, 0, 0);
                return;
            }
            if (n12 == 1) {
                c2.d(this.I.i, this.K.i, 0, 8);
                c2.d(this.I.i, this.U.I.i, 0, 4);
                c2.d(this.I.i, this.U.K.i, 0, 0);
                return;
            }
            if (n12 == 2) {
                c2.d(this.L.i, this.J.i, 0, 8);
                c2.d(this.J.i, this.U.L.i, 0, 4);
                c2.d(this.J.i, this.U.J.i, 0, 0);
                return;
            }
            if (n12 == 3) {
                c2.d(this.J.i, this.L.i, 0, 8);
                c2.d(this.J.i, this.U.J.i, 0, 4);
                c2.d(this.J.i, this.U.L.i, 0, 0);
            }
        }
    }

    public boolean e() {
        return true;
    }

    public String toString() {
        String string = a.a(android.support.v4.media.b.a((String)"[Barrier] "), ((f)this).i0, " {");
        for (int i2 = 0; i2 < this.r0; ++i2) {
            f f2 = this.q0[i2];
            if (i2 > 0) {
                string = n.a((String)string, (String)", ");
            }
            StringBuilder stringBuilder = android.support.v4.media.b.a((String)string);
            stringBuilder.append(f2.i0);
            string = stringBuilder.toString();
        }
        return n.a((String)string, (String)"}");
    }
}

