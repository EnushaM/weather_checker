/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b2.g
 *  java.lang.Object
 *  z1.c
 *  z1.f
 */
package b2;

import b2.e;
import b2.f;
import b2.g;
import z1.c;

public class k {
    public static boolean[] a = new boolean[3];

    public static void a(g g3, c c3, f f2) {
        f2.n = -1;
        f2.o = -1;
        if (g3.T[0] != 2 && f2.T[0] == 4) {
            int n2;
            int n3 = f2.I.g;
            int n4 = g3.r() - f2.K.g;
            e e2 = f2.I;
            e2.i = c3.l((Object)e2);
            e e3 = f2.K;
            e3.i = c3.l((Object)e3);
            c3.e(f2.I.i, n3);
            c3.e(f2.K.i, n4);
            f2.n = 2;
            f2.Z = n3;
            f2.V = n2 = n4 - n3;
            int n5 = f2.c0;
            if (n2 < n5) {
                f2.V = n5;
            }
        }
        if (g3.T[1] != 2 && f2.T[1] == 4) {
            int n6;
            int n7 = f2.J.g;
            int n8 = g3.l() - f2.L.g;
            e e4 = f2.J;
            e4.i = c3.l((Object)e4);
            e e5 = f2.L;
            e5.i = c3.l((Object)e5);
            c3.e(f2.J.i, n7);
            c3.e(f2.L.i, n8);
            if (f2.b0 > 0 || f2.h0 == 8) {
                e e6 = f2.M;
                e6.i = c3.l((Object)e6);
                c3.e(f2.M.i, n7 + f2.b0);
            }
            f2.o = 2;
            f2.a0 = n7;
            f2.W = n6 = n8 - n7;
            int n9 = f2.d0;
            if (n6 < n9) {
                f2.W = n9;
            }
        }
    }

    public static final boolean b(int n2, int n3) {
        return (n2 & n3) == n3;
    }
}

