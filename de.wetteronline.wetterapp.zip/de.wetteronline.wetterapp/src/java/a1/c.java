/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  f1.u
 *  java.lang.Boolean
 *  java.lang.Object
 *  o0.g
 *  o0.g$c$a
 *  rr.l
 *  rr.p
 */
package a1;

import a1.b;
import f1.u;
import o0.g;
import rr.l;
import rr.p;

public final class c
implements g.c {
    public final l<b, Boolean> b;
    public final l<b, Boolean> c;
    public u d;

    public c(l<? super b, Boolean> l2, l<? super b, Boolean> l3) {
        this.b = l2;
        this.c = null;
    }

    public <R> R E(R r2, p<? super g.c, ? super R, ? extends R> p2) {
        return (R)g.c.a.c((g.c)this, r2, p2);
    }

    public g r(g g2) {
        return g.c.a.d((g.c)this, (g)g2);
    }

    public boolean y(l<? super g.c, Boolean> l2) {
        return g.c.a.a((g.c)this, l2);
    }

    public <R> R z(R r2, p<? super R, ? super g.c, ? extends R> p2) {
        return (R)g.c.a.b((g.c)this, r2, p2);
    }
}

