/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.KeyEvent
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  ma.e
 */
package a1;

import android.view.KeyEvent;
import ma.e;

public final class b {
    public final KeyEvent a;

    public /* synthetic */ b(KeyEvent keyEvent) {
        this.a = keyEvent;
    }

    public boolean equals(Object object) {
        KeyEvent keyEvent = this.a;
        if (!(object instanceof b)) {
            return false;
        }
        return e.a((Object)keyEvent, (Object)((b)object).a);
    }

    public int hashCode() {
        return this.a.hashCode();
    }

    public String toString() {
        KeyEvent keyEvent = this.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("KeyEvent(nativeKeyEvent=");
        stringBuilder.append((Object)keyEvent);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}

