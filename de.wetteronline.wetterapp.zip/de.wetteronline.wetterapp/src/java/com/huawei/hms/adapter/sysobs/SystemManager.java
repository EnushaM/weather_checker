/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  com.huawei.hms.adapter.sysobs.SystemManager$a
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.adapter.sysobs;

import android.content.Intent;
import com.huawei.hms.adapter.sysobs.SystemManager;
import com.huawei.hms.adapter.sysobs.SystemNotifier;

public final class SystemManager {
    public static SystemManager a = new SystemManager();
    public static final Object b = new Object();
    public static SystemNotifier c = new a();

    public static /* synthetic */ Object a() {
        return b;
    }

    public static SystemManager getInstance() {
        return a;
    }

    public static SystemNotifier getSystemNotifier() {
        return c;
    }

    public void notifyNoticeResult(int n2) {
        c.notifyNoticeObservers(n2);
    }

    public void notifyResolutionResult(Intent intent, String string2) {
        c.notifyObservers(intent, string2);
    }

    public void notifyUpdateResult(int n2) {
        c.notifyObservers(n2);
    }
}

