/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.huawei.hms.adapter.internal;

public interface BinderCode {
    public static final int BINDER_SYSTEM_ERROR = -1;
    public static final int OK = 0;
    public static final int PARAM_ERROR = -2;
}

