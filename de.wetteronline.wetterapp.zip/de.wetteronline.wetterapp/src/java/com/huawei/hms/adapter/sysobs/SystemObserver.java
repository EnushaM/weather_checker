/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.adapter.sysobs;

import android.content.Intent;

public interface SystemObserver {
    public boolean onNoticeResult(int var1);

    public boolean onSolutionResult(Intent var1, String var2);

    public boolean onUpdateResult(int var1);
}

