/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.support.v4.media.b
 *  android.text.TextUtils
 *  android.view.KeyEvent
 *  com.huawei.hms.activity.IBridgeActivityDelegate
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.ref.WeakReference
 */
package com.huawei.hms.adapter.ui;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.support.v4.media.b;
import android.text.TextUtils;
import android.view.KeyEvent;
import com.huawei.hms.activity.IBridgeActivityDelegate;
import com.huawei.hms.adapter.sysobs.SystemManager;
import com.huawei.hms.availableupdate.a;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.update.manager.UpdateManager;
import com.huawei.hms.update.ui.UpdateBean;
import com.huawei.hms.utils.HMSPackageManager;
import com.huawei.hms.utils.PackageManagerHelper;
import com.huawei.hms.utils.ResourceLoaderUtil;
import java.lang.ref.WeakReference;

public class UpdateAdapter
implements IBridgeActivityDelegate {
    public WeakReference<Activity> a;
    public int b;
    public UpdateBean c;
    public String d;

    public final void a() {
        Activity activity = this.b();
        if (activity != null) {
            if (activity.isFinishing()) {
                return;
            }
            activity.finish();
        }
    }

    public final boolean a(Context context, String string, int n2) {
        boolean bl = false;
        if (context != null) {
            boolean bl2 = TextUtils.isEmpty((CharSequence)string);
            bl = false;
            if (!bl2) {
                if (n2 == 0) {
                    return false;
                }
                PackageManagerHelper packageManagerHelper = new PackageManagerHelper(context);
                PackageManagerHelper.PackageStates packageStates = packageManagerHelper.getPackageStates(string);
                if (PackageManagerHelper.PackageStates.NOT_INSTALLED.equals((Object)packageStates)) {
                    return true;
                }
                int n3 = packageManagerHelper.getPackageVersionCode(string);
                bl = false;
                if (n3 < n2) {
                    bl = true;
                }
            }
        }
        return bl;
    }

    public final Activity b() {
        WeakReference<Activity> weakReference = this.a;
        if (weakReference == null) {
            return null;
        }
        return (Activity)weakReference.get();
    }

    public final void c() {
        SystemManager.getInstance().notifyUpdateResult(8);
        this.a();
    }

    public int getRequestCode() {
        return 1001;
    }

    public void onBridgeActivityCreate(Activity activity) {
        int n2;
        this.a = new WeakReference((Object)activity);
        if (!a.b.a(this.b())) {
            return;
        }
        Intent intent = activity.getIntent();
        if (intent == null) {
            this.c();
            return;
        }
        this.b = n2 = intent.getIntExtra("update_version", 0);
        if (n2 == 0) {
            this.c();
            return;
        }
        if (intent.getBooleanExtra("new_update", false)) {
            HMSLog.i("UpdateAdapter", "4.0 framework HMSCore upgrade process");
            String string = HMSPackageManager.getInstance(activity.getApplicationContext()).getHMSPackageName();
            ComponentName componentName = new ComponentName(string, "com.huawei.hms.fwksdk.stub.UpdateStubActivity");
            Intent intent2 = new Intent();
            intent2.putExtra("kpms_key_caller_packagename", activity.getApplicationContext().getPackageName());
            intent2.putExtra("kitUpdatePackageName", string);
            intent2.setComponent(componentName);
            activity.startActivityForResult(intent2, 1001);
            return;
        }
        this.d = HMSPackageManager.getInstance(activity.getApplicationContext()).getHMSPackageName();
        UpdateBean updateBean = new UpdateBean();
        updateBean.setHmsOrApkUpgrade(true);
        StringBuilder stringBuilder = b.a((String)"target HMS Core packageName is ");
        stringBuilder.append(this.d);
        HMSLog.i("UpdateAdapter", stringBuilder.toString());
        updateBean.setClientPackageName(this.d);
        updateBean.setClientVersionCode(this.b);
        updateBean.setClientAppId("C10132067");
        if (ResourceLoaderUtil.getmContext() == null) {
            ResourceLoaderUtil.setmContext(activity.getApplicationContext());
        }
        updateBean.setClientAppName(ResourceLoaderUtil.getString("hms_update_title"));
        this.c = updateBean;
        HMSLog.i("UpdateAdapter", "old framework HMSCore upgrade process");
        UpdateManager.startUpdate(activity, 1001, updateBean);
        this.c = null;
    }

    public void onBridgeActivityDestroy() {
        HMSLog.i("UpdateAdapter", "onBridgeActivityDestroy");
        a.b.b(this.b());
        this.a = null;
    }

    public boolean onBridgeActivityResult(int n2, int n3, Intent intent) {
        if (n2 != this.getRequestCode()) {
            this.c = null;
            return false;
        }
        HMSLog.i("UpdateAdapter", "onBridgeActivityResult");
        if (n3 == 1214) {
            HMSLog.i("UpdateAdapter", "Enter update escape route");
            Activity activity = this.b();
            if (activity == null) {
                HMSLog.e("UpdateAdapter", "bridgeActivity is null, update escape failed ");
                this.c = null;
                return true;
            }
            UpdateManager.startUpdate(activity, 1001, this.c);
            this.c = null;
        }
        if (n3 == -1) {
            if (intent != null) {
                if (intent.getIntExtra("kit_update_result", 0) == 1) {
                    HMSLog.i("UpdateAdapter", "new framework update process,Error resolved successfully!");
                    SystemManager.getInstance().notifyUpdateResult(0);
                    this.c = null;
                    this.a();
                    return true;
                }
                int n4 = intent.getIntExtra("intent.extra.RESULT", -1);
                if (n4 == 0) {
                    HMSLog.i("UpdateAdapter", "Error resolved successfully!");
                    SystemManager.getInstance().notifyUpdateResult(0);
                } else if (n4 == 13) {
                    HMSLog.i("UpdateAdapter", "Resolve error process canceled by user!");
                    SystemManager.getInstance().notifyUpdateResult(13);
                } else if (n4 == 8) {
                    HMSLog.i("UpdateAdapter", "Internal error occurred, recommended retry.");
                    SystemManager.getInstance().notifyUpdateResult(8);
                } else {
                    HMSLog.i("UpdateAdapter", "Other error codes.");
                    SystemManager.getInstance().notifyUpdateResult(n4);
                }
            }
        } else if (n3 == 0) {
            HMSLog.i("UpdateAdapter", "Activity.RESULT_CANCELED");
            this.c = null;
            Activity activity = this.b();
            if (activity == null) {
                return true;
            }
            if (this.a((Context)activity, HMSPackageManager.getInstance(activity.getApplicationContext()).getHMSPackageName(), this.b)) {
                HMSLog.i("UpdateAdapter", "Resolve error, process canceled by user clicking back button!");
                SystemManager.getInstance().notifyUpdateResult(13);
            } else {
                SystemManager.getInstance().notifyUpdateResult(0);
            }
        } else if (n3 == 1) {
            SystemManager.getInstance().notifyUpdateResult(28);
        }
        this.a();
        return true;
    }

    public void onBridgeConfigurationChanged() {
        HMSLog.i("UpdateAdapter", "onBridgeConfigurationChanged");
    }

    public void onKeyUp(int n2, KeyEvent keyEvent) {
        HMSLog.i("UpdateAdapter", "On key up when resolve conn error");
    }
}

