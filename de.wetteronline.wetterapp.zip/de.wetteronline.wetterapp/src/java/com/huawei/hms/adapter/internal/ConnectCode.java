/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.huawei.hms.adapter.internal;

public interface ConnectCode {
    public static final int CONNECT_RESULT_NULL = -1;
    public static final int OK = 0;
    public static final int PARAM_ERROR = -2;
}

