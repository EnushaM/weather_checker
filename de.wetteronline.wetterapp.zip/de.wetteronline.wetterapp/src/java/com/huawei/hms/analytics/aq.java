/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.analytics;

import com.huawei.hms.analytics.bo;
import com.huawei.hms.analytics.core.log.LogAdapter;
import e.a;

public final class aq
implements LogAdapter {
    private boolean ijk = false;
    private String ikl;
    private int klm = 4;
    private boolean lmn = false;

    private static void lmn(int n2, String string, String string2) {
        int n3 = string2.length();
        int n4 = 3000;
        int n5 = 0;
        for (int j = 0; j < 1 + n3 / 3000; ++j) {
            if (n3 > n4) {
                string2.substring(n5, n4);
                int n6 = n4 + 3000;
                int n7 = n4;
                n4 = n6;
                n5 = n7;
                continue;
            }
            string2.substring(n5, n3);
        }
    }

    @Override
    public final void init(int n2, String string) {
        if (this.ijk) {
            return;
        }
        this.ijk = true;
        this.klm = n2;
        this.lmn = true;
        this.ikl = string;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.ikl);
        stringBuilder.append("_5.2.0.301");
        stringBuilder.append(bo.lmn());
    }

    @Override
    public final boolean isLoggable(int n2) {
        return this.lmn && n2 >= this.klm;
    }

    @Override
    public final void println(int n2, String string, String string2) {
        String string3 = a.a(string, "=> ", string2);
        aq.lmn(n2, this.ikl, string3);
    }

    @Override
    public final void println(int n2, String string, String string2, String string3) {
        StringBuilder stringBuilder = new StringBuilder(string);
        stringBuilder.append("=> ");
        stringBuilder.append(string2);
        stringBuilder.append("|");
        stringBuilder.append(string3);
        aq.lmn(n2, this.ikl, stringBuilder.toString());
    }
}

