/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics.type;

public interface HAEventType {
    public static final String ADDPRODUCT2CART = "$AddProduct2Cart";
    public static final String ADDPRODUCT2WISHLIST = "$AddProduct2WishList";
    public static final String CANCELCHECKOUT = "$CancelCheckout";
    public static final String CANCELORDER = "$CancelOrder";
    public static final String COMPLETELEVEL = "$CompleteLevel";
    public static final String COMPLETEORDER = "$CompleteOrder";
    public static final String COMPLETEPURCHASE = "$CompletePurchase";
    public static final String COMPLETETUTORIAL = "$CompleteTutorial";
    public static final String CONSUMEPROPS = "$ConsumeProps";
    public static final String CONSUMEVIRTUALCOIN = "$ConsumeVirtualCoin";
    public static final String CONTACTCUSTOMSERVICE = "$ContactCustomService";
    public static final String CREATEORDER = "$CreateOrder";
    public static final String CREATEPAYMENTINFO = "$CreatePaymentInfo";
    public static final String DELPRODUCTFROMCART = "$DelProductFromCart";
    public static final String ENDGAME = "$EndGame";
    public static final String FILTRATEPRODUCT = "$FiltrateProduct";
    public static final String INVITE = "$Invite";
    public static final String JOINUSERGROUP = "$JoinUserGroup";
    public static final String NOVICEGUIDEEND = "$NoviceGuideEnd";
    public static final String NOVICEGUIDESTART = "$NoviceGuideStart";
    public static final String OBTAINACHIEVEMENT = "$ObtainAchievement";
    public static final String OBTAINLEADS = "$ObtainLeads";
    public static final String OBTAINVOUCHER = "$ObtainVoucher";
    public static final String RATE = "$Rate";
    public static final String REFUNDORDER = "$RefundOrder";
    public static final String REGISTERACCOUNT = "$RegisterAccount";
    public static final String SEARCH = "$Search";
    public static final String SHARECONTENT = "$ShareContent";
    public static final String SIGNIN = "$SignIn";
    public static final String SIGNOUT = "$SignOut";
    public static final String STARTAPP = "$StartApp";
    public static final String STARTCHECKOUT = "$StartCheckout";
    public static final String STARTGAME = "$StartGame";
    public static final String STARTLEVEL = "$StartLevel";
    public static final String STARTTUTORIAL = "$StartTutorial";
    public static final String SUBMITSCORE = "$SubmitScore";
    public static final String UPDATECHECKOUTOPTION = "$UpdateCheckoutOption";
    public static final String UPDATEMEMBERSHIPLEVEL = "$UpdateMembershipLevel";
    public static final String UPDATEORDER = "$UpdateOrder";
    public static final String UPGRADELEVEL = "$UpgradeLevel";
    public static final String VIEWCAMPAIGN = "$ViewCampaign";
    public static final String VIEWCATEGORY = "$ViewCategory";
    public static final String VIEWCHECKOUTSTEP = "$ViewCheckoutStep";
    public static final String VIEWCONTENT = "$ViewContent";
    public static final String VIEWPRODUCT = "$ViewProduct";
    public static final String VIEWPRODUCTLIST = "$ViewProductList";
    public static final String VIEWSEARCHRESULT = "$ViewSearchResult";
    public static final String WINPROPS = "$WinProps";
    public static final String WINVIRTUALCOIN = "$WinVirtualCoin";
}

