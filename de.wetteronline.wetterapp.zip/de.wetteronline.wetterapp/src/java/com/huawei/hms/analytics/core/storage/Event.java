/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Cloneable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics.core.storage;

import com.huawei.hms.analytics.core.log.HiLog;
import org.json.JSONException;
import org.json.JSONObject;

public class Event
implements Cloneable {
    private static final String TAG = "EventBean";
    private String associationid;
    private String content;
    private String evtid;
    private String evttime;
    private String evttype;
    private Long id;
    private String pid;
    private String servicetag;
    private String sessionid;
    private String sessionname;

    public Event() {
    }

    public Event(Long l2, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10) {
        this.id = l2;
        this.evtid = string2;
        this.evttype = string3;
        this.content = string4;
        this.evttime = string5;
        this.servicetag = string6;
        this.sessionid = string7;
        this.sessionname = string8;
        this.associationid = string9;
        this.pid = string10;
    }

    public Event clone() {
        return (Event)super.clone();
    }

    public void formJson(JSONObject jSONObject) {
        if (jSONObject != null) {
            this.evtid = jSONObject.optString("event");
            this.evttime = jSONObject.optString("eventtime");
            this.evttype = jSONObject.optString("type");
            this.content = jSONObject.optString("properties");
            this.sessionid = jSONObject.optString("first_session_event");
            this.sessionname = jSONObject.optString("event_session_name");
            this.associationid = jSONObject.optString("id", "");
            this.pid = jSONObject.optString("pid", "");
        }
    }

    public String getAssociationid() {
        return this.associationid;
    }

    public String getContent() {
        return this.content;
    }

    public String getEvtid() {
        return this.evtid;
    }

    public String getEvttime() {
        return this.evttime;
    }

    public String getEvttype() {
        return this.evttype;
    }

    public Long getId() {
        return this.id;
    }

    public String getPid() {
        return this.pid;
    }

    public String getServicetag() {
        return this.servicetag;
    }

    public String getSessionid() {
        return this.sessionid;
    }

    public String getSessionname() {
        return this.sessionname;
    }

    public void setAssociationid(String string2) {
        this.associationid = string2;
    }

    public void setContent(String string2) {
        this.content = string2;
    }

    public void setEvtid(String string2) {
        this.evtid = string2;
    }

    public void setEvttime(String string2) {
        this.evttime = string2;
    }

    public void setEvttype(String string2) {
        this.evttype = string2;
    }

    public void setId(Long l2) {
        this.id = l2;
    }

    public void setPid(String string2) {
        this.pid = string2;
    }

    public void setServicetag(String string2) {
        this.servicetag = string2;
    }

    public void setSessionid(String string2) {
        this.sessionid = string2;
    }

    public void setSessionname(String string2) {
        this.sessionname = string2;
    }

    public JSONObject toJson() {
        block4 : {
            String string2;
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("type", (Object)this.evttype);
                jSONObject.put("eventtime", (Object)this.evttime);
                jSONObject.put("event", (Object)this.evtid);
                jSONObject.put("id", (Object)this.associationid);
                jSONObject.put("pid", (Object)this.pid);
                jSONObject.put("event_session_name", (Object)this.sessionname);
                jSONObject.put("first_session_event", (Object)this.sessionid);
                string2 = this.content;
                if (string2 == null) break block4;
            }
            catch (JSONException jSONException) {
                StringBuilder stringBuilder = new StringBuilder("JSONException: ");
                stringBuilder.append(jSONException.getMessage());
                HiLog.e(TAG, stringBuilder.toString());
                return null;
            }
            if (string2.isEmpty()) break block4;
            jSONObject.put("properties", (Object)new JSONObject(this.content));
            return jSONObject;
        }
        StringBuilder stringBuilder = new StringBuilder("content is empty: evtId:");
        stringBuilder.append(this.evtid);
        HiLog.w(TAG, stringBuilder.toString());
        return null;
    }
}

