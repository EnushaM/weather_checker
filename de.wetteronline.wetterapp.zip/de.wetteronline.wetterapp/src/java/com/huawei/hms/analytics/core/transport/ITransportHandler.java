/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.huawei.hms.analytics.core.transport;

import com.huawei.hms.analytics.core.transport.CallbackListener;
import com.huawei.hms.analytics.core.transport.net.Response;
import java.util.Map;

public interface ITransportHandler {
    public Response execute();

    public void execute(CallbackListener var1);

    public void setHttpHeaders(Map<String, String> var1);

    public void setReportData(String var1);

    public void setReportData(byte[] var1);

    public void setSSLConfig(Protocols var1, String var2, boolean var3);

    public void setUrls(String[] var1);

    public static final class Protocols
    extends Enum<Protocols> {
        private static final /* synthetic */ Protocols[] $VALUES;
        public static final /* enum */ Protocols TLS1_2;
        public static final /* enum */ Protocols TLS1_3;
        private String protocol;

        public static {
            Protocols protocols;
            Protocols protocols2;
            TLS1_2 = protocols2 = new Protocols("TLSv1.2");
            TLS1_3 = protocols = new Protocols("TLSv1.3");
            $VALUES = new Protocols[]{protocols2, protocols};
        }

        private Protocols(String string3) {
            this.protocol = string3;
        }

        public static Protocols valueOf(String string2) {
            return (Protocols)Enum.valueOf(Protocols.class, (String)string2);
        }

        public static Protocols[] values() {
            return (Protocols[])$VALUES.clone();
        }

        public final String getProtocol() {
            return this.protocol;
        }
    }

}

