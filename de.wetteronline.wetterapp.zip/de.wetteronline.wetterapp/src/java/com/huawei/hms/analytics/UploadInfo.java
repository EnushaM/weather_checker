/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.os.Parcel;
import android.os.Parcelable;

public class UploadInfo
implements Parcelable {
    public static final Parcelable.Creator<UploadInfo> CREATOR = new Parcelable.Creator<UploadInfo>(){

        public final /* synthetic */ Object createFromParcel(Parcel parcel) {
            return new UploadInfo(parcel, 0);
        }
    };
    private String[] ikl = new String[0];
    public String klm;
    public String lmn;

    public UploadInfo() {
    }

    private UploadInfo(Parcel parcel) {
        this.lmn = parcel.readString();
        this.klm = parcel.readString();
        this.ikl = parcel.createStringArray();
    }

    public /* synthetic */ UploadInfo(Parcel parcel, byte by2) {
        this(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public final void lmn(String[] arrstring) {
        if (arrstring != null) {
            this.ikl = (String[])arrstring.clone();
        }
    }

    public final String[] lmn() {
        return (String[])this.ikl.clone();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.lmn);
        parcel.writeString(this.klm);
        parcel.writeStringArray(this.ikl);
    }

}

