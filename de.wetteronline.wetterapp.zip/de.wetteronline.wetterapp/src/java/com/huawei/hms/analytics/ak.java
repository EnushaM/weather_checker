/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.os.Bundle;
import com.huawei.hms.analytics.al;
import java.util.Map;

public interface ak {
    public void lmn(Context var1);

    public void lmn(al var1);

    public void lmn(String var1, Bundle var2);

    public void lmn(Map<Object, Object> var1);

    public boolean lmn(String var1, String var2, String var3, Bundle var4);

    public boolean lmn(String var1, String var2, String var3, Bundle var4, long var5);
}

