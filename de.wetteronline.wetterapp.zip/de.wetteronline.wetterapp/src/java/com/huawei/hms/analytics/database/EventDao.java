/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteStatement
 *  java.lang.Class
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  mt.a
 *  mt.b
 *  ot.a
 */
package com.huawei.hms.analytics.database;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.database.DaoSession;
import kt.c;
import kt.e;
import org.greenrobot.greendao.database.b;
import ot.a;

public class EventDao
extends kt.a<Event, Long> {
    public static final String TABLENAME = "EVENT";

    public EventDao(a a2) {
        super(a2);
    }

    public EventDao(a a2, DaoSession daoSession) {
        super(a2, daoSession);
    }

    public static void createTable(mt.a a2, boolean bl2) {
        String string = bl2 ? "IF NOT EXISTS " : "";
        StringBuilder stringBuilder = new StringBuilder("CREATE TABLE ");
        stringBuilder.append(string);
        stringBuilder.append("\"EVENT\" (\"_id\" INTEGER PRIMARY KEY AUTOINCREMENT ,\"EVTID\" TEXT,\"EVTTYPE\" TEXT,\"CONTENT\" TEXT,\"EVTTIME\" TEXT,\"SERVICETAG\" TEXT,\"SESSIONID\" TEXT,\"SESSIONNAME\" TEXT,\"ID\" TEXT,\"PID\" TEXT)");
        String string2 = stringBuilder.toString();
        ((b)a2).o(string2);
    }

    public static void dropTable(mt.a a2, boolean bl2) {
        StringBuilder stringBuilder = new StringBuilder("DROP TABLE ");
        String string = bl2 ? "IF EXISTS " : "";
        String string2 = b2.a.a(stringBuilder, string, "\"EVENT\"");
        ((b)a2).o(string2);
    }

    @Override
    public final void bindValues(SQLiteStatement sQLiteStatement, Event event) {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        String string6;
        String string7;
        String string8;
        String string9;
        sQLiteStatement.clearBindings();
        Long l4 = event.getId();
        if (l4 != null) {
            sQLiteStatement.bindLong(1, l4.longValue());
        }
        if ((string5 = event.getEvtid()) != null) {
            sQLiteStatement.bindString(2, string5);
        }
        if ((string9 = event.getEvttype()) != null) {
            sQLiteStatement.bindString(3, string9);
        }
        if ((string = event.getContent()) != null) {
            sQLiteStatement.bindString(4, string);
        }
        if ((string7 = event.getEvttime()) != null) {
            sQLiteStatement.bindString(5, string7);
        }
        if ((string4 = event.getServicetag()) != null) {
            sQLiteStatement.bindString(6, string4);
        }
        if ((string2 = event.getSessionid()) != null) {
            sQLiteStatement.bindString(7, string2);
        }
        if ((string3 = event.getSessionname()) != null) {
            sQLiteStatement.bindString(8, string3);
        }
        if ((string8 = event.getAssociationid()) != null) {
            sQLiteStatement.bindString(9, string8);
        }
        if ((string6 = event.getPid()) != null) {
            sQLiteStatement.bindString(10, string6);
        }
    }

    @Override
    public final void bindValues(mt.b b2, Event event) {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        String string6;
        String string7;
        String string8;
        String string9;
        b b3 = (b)b2;
        b3.g();
        Long l4 = event.getId();
        if (l4 != null) {
            b3.c(1, l4);
        }
        if ((string9 = event.getEvtid()) != null) {
            b3.e(2, string9);
        }
        if ((string = event.getEvttype()) != null) {
            b3.e(3, string);
        }
        if ((string7 = event.getContent()) != null) {
            b3.e(4, string7);
        }
        if ((string5 = event.getEvttime()) != null) {
            b3.e(5, string5);
        }
        if ((string2 = event.getServicetag()) != null) {
            b3.e(6, string2);
        }
        if ((string4 = event.getSessionid()) != null) {
            b3.e(7, string4);
        }
        if ((string8 = event.getSessionname()) != null) {
            b3.e(8, string8);
        }
        if ((string6 = event.getAssociationid()) != null) {
            b3.e(9, string6);
        }
        if ((string3 = event.getPid()) != null) {
            b3.e(10, string3);
        }
    }

    @Override
    public Long getKey(Event event) {
        if (event != null) {
            return event.getId();
        }
        return null;
    }

    @Override
    public boolean hasKey(Event event) {
        return event.getId() != null;
    }

    @Override
    public final boolean isEntityUpdateable() {
        return true;
    }

    @Override
    public Event readEntity(Cursor cursor, int n2) {
        int n3 = n2 + 0;
        Long l4 = cursor.isNull(n3) ? null : Long.valueOf((long)cursor.getLong(n3));
        int n4 = n2 + 1;
        String string = cursor.isNull(n4) ? null : cursor.getString(n4);
        int n5 = n2 + 2;
        String string2 = cursor.isNull(n5) ? null : cursor.getString(n5);
        int n6 = n2 + 3;
        String string3 = cursor.isNull(n6) ? null : cursor.getString(n6);
        int n7 = n2 + 4;
        String string4 = cursor.isNull(n7) ? null : cursor.getString(n7);
        int n8 = n2 + 5;
        String string5 = cursor.isNull(n8) ? null : cursor.getString(n8);
        int n9 = n2 + 6;
        String string6 = cursor.isNull(n9) ? null : cursor.getString(n9);
        int n10 = n2 + 7;
        String string7 = cursor.isNull(n10) ? null : cursor.getString(n10);
        int n11 = n2 + 8;
        String string8 = cursor.isNull(n11) ? null : cursor.getString(n11);
        int n12 = n2 + 9;
        String string9 = cursor.isNull(n12) ? null : cursor.getString(n12);
        Event event = new Event(l4, string, string2, string3, string4, string5, string6, string7, string8, string9);
        return event;
    }

    @Override
    public void readEntity(Cursor cursor, Event event, int n2) {
        int n3 = n2 + 0;
        Long l4 = cursor.isNull(n3) ? null : Long.valueOf((long)cursor.getLong(n3));
        event.setId(l4);
        int n4 = n2 + 1;
        String string = cursor.isNull(n4) ? null : cursor.getString(n4);
        event.setEvtid(string);
        int n5 = n2 + 2;
        String string2 = cursor.isNull(n5) ? null : cursor.getString(n5);
        event.setEvttype(string2);
        int n6 = n2 + 3;
        String string3 = cursor.isNull(n6) ? null : cursor.getString(n6);
        event.setContent(string3);
        int n7 = n2 + 4;
        String string4 = cursor.isNull(n7) ? null : cursor.getString(n7);
        event.setEvttime(string4);
        int n8 = n2 + 5;
        String string5 = cursor.isNull(n8) ? null : cursor.getString(n8);
        event.setServicetag(string5);
        int n9 = n2 + 6;
        String string6 = cursor.isNull(n9) ? null : cursor.getString(n9);
        event.setSessionid(string6);
        int n10 = n2 + 7;
        String string7 = cursor.isNull(n10) ? null : cursor.getString(n10);
        event.setSessionname(string7);
        int n11 = n2 + 8;
        String string8 = cursor.isNull(n11) ? null : cursor.getString(n11);
        event.setAssociationid(string8);
        int n12 = n2 + 9;
        String string9 = cursor.isNull(n12) ? null : cursor.getString(n12);
        event.setPid(string9);
    }

    @Override
    public Long readKey(Cursor cursor, int n2) {
        int n3 = n2 + 0;
        if (cursor.isNull(n3)) {
            return null;
        }
        return cursor.getLong(n3);
    }

    @Override
    public final Long updateKeyAfterInsert(Event event, long l4) {
        event.setId(l4);
        return l4;
    }

}

