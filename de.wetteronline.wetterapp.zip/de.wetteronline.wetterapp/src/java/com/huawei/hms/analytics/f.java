/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.huawei.hms.analytics;

import android.content.Context;
import com.huawei.hms.analytics.i;
import com.huawei.hms.api.Api;
import com.huawei.hms.common.internal.AbstractClientBuilder;
import com.huawei.hms.common.internal.AnyClient;
import com.huawei.hms.common.internal.BaseHmsClient;
import com.huawei.hms.common.internal.ClientSettings;

public final class f
extends AbstractClientBuilder<i, Api.ApiOptions.NoOptions> {
    @Override
    public final /* synthetic */ AnyClient buildClient(Context context, ClientSettings clientSettings, BaseHmsClient.OnConnectionFailedListener onConnectionFailedListener, BaseHmsClient.ConnectionCallbacks connectionCallbacks) {
        return new i(context, clientSettings, onConnectionFailedListener, connectionCallbacks);
    }
}

