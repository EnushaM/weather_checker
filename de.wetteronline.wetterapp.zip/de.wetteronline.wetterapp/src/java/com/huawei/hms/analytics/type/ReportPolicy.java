/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics.type;

import com.huawei.hms.analytics.core.log.HiLog;

public final class ReportPolicy
extends Enum<ReportPolicy> {
    private static final /* synthetic */ ReportPolicy[] $VALUES;
    public static final /* enum */ ReportPolicy ON_APP_LAUNCH_POLICY;
    public static final /* enum */ ReportPolicy ON_CACHE_THRESHOLD_POLICY;
    public static final /* enum */ ReportPolicy ON_MOVE_BACKGROUND_POLICY;
    public static final /* enum */ ReportPolicy ON_SCHEDULED_TIME_POLICY;
    private long threshold;

    public static {
        ReportPolicy reportPolicy;
        ReportPolicy reportPolicy2;
        ReportPolicy reportPolicy3;
        ReportPolicy reportPolicy4;
        ON_SCHEDULED_TIME_POLICY = reportPolicy = new ReportPolicy(60L);
        ON_APP_LAUNCH_POLICY = reportPolicy3 = new ReportPolicy(-1L);
        ON_MOVE_BACKGROUND_POLICY = reportPolicy2 = new ReportPolicy(-1L);
        ON_CACHE_THRESHOLD_POLICY = reportPolicy4 = new ReportPolicy(30L);
        $VALUES = new ReportPolicy[]{reportPolicy, reportPolicy3, reportPolicy2, reportPolicy4};
    }

    private ReportPolicy(long l2) {
        this.threshold = l2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private long checkThreshold(long l2) {
        long l3;
        long l4;
        int n2 = 1.lmn[this.ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                return -1L;
            }
            l4 = 1800L;
            long l5 = l2 LCMP l4;
            l3 = 60L;
            if (l5 > 0) {
                HiLog.w("PolicyToolsKit", "The auto-reporting period is too long.Use the default value.");
                do {
                    return l4;
                    break;
                } while (true);
            }
            if (l2 >= l3) return l2;
            HiLog.w("PolicyToolsKit", "The auto-reporting period is too short. Use the default value.");
            do {
                return l3;
                break;
            } while (true);
        }
        l4 = 1000L;
        long l6 = l2 LCMP l4;
        l3 = 30L;
        if (l6 > 0) {
            HiLog.i("PolicyToolsKit", "The number of automatically reported thresholds is too large. Use the maximum  default value.");
            return l4;
        }
        if (l2 >= l3) return l2;
        HiLog.i("PolicyToolsKit", "The number of automatically reported thresholds is too small. Use the minimum  default value.");
        return l3;
    }

    public static ReportPolicy valueOf(String string2) {
        return (ReportPolicy)Enum.valueOf(ReportPolicy.class, (String)string2);
    }

    public static ReportPolicy[] values() {
        return (ReportPolicy[])$VALUES.clone();
    }

    public final long getThreshold() {
        return this.threshold;
    }

    public final void setThreshold(long l2) {
        this.threshold = this.checkThreshold(l2);
    }

}

