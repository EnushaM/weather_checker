/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.content.Context;
import com.huawei.hms.analytics.abc;

public final class ab {
    public boolean a = false;
    public boolean abc = true;
    public String b;
    public Context bcd;
    public String c = "";
    public String cde = "";
    public boolean d;
    public String def;
    public abc e;
    public String efg;
    public String f;
    public String fgh;
    public String g;
    public String ghi;
    public long h = 30L;
    public String hij;
    public String i = "";
    public String ijk;
    public String ikl;
    public String j = "";
    public String k;
    public String klm;
    public String l;
    public String lmn;
    public String m = "";
    public String n;
    public String o;
    public String p;
    public boolean q;
    private String[] r = new String[0];

    public final void lmn(String[] arrstring) {
        this.r = (String[])arrstring.clone();
    }

    public final String[] lmn() {
        return (String[])this.r.clone();
    }
}

