/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.huawei.hms.analytics.core.storage;

import com.huawei.hms.analytics.core.storage.Event;
import java.util.List;

public interface IStorageHandler {
    public void deleteAll();

    public void deleteByTag(String var1);

    public void deleteByTagType(String var1, String var2);

    public void deleteEvents(List<Event> var1);

    public long insert(Event var1);

    public void insertEx(List<Event> var1);

    public List<Event> readBySql(String var1);

    public List<Event> readEvents(String var1);

    public List<Event> readEvents(String var1, String var2);
}

