/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.huawei.hms.analytics;

public interface abc {
    public void klm();

    public void lmn();
}

