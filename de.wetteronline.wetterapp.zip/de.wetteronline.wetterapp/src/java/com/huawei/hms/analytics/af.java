/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.huawei.hms.analytics.database.DaoSession
 *  com.huawei.hms.analytics.database.EventDao
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.huawei.hms.analytics;

import android.content.Context;
import com.huawei.hms.analytics.ae;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.core.storage.IStorageHandler;
import com.huawei.hms.analytics.database.DaoSession;
import com.huawei.hms.analytics.database.EventDao;
import java.util.List;
import kt.e;
import pt.d;
import pt.f;
import pt.g;
import pt.i;

public final class af
implements IStorageHandler {
    private static IStorageHandler lmn;
    private ae klm;

    private af(Context context) {
        this.klm = ae.lmn(context);
    }

    private static void klm(Context context) {
        Class<af> class_ = af.class;
        synchronized (af.class) {
            if (lmn == null) {
                lmn = new af(context);
            }
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return;
        }
    }

    public static IStorageHandler lmn(Context context) {
        if (lmn == null) {
            af.klm(context);
        }
        return lmn;
    }

    @Override
    public final void deleteAll() {
        this.klm.lmn.getEventDao().deleteAll();
    }

    @Override
    public final void deleteByTag(String string) {
        g g3 = this.klm.lmn.getEventDao().queryBuilder();
        g3.d(EventDao.Properties.ghi.a(string), new i[0]);
        g3.c().c();
    }

    @Override
    public final void deleteByTagType(String string, String string2) {
        g g3 = this.klm.lmn.getEventDao().queryBuilder();
        g3.d(EventDao.Properties.ghi.a(string), new i[0]);
        g3.d(EventDao.Properties.ikl.a(string2), new i[0]);
        g3.c().c();
    }

    @Override
    public final void deleteEvents(List<Event> list) {
        this.klm.lmn.getEventDao().deleteInTx(list);
    }

    @Override
    public final long insert(Event event) {
        return this.klm.lmn.getEventDao().insert(event);
    }

    @Override
    public final void insertEx(List<Event> list) {
        this.klm.lmn(list);
    }

    @Override
    public final List<Event> readBySql(String string) {
        g g3 = this.klm.lmn.getEventDao().queryBuilder();
        g3.d((i)new i.a(string){
            public final String c;
            {
                this.c = string;
            }

            public void b(java.lang.StringBuilder stringBuilder, String string) {
                stringBuilder.append(this.c);
            }
        }, new i[0]);
        return g3.b().d().e();
    }

    @Override
    public final List<Event> readEvents(String string) {
        g g3 = this.klm.lmn.getEventDao().queryBuilder();
        g3.d(EventDao.Properties.ghi.a(string), new i[0]);
        return g3.b().d().e();
    }

    @Override
    public final List<Event> readEvents(String string, String string2) {
        g g3 = this.klm.lmn.getEventDao().queryBuilder();
        g3.d(EventDao.Properties.ghi.a(string), new i[0]);
        g3.d(EventDao.Properties.ikl.a(string2), new i[0]);
        return g3.b().d().e();
    }
}

