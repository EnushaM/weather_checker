/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.huawei.hms.analytics.framework.b;

import com.huawei.hms.analytics.core.storage.IStorageHandler;
import com.huawei.hms.analytics.framework.b.c;
import com.huawei.hms.analytics.framework.config.ICollectorConfig;
import com.huawei.hms.analytics.framework.policy.IStoragePolicy;

public final class a {
    public ICollectorConfig a;
    public IStoragePolicy b;
    public com.huawei.hms.analytics.framework.listener.a c;
    public c d;

    public a(ICollectorConfig iCollectorConfig, IStorageHandler iStorageHandler, IStoragePolicy iStoragePolicy, com.huawei.hms.analytics.framework.listener.a a2) {
        c c2;
        this.a = iCollectorConfig;
        this.d = c2 = new c();
        c2.b = iStorageHandler;
        this.b = iStoragePolicy;
        this.c = a2;
    }
}

