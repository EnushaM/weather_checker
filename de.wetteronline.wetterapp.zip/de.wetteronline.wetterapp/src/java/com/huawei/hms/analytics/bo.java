/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

public final class bo {
    public static final Boolean lmn = Boolean.FALSE;

    public static String lmn() {
        if (lmn.booleanValue()) {
            return "-dev";
        }
        return "";
    }
}

