/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import com.huawei.hms.analytics.core.log.HiLog;

public class HiAnalyticsTools {
    private static final String MODELNAME = "HiAnalyticsSDK";

    public static void enableLog() {
        HiAnalyticsTools.enableLog(3);
    }

    public static void enableLog(int n2) {
        HiLog.init(n2, MODELNAME);
    }
}

