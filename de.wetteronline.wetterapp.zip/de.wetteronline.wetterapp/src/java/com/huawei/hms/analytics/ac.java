/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.huawei.hms.analytics;

import java.util.Map;

public final class ac {
    public Map<String, String> klm;
    public boolean lmn;
}

