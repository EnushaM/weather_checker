/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.os.Bundle;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.br;
import com.huawei.hms.analytics.bt;
import com.huawei.hms.analytics.bu;
import com.huawei.hms.analytics.core.log.HiLog;

public final class bf
implements Runnable {
    private ah klm;
    private Context lmn;

    public bf(Context context, ah ah2) {
        this.lmn = context;
        this.klm = ah2;
    }

    private static Bundle klm() {
        Bundle bundle = new Bundle();
        ab ab2 = aa.lmn().klm;
        String string2 = ab2.b;
        String string3 = "";
        if (string2 == null) {
            string2 = string3;
        }
        bundle.putString("$StartType", string2);
        String string4 = ab2.f;
        if (string4 != null) {
            string3 = string4;
        }
        bundle.putString("$InstallChannel", string3);
        return bundle;
    }

    private void lmn() {
        bt bt2 = new bt("$AppFirstOpen", bf.klm());
        if (br.ikl(this.lmn)) {
            HiLog.i("ReferrerMission", "debugview FirstOpen");
            this.klm.lmn("$AppFirstOpen", bt2, System.currentTimeMillis());
            return;
        }
        if (!bu.klm(this.lmn, "global_v2", "isFirstRun", false)) {
            HiLog.i("ReferrerMission", "normal FirstOpen");
            this.klm.lmn("$AppFirstOpen", bt2, System.currentTimeMillis());
            bu.lmn(this.lmn, "global_v2", "isFirstRun", true);
        }
    }

    public static /* synthetic */ void lmn(bf bf2) {
        bf2.lmn();
    }

    /*
     * Exception decompiling
     */
    public final void run() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl33 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }
}

