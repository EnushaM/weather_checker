/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.IBinder;
import com.huawei.hms.analytics.a;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.n;
import com.huawei.hms.analytics.o;

public final class m
implements n {
    private final Context klm;
    private final a.lmn lmn;

    public m(Context context, a.lmn lmn2) {
        this.klm = context;
        this.lmn = lmn2;
    }

    public final void lmn() {
        this.klm.getPackageManager().getPackageInfo("com.android.vending", 0);
        Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
        intent.setPackage("com.google.android.gms");
        new o(this.klm, intent, this).lmn();
    }

    /*
     * Exception decompiling
     */
    @Override
    public final void lmn(IBinder var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.ArrayIndexOutOfBoundsException: length=0; index=-1
        // java.util.ArrayList.get(ArrayList.java:439)
        // org.benf.cfr.reader.b.a.a.c.ab.a(VarArgsRewriter.java:87)
        // org.benf.cfr.reader.b.a.b.a.e.a(AbstractMemberFunctionInvokation.java:146)
        // org.benf.cfr.reader.b.a.a.c.ab.a(VarArgsRewriter.java:56)
        // org.benf.cfr.reader.b.a.d.b.g.a(StructuredAssignment.java:136)
        // org.benf.cfr.reader.b.a.a.c.ab.a(VarArgsRewriter.java:42)
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:1185)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:760)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public final void lmn(String string) {
        HiLog.w("gaidHepler", "bind service error");
        this.lmn.lmn("", "");
    }
}

