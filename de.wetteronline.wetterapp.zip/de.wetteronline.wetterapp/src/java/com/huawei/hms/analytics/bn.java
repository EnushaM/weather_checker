/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 *  java.util.List
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.huawei.hms.analytics;

import android.text.TextUtils;
import com.huawei.hms.analytics.core.log.HiLog;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class bn {
    /*
     * Enabled aggressive block sorting
     */
    public static boolean lmn(String string2) {
        String string3;
        String string4;
        if (TextUtils.isEmpty((CharSequence)string2)) {
            string4 = "PE-001";
            string3 = " param is null";
        } else {
            if (string2.length() <= 256) {
                return true;
            }
            string4 = "PE-002";
            string3 = " Length of param exceeds the limit. Max Length is 256.";
        }
        HiLog.w("CheckToolsKit", string4, string3);
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean lmn(String string2, String string3, Pattern pattern) {
        String string4;
        String string5;
        if (TextUtils.isEmpty((CharSequence)string3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(" is null");
            string5 = stringBuilder.toString();
            string4 = "PE-001";
        } else {
            if (pattern.matcher((CharSequence)string3).matches()) {
                return true;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(" is invalid.");
            string5 = stringBuilder.toString();
            string4 = "PE-006";
        }
        HiLog.w("CheckToolsKit", string4, string5);
        return false;
    }

    public static boolean lmn(String string2, List<String> list) {
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            if (!((String)iterator.next()).equals((Object)string2)) continue;
            return true;
        }
        return false;
    }
}

