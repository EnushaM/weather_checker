/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.huawei.hms.analytics.framework.c;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.core.storage.IStorageHandler;
import com.huawei.hms.analytics.framework.a.a;
import com.huawei.hms.analytics.framework.c.c;
import com.huawei.hms.analytics.framework.config.ICallback;
import java.util.List;

public final class d
implements Runnable {
    private String a;
    private String b;
    private ICallback c;

    public d(String string2, String string3, ICallback iCallback) {
        this.a = string2;
        this.b = string3;
        this.c = iCallback;
    }

    public final void run() {
        List<Event> list;
        HiLog.d("ReportMission", "report running");
        IStorageHandler iStorageHandler = a.a(this.a);
        if (iStorageHandler != null) {
            list = iStorageHandler.readEvents(this.a, this.b);
        } else {
            HiLog.e("ReportMission", "storageHandler is null! Data cannot be queried.");
            list = null;
        }
        if (list != null && list.size() != 0) {
            new c(this.a, this.b, list, this.c).a();
            return;
        }
        StringBuilder stringBuilder = new StringBuilder("events size is empty,TAG: ");
        stringBuilder.append(this.a);
        HiLog.w("ReportMission", stringBuilder.toString());
    }
}

