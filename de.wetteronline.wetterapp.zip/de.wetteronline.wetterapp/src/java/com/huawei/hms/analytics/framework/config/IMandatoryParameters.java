/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics.framework.config;

import com.huawei.hms.analytics.core.transport.ITransportHandler;
import com.huawei.hms.analytics.framework.config.CipherType;

public interface IMandatoryParameters {
    public String getAppVer();

    public String getCaCertificatePath();

    public CipherType getCipherType();

    public String getLoadWorkKey();

    public String getModel();

    public ITransportHandler.Protocols getProtocols();

    public String getPubKeyVersion();

    public byte[] getRsaPublicKey();

    public boolean isGCMParameterSpec();

    public boolean isHighCipher();
}

