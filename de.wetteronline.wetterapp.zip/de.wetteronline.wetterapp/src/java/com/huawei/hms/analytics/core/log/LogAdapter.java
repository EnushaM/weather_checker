/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics.core.log;

public interface LogAdapter {
    public void init(int var1, String var2);

    public boolean isLoggable(int var1);

    public void println(int var1, String var2, String var3);

    public void println(int var1, String var2, String var3, String var4);
}

