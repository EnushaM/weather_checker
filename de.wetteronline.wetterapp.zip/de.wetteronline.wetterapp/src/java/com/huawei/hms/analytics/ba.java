/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.huawei.hms.analytics;

import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.az;
import com.huawei.hms.analytics.bd;
import com.huawei.hms.analytics.bi;
import com.huawei.hms.analytics.core.crypto.HexUtil;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.database.APIEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class ba {
    public static APIEvent klm(az az2) {
        String string2 = HexUtil.initRandomKey(16);
        String string3 = String.valueOf((long)System.currentTimeMillis());
        APIEvent aPIEvent = new APIEvent(string2, string3, "0", az2.ikl, az2.lmn, az2.klm, az2.ijk, "1", String.valueOf((long)az2.lmn()));
        return aPIEvent;
    }

    public static az lmn(String string2) {
        Class<ba> class_ = ba.class;
        synchronized (ba.class) {
            az az2 = new az();
            az2.ikl = string2;
            // ** MonitorExit[var3_1] (shouldn't be in output)
            return az2;
        }
    }

    /*
     * Exception decompiling
     */
    public static void lmn(az var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl48 : ALOAD : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void lmn(Map<String, Integer> map, String string2, long l2, int n2) {
        if (!aa.lmn().klm.abc) {
            HiLog.w("APIEvtRecordHolder", "The Analytics Kit is disabled, don't record");
            return;
        }
        Iterator iterator = map.entrySet().iterator();
        ArrayList arrayList = new ArrayList();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            String string3 = (String)entry.getKey();
            Integer n3 = (Integer)entry.getValue();
            String string4 = HexUtil.initRandomKey(16);
            String string5 = String.valueOf((long)System.currentTimeMillis());
            String string6 = n2 == 200 ? "0" : "1";
            String string7 = string6;
            APIEvent aPIEvent = new APIEvent(string4, string5, "1", string2, string7, String.valueOf((int)n2), string3, String.valueOf((Object)n3), String.valueOf((long)l2));
            arrayList.add((Object)aPIEvent);
        }
        try {
            bd bd2 = new bd((List<APIEvent>)arrayList);
            bi.lmn().lmn(bd2);
            return;
        }
        catch (NoClassDefFoundError noClassDefFoundError) {
            HiLog.e("APIEvtRecordHolder", "IE-004", "HMSBIInitializer init failed,Missing hms sdk!");
            return;
        }
        catch (Exception exception) {
            HiLog.e("APIEvtRecordHolder", "HMSBIInitializer init failed!");
            return;
        }
    }
}

