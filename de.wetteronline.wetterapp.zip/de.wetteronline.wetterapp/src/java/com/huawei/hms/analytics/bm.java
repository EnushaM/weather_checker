/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.huawei.hms.analytics;

public final class bm {
    private int ikl = 1024;
    public int klm = 0;
    public byte[] lmn = null;

    public bm() {
        this.lmn = new byte[1024];
    }

    public bm(byte by2) {
        this.ikl = 1024;
        this.lmn = new byte[1024];
    }
}

