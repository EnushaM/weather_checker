/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Collection
 *  java.util.List
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics.framework.c;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.core.storage.IStorageHandler;
import com.huawei.hms.analytics.framework.c.a;
import com.huawei.hms.analytics.framework.c.c;
import com.huawei.hms.analytics.framework.c.d;
import com.huawei.hms.analytics.framework.config.ICallback;
import com.huawei.hms.analytics.framework.config.ICollectorConfig;
import com.huawei.hms.analytics.framework.e.b;
import com.huawei.hms.analytics.framework.policy.IStoragePolicy;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import org.json.JSONObject;

public final class b
implements Runnable {
    public boolean a;
    public ICallback b;
    private String c;
    private String d;
    private long e;
    private List<JSONObject> f;
    private String g;
    private boolean h;
    private List<Event> i;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public b(String var1_1, String var2_2, List<JSONObject> var3_3) {
        block9 : {
            block11 : {
                block10 : {
                    block8 : {
                        super();
                        this.c = var1_1;
                        this.e = System.currentTimeMillis();
                        if (var3_3 != null) {
                            this.f = new ArrayList(var3_3);
                        }
                        this.d = var2_2;
                        if ("oper".equals((Object)var2_2) == false) return;
                        if (com.huawei.hms.analytics.framework.b.b.a().a(var1_1).isEnableSession("oper") == false) return;
                        var4_4 = com.huawei.hms.analytics.framework.e.a.a();
                        var5_5 = this.e;
                        var7_6 = var4_4.a(var1_1);
                        var8_7 = var7_6.e;
                        if (var8_7 != null) break block8;
                        HiLog.i("SessionKeeper", "Session is first flush");
                        var7_6.e = new b.a(var7_6, var5_5);
                        break block9;
                    }
                    var9_8 = com.huawei.hms.analytics.framework.b.b.a().b(var1_1);
                    if (var9_8 == null || !var9_8.a) break block10;
                    var9_8.a = false;
                    ** GOTO lbl-1000
                }
                if (!var8_7.d.c) break block11;
                var21_9 = var5_5 - var8_7.d.d;
                var23_10 = var8_7.d;
                if (var21_9 <= var23_10.b) break block11;
                var23_10.c = false;
                var8_7.d.d = 0L;
                ** GOTO lbl-1000
            }
            var10_11 = var8_7.c;
            var12_12 = var5_5 - var10_11 LCMP var8_7.d.a;
            var13_13 = 1;
            var14_14 = var12_12 >= 0 ? var13_13 : 0;
            if (var14_14 != 0) ** GOTO lbl-1000
            var15_15 = Calendar.getInstance();
            var15_15.setTimeInMillis(var10_11);
            var16_16 = Calendar.getInstance();
            var16_16.setTimeInMillis(var5_5);
            if (var15_15.get(var13_13) == var16_16.get(var13_13) && var15_15.get(6) == var16_16.get(6)) {
                var13_13 = 0;
            }
            if (var13_13 != 0) lbl-1000: // 4 sources:
            {
                var8_7.a(var5_5);
            } else {
                var8_7.c = var5_5;
                var8_7.b = false;
            }
        }
        var17_17 = var7_6.e;
        if (var17_17 == null) {
            HiLog.w("SessionKeeper", "getSessionName(): session not prepared. onEvent() must be called first.");
            var18_18 = "";
        } else {
            var18_18 = var17_17.a;
        }
        this.g = var18_18;
        var19_19 = var7_6.e;
        if (var19_19 == null) {
            HiLog.w("SessionKeeper", "isFirstEvent(): session not prepared. onEvent() must be called first.");
            var20_20 = false;
        } else {
            var20_20 = var19_19.b;
        }
        this.h = var20_20;
    }

    public b(List<Event> list) {
        if (list != null && list.size() > 0) {
            ArrayList arrayList;
            this.i = arrayList = new ArrayList(list);
            this.c = ((Event)arrayList.get(0)).getServicetag();
            this.d = ((Event)this.i.get(0)).getEvttype();
        }
    }

    private void a() {
        String string2 = this.c;
        com.huawei.hms.analytics.framework.b.c c2 = com.huawei.hms.analytics.framework.b.b.a().b(string2);
        if (c2 == null) {
            HiLog.w("RecordMission", "get framework config info error");
            return;
        }
        long l2 = c2.a(this.d);
        long l3 = System.currentTimeMillis();
        if (l3 - l2 > 30000L) {
            HiLog.d("RecordMission", "begin to auto report!");
            c2.a(this.d, l3);
            com.huawei.hms.analytics.framework.f.a.b().a(new d(this.c, this.d, this.b));
            return;
        }
        HiLog.w("RecordMission", "autoReport timeout. interval < 30s ");
    }

    private void a(List<Event> list) {
        IStorageHandler iStorageHandler = com.huawei.hms.analytics.framework.a.a.a(this.c);
        IStoragePolicy iStoragePolicy = com.huawei.hms.analytics.framework.a.a.b(this.c);
        if (iStorageHandler != null && iStoragePolicy != null) {
            if (iStoragePolicy.decide(IStoragePolicy.PolicyType.STORAGELENGTH, this.d)) {
                HiLog.e("RecordMission", "db file reach max limited length,clear db file");
                iStorageHandler.deleteAll();
                iStorageHandler.insertEx(list);
                return;
            }
            List<Event> list2 = iStorageHandler.readEvents(this.c);
            if (list2 != null && list2.size() != 0) {
                if ((long)list2.size() > 5000L) {
                    HiLog.e("RecordMission", "db file reach max limited size,clear db file");
                    iStorageHandler.deleteByTag(this.c);
                    iStorageHandler.insertEx(list);
                    return;
                }
                iStorageHandler.insertEx(list);
                List<Event> list3 = iStorageHandler.readEvents(this.c, this.d);
                StringBuilder stringBuilder = new StringBuilder("record evt size : ");
                stringBuilder.append(list3.size());
                HiLog.i("RecordMission", stringBuilder.toString());
                if (iStoragePolicy.decide(IStoragePolicy.PolicyType.STORAGESIZE, this.d, list3.size()) && iStoragePolicy.decide(IStoragePolicy.PolicyType.NETWORK, this.d)) {
                    HiLog.i("RecordMission", "ready to auto report!");
                    this.a();
                }
                return;
            }
            iStorageHandler.insertEx(list);
            return;
        }
        HiLog.e("RecordMission", "storageHandler is null!");
    }

    public final void run() {
        List<Event> list = this.i;
        if (list != null) {
            for (Event event : list) {
                event.setContent(a.a(event.getContent()));
            }
            this.a(list);
            return;
        }
        if (this.f == null) {
            return;
        }
        ArrayList arrayList = new ArrayList();
        for (JSONObject jSONObject : this.f) {
            String string2 = (String)jSONObject.remove("^eventId");
            String string3 = (String)jSONObject.remove("^id");
            String string4 = (String)jSONObject.remove("^pid");
            Event event = new Event();
            event.setServicetag(this.c);
            event.setEvttype(this.d);
            event.setEvtid(string2);
            event.setEvttime(String.valueOf((long)this.e));
            event.setSessionid(String.valueOf((boolean)this.h));
            event.setSessionname(this.g);
            event.setAssociationid(string3);
            event.setPid(string4);
            String string5 = jSONObject.toString();
            if (!this.a) {
                string5 = a.a(string5);
            }
            event.setContent(string5);
            arrayList.add((Object)event);
        }
        if (arrayList.size() == 0) {
            return;
        }
        if (this.a) {
            c c2 = new c(this.c, this.d, (List<Event>)arrayList, this.b);
            c2.a = true;
            c2.a();
            return;
        }
        this.a((List<Event>)arrayList);
    }
}

