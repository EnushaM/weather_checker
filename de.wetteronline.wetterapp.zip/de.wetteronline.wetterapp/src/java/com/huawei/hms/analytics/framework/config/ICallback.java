/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.List
 */
package com.huawei.hms.analytics.framework.config;

import com.huawei.hms.analytics.core.storage.Event;
import java.util.List;

public interface ICallback {
    public boolean isNeedStorage();

    public void onResult(int var1, long var2, List<Event> var4);
}

