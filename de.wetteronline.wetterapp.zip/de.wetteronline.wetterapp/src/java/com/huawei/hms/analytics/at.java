/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.framework.config.DeviceAttributeCollector;
import org.json.JSONException;
import org.json.JSONObject;

public final class at
implements DeviceAttributeCollector {
    private String ghi = "";
    public String hij = "";
    public String ijk = "";
    public String ikl = "";
    public String klm = "";
    public String lmn = "";

    @Override
    public final JSONObject doCollector() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("androidid", (Object)this.ghi);
            jSONObject.put("aaid", (Object)this.lmn);
            jSONObject.put("oaid", (Object)this.klm);
            jSONObject.put("pushtoken", (Object)this.ikl);
            jSONObject.put("userid", (Object)this.ijk);
            jSONObject.put("events_global_properties", (Object)this.hij);
            return jSONObject;
        }
        catch (JSONException jSONException) {
            HiLog.w("OpennessDeviceGathering", "doCollector JSONException");
            return jSONObject;
        }
    }
}

