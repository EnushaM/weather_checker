/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.huawei.hms.analytics.core.transport.net.HttpTransportHandler
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package com.huawei.hms.analytics.framework.c;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.core.storage.IStorageHandler;
import com.huawei.hms.analytics.core.transport.ITransportHandler;
import com.huawei.hms.analytics.core.transport.net.HttpTransportHandler;
import com.huawei.hms.analytics.core.transport.net.Response;
import com.huawei.hms.analytics.framework.a.a;
import com.huawei.hms.analytics.framework.b.b;
import com.huawei.hms.analytics.framework.config.ICallback;
import com.huawei.hms.analytics.framework.config.ICollectorConfig;
import com.huawei.hms.analytics.framework.config.IMandatoryParameters;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class e
implements Runnable {
    public ICallback a;
    public boolean b;
    private byte[] c;
    private String d;
    private String e;
    private String f;
    private List<Event> g;

    public e(byte[] arrby, String string2, String string3, String string4, List<Event> list) {
        byte[] arrby2 = arrby != null ? (byte[])arrby.clone() : null;
        this.c = arrby2;
        this.d = string2;
        this.e = string4;
        this.f = string3;
        this.g = list;
    }

    private String[] a() {
        String[] arrstring = b.a().a(this.d).getCollectUrls(this.f);
        for (int i2 = 0; i2 < arrstring.length; ++i2) {
            if (!"oper".equals((Object)this.f)) {
                if ("maint".equals((Object)this.f)) {
                    arrstring[i2] = "{url}/common/hmshimaintqrt".replace((CharSequence)"{url}", (CharSequence)arrstring[i2]);
                    continue;
                }
                if ("diffprivacy".equals((Object)this.f)) {
                    arrstring[i2] = "{url}/common/common2".replace((CharSequence)"{url}", (CharSequence)arrstring[i2]);
                    continue;
                }
                if ("preins".equals((Object)this.f)) {
                    arrstring[i2] = "{url}/common/hmshioperbatch".replace((CharSequence)"{url}", (CharSequence)arrstring[i2]);
                    continue;
                }
            }
            arrstring[i2] = "{url}/common/hmshioperqrt".replace((CharSequence)"{url}", (CharSequence)arrstring[i2]);
        }
        return arrstring;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void run() {
        block6 : {
            HiLog.i("SendMission", "send data running");
            var1_1 = System.currentTimeMillis();
            var3_2 = new HttpTransportHandler();
            var4_3 = b.a().a;
            var3_2.setUrls(this.a());
            var3_2.setReportData(this.c);
            var5_4 = b.a().a(this.d);
            var6_5 = this.e;
            var7_6 = b.a().a(this.d);
            var8_7 = b.a().a.getAppVer();
            var9_8 = b.a().a.getModel();
            var10_9 = new HashMap();
            var10_9.put((Object)"App-Id", (Object)var7_6.getAppId());
            var10_9.put((Object)"App-Ver", (Object)var8_7);
            var10_9.put((Object)"Sdk-Name", (Object)"hianalytics");
            var10_9.put((Object)"Sdk-Ver", (Object)"5.2.0.301");
            var10_9.put((Object)"Device-Type", (Object)var9_8);
            var10_9.put((Object)"servicetag", (Object)this.d);
            HiLog.i("SendMission", "sendData RequestId : ".concat(String.valueOf((Object)var6_5)));
            var10_9.put((Object)"Request-Id", (Object)var6_5);
            var18_10 = var5_4.getHttpHeader(this.f);
            if (var18_10 != null) {
                var10_9.putAll(var18_10);
            }
            var3_2.setHttpHeaders((Map<String, String>)var10_9);
            var3_2.setSSLConfig(var4_3.getProtocols(), var4_3.getCaCertificatePath(), var4_3.isHighCipher());
            var19_11 = var3_2.execute().getHttpCode();
            if (var19_11 != 200) ** GOTO lbl33
            try {
                block7 : {
                    if (!this.b && (var33_12 = a.a(this.d)) != null && (var34_13 = this.g) != null && var34_13.size() > 0) {
                        HiLog.i("SendMission", "storageHandler deleteEvents");
                        var33_12.deleteEvents(this.g);
                    }
                    break block7;
lbl33: // 1 sources:
                    var26_14 = this.a;
                    if (var26_14 != null && var26_14.isNeedStorage() && (var32_15 = a.a(this.d)) != null) {
                        var32_15.insertEx(this.g);
                    }
                }
                if ((var27_16 = this.a) == null) break block6;
            }
            catch (Throwable var20_20) {
                var21_21 = this.a;
                if (var21_21 != null) {
                    var21_21.onResult(var19_11, var1_1, this.g);
                }
                var22_22 = new StringBuilder("events PostRequest sendevent TYPE : %s, TAG : %s, resultCode: %d ,reqID:");
                var22_22.append(this.e);
                var24_23 = var22_22.toString();
                var25_24 = new Object[]{this.f, this.d, var19_11};
                HiLog.i("SendMission", var24_23, var25_24);
                throw var20_20;
            }
            var27_16.onResult(var19_11, var1_1, this.g);
        }
        var28_17 = new StringBuilder("events PostRequest sendevent TYPE : %s, TAG : %s, resultCode: %d ,reqID:");
        var28_17.append(this.e);
        var30_18 = var28_17.toString();
        var31_19 = new Object[]{this.f, this.d, var19_11};
        HiLog.i("SendMission", var30_18, var31_19);
        return;
    }
}

