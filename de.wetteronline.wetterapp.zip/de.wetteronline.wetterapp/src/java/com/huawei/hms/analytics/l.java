/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.i;
import com.huawei.hms.common.ApiException;
import com.huawei.hms.common.internal.AnyClient;
import com.huawei.hms.common.internal.ResponseErrorCode;
import com.huawei.hms.common.internal.TaskApiCall;
import com.huawei.hms.support.api.client.Status;
import je.g;

public final class l
extends TaskApiCall<i, String> {
    public l(String string, String string2) {
        super(string, string2, null);
    }

    @Override
    public final /* synthetic */ void doExecute(AnyClient anyClient, ResponseErrorCode responseErrorCode, String string, g g2) {
        if (responseErrorCode != null && g2 != null) {
            if (responseErrorCode.getErrorCode() == 0) {
                HiLog.i("HiAnalyticsTaskApiRequire", "HMS API call succeed.");
                g2.b("HMS API call succeed.");
                return;
            }
            HiLog.w("HiAnalyticsTaskApiRequire", "HMS API call failed. header.getErrorCode() != CommonCode.OK ");
            g2.a(new ApiException(new Status(responseErrorCode.getErrorCode(), responseErrorCode.getErrorReason())));
            return;
        }
        HiLog.w("HiAnalyticsTaskApiRequire", "HMS API call failed. header or taskCompletionSource is null");
    }

    @Override
    public final int getMinApkVersion() {
        return 40000000;
    }
}

