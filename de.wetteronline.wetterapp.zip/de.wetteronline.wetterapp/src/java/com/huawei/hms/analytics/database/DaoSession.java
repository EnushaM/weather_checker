/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.util.Map
 *  mt.a
 *  nt.a
 *  nt.c
 *  ot.a
 */
package com.huawei.hms.analytics.database;

import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.database.APIEvent;
import com.huawei.hms.analytics.database.APIEventDao;
import com.huawei.hms.analytics.database.EventDao;
import java.util.Map;
import nt.c;
import ot.a;

public class DaoSession
extends kt.c {
    private final APIEventDao aPIEventDao;
    private final a aPIEventDaoConfig;
    private final EventDao eventDao;
    private final a eventDaoConfig;

    public DaoSession(mt.a a2, c c3, Map<Class<? extends kt.a<?, ?>>, a> map) {
        a a4;
        EventDao eventDao;
        APIEventDao aPIEventDao;
        a a5;
        super(a2);
        this.aPIEventDaoConfig = a4 = new a((a)map.get(APIEventDao.class));
        a4.a(c3);
        this.eventDaoConfig = a5 = new a((a)map.get(EventDao.class));
        a5.a(c3);
        this.aPIEventDao = aPIEventDao = new APIEventDao(a4, this);
        this.eventDao = eventDao = new EventDao(a5, this);
        this.registerDao(APIEvent.class, aPIEventDao);
        this.registerDao(Event.class, eventDao);
    }

    public void clear() {
        nt.a a2;
        nt.a a4 = this.aPIEventDaoConfig.k;
        if (a4 != null) {
            a4.clear();
        }
        if ((a2 = this.eventDaoConfig.k) != null) {
            a2.clear();
        }
    }

    public APIEventDao getAPIEventDao() {
        return this.aPIEventDao;
    }

    public EventDao getEventDao() {
        return this.eventDao;
    }
}

