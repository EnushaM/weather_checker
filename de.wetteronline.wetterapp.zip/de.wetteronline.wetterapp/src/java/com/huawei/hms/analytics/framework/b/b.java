/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  j
 *  j$.util.concurrent.ConcurrentHashMap
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.huawei.hms.analytics.framework.b;

import com.huawei.hms.analytics.framework.b.a;
import com.huawei.hms.analytics.framework.b.c;
import com.huawei.hms.analytics.framework.config.ICollectorConfig;
import com.huawei.hms.analytics.framework.config.IMandatoryParameters;
import java.util.Map;

public final class b {
    private static b c = new b();
    public IMandatoryParameters a;
    public Map<String, a> b = new j.ConcurrentHashMap();

    public static b a() {
        return c;
    }

    public final ICollectorConfig a(String string2) {
        a a2 = (a)this.b.get((Object)string2);
        if (a2 != null) {
            return a2.a;
        }
        return null;
    }

    public final void a(String string2, IMandatoryParameters iMandatoryParameters, a a2) {
        b b3 = this;
        synchronized (b3) {
            this.b.put((Object)string2, (Object)a2);
            if (this.a == null && iMandatoryParameters != null) {
                this.a = iMandatoryParameters;
            }
            return;
        }
    }

    public final c b(String string2) {
        a a2 = (a)this.b.get((Object)string2);
        if (a2 != null) {
            return a2.d;
        }
        return null;
    }
}

