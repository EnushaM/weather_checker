/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Bundle
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Set
 *  je.f
 */
package com.huawei.hms.analytics;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import com.huawei.hms.analytics.ai;
import com.huawei.hms.analytics.type.ReportPolicy;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import je.f;

public class HiAnalyticsInstance {
    private static final String TAG = "HiAnalyticsCreation";
    private static ai externalInstance;
    private static HiAnalyticsInstance instance;

    private HiAnalyticsInstance() {
    }

    public static HiAnalyticsInstance getInstance(Context context) {
        if (instance == null) {
            HiAnalyticsInstance.syncInstance(context);
        }
        return instance;
    }

    /*
     * Exception decompiling
     */
    private static ai synInit(Context var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl65 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static void syncInstance(Context context) {
        Class<HiAnalyticsInstance> class_ = HiAnalyticsInstance.class;
        synchronized (HiAnalyticsInstance.class) {
            if (instance == null) {
                instance = new HiAnalyticsInstance();
                externalInstance = HiAnalyticsInstance.synInit(context);
            }
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return;
        }
    }

    public void clearCachedData() {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.hij();
        }
    }

    public f<String> getAAID() {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            return ai2.ghi();
        }
        return null;
    }

    public Map<String, String> getUserProfiles(boolean bl2) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            return ai2.lmn(bl2);
        }
        return new HashMap();
    }

    public boolean isRestrictionEnabled() {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            return ai2.ijk();
        }
        return false;
    }

    public void onEvent(String string2, Bundle bundle) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.lmn(string2, bundle);
        }
    }

    public void pageEnd(String string2) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.klm(string2);
        }
    }

    public void pageStart(String string2, String string3) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.klm(string2, string3);
        }
    }

    @Deprecated
    public void regHmsSvcEvent() {
    }

    public void setAnalyticsEnabled(boolean bl2) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.hij(bl2);
        }
    }

    @Deprecated
    public void setAutoCollectionEnabled(boolean bl2) {
    }

    public void setCollectAdsIdEnabled(boolean bl2) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.ikl(bl2);
        }
    }

    @Deprecated
    public void setCurrentActivity(Activity activity, String string2, String string3) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.lmn(activity, string2, string3);
        }
    }

    public void setMinActivitySessions(long l2) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.ikl(l2);
        }
    }

    public void setPushToken(String string2) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.ijk(string2);
        }
    }

    public void setReportPolicies(Set<ReportPolicy> set) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.lmn(set);
        }
    }

    public void setRestrictionEnabled(boolean bl2) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.ijk(bl2);
        }
    }

    public void setSessionDuration(long l2) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.ijk(l2);
        }
    }

    public void setUserId(String string2) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.ikl(string2);
        }
    }

    public void setUserProfile(String string2, String string3) {
        ai ai2 = externalInstance;
        if (ai2 != null) {
            ai2.lmn(string2, string3);
        }
    }

    @Deprecated
    public void unRegHmsSvcEvent() {
    }
}

