/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.security.cert.X509Certificate
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.Locale
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  javax.net.ssl.SSLException
 *  javax.security.auth.x500.X500Principal
 */
package com.huawei.hms.analytics.core.transport.net;

import com.huawei.hms.analytics.core.transport.net.b;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.net.ssl.SSLException;
import javax.security.auth.x500.X500Principal;

public final class c {
    private static final Pattern a = Pattern.compile((String)"^(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}$");
    private static final String[] b;

    public static {
        Object[] arrobject = new String[]{"ac", "co", "com", "ed", "edu", "go", "gouv", "gov", "info", "lg", "ne", "net", "or", "org"};
        b = arrobject;
        Arrays.sort((Object[])arrobject);
    }

    private static int a(String string2) {
        int n2 = 0;
        for (int i2 = 0; i2 < string2.length(); ++i2) {
            if (string2.charAt(i2) != '.') continue;
            ++n2;
        }
        return n2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static void a(String var0, X509Certificate var1_1) {
        block12 : {
            var2_2 = new b(var1_1.getSubjectX500Principal());
            var2_2.c = 0;
            var2_2.d = 0;
            var2_2.e = 0;
            var2_2.f = 0;
            var2_2.g = var2_2.a.toCharArray();
            var3_3 = Collections.emptyList();
            var4_4 = var2_2.a();
            if (var4_4 == null) break block12;
            block0 : while ((var7_5 = var2_2.c) < var2_2.b) {
                block13 : {
                    var8_6 = var2_2.g[var7_5];
                    if (var8_6 == '\"') break block13;
                    var16_12 = var8_6 != '#' ? (var8_6 != '+' && var8_6 != ',' && var8_6 != ';' ? var2_2.c() : "") : var2_2.b();
                    ** GOTO lbl32
                }
                var2_2.c = var9_7 = var7_5 + 1;
                var2_2.d = var9_7;
                do {
                    block14 : {
                        var2_2.e = var9_7;
                        var10_8 = var2_2.c;
                        if (var10_8 == var2_2.b) {
                            var11_17 = new StringBuilder("Unexpected end of DN: ");
                            var11_17.append(var2_2.a);
                            throw new IllegalStateException(var11_17.toString());
                        }
                        var13_9 = var2_2.g;
                        if (var13_9[var10_8] != '\"') break block14;
                        while ((var10_8 = (var2_2.c = var10_8 + 1)) < var2_2.b && var2_2.g[var10_8] == ' ') {
                        }
                        var14_10 = var2_2.g;
                        var15_11 = var2_2.d;
                        var16_12 = new String(var14_10, var15_11, var2_2.e - var15_11);
lbl32: // 2 sources:
                        if ("cn".equalsIgnoreCase(var4_4)) {
                            if (var3_3.isEmpty()) {
                                var3_3 = new ArrayList();
                            }
                            var3_3.add((Object)var16_12);
                        }
                        if ((var17_13 = var2_2.c) >= var2_2.b) break block0;
                        var18_14 = var2_2.g;
                        if (var18_14[var17_13] != ',' && var18_14[var17_13] != ';' && var18_14[var17_13] != '+') {
                            var21_15 = new StringBuilder("Malformed DN: ");
                            var21_15.append(var2_2.a);
                            throw new IllegalStateException(var21_15.toString());
                        }
                        var2_2.c = var17_13 + 1;
                        var4_4 = var2_2.a();
                        if (var4_4 != null) continue block0;
                        var19_16 = new StringBuilder("Malformed DN: ");
                        var19_16.append(var2_2.a);
                        throw new IllegalStateException(var19_16.toString());
                    }
                    var13_9[var2_2.e] = var13_9[var10_8] == '\\' ? var2_2.d() : var13_9[var10_8];
                    var2_2.c = 1 + var2_2.c;
                    var9_7 = 1 + var2_2.e;
                } while (true);
            }
        }
        if (!var3_3.isEmpty()) {
            var5_18 = new String[var3_3.size()];
            var3_3.toArray(var5_18);
        } else {
            var5_18 = null;
        }
        c.a(var0, (String[])var5_18, c.a(var1_1));
    }

    private static void a(String string2, String[] arrstring, String[] arrstring2) {
        LinkedList linkedList = new LinkedList();
        if (arrstring != null && arrstring.length > 0 && arrstring[0] != null) {
            linkedList.add((Object)arrstring[0]);
        }
        if (arrstring2 != null) {
            for (String string3 : arrstring2) {
                if (string3 == null) continue;
                linkedList.add((Object)string3);
            }
        }
        if (!linkedList.isEmpty()) {
            StringBuffer stringBuffer = new StringBuffer();
            String string4 = string2.trim().toLowerCase(Locale.ENGLISH);
            Iterator iterator = linkedList.iterator();
            int n2 = 0;
            while (iterator.hasNext()) {
                int n3;
                String string5;
                int n4;
                int n5;
                String string6 = ((String)iterator.next()).toLowerCase(Locale.ENGLISH);
                stringBuffer.append(" <");
                stringBuffer.append(string6);
                stringBuffer.append('>');
                if (iterator.hasNext()) {
                    stringBuffer.append(" OR");
                }
                boolean bl2 = string6.startsWith("*.");
                int n6 = 1;
                int n7 = bl2 && string6.indexOf(46, 2) != -1 && (n5 = (n3 = string6.length()) >= 7 && n3 <= 9 && string6.charAt(n4 = n3 - 3) == '.' && Arrays.binarySearch((Object[])b, (Object)(string5 = string6.substring(2, n4))) >= 0 ? 0 : n6) != 0 && !a.matcher((CharSequence)string2).matches() ? n6 : 0;
                if (n7 != 0) {
                    int n8 = string4.endsWith(string6.substring(n6));
                    if (n8 != 0) {
                        if (c.a(string4) != c.a(string6)) {
                            n6 = 0;
                        }
                        n2 = n6;
                    } else {
                        n2 = n8;
                    }
                } else {
                    n2 = string4.equals((Object)string6);
                }
                if (n2 == 0) continue;
            }
            if (n2 != 0) {
                return;
            }
            StringBuilder stringBuilder = new StringBuilder("hostname in certificate didn't match: <");
            stringBuilder.append(string2);
            stringBuilder.append("> !=");
            stringBuilder.append((Object)stringBuffer);
            throw new SSLException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder("Certificate for <");
        stringBuilder.append(string2);
        stringBuilder.append("> doesn't contain CN or DNS subjectAlt");
        throw new SSLException(stringBuilder.toString());
    }

    /*
     * Exception decompiling
     */
    private static String[] a(X509Certificate var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl14 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }
}

