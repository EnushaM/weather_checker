/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics.framework.policy;

public interface IStoragePolicy {
    public boolean decide(PolicyType var1, String var2);

    public boolean decide(PolicyType var1, String var2, long var3);

    public static final class PolicyType
    extends Enum<PolicyType> {
        private static final /* synthetic */ PolicyType[] $VALUES;
        public static final /* enum */ PolicyType NETWORK;
        public static final /* enum */ PolicyType PARAMS;
        public static final /* enum */ PolicyType STORAGECYCLY;
        public static final /* enum */ PolicyType STORAGELENGTH;
        public static final /* enum */ PolicyType STORAGESIZE;

        public static {
            PolicyType policyType;
            PolicyType policyType2;
            PolicyType policyType3;
            PolicyType policyType4;
            PolicyType policyType5;
            NETWORK = policyType = new PolicyType();
            STORAGECYCLY = policyType3 = new PolicyType();
            STORAGELENGTH = policyType4 = new PolicyType();
            STORAGESIZE = policyType2 = new PolicyType();
            PARAMS = policyType5 = new PolicyType();
            $VALUES = new PolicyType[]{policyType, policyType3, policyType4, policyType2, policyType5};
        }

        public static PolicyType valueOf(String string2) {
            return (PolicyType)Enum.valueOf(PolicyType.class, (String)string2);
        }

        public static PolicyType[] values() {
            return (PolicyType[])$VALUES.clone();
        }
    }

}

