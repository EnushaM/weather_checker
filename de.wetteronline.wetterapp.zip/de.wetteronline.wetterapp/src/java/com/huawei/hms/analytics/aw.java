/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AppOpsManager
 *  android.content.Context
 *  android.content.pm.PackageManager
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.os.Process
 *  android.text.TextUtils
 *  java.io.File
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package com.huawei.hms.analytics;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Process;
import android.text.TextUtils;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.aw;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.framework.policy.IStoragePolicy;
import java.io.File;

public final class aw
implements IStoragePolicy {
    public String lmn;

    public aw() {
    }

    public aw(String string) {
        this.lmn = string;
    }

    /*
     * Exception decompiling
     */
    private boolean lmn() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl12 : NEW : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final boolean decide(IStoragePolicy.PolicyType var1_1, String var2_2) {
        block18 : {
            block21 : {
                block20 : {
                    block19 : {
                        block17 : {
                            block16 : {
                                block13 : {
                                    block14 : {
                                        block15 : {
                                            block12 : {
                                                var3_3 = 1.lmn[var1_1.ordinal()];
                                                if (var3_3 == 1) {
                                                    if (new File(aa.lmn().klm.bcd.getDatabasePath("userEvent.db").getPath()).length() <= 0xA00000L) return false;
                                                    return true;
                                                }
                                                if (var3_3 != 2) {
                                                    if (var3_3 == 3) return this.lmn();
                                                    return true;
                                                }
                                                var4_4 = aa.lmn().klm.bcd;
                                                var5_5 = Process.myPid();
                                                var6_6 = Process.myUid();
                                                var7_7 = -2;
                                                if (var4_4 == null || var4_4.checkPermission("android.permission.ACCESS_NETWORK_STATE", var5_5, var6_6) == -1) break block12;
                                                var8_8 = AppOpsManager.permissionToOp((String)"android.permission.ACCESS_NETWORK_STATE");
                                                if (var8_8 == null) break block13;
                                                var15_9 = var4_4.getPackageName();
                                                if (var15_9 != null) break block14;
                                                var18_10 = var4_4.getPackageManager().getPackagesForUid(var6_6);
                                                if (var18_10 != null && var18_10.length > 0) break block15;
                                            }
                                            var7_7 = -1;
                                            break block16;
                                        }
                                        var15_9 = var18_10[0];
                                    }
                                    if ((var17_12 = (var16_11 = (AppOpsManager)var4_4.getSystemService(AppOpsManager.class)) == null ? var7_7 : var16_11.noteProxyOpNoThrow(var8_8, var15_9)) != 0) break block16;
                                }
                                var7_7 = 0;
                            }
                            var9_13 = "";
                            if (var7_7 == 0) break block17;
                            HiLog.w("DeviceToolsKit", "not have network state phone permission!");
                            break block18;
                        }
                        var10_14 = (ConnectivityManager)var4_4.getSystemService("connectivity");
                        if (var10_14 == null || (var11_15 = var10_14.getActiveNetworkInfo()) == null || !var11_15.isConnected()) break block18;
                        if (var11_15.getType() != 1) break block19;
                        var9_13 = "WIFI";
                        break block18;
                    }
                    if (var11_15.getType() != 0) break block20;
                    var9_13 = var11_15.getSubtypeName();
                    HiLog.i("DeviceToolsKit", "Network getSubtypeName : ".concat(String.valueOf((Object)var9_13)));
                    switch (var11_15.getSubtype()) {
                        default: {
                            if (!var9_13.equalsIgnoreCase("TD-SCDMA") && !var9_13.equalsIgnoreCase("WCDMA") && !var9_13.equalsIgnoreCase("CDMA2000")) break;
                            ** GOTO lbl50
                        }
                        case 13: {
                            var14_16 = "4G";
                            ** break;
                        }
lbl50: // 2 sources:
                        case 3: 
                        case 5: 
                        case 6: 
                        case 8: 
                        case 9: 
                        case 10: 
                        case 12: 
                        case 14: 
                        case 15: {
                            var9_13 = "3G";
                            break;
                        }
                        case 1: 
                        case 2: 
                        case 4: 
                        case 7: 
                        case 11: {
                            var14_16 = "2G";
lbl55: // 2 sources:
                            var9_13 = var14_16;
                            break;
                        }
                    }
                    break block18;
                }
                if (var11_15.getType() != 16) break block21;
                var9_13 = "COMPANION_PROXY";
                ** GOTO lbl65
            }
            if (var11_15.getType() == 9) {
                var9_13 = "ETHERNET";
lbl65: // 2 sources:
                HiLog.i("DeviceToolsKit", "type name = ".concat(var9_13));
            } else {
                var12_17 = new StringBuilder("type name = ");
                var12_17.append(var11_15.getType());
                HiLog.i("DeviceToolsKit", var12_17.toString());
                var9_13 = "OTHER_NETWORK_TYPE";
            }
        }
        if (TextUtils.isEmpty((CharSequence)var9_13) == false) return true;
        HiLog.w("ReportPolicy", "The network is unavailable.");
        return false;
    }

    @Override
    public final boolean decide(IStoragePolicy.PolicyType policyType, String string, long l4) {
        int n2 = 1.lmn[policyType.ordinal()];
        if (n2 != 4) {
            if (n2 != 5) {
                return false;
            }
            return l4 >= aa.lmn().klm.h;
        }
        return System.currentTimeMillis() - l4 > 604800000L;
    }
}

