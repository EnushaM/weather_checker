/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 */
package com.huawei.hms.analytics.framework.f;

import com.huawei.hms.analytics.core.log.HiLog;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class a {
    private static a a = new a(5);
    private static a b = new a(1);
    private ThreadPoolExecutor c;

    private a(int n2) {
        ThreadPoolExecutor threadPoolExecutor;
        LinkedBlockingQueue linkedBlockingQueue = new LinkedBlockingQueue(5000);
        this.c = threadPoolExecutor = new ThreadPoolExecutor(0, n2, 10000L, TimeUnit.MILLISECONDS, (BlockingQueue)linkedBlockingQueue);
    }

    public static a a() {
        return a;
    }

    public static a b() {
        return b;
    }

    public final void a(Runnable runnable) {
        try {
            this.c.execute((Runnable)new a(runnable));
            return;
        }
        catch (RejectedExecutionException rejectedExecutionException) {
            HiLog.w("MissionThread", "addToQueue() Exception has happened! From rejected execution");
            return;
        }
    }

    public static final class a
    implements Runnable {
        private Runnable a;

        public a(Runnable runnable) {
            this.a = runnable;
        }

        public final void run() {
            Runnable runnable = this.a;
            if (runnable != null) {
                try {
                    runnable.run();
                    return;
                }
                catch (Exception exception) {
                    StringBuilder stringBuilder = new StringBuilder("other error :");
                    stringBuilder.append(exception.getMessage());
                    HiLog.e("MissionThread", stringBuilder.toString());
                }
            }
        }
    }

}

