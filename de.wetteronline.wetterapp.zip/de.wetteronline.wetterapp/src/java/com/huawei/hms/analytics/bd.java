/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.huawei.hms.analytics.database.APIEventDao
 *  com.huawei.hms.analytics.database.DaoSession
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.Collection
 *  java.util.List
 */
package com.huawei.hms.analytics;

import android.content.Context;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ae;
import com.huawei.hms.analytics.bb;
import com.huawei.hms.analytics.bu;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.database.APIEvent;
import com.huawei.hms.analytics.database.APIEventDao;
import com.huawei.hms.analytics.database.DaoSession;
import java.util.Collection;
import java.util.List;

public final class bd
implements Runnable {
    private ae ikl;
    private List<APIEvent> klm;
    private Context lmn;

    public bd(List<APIEvent> list) {
        Context context;
        this.lmn = context = aa.lmn().klm.bcd;
        this.klm = list;
        this.ikl = ae.lmn(context);
        bb.lmn(this.lmn);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void run() {
        block4 : {
            block5 : {
                var1_1 = new StringBuilder("Begin to run EventApiUsageRecordTask...");
                var1_1.append(this.klm.size());
                HiLog.i("EventApiUsageRecordMission", var1_1.toString());
                var3_2 = this.klm;
                if (var3_2 == null || var3_2.size() == 0) break block4;
                var4_3 = bu.klm(this.lmn, "latest_upload_time", "apiUsageUploadKey");
                var6_4 = System.currentTimeMillis();
                if (var4_3 != -1L) break block5;
                bu.lmn(this.lmn, "latest_upload_time", "apiUsageUploadKey", var6_4);
                ** GOTO lbl-1000
            }
            if (var6_4 - var4_3 > 86400000L) {
                HiLog.i("EventApiUsageRecordMission", "api usage cycle is exceeded the threshold.");
                bu.lmn(this.lmn, "latest_upload_time", "apiUsageUploadKey", var6_4);
                var8_5 = true;
            } else lbl-1000: // 2 sources:
            {
                var8_5 = false;
            }
            if (!var8_5 && this.klm.size() <= 20) {
                var11_6 = this.ikl.klm();
                if (var11_6.size() + this.klm.size() > 20) {
                    HiLog.i("EventApiUsageRecordMission", "auto report api data for bi");
                    this.klm.addAll(var11_6);
                    this.ikl.lmn();
                    bb.lmn(this.lmn).lmn(var11_6);
                    return;
                }
                var12_7 = this.ikl;
                var13_8 = this.klm;
                var12_7.lmn.getAPIEventDao().insertInTx(var13_8);
                return;
            }
            HiLog.i("EventApiUsageRecordMission", "auto report api data for bi");
            var9_9 = this.ikl.klm();
            this.ikl.lmn();
            this.klm.addAll(var9_9);
            bb.lmn(this.lmn).lmn(this.klm);
            return;
        }
        HiLog.w("EventApiUsageRecordMission", "apiEvents is empty, no data save");
    }
}

