/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.IllegalAccessException
 *  java.lang.Long
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 *  java.util.regex.Pattern
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics.internal.filter;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import com.huawei.hms.analytics.ak;
import com.huawei.hms.analytics.al;
import com.huawei.hms.analytics.bn;
import com.huawei.hms.analytics.bt;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.y;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.json.JSONObject;

public class EventFilter
implements ak {
    private Method hij;
    private Object ijk;
    private Method ikl;
    private Method klm;
    private al lmn;

    /*
     * Exception decompiling
     */
    private boolean klm(String var1, Bundle var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl41 : ILOAD_3 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static long lmn(String string) {
        try {
            long l4 = Long.parseLong((String)string);
            return l4;
        }
        catch (NumberFormatException numberFormatException) {
            return 0L;
        }
    }

    private static void lmn(Bundle bundle) {
        bundle.remove("$HA_FIXED_TAG");
        bundle.remove("$HA_FIXED_TYPE");
        bundle.remove("$HA_FIXED_SOURCE");
        bundle.remove("$HA_FIXED_TIMESTAMP");
    }

    private static boolean lmn(String string, String string2) {
        if (!TextUtils.isEmpty((CharSequence)string) && "oper".equals((Object)string2)) {
            return true;
        }
        HiLog.e("IncidentFilter", "third callback params invalid");
        return false;
    }

    public String getUserProfile(String string) {
        HiLog.d("IncidentFilter", "get user property#".concat(String.valueOf((Object)string)));
        al al2 = this.lmn;
        if (al2 == null) {
            return null;
        }
        return al2.lmn(string);
    }

    /*
     * Exception decompiling
     */
    @Override
    public final void lmn(Context var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl153 : RETURN : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public final void lmn(al al2) {
        this.lmn = al2;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public final void lmn(String string, Bundle bundle) {
        Method method = this.ikl;
        if (method == null) {
            return;
        }
        try {
            method.invoke(this.ijk, new Object[]{string, bundle});
            return;
        }
        catch (InvocationTargetException throwable2) {
            String string2;
            block4 : {
                string2 = "Invocation target warning";
                break block4;
                catch (IllegalAccessException throwable2) {
                    string2 = "Illegal access warning";
                }
            }
            HiLog.w("IncidentFilter", string2);
            return;
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    public final void lmn(Map<Object, Object> var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl6 : LDC : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public final boolean lmn(String string, String string2, String string3, Bundle bundle) {
        if (this.klm == null) {
            return false;
        }
        bundle.putString("$HA_FIXED_TAG", string);
        bundle.putString("$HA_FIXED_TYPE", string2);
        bundle.putString("$HA_FIXED_SOURCE", "Event");
        return this.klm(string3, bundle);
    }

    @Override
    public final boolean lmn(String string, String string2, String string3, Bundle bundle, long l4) {
        if (this.klm == null) {
            return false;
        }
        bundle.putString("$HA_FIXED_TAG", string);
        bundle.putString("$HA_FIXED_TYPE", string2);
        bundle.putString("$HA_FIXED_SOURCE", "StreamEvent");
        bundle.putString("$HA_FIXED_TIMESTAMP", String.valueOf((long)l4));
        return this.klm(string3, bundle);
    }

    public void logFilteredEvent(String string, Bundle bundle) {
        HiLog.d("IncidentFilter", "log filtered event#".concat(String.valueOf((Object)string)));
        if (this.lmn == null) {
            return;
        }
        if (bundle != null) {
            String string2 = bundle.getString("$HA_FIXED_SOURCE");
            String string3 = bundle.getString("$HA_FIXED_TAG");
            if (string != null && string.length() <= 256) {
                if (!bn.lmn("eventId", string, y.klm)) {
                    return;
                }
                String string4 = bundle.getString("$HA_FIXED_TYPE");
                EventFilter.lmn(bundle.getString("$HA_FIXED_TIMESTAMP"));
                EventFilter.lmn(bundle);
                bt bt2 = new bt(string, true);
                if (!bt2.lmn(bundle)) {
                    HiLog.w("IncidentFilter", "bundle params is invalid.");
                    return;
                }
                if ("Event".equals((Object)string2)) {
                    HiLog.i("IncidentFilter", "begin onEventFiltered");
                    if (EventFilter.lmn(string3, string4)) {
                        this.lmn.lmn(string3, (List<JSONObject>)bt2.klm);
                        return;
                    }
                } else if ("StreamEvent".equals((Object)string2)) {
                    HiLog.i("IncidentFilter", "begin onStreamEventFiltered");
                    if (EventFilter.lmn(string3, string4)) {
                        this.lmn.klm(string3, (List<JSONObject>)bt2.klm);
                        return;
                    }
                } else {
                    HiLog.i("IncidentFilter", "begin onEventFiltered with default");
                    this.lmn.lmn("_openness_config_tag", (List<JSONObject>)bt2.klm);
                }
            }
            return;
        }
        HiLog.e("IncidentFilter", "the params is null");
    }
}

