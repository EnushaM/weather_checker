/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics.framework.config;

import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.framework.config.DeviceAttributeCollector;
import com.huawei.hms.analytics.framework.config.EvtHeaderAttributeCollector;
import com.huawei.hms.analytics.framework.config.RomAttributeCollector;
import java.util.Map;
import org.json.JSONObject;

public interface ICollectorConfig {
    public String getAppId();

    public String[] getCollectUrls(String var1);

    public DeviceAttributeCollector getDeviceAttribute(String var1);

    public EvtHeaderAttributeCollector getEvtCustomHeader(String var1, JSONObject var2);

    public Map<String, String> getHttpHeader(String var1);

    public RomAttributeCollector getRomAttribute(String var1);

    public Event getSpecialEvent(String var1);

    public boolean isEnableSession(String var1);
}

