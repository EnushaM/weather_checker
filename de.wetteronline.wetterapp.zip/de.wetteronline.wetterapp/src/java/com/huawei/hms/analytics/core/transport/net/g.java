/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.security.cert.Certificate
 *  java.security.cert.X509Certificate
 *  javax.net.ssl.HostnameVerifier
 *  javax.net.ssl.SSLException
 *  javax.net.ssl.SSLSession
 */
package com.huawei.hms.analytics.core.transport.net;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.transport.net.c;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;

public final class g
implements HostnameVerifier {
    public final boolean verify(String string2, SSLSession sSLSession) {
        try {
            c.a(string2, (X509Certificate)sSLSession.getPeerCertificates()[0]);
            return true;
        }
        catch (SSLException sSLException) {
            HiLog.e("StrictHostnameChecker", "verify,SSLException");
            return false;
        }
    }
}

