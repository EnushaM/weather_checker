/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  java.lang.Object
 */
package com.huawei.hms.analytics;

import android.app.Activity;
import android.content.Context;
import com.huawei.hms.analytics.HiAnalyticsInstance;

public class HiAnalytics {
    public static HiAnalyticsInstance getInstance(Activity activity) {
        return HiAnalyticsInstance.getInstance((Context)activity);
    }

    public static HiAnalyticsInstance getInstance(Context context) {
        return HiAnalyticsInstance.getInstance(context);
    }
}

