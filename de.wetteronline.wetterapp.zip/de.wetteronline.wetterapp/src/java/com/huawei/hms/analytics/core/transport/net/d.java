/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 */
package com.huawei.hms.analytics.core.transport.net;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class d {
    public static final List<String> a;
    public static final List<String> b;
    public static final List<String> c;
    public static final List<String> d;
    private static final String[] e;
    private static final String[] f;
    private static final String[] g;
    private static final String[] h;

    public static {
        Object[] arrobject = new String[]{"TLS_DHE_DSS_WITH_AES_128_CBC_SHA", "TLS_DHE_RSA_WITH_AES_128_CBC_SHA", "TLS_DHE_DSS_WITH_AES_256_CBC_SHA", "TLS_DHE_RSA_WITH_AES_256_CBC_SHA", "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA", "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA", "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA", "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA"};
        e = arrobject;
        a = Collections.unmodifiableList((List)Arrays.asList((Object[])arrobject));
        Object[] arrobject2 = new String[]{"TLS_DHE_RSA_WITH_AES_128_GCM_SHA256", "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384", "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256", "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384", "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256", "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384", "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256", "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"};
        f = arrobject2;
        b = Collections.unmodifiableList((List)Arrays.asList((Object[])arrobject2));
        Object[] arrobject3 = new String[]{"TLS_RSA", "CBC", "TEA", "SHA0", "MD2", "MD4", "RIPEMD", "NULL", "RC4", "DES", "DESX", "DES40", "RC2", "MD5", "ANON", "TLS_EMPTY_RENEGOTIATION_INFO_SCSV"};
        g = arrobject3;
        c = Collections.unmodifiableList((List)Arrays.asList((Object[])arrobject3));
        Object[] arrobject4 = new String[]{"TLS_RSA", "TEA", "SHA0", "MD2", "MD4", "RIPEMD", "NULL", "RC4", "DES", "DESX", "DES40", "RC2", "MD5", "ANON", "TLS_EMPTY_RENEGOTIATION_INFO_SCSV"};
        h = arrobject4;
        d = Collections.unmodifiableList((List)Arrays.asList((Object[])arrobject4));
    }
}

