/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.IBinder
 *  android.text.TextUtils
 *  com.huawei.hms.analytics.o
 *  com.huawei.hms.analytics.q
 *  com.huawei.hms.analytics.t
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.text.TextUtils;
import com.huawei.hms.analytics.a;
import com.huawei.hms.analytics.n;
import com.huawei.hms.analytics.o;
import com.huawei.hms.analytics.q;
import com.huawei.hms.analytics.t;

public final class u
extends q {
    public o lmn;

    public u(Context context, a.lmn lmn2) {
        super(context, lmn2);
        Intent intent = new Intent();
        intent.setClassName("com.samsung.android.deviceidservice", "com.samsung.android.deviceidservice.DeviceIdService");
        this.lmn = new o(context, intent, (n)((Object)this));
    }

    public final void lmn(IBinder iBinder) {
        String string = new t("com.samsung.android.deviceidservice.IDeviceIdService", iBinder).lmn();
        if (!TextUtils.isEmpty((CharSequence)string)) {
            this.klm.lmn(string, "");
            return;
        }
        throw new IllegalArgumentException("oaid is empty");
    }

    public final void lmn(String string) {
        super.lmn(string);
    }
}

