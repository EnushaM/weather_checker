/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.huawei.hms.analytics.core.transport;

import com.huawei.hms.analytics.core.transport.net.Response;

public interface CallbackListener {
    public void onFailure(int var1);

    public void onSuccess(Response var1);
}

