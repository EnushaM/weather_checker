/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics.framework.config;

import org.json.JSONObject;

public interface EvtHeaderAttributeCollector {
    public JSONObject doCollector();
}

