/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.framework.config.RomAttributeCollector;
import org.json.JSONException;
import org.json.JSONObject;

public final class ax
implements RomAttributeCollector {
    public String a;
    public String abc;
    public int b;
    public String bcd;
    public int c;
    public String cde;
    public String d;
    public String def;
    public boolean e;
    public String efg;
    public String f;
    public String fgh;
    public String g;
    public String ghi;
    public String hij;
    public String ijk;
    public String ikl;
    public String klm;
    public String lmn;

    @Override
    public final JSONObject doCollector() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("_rom_ver", (Object)this.lmn);
            jSONObject.put("_emui_ver", (Object)this.klm);
            jSONObject.put("_model", (Object)this.ikl);
            jSONObject.put("_package_name", (Object)this.ijk);
            jSONObject.put("_app_ver", (Object)this.hij);
            jSONObject.put("_lib_ver", (Object)this.ghi);
            jSONObject.put("_lib_name", (Object)this.def);
            jSONObject.put("_channel", (Object)this.efg);
            jSONObject.put("_restriction_enabled", this.e);
            jSONObject.put("_terminal_name", (Object)this.fgh);
            jSONObject.put("_sys_language", (Object)this.abc);
            jSONObject.put("_manufacturer", (Object)this.a);
            jSONObject.put("_os", (Object)this.cde);
            jSONObject.put("_os_ver", (Object)this.bcd);
            jSONObject.put("_screen_height", this.b);
            jSONObject.put("_screen_width", this.c);
            jSONObject.put("_device_category", (Object)this.d);
            jSONObject.put("_ab_info", (Object)this.f);
            jSONObject.put("_oaid_tracking_flag", (Object)this.g);
            return jSONObject;
        }
        catch (JSONException jSONException) {
            HiLog.w("OpennessRomGathering", "doCollector JSONException");
            return jSONObject;
        }
    }
}

