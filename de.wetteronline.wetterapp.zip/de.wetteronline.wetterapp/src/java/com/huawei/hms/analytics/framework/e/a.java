/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.huawei.hms.analytics.framework.e;

import com.huawei.hms.analytics.framework.e.b;
import java.util.HashMap;
import java.util.Map;

public final class a {
    private static a a;
    private volatile Map<String, b> b = new HashMap();

    private a() {
    }

    public static a a() {
        if (a == null) {
            a.b();
        }
        return a;
    }

    private static void b() {
        Class<a> class_ = a.class;
        synchronized (a.class) {
            if (a == null) {
                a = new a();
            }
            // ** MonitorExit[var1] (shouldn't be in output)
            return;
        }
    }

    public final b a(String string2) {
        if (!this.b.containsKey((Object)string2)) {
            b b3 = new b();
            this.b.put((Object)string2, (Object)b3);
        }
        return (b)this.b.get((Object)string2);
    }
}

