/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.pm.FeatureInfo
 *  android.content.pm.PackageManager
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.provider.Settings
 *  android.provider.Settings$Global
 *  android.text.TextUtils
 *  android.util.DisplayMetrics
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.Locale
 *  java.util.Map
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.FeatureInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ac;
import com.huawei.hms.analytics.at;
import com.huawei.hms.analytics.au;
import com.huawei.hms.analytics.ax;
import com.huawei.hms.analytics.bj;
import com.huawei.hms.analytics.br;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.framework.config.DeviceAttributeCollector;
import com.huawei.hms.analytics.framework.config.EvtHeaderAttributeCollector;
import com.huawei.hms.analytics.framework.config.ICollectorConfig;
import com.huawei.hms.analytics.framework.config.RomAttributeCollector;
import com.huawei.hms.analytics.s;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.json.JSONObject;

public final class as
implements ICollectorConfig {
    private ax klm;
    private String lmn;

    public as(String string) {
        this.lmn = string;
    }

    @Override
    public final String getAppId() {
        return aa.lmn().klm.klm;
    }

    @Override
    public final String[] getCollectUrls(String string) {
        return aa.lmn().klm.lmn();
    }

    @Override
    public final DeviceAttributeCollector getDeviceAttribute(String string) {
        ab ab2 = aa.lmn().klm;
        s.lmn(ab2.bcd);
        at at2 = new at();
        at2.lmn = bj.lmn().ikl;
        at2.klm = ab2.n;
        at2.ikl = ab2.cde;
        at2.ijk = ab2.c;
        JSONObject jSONObject = aa.lmn().klm();
        String string2 = jSONObject != null ? jSONObject.toString() : "";
        at2.hij = string2;
        return at2;
    }

    @Override
    public final EvtHeaderAttributeCollector getEvtCustomHeader(String string, JSONObject jSONObject) {
        return new au(jSONObject);
    }

    @Override
    public final Map<String, String> getHttpHeader(String string) {
        Map<String, String> map;
        HashMap hashMap = new HashMap();
        if (br.ikl(aa.lmn().klm.bcd)) {
            hashMap.put((Object)"x-hasdk-realtime", (Object)"true");
        }
        hashMap.put((Object)"x-hasdk-productid", (Object)aa.lmn().klm.ghi);
        hashMap.put((Object)"x-hasdk-resourceid", (Object)aa.lmn().klm.fgh);
        hashMap.put((Object)"x-hasdk-token", (Object)aa.lmn().klm.def);
        hashMap.put((Object)"x-hasdk-clientid", (Object)aa.lmn().klm.efg);
        ac ac2 = aa.lmn().lmn(this.lmn);
        if (ac2 != null && (map = ac2.klm) != null && map.size() > 0) {
            hashMap.putAll(map);
        }
        return hashMap;
    }

    @Override
    public final RomAttributeCollector getRomAttribute(String string) {
        Configuration configuration;
        Locale locale;
        ab ab2 = aa.lmn().klm;
        ax ax2 = this.klm;
        String string2 = "";
        if (ax2 == null) {
            this.klm = new ax();
            String string3 = ab2.lmn;
            if (TextUtils.isEmpty((CharSequence)string3)) {
                ab2.lmn = string3 = br.lmn("ro.build.version.emui", string2);
            }
            String string4 = Build.MANUFACTURER;
            String string5 = "unknown";
            if (string4 == null) {
                string4 = string5;
            }
            DisplayMetrics displayMetrics = ab2.bcd.getResources().getDisplayMetrics();
            int n2 = displayMetrics.heightPixels;
            int n3 = displayMetrics.widthPixels;
            ax ax3 = this.klm;
            ax3.a = string4;
            ax3.b = n2;
            ax3.c = n3;
            String string6 = br.lmn("com.huawei.android.os.SystemPropertiesEx", "ro.huawei.build.display.id", string2);
            HiLog.i("DeviceToolsKit", "SystemPropertiesEx: get rom_ver: ".concat(String.valueOf((Object)string6)));
            if (TextUtils.isEmpty((CharSequence)string6)) {
                string6 = Build.DISPLAY;
                HiLog.i("DeviceToolsKit", "SystemProperties: get rom_ver: ".concat(String.valueOf((Object)string6)));
            }
            ax3.lmn = string6;
            ax ax4 = this.klm;
            ax4.hij = ab2.ikl;
            ax4.efg = ab2.hij;
            ax4.klm = string3;
            ax4.def = "hianalytics";
            ax4.ghi = "5.2.0.301";
            String string7 = Build.MODEL;
            if (string7 != null) {
                string5 = string7;
            }
            ax4.ikl = string5;
            ax4.cde = "android";
            ax4.bcd = Build.VERSION.RELEASE;
            ax4.ijk = ab2.bcd.getPackageName();
            ax ax5 = this.klm;
            Context context = ab2.bcd;
            Class[] arrclass = new Class[]{String.class, Boolean.TYPE};
            Object[] arrobject = new Object[2];
            String string8 = "ro.kernel.qemu";
            arrobject[0] = string8;
            Boolean bl = Boolean.FALSE;
            arrobject[1] = bl;
            Object object = br.lmn("com.huawei.android.os.SystemPropertiesEx", "getBoolean", arrclass, arrobject);
            if (object != null && object instanceof Boolean) {
                bl = (Boolean)object;
            }
            if (!bl.booleanValue()) {
                StringBuilder stringBuilder = new StringBuilder();
                FeatureInfo[] arrfeatureInfo = context.getPackageManager().getSystemAvailableFeatures();
                int n4 = arrfeatureInfo.length;
                for (int j = 0; j < n4; ++j) {
                    String string9 = arrfeatureInfo[j].name;
                    if (TextUtils.isEmpty((CharSequence)string9) || !string9.startsWith("com.huawei.software.features")) continue;
                    stringBuilder.append(string9);
                    stringBuilder.append('|');
                }
                String string10 = stringBuilder.toString();
                if (string10.length() > 0) {
                    string10 = string10.substring(0, string10.length() - 1);
                }
                string8 = string10;
            }
            ax5.d = string8;
        }
        String string11 = (configuration = ab2.bcd.getResources().getConfiguration()) != null && (locale = configuration.locale) != null ? locale.toString() : string2;
        Context context = ab2.bcd;
        if (br.ikl(context) && TextUtils.isEmpty((CharSequence)(string2 = Settings.Global.getString((ContentResolver)context.getContentResolver(), (String)"unified_device_name")))) {
            string2 = Build.MODEL;
        }
        ax ax6 = this.klm;
        ax6.e = ab2.a;
        ax6.abc = string11;
        ax6.fgh = string2;
        ax6.f = ab2.m;
        ax6.g = ab2.o;
        return ax6;
    }

    /*
     * Exception decompiling
     */
    @Override
    public final Event getSpecialEvent(String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl41 : ACONST_NULL : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public final boolean isEnableSession(String string) {
        return true;
    }
}

