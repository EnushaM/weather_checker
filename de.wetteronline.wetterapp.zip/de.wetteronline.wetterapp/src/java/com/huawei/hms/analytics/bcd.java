/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.os.Parcelable
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.analytics;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Parcelable;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.abc;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.az;
import com.huawei.hms.analytics.b;
import com.huawei.hms.analytics.cde;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.g;
import com.huawei.hms.analytics.hij;
import com.huawei.hms.analytics.j;
import com.huawei.hms.analytics.k;
import com.huawei.hms.api.HuaweiMobileServicesUtil;
import com.huawei.hms.common.internal.AnyClient;
import com.huawei.hms.common.internal.TaskApiCall;
import je.d;
import je.e;
import je.f;

public final class bcd
implements abc {
    private az.lmn ijk;
    private cde ikl;
    private g klm;
    private Context lmn;

    public bcd(Context context, ah ah2, az.lmn lmn2) {
        this.lmn = context;
        this.ikl = new cde(new b(ah2), lmn2);
        this.klm = new g(context);
        this.ijk = lmn2;
    }

    @Override
    public final void klm() {
        HiLog.i("HAServiceCommander", "unBindService is running");
        if (aa.lmn().klm.d) {
            this.lmn.unbindService((ServiceConnection)this.ikl);
            aa.lmn().klm.d = false;
        }
    }

    @Override
    public final void lmn() {
        HiLog.i("HAServiceCommander", "bindService is running");
        if (aa.lmn().klm.d) {
            HiLog.i("HAServiceCommander", "Service is already bind, when want to bind.");
            return;
        }
        if (HuaweiMobileServicesUtil.isHuaweiMobileServicesAvailable(this.lmn, 40000000) != 0) {
            HiLog.w("HAServiceCommander", "IE-005", "Missing hms core sdk,HMS version is too low");
            az.lmn lmn2 = this.ijk;
            if (lmn2 != null) {
                lmn2.lmn("3");
            }
            return;
        }
        g g2 = this.klm;
        k k2 = new k("hianalytics.analyticsEvtService", "");
        if (g2.lmn != null) {
            Intent intent = new Intent();
            k2.setParcelable((Parcelable)PendingIntent.getService((Context)g2.lmn, (int)1, (Intent)intent, (int)134217728));
        }
        f<j> f2 = g2.doWrite(k2);
        f2.b(new lmn(this.ijk));
        f2.d(new klm(f2, this.lmn, this.ikl, this.ijk));
    }

    public static final class klm
    implements e<j> {
        private ServiceConnection ijk;
        private Context ikl;
        private f<j> klm;
        public az.lmn lmn;

        public klm(f<j> f2, Context context, ServiceConnection serviceConnection, az.lmn lmn2) {
            this.klm = f2;
            this.ikl = context;
            this.ijk = serviceConnection;
            this.lmn = lmn2;
        }

        @Override
        public final /* synthetic */ void onSuccess(Object object) {
            HiLog.i("HAServiceCommander", "Task bindApkService onSuccess enter.");
            Intent intent = this.klm.f().lmn;
            if (intent != null) {
                HiLog.i("HAServiceCommander", "Task bindApkService success.");
                intent.setPackage(this.ikl.getPackageName());
                if (this.ikl.bindService(intent, this.ijk, 1)) {
                    HiLog.i("HAServiceCommander", "bind service success");
                    return;
                }
                HiLog.w("HAServiceCommander", "bind service failed");
                az.lmn lmn2 = this.lmn;
                if (lmn2 != null) {
                    lmn2.lmn("1");
                    return;
                }
            } else {
                az.lmn lmn3 = this.lmn;
                if (lmn3 != null) {
                    lmn3.lmn("1");
                }
            }
        }
    }

    public static final class lmn
    implements d {
        public az.lmn lmn;

        public lmn(az.lmn lmn2) {
            this.lmn = lmn2;
        }

        @Override
        public final void onFailure(Exception exception) {
            StringBuilder stringBuilder = new StringBuilder("Task bindApkService fail.");
            stringBuilder.append(exception.getMessage());
            HiLog.e("HAServiceCommander", stringBuilder.toString());
            az.lmn lmn2 = this.lmn;
            if (lmn2 != null) {
                lmn2.lmn("1");
            }
        }
    }

}

