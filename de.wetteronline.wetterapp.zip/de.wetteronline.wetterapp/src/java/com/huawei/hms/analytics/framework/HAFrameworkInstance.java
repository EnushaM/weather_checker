/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.huawei.hms.analytics.framework.a
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics.framework;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.core.storage.IStorageHandler;
import com.huawei.hms.analytics.framework.a;
import com.huawei.hms.analytics.framework.b.b;
import com.huawei.hms.analytics.framework.config.ICallback;
import com.huawei.hms.analytics.framework.config.ICollectorConfig;
import com.huawei.hms.analytics.framework.config.IMandatoryParameters;
import com.huawei.hms.analytics.framework.listener.IEventListener;
import com.huawei.hms.analytics.framework.policy.IStoragePolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public interface HAFrameworkInstance {
    public static final String TAG = "HAFrameworkCase";

    public void clearCacheData(String var1);

    public void onBackground(long var1);

    public void onEvent(String var1, List<JSONObject> var2, ICallback var3);

    public void onEvent(List<Event> var1, ICallback var2);

    public void onForeground(long var1);

    public void onReport(String var1, ICallback var2);

    public void onStreamEvent(String var1, List<JSONObject> var2, ICallback var3);

    public void setMinSessionDuration(long var1);

    public void setNeedRefreshSession(boolean var1);

    public void setSessionTimeoutDuration(long var1);

    public static final class Builder {
        private ICollectorConfig collectorConfig;
        private com.huawei.hms.analytics.framework.listener.a listenerManager;
        private IMandatoryParameters parameters;
        private IStorageHandler storageHandler;
        private IStoragePolicy storagePolicy;

        public final Builder addEventListener(IEventListener iEventListener) {
            if (this.listenerManager == null) {
                this.listenerManager = new com.huawei.hms.analytics.framework.listener.a();
            }
            com.huawei.hms.analytics.framework.listener.a a2 = this.listenerManager;
            if (a2.a == null) {
                a2.a = new ArrayList();
            }
            a2.a.add((Object)iEventListener);
            return this;
        }

        public final HAFrameworkInstance build(String string2) {
            if (this.parameters == null && b.a().a == null) {
                return null;
            }
            if (b.a().b.containsKey((Object)string2)) {
                HiLog.w(HAFrameworkInstance.TAG, "serviceTag check failed : ".concat(String.valueOf((Object)string2)));
                return null;
            }
            com.huawei.hms.analytics.framework.b.a a2 = new com.huawei.hms.analytics.framework.b.a(this.collectorConfig, this.storageHandler, this.storagePolicy, this.listenerManager);
            b.a().a(string2, this.parameters, a2);
            return new a(string2);
        }

        public final Builder setCollectorConfig(ICollectorConfig iCollectorConfig) {
            this.collectorConfig = iCollectorConfig;
            return this;
        }

        public final Builder setMandatoryParameters(IMandatoryParameters iMandatoryParameters) {
            this.parameters = iMandatoryParameters;
            return this;
        }

        public final Builder setStorageHandler(IStorageHandler iStorageHandler) {
            this.storageHandler = iStorageHandler;
            return this;
        }

        public final Builder setStoragePolicy(IStoragePolicy iStoragePolicy) {
            this.storagePolicy = iStoragePolicy;
            return this;
        }
    }

}

