/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.HashMap
 *  java.util.Map
 */
package com.huawei.hms.analytics;

import android.os.Bundle;
import com.huawei.hms.analytics.bc;
import com.huawei.hms.analytics.bi;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

public final class am {
    public static final String[] lmn = new String[]{"com.huawei.agconnect.abtest.ABTestHAEventCallback", "com.huawei.agconnect.appmessaging.AppMessagingHAEventCallback"};
    public Map<String, Object> ikl = new HashMap();
    public Map<String, Method> klm = new HashMap();

    public final void lmn(String string2, String string3, String string4, Bundle bundle) {
        Map<String, Method> map;
        Map<String, Object> map2 = this.ikl;
        if (map2 != null && map2.size() != 0 && (map = this.klm) != null) {
            if (map.size() == 0) {
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putString("$HA_METADATA_TAG", string2);
            bundle2.putString("$HA_METADATA_TYPE", string3);
            bundle2.putString("$HA_METADATA_SOURCE", "Event");
            bc bc2 = new bc(string4, bundle, bundle2, this.ikl, this.klm);
            bi.klm().lmn(bc2);
        }
    }

    public final void lmn(String string2, String string3, String string4, Bundle bundle, long l2) {
        Map<String, Method> map;
        Map<String, Object> map2 = this.ikl;
        if (map2 != null && map2.size() != 0 && (map = this.klm) != null) {
            if (map.size() == 0) {
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putString("$HA_METADATA_TAG", string2);
            bundle2.putString("$HA_METADATA_TYPE", string3);
            bundle2.putString("$HA_METADATA_SOURCE", "StreamEvent");
            bundle2.putString("$HA_METADATA_TIMESTAMP", String.valueOf((long)l2));
            bc bc2 = new bc(string4, bundle, bundle2, this.ikl, this.klm);
            bi.klm().lmn(bc2);
        }
    }
}

