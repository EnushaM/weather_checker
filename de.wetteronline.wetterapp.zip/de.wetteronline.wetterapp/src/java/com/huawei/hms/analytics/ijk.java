/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.content.Context
 *  android.content.Intent
 *  android.text.TextUtils
 *  com.huawei.hms.analytics.bcd
 *  com.huawei.hms.analytics.ijk$lmn
 *  j
 *  j$.util.concurrent.ConcurrentHashMap
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.util.ArrayList
 *  java.util.Locale
 *  java.util.Map
 *  xd.a
 *  yd.c
 */
package com.huawei.hms.analytics;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.abc;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.az;
import com.huawei.hms.analytics.bcd;
import com.huawei.hms.analytics.be;
import com.huawei.hms.analytics.bh;
import com.huawei.hms.analytics.bi;
import com.huawei.hms.analytics.bj;
import com.huawei.hms.analytics.bk;
import com.huawei.hms.analytics.br;
import com.huawei.hms.analytics.bu;
import com.huawei.hms.analytics.by;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.efg;
import com.huawei.hms.analytics.fgh;
import com.huawei.hms.analytics.ijk;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import xd.a;
import yd.c;

/*
 * Exception performing whole class analysis.
 */
public final class ijk {
    private static ijk lmn;
    private boolean ikl;
    private Map<String, ah> klm;

    public static {
        lmn = new ijk();
    }

    public ijk() {
        this.klm = new j.ConcurrentHashMap();
        this.ikl = false;
    }

    public static void klm(Context context) {
        if (context instanceof Activity) {
            Intent intent;
            Activity activity = (Activity)context;
            String string2 = bk.lmn(activity);
            if (TextUtils.isEmpty((CharSequence)string2) && TextUtils.isEmpty((CharSequence)(string2 = bk.klm(activity))) && (string2 = activity.getCallingPackage()) == null) {
                string2 = "";
            }
            if (!TextUtils.isEmpty((CharSequence)string2)) {
                HiLog.i("ActivityReferrerToolsKit", "get startType success.");
                aa.lmn().klm.i = string2;
            }
            if ((intent = activity.getIntent()) != null) {
                aa.lmn().klm.b = intent.getAction();
            }
        }
    }

    public static void klm(Context context, ah ah2) {
        if (aa.lmn().klm.lmn().length != 0 && !TextUtils.isEmpty((CharSequence)bj.lmn().ikl)) {
            void var3_5;
            try {
                bcd bcd2 = new bcd(context, ah2, (az.lmn)new /* Unavailable Anonymous Inner Class!! */);
                aa.lmn().klm.e = bcd2;
                return;
            }
            catch (NoClassDefFoundError noClassDefFoundError) {
            }
            catch (Exception exception) {
                // empty catch block
            }
            StringBuilder stringBuilder = new StringBuilder("initService error : ");
            stringBuilder.append(var3_5.getMessage());
            HiLog.e("HiAnalyticsInstanceCommander", stringBuilder.toString());
            return;
        }
        HiLog.w("HiAnalyticsInstanceCommander", "collect urls is empty or aaid is empty");
    }

    private static String[] klm(String string2) {
        String[] arrstring = string2.split(",");
        ArrayList arrayList = new ArrayList();
        for (String string3 : arrstring) {
            String string4 = string3.toLowerCase(Locale.US);
            if (string4.startsWith("http://")) {
                HiLog.e("HiAnalyticsInstanceCommander", "URL cannot be http protocol");
                continue;
            }
            if (!string4.startsWith("https://")) {
                string3 = "https://".concat(string3);
            }
            if (!by.lmn(string3)) continue;
            arrayList.add((Object)string3);
        }
        return (String[])arrayList.toArray((Object[])new String[arrayList.size()]);
    }

    public static ijk lmn() {
        return lmn;
    }

    public static void lmn(Context context, ah ah2) {
        Application application = context.getApplicationContext() instanceof Application ? (Application)context.getApplicationContext() : br.lmn();
        efg.lmn().ikl = ah2;
        fgh.lmn().efg = ah2;
        if (application != null) {
            HiLog.i("LifecycleRingback", "LifecycleCallbacks is init");
            application.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)efg.lmn);
            return;
        }
        HiLog.e("LifecycleRingback", "application is null.");
    }

    public final ah lmn(String string2) {
        return (ah)this.klm.get((Object)string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void lmn(Context context) {
        ijk ijk2 = this;
        synchronized (ijk2) {
            boolean bl2 = this.ikl;
            if (bl2) {
                return;
            }
            a a2 = a.d((Context)context);
            String string2 = ((c)a2).g("client/app_id", null);
            c c2 = (c)a2;
            String string3 = c2.g("client/product_id", "");
            String string4 = ((c)a2).g("service/analytics/collector_url", null);
            String string5 = c2.g("service/analytics/resource_id", "");
            String string6 = c2.g("client/client_id", "");
            String string7 = c2.g("region", "");
            if (!TextUtils.isEmpty((CharSequence)string4) && !TextUtils.isEmpty((CharSequence)string3)) {
                boolean bl3;
                String[] arrstring = ijk.klm(string4);
                if (arrstring.length == 0) {
                    throw new IllegalAccessException("collect urls check failed");
                }
                String string8 = br.klm(context);
                String string9 = bu.klm(context, "global_v2", "ab_info", "");
                String string10 = bu.klm(context, "global_v2", "app_ver", "");
                bu.lmn(context, "global_v2", "app_ver", string8);
                String string11 = bu.klm(context, "global_v2", "push_token", "");
                ab ab2 = aa.lmn().klm;
                ab2.ikl = string8;
                ab2.ijk = string10;
                ab2.klm = string2;
                ab2.hij = br.lmn(context);
                ab2.ghi = string3;
                ab2.bcd = context;
                ab2.fgh = string5;
                ab2.efg = string6;
                ab2.lmn(arrstring);
                ab2.m = string9;
                ab2.cde = string11;
                ab2.p = string7;
                boolean bl4 = bu.klm(context, "global_v2", "is_analytics_enabled", true);
                if (bu.lmn(context, "global_v2", "is_restriction_enabled")) {
                    bl3 = bu.klm(context, "global_v2", "is_restriction_enabled", false);
                } else {
                    bl3 = false;
                    if (!bl4) {
                        bl3 = true;
                    }
                }
                boolean bl5 = bu.klm(context, "global_v2", "is_enabled_adsid", true);
                bj.lmn().lmn(context);
                new Thread((Runnable)new bh()).start();
                aa.lmn().klm.abc = bl4;
                aa.lmn().klm.a = bl3;
                aa.lmn().klm.q = bl5;
                bi.ikl().lmn(new be(context));
                this.ikl = true;
                return;
            }
            HiLog.e("HiAnalyticsInstanceCommander", "CE-001", "Cannot find url or productId from agconnect-service.json");
            throw new IllegalAccessException("config params is error");
        }
    }

    public final void lmn(String string2, ah ah2) {
        this.klm.put((Object)string2, (Object)ah2);
    }
}

