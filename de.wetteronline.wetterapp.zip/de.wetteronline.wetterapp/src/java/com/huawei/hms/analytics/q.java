/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.content.Context;
import com.huawei.hms.analytics.a;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.m;
import com.huawei.hms.analytics.n;

public abstract class q
implements n {
    public final Context ikl;
    public final a.lmn klm;

    public q(Context context, a.lmn lmn2) {
        this.ikl = context;
        this.klm = lmn2;
    }

    @Override
    public void lmn(String string) {
        HiLog.w("oaidHelper", string);
        m m2 = new m(this.ikl, this.klm);
        try {
            m2.lmn();
            return;
        }
        catch (Exception exception) {
            HiLog.w("AdvertisingIdInfo", "service exception");
            this.klm.lmn("", "");
            return;
        }
    }
}

