/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  com.huawei.hms.analytics.hij$lmn
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.System
 *  java.util.List
 *  java.util.Set
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.os.Bundle;
import com.huawei.hms.analytics.CustomEvent;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.az;
import com.huawei.hms.analytics.ba;
import com.huawei.hms.analytics.bt;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.hij;
import java.util.List;
import java.util.Set;

public final class b
extends hij.lmn {
    private ah lmn;

    public b(ah ah2) {
        this.lmn = ah2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final int lmn(List<CustomEvent> list) {
        if (!aa.lmn().klm.abc) {
            HiLog.w("ServiceRingback", "isAnalyticsEnabled is false");
            return -1;
        }
        az az2 = ba.lmn("ServiceCallback#handleCustomEvent(List<CustomEvent>)");
        az2.ikl = "ServiceCallback#handleCustomEvent(List<CustomEvent>)";
        if (list != null && !list.isEmpty() && this.lmn != null) {
            HiLog.i("ServiceRingback", "events got");
            try {
                for (CustomEvent customEvent : list) {
                    bt bt2;
                    if (!customEvent.lmn.equals((Object)aa.lmn().klm.bcd.getPackageName())) continue;
                    String string = customEvent.klm;
                    Bundle bundle = customEvent.ikl;
                    boolean bl = "$HA_LOGIN".equals((Object)string);
                    if (bl || "$HA_LOGOUT".equals((Object)string)) {
                        string = "$HA_LOGIN".equals((Object)string) ? "$SignIn" : ("$HA_LOGOUT".equals((Object)string) ? "$SignOut" : null);
                        Bundle bundle2 = new Bundle();
                        if (bundle != null) {
                            for (String string2 : bundle.keySet()) {
                                String string3;
                                if ("$HA_METHOD".equals((Object)string2)) {
                                    string3 = "$Channel";
                                } else {
                                    if (!"$HA_RESULT".equals((Object)string2)) continue;
                                    string3 = "$EvtResult";
                                }
                                bundle2.putString(string3, bundle.getString(string2));
                            }
                        }
                        bundle = bundle2;
                    }
                    if (!(bt2 = new bt(string, false)).lmn(bundle)) {
                        HiLog.w("ServiceRingback", "bundle params is invalid.");
                        continue;
                    }
                    this.lmn.lmn(string, bt2, System.currentTimeMillis());
                }
            }
            catch (RuntimeException runtimeException) {
                HiLog.w("ServiceRingback", "handleCustomEvent RuntimeException");
                ba.lmn(az2);
                return -1;
            }
            az2.lmn = "0";
            ba.lmn(az2);
            return 0;
        }
        HiLog.w("ServiceRingback", "events empty");
        ba.lmn(az2);
        return -1;
    }
}

