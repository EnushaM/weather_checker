/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Object
 *  java.util.zip.Deflater
 */
package com.huawei.hms.analytics.framework.g;

import com.huawei.hms.analytics.core.log.HiLog;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.Deflater;

public final class a {
    private static void a(OutputStream outputStream) {
        try {
            outputStream.close();
            return;
        }
        catch (IOException iOException) {
            HiLog.w("StreamToolsKit", "closeStream(): Exception: close OutputStream error!");
            return;
        }
    }

    public static byte[] a(byte[] arrby) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        Deflater deflater = new Deflater();
        try {
            deflater.setInput(arrby);
            deflater.finish();
            byte[] arrby2 = new byte[1024];
            while (!deflater.finished()) {
                byteArrayOutputStream.write(arrby2, 0, deflater.deflate(arrby2));
            }
            byte[] arrby3 = byteArrayOutputStream.toByteArray();
            return arrby3;
        }
        finally {
            deflater.end();
            a.a((OutputStream)byteArrayOutputStream);
        }
    }
}

