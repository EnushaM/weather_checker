/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Locale
 */
package com.huawei.hms.analytics.core.log;

import com.huawei.hms.analytics.core.log.LogAdapter;
import java.util.Locale;

public class HiLog {
    private static LogAdapter a;
    private static boolean b = false;
    private static int c = 3;
    private static String d = "";

    private static boolean a() {
        LogAdapter logAdapter = a;
        if (logAdapter != null) {
            return logAdapter.isLoggable(3);
        }
        return false;
    }

    private static boolean b() {
        LogAdapter logAdapter = a;
        if (logAdapter != null) {
            return logAdapter.isLoggable(4);
        }
        return false;
    }

    private static boolean c() {
        LogAdapter logAdapter = a;
        if (logAdapter != null) {
            return logAdapter.isLoggable(5);
        }
        return false;
    }

    public static void d(String string2, String string3) {
        if (HiLog.a() && string2 != null && string3 != null) {
            a.println(3, string2, string3);
        }
    }

    public static void d(String string2, String string3, String string4) {
        if (HiLog.a()) {
            a.println(3, string2, string3, string4);
        }
    }

    private static boolean d() {
        LogAdapter logAdapter = a;
        if (logAdapter != null) {
            return logAdapter.isLoggable(6);
        }
        return false;
    }

    public static void e(String string2, String string3) {
        if (HiLog.d() && string2 != null && string3 != null) {
            a.println(6, string2, string3);
        }
    }

    public static void e(String string2, String string3, String string4) {
        if (HiLog.d()) {
            a.println(6, string2, string3, string4);
        }
    }

    public static void i(String string2, String string3) {
        if (HiLog.b() && string2 != null && string3 != null) {
            a.println(4, string2, string3);
        }
    }

    public static void i(String string2, String string3, String string4) {
        if (HiLog.b()) {
            a.println(4, string2, string3, string4);
        }
    }

    public static /* varargs */ void i(String string2, String string3, Object ... arrobject) {
        if (HiLog.b() && string2 != null && string3 != null) {
            String string4 = String.format((Locale)Locale.ROOT, (String)string3, (Object[])arrobject);
            a.println(4, string2, string4);
        }
    }

    public static void init(int n2, String string2) {
        b = true;
        c = n2;
        d = string2;
        LogAdapter logAdapter = a;
        if (logAdapter != null) {
            logAdapter.init(n2, string2);
        }
    }

    public static void setLogAdapter(LogAdapter logAdapter) {
        if (a == null) {
            a = logAdapter;
        }
        if (b) {
            HiLog.init(c, d);
        }
    }

    public static void w(String string2, String string3) {
        if (HiLog.c() && string2 != null && string3 != null) {
            a.println(5, string2, string3);
        }
    }

    public static void w(String string2, String string3, String string4) {
        if (HiLog.c()) {
            a.println(5, string2, string3, string4);
        }
    }

    public static interface ErrorCode {
        public static final String CE001 = "CE-001";
        public static final String IE001 = "IE-001";
        public static final String IE002 = "IE-002";
        public static final String IE003 = "IE-003";
        public static final String IE004 = "IE-004";
        public static final String IE005 = "IE-005";
        public static final String IE006 = "IE-006";
        public static final String NE001 = "NE-001";
        public static final String NE002 = "NE-002";
        public static final String NE003 = "NE-003";
        public static final String NE004 = "NE-004";
        public static final String NE005 = "NE-005";
        public static final String NE006 = "NE-006";
        public static final String PE001 = "PE-001";
        public static final String PE002 = "PE-002";
        public static final String PE003 = "PE-003";
        public static final String PE004 = "PE-004";
        public static final String PE005 = "PE-005";
        public static final String PE006 = "PE-006";
        public static final String SE001 = "SE-001";
        public static final String SE002 = "SE-002";
        public static final String SE003 = "SE-003";
    }

}

