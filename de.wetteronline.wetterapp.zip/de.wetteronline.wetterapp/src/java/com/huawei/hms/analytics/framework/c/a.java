/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.spec.AlgorithmParameterSpec
 */
package com.huawei.hms.analytics.framework.c;

import com.huawei.hms.analytics.core.crypto.AesCipher;
import com.huawei.hms.analytics.core.crypto.HexUtil;
import com.huawei.hms.analytics.framework.b.b;
import com.huawei.hms.analytics.framework.config.CipherType;
import com.huawei.hms.analytics.framework.config.IMandatoryParameters;
import java.security.spec.AlgorithmParameterSpec;

public final class a {
    public static String a(String string2) {
        IMandatoryParameters iMandatoryParameters = b.a().a;
        if (iMandatoryParameters != null) {
            String string3 = iMandatoryParameters.getLoadWorkKey();
            int n2 = 1.a[iMandatoryParameters.getCipherType().ordinal()];
            if (n2 != 1) {
                if (n2 != 2) {
                    return "";
                }
                return AesCipher.encryptCbc(string2, string3);
            }
            byte[] arrby = HexUtil.initRandomByte(12);
            String string4 = AesCipher.gcmEncrypt(string2, string3, AesCipher.getSpec(arrby, iMandatoryParameters.isGCMParameterSpec()));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(HexUtil.byteArray2HexString(arrby));
            stringBuilder.append(string4);
            return stringBuilder.toString();
        }
        return "";
    }

    public static String a(String string2, IMandatoryParameters iMandatoryParameters) {
        if (iMandatoryParameters != null) {
            int n2 = 1.a[iMandatoryParameters.getCipherType().ordinal()];
            if (n2 != 1) {
                if (n2 != 2) {
                    return "";
                }
                return AesCipher.decryptCbc(string2, iMandatoryParameters.getLoadWorkKey());
            }
            String string3 = AesCipher.getGCMIv(string2);
            String string4 = AesCipher.getEncryptWord(string2);
            AlgorithmParameterSpec algorithmParameterSpec = AesCipher.getSpec(HexUtil.hexString2ByteArray(string3), iMandatoryParameters.isGCMParameterSpec());
            return AesCipher.gcmDecrypt(string4, iMandatoryParameters.getLoadWorkKey(), algorithmParameterSpec);
        }
        return "";
    }

}

