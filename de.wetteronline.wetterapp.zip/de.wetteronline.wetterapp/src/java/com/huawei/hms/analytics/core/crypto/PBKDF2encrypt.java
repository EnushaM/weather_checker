/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.security.NoSuchAlgorithmException
 *  java.security.spec.InvalidKeySpecException
 *  java.security.spec.KeySpec
 *  javax.crypto.SecretKey
 *  javax.crypto.SecretKeyFactory
 *  javax.crypto.spec.PBEKeySpec
 */
package com.huawei.hms.analytics.core.crypto;

import com.huawei.hms.analytics.core.log.HiLog;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class PBKDF2encrypt {
    private static byte[] a(char[] arrc, byte[] arrby, int n2, int n3) {
        try {
            PBEKeySpec pBEKeySpec = new PBEKeySpec(arrc, arrby, n2, n3);
            byte[] arrby2 = SecretKeyFactory.getInstance((String)"PBKDF2WithHmacSHA1").generateSecret((KeySpec)pBEKeySpec).getEncoded();
            return arrby2;
        }
        catch (NoSuchAlgorithmException | InvalidKeySpecException throwable) {
            HiLog.e("PBKDFWork2encrypt", "pbkdf generateSecret exception");
            return new byte[0];
        }
    }

    public static byte[] pbkdf2(char[] arrc, byte[] arrby, int n2, int n3) {
        return PBKDF2encrypt.a(arrc, arrby, n2, n3);
    }
}

