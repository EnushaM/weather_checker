/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  f3.j
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.UUID
 *  java.util.regex.Pattern
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import android.os.Bundle;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.bn;
import com.huawei.hms.analytics.bv;
import com.huawei.hms.analytics.core.crypto.HexUtil;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.y;
import f3.j;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class bt {
    private final Map<String, String> def;
    private String efg = "_openness_config_tag";
    private String fgh = null;
    private boolean ghi;
    private final String hij;
    private final String ijk;
    private int ikl = -1;
    public final ArrayList<JSONObject> klm;
    public Bundle lmn;

    public bt(String string2, Bundle bundle) {
        ArrayList arrayList;
        String string3;
        this.klm = arrayList = new ArrayList();
        this.def = new HashMap();
        this.ijk = string2;
        this.hij = string3 = HexUtil.initRandomKey(16);
        this.lmn = bundle;
        JSONObject jSONObject = bv.lmn(bundle);
        this.lmn(jSONObject, string2, string3, "");
        arrayList.add((Object)jSONObject);
    }

    public bt(String string2, String string3) {
        this.klm = new ArrayList();
        this.def = new HashMap();
        this.ghi = false;
        this.ijk = string2;
        this.efg = string3;
        this.hij = HexUtil.initRandomKey(16);
    }

    public bt(String string2, boolean bl2) {
        this.klm = new ArrayList();
        this.def = new HashMap();
        this.ghi = bl2;
        this.ijk = string2;
        this.hij = HexUtil.initRandomKey(16);
    }

    private Bundle klm(Bundle bundle) {
        if (bundle == null) {
            return new Bundle();
        }
        this.klm.clear();
        JSONObject jSONObject = new JSONObject();
        Bundle bundle2 = new Bundle();
        Iterator iterator = bundle.keySet().iterator();
        int n2 = 0;
        boolean bl2 = false;
        boolean bl3 = false;
        while (iterator.hasNext()) {
            String string2 = (String)iterator.next();
            if (n2 >= 2048) {
                HiLog.w("P_CEvtHandler", "PE-005", "The bundle size exceeds the limit.Unnecessary data is discarded.Limit size: 2048");
                break;
            }
            Object object = bundle.get(string2);
            if (object instanceof Bundle) {
                if (bl2) continue;
                this.ikl = 1 + this.ikl;
                bundle2.putBundle(string2, this.lmn(string2, (Bundle)object));
                bl2 = true;
            } else if (object instanceof List) {
                if (bl3) continue;
                ArrayList<?> arrayList = this.lmn(string2, (List)object);
                bt.lmn(jSONObject, string2, this.fgh);
                bundle2.putParcelableArrayList(string2, arrayList);
                bl3 = true;
            } else {
                if (!bt.lmn(object) || !this.lmn(string2)) continue;
                bundle2.putSerializable(string2, (Serializable)object);
                bt.lmn(jSONObject, string2, object);
            }
            ++n2;
        }
        this.lmn(jSONObject);
        this.klm.add((Object)jSONObject);
        return bundle2;
    }

    private Bundle lmn(String string2, Bundle bundle) {
        Bundle bundle2 = new Bundle();
        JSONObject jSONObject = new JSONObject();
        String string3 = this.hij;
        StringBuilder stringBuilder = new StringBuilder("$sub_");
        j.a((StringBuilder)stringBuilder, (String)this.ijk, (String)"_", (String)string2, (String)"_");
        stringBuilder.append(this.ikl);
        String string4 = stringBuilder.toString();
        String string5 = HexUtil.initRandomKey(16);
        String string6 = UUID.randomUUID().toString();
        StringBuilder stringBuilder2 = new StringBuilder("$sub_evt_rel_");
        stringBuilder2.append(this.ikl);
        String string7 = stringBuilder2.toString();
        this.def.put((Object)string7, (Object)string6);
        bt.lmn(jSONObject, string7, string6);
        this.lmn(jSONObject, string4, string5, string3);
        Iterator iterator = bundle.keySet().iterator();
        int n2 = 0;
        while (iterator.hasNext()) {
            String string8 = (String)iterator.next();
            if (n2 >= 2048) break;
            if (!this.lmn(string8)) continue;
            ++n2;
            Object object = bundle.get(string8);
            if (bt.lmn(object)) {
                bundle2.putSerializable(string8, (Serializable)object);
                bt.lmn(jSONObject, string8, object);
                continue;
            }
            HiLog.e("P_CEvtHandler", "bundle value is error");
        }
        this.klm.add((Object)jSONObject);
        return bundle2;
    }

    private ArrayList<?> lmn(String string2, List<?> list) {
        ArrayList arrayList = new ArrayList();
        int n2 = list.size();
        ArrayList arrayList2 = null;
        int n3 = 0;
        for (int i2 = 0; i2 < n2 && n3 < 50; ++i2) {
            Object object = list.get(i2);
            if (object instanceof Bundle) {
                this.ikl = 1 + this.ikl;
                ++n3;
                arrayList.add((Object)this.lmn(string2, (Bundle)object));
                continue;
            }
            if (!bt.lmn(object)) continue;
            ++n3;
            if (arrayList2 == null) {
                arrayList2 = new ArrayList();
            }
            arrayList.add(object);
            arrayList2.add(object);
        }
        if (arrayList2 != null) {
            this.fgh = new JSONArray(arrayList2).toString();
        }
        return arrayList;
    }

    private void lmn(JSONObject jSONObject) {
        this.lmn(jSONObject, this.ijk, this.hij, "");
        for (String string2 : this.def.keySet()) {
            bt.lmn(jSONObject, string2, this.def.get((Object)string2));
        }
    }

    private static void lmn(JSONObject jSONObject, String string2, Object object) {
        try {
            jSONObject.put(string2, object);
            return;
        }
        catch (JSONException jSONException) {
            HiLog.w("P_CEvtHandler", "put json exception, ".concat(String.valueOf((Object)string2)));
            return;
        }
    }

    private void lmn(JSONObject jSONObject, String string2, String string3, String string4) {
        bt.lmn(jSONObject, "^eventId", string2);
        bt.lmn(jSONObject, "^id", string3);
        bt.lmn(jSONObject, "^pid", string4);
        if ("_openness_config_tag".equals((Object)this.efg)) {
            bt.lmn(jSONObject, "$TaskId", aa.lmn().klm.j);
        }
    }

    private static boolean lmn(Object object) {
        return object instanceof Number || object instanceof String || object instanceof Character || object instanceof Boolean;
        {
        }
    }

    private boolean lmn(String string2) {
        if (!this.ghi) {
            return true;
        }
        if (!bn.lmn("bundleKey", string2, y.klm)) {
            HiLog.w("P_CEvtHandler", "bundle key check failed! ".concat(String.valueOf((Object)string2)));
            return false;
        }
        return true;
    }

    public final boolean lmn(Bundle bundle) {
        Bundle bundle2;
        this.lmn = bundle2 = this.klm(bundle);
        return (long)bundle2.toString().length() <= 204800L;
    }
}

