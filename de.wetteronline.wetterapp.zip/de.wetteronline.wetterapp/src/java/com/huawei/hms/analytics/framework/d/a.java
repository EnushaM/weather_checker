/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.List
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics.framework.d;

import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.core.storage.IStorageHandler;
import com.huawei.hms.analytics.framework.c.b;
import com.huawei.hms.analytics.framework.c.d;
import com.huawei.hms.analytics.framework.config.ICallback;
import com.huawei.hms.analytics.framework.policy.IStoragePolicy;
import java.util.List;
import org.json.JSONObject;

public final class a {
    private static a a;

    public static a a() {
        if (a == null) {
            a.b();
        }
        return a;
    }

    public static void a(String string2, String string3, ICallback iCallback) {
        IStoragePolicy iStoragePolicy = com.huawei.hms.analytics.framework.a.a.b(string2);
        if (iStoragePolicy != null && iStoragePolicy.decide(IStoragePolicy.PolicyType.NETWORK, string3)) {
            d d2 = new d(string2, string3, iCallback);
            com.huawei.hms.analytics.framework.f.a.b().a(d2);
        }
    }

    private static void b() {
        Class<a> class_ = a.class;
        synchronized (a.class) {
            if (a == null) {
                a = new a();
            }
            // ** MonitorExit[var1] (shouldn't be in output)
            return;
        }
    }

    public static void b(String string2, String string3, List<JSONObject> list, ICallback iCallback) {
        b b3 = new b(string2, string3, list);
        b3.a = true;
        b3.b = iCallback;
        com.huawei.hms.analytics.framework.f.a.a().a(b3);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(String string2, String string3) {
        a a2 = this;
        synchronized (a2) {
            IStorageHandler iStorageHandler = com.huawei.hms.analytics.framework.a.a.a(string2);
            if (iStorageHandler != null) {
                iStorageHandler.deleteByTagType(string2, string3);
            }
            return;
        }
    }

    public final void a(String string2, String string3, List<JSONObject> list, ICallback iCallback) {
        a a2 = this;
        synchronized (a2) {
            b b3 = new b(string2, string3, list);
            b3.b = iCallback;
            com.huawei.hms.analytics.framework.f.a.a().a(b3);
            return;
        }
    }

    public final void a(List<Event> list, ICallback iCallback) {
        a a2 = this;
        synchronized (a2) {
            b b3 = new b(list);
            b3.b = iCallback;
            com.huawei.hms.analytics.framework.f.a.a().a(b3);
            return;
        }
    }
}

