/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.perf.network.FirebasePerfUrlConnection
 *  java.io.BufferedOutputStream
 *  java.io.Closeable
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.net.ConnectException
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.net.URLConnection
 *  java.net.URLEncoder
 *  java.net.UnknownHostException
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  javax.net.ssl.HostnameVerifier
 *  javax.net.ssl.HttpsURLConnection
 *  javax.net.ssl.SSLHandshakeException
 *  javax.net.ssl.SSLPeerUnverifiedException
 *  javax.net.ssl.SSLSocketFactory
 */
package com.huawei.hms.analytics.core.transport.net;

import com.google.firebase.perf.network.FirebasePerfUrlConnection;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.transport.CallbackListener;
import com.huawei.hms.analytics.core.transport.ITransportHandler;
import com.huawei.hms.analytics.core.transport.net.HttpTransportHandler;
import com.huawei.hms.analytics.core.transport.net.Response;
import com.huawei.hms.analytics.core.transport.net.a;
import com.huawei.hms.analytics.core.transport.net.f;
import com.huawei.hms.analytics.core.transport.net.g;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocketFactory;

public class HttpTransportHandler
implements ITransportHandler {
    private static final int RECONNECTION_TIMES = 3;
    private static final String TAG = "HttpTransportCommander";
    private String caPath;
    private String[] collectURLs;
    private HttpURLConnection connection;
    private Map<String, String> headers;
    private boolean isHighCiphers;
    private ITransportHandler.Protocols protocol;
    private byte[] reportData;

    private void closeConnection() {
        HttpURLConnection httpURLConnection = this.connection;
        if (httpURLConnection != null) {
            httpURLConnection.disconnect();
        }
    }

    private void createConnection(String string) {
        this.connection = (HttpURLConnection)((URLConnection)FirebasePerfUrlConnection.instrument((Object)new URL(string).openConnection()));
        this.setHttpsConn();
        this.connection.setRequestMethod("POST");
        this.connection.setConnectTimeout(15000);
        this.connection.setReadTimeout(15000);
        this.connection.setDoOutput(true);
        this.connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        byte[] arrby = this.reportData;
        int n2 = arrby == null ? 0 : arrby.length;
        this.connection.setRequestProperty("Content-Length", String.valueOf((int)n2));
        this.connection.setRequestProperty("Connection", "close");
        Map<String, String> map = this.headers;
        if (map != null && map.size() > 0) {
            for (Map.Entry entry : this.headers.entrySet()) {
                String string2 = (String)entry.getKey();
                if (string2 == null || string2.isEmpty()) continue;
                HttpURLConnection httpURLConnection = this.connection;
                String string3 = entry.getValue() == null ? "" : (String)entry.getValue();
                httpURLConnection.setRequestProperty(string2, URLEncoder.encode((String)string3, (String)"UTF-8"));
            }
        }
    }

    private Response handlerException(Exception exception) {
        if (exception instanceof SecurityException) {
            HiLog.e(TAG, "NE-003", "No Permission\uff1aINTERNET.");
            return new Response(-101, "");
        }
        if (exception instanceof SSLPeerUnverifiedException) {
            HiLog.e(TAG, "NE-002", "Certificate has not been verified,Request is restricted!");
            return new Response(-106, "");
        }
        if (exception instanceof SSLHandshakeException) {
            HiLog.e(TAG, "NE-002", "Chain validation failed,Certificate expired");
            return new Response(-109, "");
        }
        if (exception instanceof ConnectException) {
            HiLog.e(TAG, "NE-005", "Network is unreachable or Connection refused");
            return new Response(-103, "");
        }
        if (exception instanceof UnknownHostException) {
            HiLog.e(TAG, "NE-006", "Invalid URL.No address associated with hostname");
            return new Response(-104, "");
        }
        if (exception instanceof IOException) {
            HiLog.e(TAG, "NE-004", "post request IO Exception.");
            return new Response(-102, "");
        }
        if (exception instanceof com.huawei.hms.analytics.core.transport.a.a) {
            StringBuilder stringBuilder = new StringBuilder("SSLConfigException:");
            stringBuilder.append(exception.getMessage());
            HiLog.e(TAG, "NE-001", stringBuilder.toString());
            return new Response(-105, "");
        }
        StringBuilder stringBuilder = new StringBuilder("other exception\uff1a ");
        stringBuilder.append(exception.getMessage());
        HiLog.e(TAG, stringBuilder.toString());
        return new Response(-108, "");
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Response post(String string) {
        BufferedOutputStream bufferedOutputStream;
        Throwable throwable;
        OutputStream outputStream;
        block10 : {
            BufferedOutputStream bufferedOutputStream2;
            block9 : {
                block8 : {
                    this.createConnection(string);
                    bufferedOutputStream2 = null;
                    byte[] arrby = this.reportData;
                    if (arrby == null || arrby.length <= 0) break block8;
                    outputStream = this.connection.getOutputStream();
                    try {
                        bufferedOutputStream = new BufferedOutputStream(outputStream);
                    }
                    catch (Throwable throwable2) {
                        bufferedOutputStream = bufferedOutputStream2;
                        throwable = throwable2;
                        break block10;
                    }
                    try {
                        bufferedOutputStream.write(this.reportData);
                        bufferedOutputStream.flush();
                        bufferedOutputStream2 = bufferedOutputStream;
                        break block9;
                    }
                    catch (Throwable throwable3) {
                        break block10;
                    }
                }
                HiLog.i(TAG, "report data is empty");
                outputStream = null;
            }
            Response response = new Response(this.connection.getResponseCode(), this.readResponse());
            f.a((Closeable)bufferedOutputStream2);
            f.a((Closeable)outputStream);
            this.closeConnection();
            return response;
            catch (Throwable throwable4) {
                bufferedOutputStream = null;
                throwable = throwable4;
                outputStream = null;
            }
        }
        f.a(bufferedOutputStream);
        f.a((Closeable)outputStream);
        this.closeConnection();
        throw throwable;
    }

    /*
     * Exception decompiling
     */
    private String readResponse() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl56 : LDC : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private Response reconnection(String string) {
        Response response = new Response(-108, "");
        for (int i2 = 0; i2 < 3; ++i2) {
            try {
                Response response2 = this.post(string);
                return response2;
            }
            catch (Exception exception) {
                response = this.handlerException(exception);
                if (response.getHttpCode() == -104) continue;
                return response;
            }
        }
        return response;
    }

    private void setHttpsConn() {
        HttpURLConnection httpURLConnection = this.connection;
        if (httpURLConnection instanceof HttpsURLConnection) {
            HttpsURLConnection httpsURLConnection = (HttpsURLConnection)httpURLConnection;
            SSLSocketFactory sSLSocketFactory = (SSLSocketFactory)a.a(this.caPath, this.protocol, this.isHighCiphers);
            if (sSLSocketFactory != null) {
                httpsURLConnection.setSSLSocketFactory(sSLSocketFactory);
                httpsURLConnection.setHostnameVerifier((HostnameVerifier)a.a);
                return;
            }
            throw new com.huawei.hms.analytics.core.transport.a.a("No ssl socket factory set ");
        }
    }

    @Override
    public Response execute() {
        String[] arrstring = this.collectURLs;
        if (arrstring != null && arrstring.length != 0) {
            int n2 = 0;
            Response response = null;
            do {
                if (response != null && (response.getHttpCode() != -104 || n2 >= this.collectURLs.length)) {
                    return response;
                }
                response = this.reconnection(this.collectURLs[n2]);
                HiLog.d(TAG, "request times: ".concat(String.valueOf((int)(++n2))));
            } while (true);
        }
        HiLog.e(TAG, "collectUrls is empty");
        return new Response(-100, "");
    }

    @Override
    public void execute(CallbackListener callbackListener) {
        new Thread(new Runnable(this, callbackListener){
            public final /* synthetic */ CallbackListener a;
            public final /* synthetic */ HttpTransportHandler b;
            {
                this.b = httpTransportHandler;
                this.a = callbackListener;
            }

            public final void run() {
                if (this.a != null) {
                    Response response = this.b.execute();
                    if (200 != response.getHttpCode()) {
                        this.a.onFailure(response.getHttpCode());
                        return;
                    }
                    this.a.onSuccess(response);
                }
            }
        }).start();
    }

    @Override
    public void setHttpHeaders(Map<String, String> map) {
        this.headers = map;
    }

    @Override
    public void setReportData(String string) {
    }

    @Override
    public void setReportData(byte[] arrby) {
        byte[] arrby2 = arrby != null ? (byte[])arrby.clone() : new byte[0];
        this.reportData = arrby2;
    }

    @Override
    public void setSSLConfig(ITransportHandler.Protocols protocols, String string, boolean bl2) {
        this.caPath = string;
        this.protocol = protocols;
        this.isHighCiphers = bl2;
    }

    @Override
    public void setUrls(String[] arrstring) {
        String[] arrstring2 = arrstring != null ? (String[])arrstring.clone() : null;
        this.collectURLs = arrstring2;
    }
}

