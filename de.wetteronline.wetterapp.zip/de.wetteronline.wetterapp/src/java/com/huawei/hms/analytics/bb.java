/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.huawei.hms.support.hianalytics.HiAnalyticsUtil
 *  com.huawei.hms.utils.HMSBIInitializer
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 */
package com.huawei.hms.analytics;

import android.content.Context;
import com.huawei.hms.analytics.database.APIEvent;
import com.huawei.hms.support.hianalytics.HiAnalyticsUtil;
import com.huawei.hms.utils.HMSBIInitializer;
import java.util.List;
import java.util.Map;

public final class bb {
    private static bb lmn;
    private Context klm;

    private bb(Context context) {
        this.klm = context;
        HMSBIInitializer.getInstance((Context)context).initBI();
    }

    private static void klm(Context context) {
        Class<bb> class_ = bb.class;
        synchronized (bb.class) {
            if (lmn == null) {
                lmn = new bb(context);
            }
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return;
        }
    }

    public static bb lmn(Context context) {
        if (lmn == null) {
            bb.klm(context);
        }
        return lmn;
    }

    public final void lmn(List<APIEvent> list) {
        for (APIEvent aPIEvent : list) {
            HiAnalyticsUtil.getInstance().onNewEvent(this.klm, aPIEvent.getCode(), aPIEvent.toMap());
        }
    }
}

