/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.huawei.hms.analytics.h
 *  java.lang.Object
 */
package com.huawei.hms.analytics;

import android.content.Context;
import com.huawei.hms.analytics.h;

public final class def {
    public h lmn;

    public def(Context context) {
        this.lmn = new h(context);
    }
}

