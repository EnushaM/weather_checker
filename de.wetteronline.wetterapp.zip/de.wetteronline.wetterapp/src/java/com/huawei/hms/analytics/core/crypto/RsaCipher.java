/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.math.BigInteger
 *  java.nio.charset.Charset
 *  java.security.GeneralSecurityException
 *  java.security.InvalidKeyException
 *  java.security.Key
 *  java.security.KeyFactory
 *  java.security.NoSuchAlgorithmException
 *  java.security.PrivateKey
 *  java.security.PublicKey
 *  java.security.interfaces.RSAPublicKey
 *  java.security.spec.InvalidKeySpecException
 *  java.security.spec.KeySpec
 *  java.security.spec.PKCS8EncodedKeySpec
 *  java.security.spec.X509EncodedKeySpec
 *  javax.crypto.BadPaddingException
 *  javax.crypto.Cipher
 *  javax.crypto.IllegalBlockSizeException
 *  javax.crypto.NoSuchPaddingException
 */
package com.huawei.hms.analytics.core.crypto;

import com.huawei.hms.analytics.core.crypto.HexUtil;
import com.huawei.hms.analytics.core.log.HiLog;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class RsaCipher {
    private static final Charset a = Charset.forName((String)"UTF-8");

    public static String decrypt(byte[] arrby, String string2) {
        PrivateKey privateKey = RsaCipher.getPrivateKey(arrby);
        return new String(RsaCipher.decrypt(HexUtil.hexString2ByteArray(string2), privateKey), a);
    }

    public static byte[] decrypt(byte[] arrby, PrivateKey privateKey) {
        byte[] arrby2 = new byte[]{};
        try {
            Cipher cipher = Cipher.getInstance((String)"RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
            cipher.init(2, (Key)privateKey);
            byte[] arrby3 = cipher.doFinal(arrby);
            return arrby3;
        }
        catch (GeneralSecurityException generalSecurityException) {
            HiLog.e("RsaCipherCommander", "RSA decrypt exception : ");
            return arrby2;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String encrypt(byte[] var0, String var1_1) {
        block10 : {
            if (var0 == null || var1_1 == null || var1_1.length() == 0) break block10;
            try {
                var2_2 = new X509EncodedKeySpec(var0);
                var4_3 = KeyFactory.getInstance((String)"RSA").generatePublic((KeySpec)var2_2);
                var5_4 = (RSAPublicKey)var4_3;
                if (var5_4 == null) ** GOTO lbl-1000
                var6_5 = var5_4.getModulus().bitLength();
                HiLog.i("RsaCipherCommander", "rsa bitLength : ".concat(String.valueOf((int)var6_5)));
                if (var6_5 >= 2048) {
                    var7_6 = true;
                } else lbl-1000: // 2 sources:
                {
                    var7_6 = false;
                }
                if (!var7_6) {
                    HiLog.e("RsaCipherCommander", "publicKey length is too short");
                    return "";
                }
                var8_7 = Cipher.getInstance((String)"RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
                var8_7.init(1, (Key)var4_3);
                return HexUtil.byteArray2HexString(var8_7.doFinal(var1_1.getBytes(RsaCipher.a)));
            }
            catch (IllegalBlockSizeException v0) {
                var3_9 = "rsaEncrypt(): doFinal - The provided block is not filled with";
            }
            catch (BadPaddingException v0) {
                var3_9 = "rsaEncrypt():False filling parameters!";
            }
            catch (NoSuchPaddingException v0) {
                var3_9 = "rsaEncrypt():  No such filling parameters ";
            }
            catch (InvalidKeyException v0) {
                var3_9 = "rsaEncrypt(): init - Invalid key!";
            }
            catch (NoSuchAlgorithmException v0) {
                var3_9 = "rsaEncrypt(): getInstance - No such algorithm,transformation";
            }
            catch (InvalidKeySpecException v0) {
                var3_9 = "rsaEncrypt(): InvalidKeySpecException";
            }
            HiLog.w("RsaCipherCommander", var3_9);
            return "";
        }
        HiLog.e("RsaCipherCommander", "content or public key is null");
        return "";
    }

    public static PrivateKey getPrivateKey(byte[] arrby) {
        try {
            PKCS8EncodedKeySpec pKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(arrby);
            PrivateKey privateKey = KeyFactory.getInstance((String)"RSA").generatePrivate((KeySpec)pKCS8EncodedKeySpec);
            return privateKey;
        }
        catch (GeneralSecurityException generalSecurityException) {
            HiLog.e("RsaCipherCommander", "load Key General Security Exception:");
            return null;
        }
    }
}

