/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics.framework.c.a;

import org.json.JSONException;
import org.json.JSONObject;

public final class a {
    public String a;
    public String b;
    public String c;
    public String d;
    public String e;
    public String f;

    public final JSONObject a() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("protocol_version", (Object)"1");
            jSONObject.put("compress_mode", (Object)"1");
            jSONObject.put("serviceid", (Object)this.f);
            jSONObject.put("appid", (Object)this.b);
            jSONObject.put("chifer", (Object)this.a);
            jSONObject.put("timestamp", (Object)this.d);
            jSONObject.put("servicetag", (Object)this.c);
            jSONObject.put("requestid", (Object)this.e);
            return jSONObject;
        }
        catch (JSONException jSONException) {
            return null;
        }
    }
}

