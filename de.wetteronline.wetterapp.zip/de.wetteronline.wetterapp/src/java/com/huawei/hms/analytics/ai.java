/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  java.util.Set
 *  je.f
 */
package com.huawei.hms.analytics;

import android.app.Activity;
import android.os.Bundle;
import com.huawei.hms.analytics.type.ReportPolicy;
import java.util.Map;
import java.util.Set;
import je.f;

public interface ai {
    public f<String> ghi();

    public void hij();

    public void hij(boolean var1);

    public void ijk(long var1);

    public void ijk(String var1);

    public void ijk(boolean var1);

    public boolean ijk();

    public void ikl(long var1);

    public void ikl(String var1);

    public void ikl(boolean var1);

    public void klm(String var1);

    public void klm(String var1, String var2);

    public Map<String, String> lmn(boolean var1);

    public void lmn(Activity var1, String var2, String var3);

    public void lmn(String var1, Bundle var2);

    public void lmn(String var1, String var2);

    public void lmn(Set<ReportPolicy> var1);
}

