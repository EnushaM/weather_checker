/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.nio.charset.Charset
 *  java.security.InvalidAlgorithmParameterException
 *  java.security.InvalidKeyException
 *  java.security.Key
 *  java.security.NoSuchAlgorithmException
 *  java.security.spec.AlgorithmParameterSpec
 *  java.util.Arrays
 *  javax.crypto.BadPaddingException
 *  javax.crypto.Cipher
 *  javax.crypto.IllegalBlockSizeException
 *  javax.crypto.NoSuchPaddingException
 *  javax.crypto.SecretKey
 *  javax.crypto.spec.GCMParameterSpec
 *  javax.crypto.spec.IvParameterSpec
 *  javax.crypto.spec.SecretKeySpec
 */
package com.huawei.hms.analytics.core.crypto;

import com.huawei.hms.analytics.core.crypto.HexUtil;
import com.huawei.hms.analytics.core.log.HiLog;
import java.nio.charset.Charset;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Arrays;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AesCipher {
    public static final Charset a = Charset.forName((String)"UTF-8");

    /*
     * Exception decompiling
     */
    private static String a(String var0, byte[] var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl58 : LDC : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static String a(byte[] arrby, byte[] arrby2) {
        String string2;
        String string3;
        byte[] arrby3;
        block8 : {
            SecretKeySpec secretKeySpec = new SecretKeySpec(arrby2, "AES");
            arrby3 = HexUtil.initRandomByte(16);
            Cipher cipher = Cipher.getInstance((String)"AES/CBC/PKCS5Padding");
            cipher.init(1, (Key)secretKeySpec, (AlgorithmParameterSpec)new IvParameterSpec(arrby3));
            string3 = HexUtil.byteArray2HexString(cipher.doFinal(arrby));
            if (!string3.isEmpty()) break block8;
            return "";
        }
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(HexUtil.byteArray2HexString(arrby3));
            stringBuilder.append(string3);
            String string4 = stringBuilder.toString();
            return string4;
        }
        catch (BadPaddingException throwable) {
            string2 = "BadPaddingException encryptCBC: ";
        }
        catch (IllegalBlockSizeException throwable) {
            string2 = "IllegalBlockSizeException encryptCBC: ";
        }
        catch (InvalidAlgorithmParameterException throwable) {
            string2 = "InvalidAlgorithmParameterException encryptCBC: ";
        }
        catch (InvalidKeyException throwable) {
            string2 = "InvalidKeyException encryptCBC: ";
        }
        catch (NoSuchPaddingException throwable) {
            string2 = "NoSuchPaddingException encryptCBC: ";
        }
        catch (NoSuchAlgorithmException throwable) {
            string2 = "NoSuchAlgorithmException encryptCBC: ";
        }
        HiLog.e("AesCypher", string2);
        return "";
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String decryptCbc(String string2, String string3) {
        String string4;
        if (string2 != null && !string2.isEmpty() && string3 != null) {
            byte[] arrby = HexUtil.hexString2ByteArray(string3);
            if (arrby.length >= 16) {
                String string5 = AesCipher.getCBCIv(string2);
                return AesCipher.a(AesCipher.getCbcEncryptWord(string2), arrby, string5);
            }
            string4 = "key length is not right";
        } else {
            string4 = "cbc decrypt param is not right";
        }
        HiLog.e("AesCypher", string4);
        return "";
    }

    public static String encrypt(String string2, byte[] arrby) {
        HiLog.i("AesCypher", "aes encrypt begin 2");
        if (string2 != null && !string2.isEmpty() && arrby != null && arrby.length >= 16) {
            String string3;
            String string4;
            byte[] arrby2;
            block9 : {
                arrby2 = HexUtil.initRandomByte(16);
                byte[] arrby3 = string2.getBytes(a);
                SecretKeySpec secretKeySpec = new SecretKeySpec(arrby, "AES");
                Cipher cipher = Cipher.getInstance((String)"AES/CBC/PKCS5Padding");
                cipher.init(1, (Key)secretKeySpec, (AlgorithmParameterSpec)new IvParameterSpec(arrby2));
                string4 = HexUtil.byteArray2HexString(cipher.doFinal(arrby3));
                if (!string4.isEmpty()) break block9;
                return "";
            }
            try {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(HexUtil.byteArray2HexString(arrby2));
                stringBuilder.append(string4);
                String string5 = stringBuilder.toString();
                return string5;
            }
            catch (BadPaddingException throwable) {
                string3 = "BadPaddingException encryptCBC: ";
            }
            catch (IllegalBlockSizeException throwable) {
                string3 = "IllegalBlockSizeException encryptCBC: ";
            }
            catch (InvalidAlgorithmParameterException throwable) {
                string3 = "InvalidAlgorithmParameterException encryptCBC: ";
            }
            catch (InvalidKeyException throwable) {
                string3 = "InvalidKeyException encryptCBC: ";
            }
            catch (NoSuchPaddingException throwable) {
                string3 = "NoSuchPaddingException encryptCBC: ";
            }
            catch (NoSuchAlgorithmException throwable) {
                string3 = "NoSuchAlgorithmException encryptCBC: ";
            }
            HiLog.e("AesCypher", string3);
            return "";
        }
        HiLog.e("AesCypher", "cbc encrypt param is not right");
        return "";
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String encryptCbc(String string2, String string3) {
        String string4;
        if (string2 != null && !string2.isEmpty() && string3 != null) {
            byte[] arrby = HexUtil.hexString2ByteArray(string3);
            if (arrby.length >= 16) {
                return AesCipher.a(string2.getBytes(a), arrby);
            }
            string4 = "key length is not right";
        } else {
            string4 = "cbc encrypt param is not right";
        }
        HiLog.e("AesCypher", string4);
        return "";
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String encryptCbc(byte[] arrby, String string2) {
        String string3;
        if (arrby != null && arrby.length != 0 && string2 != null) {
            byte[] arrby2 = HexUtil.hexString2ByteArray(string2);
            if (arrby2.length >= 16) {
                return AesCipher.a(arrby, arrby2);
            }
            string3 = "key length is not right";
        } else {
            string3 = "cbc encrypt(byte) param is not right";
        }
        HiLog.e("AesCypher", string3);
        return "";
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String gcmDecrypt(String var0, String var1_1, AlgorithmParameterSpec var2_2) {
        if (var0 == null || var0.isEmpty() || var1_1 == null) ** GOTO lbl31
        var4_3 = HexUtil.hexString2ByteArray(var1_1);
        if (var4_3.length < 16) {
            var3_4 = "key length is not right";
        } else {
            var5_5 = new SecretKeySpec(var4_3, "AES");
            var6_6 = HexUtil.hexString2ByteArray(var0);
            try {
                var8_7 = Cipher.getInstance((String)"AES/GCM/NoPadding");
                var8_7.init(2, (Key)var5_5, var2_2);
                return new String(var8_7.doFinal(var6_6), AesCipher.a);
            }
            catch (IllegalBlockSizeException v0) {
                var7_9 = "IllegalBlockSizeException gcmDecrypt: ";
            }
            catch (BadPaddingException v0) {
                var7_9 = "BadPaddingException gcmDecrypt: ";
            }
            catch (InvalidKeyException v0) {
                var7_9 = "InvalidKeyException gcmDecrypt: ";
            }
            catch (NoSuchAlgorithmException v0) {
                var7_9 = "NoSuchAlgorithmException gcmDecrypt: ";
            }
            catch (NoSuchPaddingException v0) {
                var7_9 = "NoSuchPaddingException gcmDecrypt: ";
            }
            catch (InvalidAlgorithmParameterException v0) {
                var7_9 = "InvalidAlgorithmParameterException gcmDecrypt: ";
            }
            HiLog.e("AesCypher", var7_9);
            return "";
lbl31: // 1 sources:
            var3_4 = "gcmDecrypt : content or key is not right";
        }
        HiLog.e("AesCypher", var3_4);
        return "";
    }

    public static String gcmDecrypt(SecretKey secretKey, String string2) {
        if (secretKey != null && string2 != null && !string2.isEmpty()) {
            String string3;
            byte[] arrby;
            block9 : {
                arrby = HexUtil.hexString2ByteArray(string2);
                if (arrby.length > 12) break block9;
                HiLog.e("AesCypher", "Decrypt source data is invalid.");
                return "";
            }
            try {
                byte[] arrby2 = Arrays.copyOf((byte[])arrby, (int)12);
                Cipher cipher = Cipher.getInstance((String)"AES/GCM/NoPadding");
                cipher.init(2, (Key)secretKey, (AlgorithmParameterSpec)new GCMParameterSpec(128, arrby2));
                String string4 = new String(cipher.doFinal(arrby, 12, arrby.length - 12), a);
                return string4;
            }
            catch (BadPaddingException throwable) {
                string3 = "BadPaddingException gcmDecryptKs: ";
            }
            catch (IllegalBlockSizeException throwable) {
                string3 = "IllegalBlockSizeException gcmDecryptKs: ";
            }
            catch (InvalidAlgorithmParameterException throwable) {
                string3 = "InvalidAlgorithmParameterException gcmDecryptKs: ";
            }
            catch (InvalidKeyException throwable) {
                string3 = "InvalidKeyException gcmDecryptKs: ";
            }
            catch (NoSuchPaddingException throwable) {
                string3 = "NoSuchPaddingException gcmDecryptKs: ";
            }
            catch (NoSuchAlgorithmException throwable) {
                string3 = "NoSuchAlgorithmException gcmDecryptKs: ";
            }
            HiLog.e("AesCypher", string3);
            return "";
        }
        HiLog.e("AesCypher", "gcmDecrypt : secretKey or enContent is null");
        return "";
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String gcmEncrypt(String var0, String var1_1, AlgorithmParameterSpec var2_2) {
        if (var0 == null || var0.isEmpty() || var1_1 == null) ** GOTO lbl33
        if (var2_2 == null) {
            var3_3 = "ivParameterSpec is null";
        } else {
            var4_4 = HexUtil.hexString2ByteArray(var1_1);
            if (var4_4.length < 16) {
                var3_3 = "key length is not right";
            } else {
                var5_5 = new SecretKeySpec(var4_4, "AES");
                try {
                    var7_6 = Cipher.getInstance((String)"AES/GCM/NoPadding");
                    var7_6.init(1, (Key)var5_5, var2_2);
                    return HexUtil.byteArray2HexString(var7_6.doFinal(var0.getBytes(AesCipher.a)));
                }
                catch (IllegalBlockSizeException v0) {
                    var6_8 = "IllegalBlockSizeException gcmEncrypt: ";
                }
                catch (BadPaddingException v0) {
                    var6_8 = "BadPaddingException gcmEncrypt: ";
                }
                catch (InvalidKeyException v0) {
                    var6_8 = "InvalidKeyException gcmEncrypt: ";
                }
                catch (NoSuchAlgorithmException v0) {
                    var6_8 = "NoSuchAlgorithmException gcmEncrypt: ";
                }
                catch (NoSuchPaddingException v0) {
                    var6_8 = "NoSuchPaddingException gcmEncrypt: ";
                }
                catch (InvalidAlgorithmParameterException v0) {
                    var6_8 = "InvalidAlgorithmParameterException gcmEncrypt: ";
                }
                HiLog.e("AesCypher", var6_8);
                return "";
lbl33: // 1 sources:
                var3_3 = "content or key is not right";
            }
        }
        HiLog.e("AesCypher", var3_3);
        return "";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String gcmEncrypt(SecretKey secretKey, String string2) {
        String string3;
        if (secretKey == null) {
            string3 = "Encrypt secret key is null";
        } else {
            if (string2 != null && !string2.isEmpty()) {
                String string4;
                try {
                    Cipher cipher = Cipher.getInstance((String)"AES/GCM/NoPadding");
                    cipher.init(1, (Key)secretKey);
                    byte[] arrby = cipher.doFinal(string2.getBytes(a));
                    byte[] arrby2 = cipher.getIV();
                    if (arrby2 != null && arrby2.length == 12) {
                        byte[] arrby3 = Arrays.copyOf((byte[])arrby2, (int)(arrby2.length + arrby.length));
                        System.arraycopy((Object)arrby, (int)0, (Object)arrby3, (int)arrby2.length, (int)arrby.length);
                        return HexUtil.byteArray2HexString(arrby3);
                    }
                    HiLog.e("AesCypher", "IV is invalid");
                    return "";
                }
                catch (IllegalBlockSizeException throwable) {
                    string4 = "IllegalBlockSizeException gcmEncryptKs: ";
                }
                catch (BadPaddingException throwable) {
                    string4 = "BadPaddingException gcmEncryptKs: ";
                }
                catch (InvalidKeyException throwable) {
                    string4 = "InvalidKeyException gcmEncryptKs:";
                }
                catch (NoSuchAlgorithmException throwable) {
                    string4 = "NoSuchAlgorithmException gcmEncryptKs: ";
                }
                catch (NoSuchPaddingException throwable) {
                    string4 = "NoSuchPaddingException gcmEncryptKs: ";
                }
                HiLog.e("AesCypher", string4);
                return "";
            }
            string3 = "encrypt content is null or empty";
        }
        HiLog.e("AesCypher", string3);
        return "";
    }

    public static String getCBCIv(String string2) {
        if (string2 != null && string2.length() >= 32) {
            return string2.substring(0, 32);
        }
        HiLog.e("AesCypher", "cbc IV is invalid.");
        return "";
    }

    public static String getCbcEncryptWord(String string2) {
        if (string2 != null && string2.length() >= 32) {
            return string2.substring(32);
        }
        return "";
    }

    public static String getEncryptWord(String string2) {
        if (string2 != null && string2.length() >= 24) {
            return string2.substring(24);
        }
        return "";
    }

    public static String getGCMIv(String string2) {
        if (string2 != null && string2.length() >= 24) {
            return string2.substring(0, 24);
        }
        HiLog.e("AesCypher", "IV is invalid.");
        return "";
    }

    public static AlgorithmParameterSpec getSpec(byte[] arrby, boolean bl2) {
        if (!bl2) {
            return new IvParameterSpec(arrby);
        }
        return new GCMParameterSpec(128, arrby);
    }

    public static interface AesLen {
        public static final int AES_128_CBC_IV_LEN = 16;
        public static final int AES_128_CBC_KEY_LEN = 16;
        public static final int AES_GCM_IV_LEN = 12;
        public static final int ROOTKEY_COMPONET_LEN = 128;
    }

}

