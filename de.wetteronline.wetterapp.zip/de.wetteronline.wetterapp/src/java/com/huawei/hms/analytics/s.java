/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import com.huawei.hms.analytics.a;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.bj;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.m;
import com.huawei.hms.analytics.o;
import com.huawei.hms.analytics.p;
import com.huawei.hms.analytics.u;
import com.huawei.hms.analytics.v;
import com.huawei.hms.analytics.w;

public final class s
implements a.lmn {
    public static void lmn(Context context) {
        HiLog.i("oaidMg", "start get oaid");
        if (!"CN".equals((Object)aa.lmn().klm.p)) {
            HiLog.i("oaidMg", "Region is not CN,Do not collect oaid");
            return;
        }
        if (!aa.lmn().klm.q) {
            aa.lmn().klm.n = "";
            aa.lmn().klm.o = "";
            HiLog.i("oaidMg", "Stopped collecting oaid.");
            return;
        }
        s s2 = new s();
        String string = Build.MANUFACTURER.toUpperCase();
        if ("HUAWEI".equals((Object)string)) {
            new p(context, s2).lmn();
            return;
        }
        if ("OPPO".equals((Object)string)) {
            m m2 = new m(context, s2);
            try {
                m2.lmn();
                return;
            }
            catch (Exception exception) {
                HiLog.w("AdvertisingIdInfo", "service exception");
                s2.lmn("", "");
                return;
            }
        }
        if (string.equals((Object)"VIVO")) {
            new v(context, s2).lmn();
            return;
        }
        if (string.equals((Object)"SAMSUNG")) {
            u u2 = new u(context, s2);
            try {
                u2.lmn.lmn();
                return;
            }
            catch (Exception exception) {
                u2.lmn("getOaid,bindService error, begin get gaid");
                return;
            }
        }
        if (string.equals((Object)"XIAOMI")) {
            new w(context, s2).lmn();
            return;
        }
        aa.lmn().klm.n = "";
        aa.lmn().klm.o = "";
    }

    @Override
    public final void lmn(String string, String string2) {
        if (TextUtils.isEmpty((CharSequence)string)) {
            string = bj.lmn().ikl;
            string2 = "";
        }
        aa.lmn().klm.n = string;
        aa.lmn().klm.o = string2;
    }
}

