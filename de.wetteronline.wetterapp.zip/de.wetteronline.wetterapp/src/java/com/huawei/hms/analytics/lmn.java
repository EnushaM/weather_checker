/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IInterface
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.os.IInterface;

public interface lmn
extends IInterface {
    public String lmn();
}

