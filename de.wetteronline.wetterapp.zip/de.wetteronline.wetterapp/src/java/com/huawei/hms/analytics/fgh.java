/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.Map
 */
package com.huawei.hms.analytics;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.bt;
import com.huawei.hms.analytics.core.log.HiLog;
import java.util.HashMap;
import java.util.Map;

public final class fgh {
    public static fgh lmn = new fgh();
    public ah efg;
    public Handler fgh;
    public boolean ghi;
    public boolean hij;
    public lmn ijk;
    public Map<String, lmn> ikl;
    public lmn klm;

    public fgh() {
        lmn lmn2;
        lmn lmn3;
        this.klm = lmn3 = new lmn("", "", "", 0L);
        this.ikl = new HashMap();
        this.ijk = lmn2 = new lmn("", "", "", 0L);
        this.hij = false;
        this.ghi = false;
        this.fgh = new Handler(Looper.myLooper());
    }

    public static fgh lmn() {
        return lmn;
    }

    public final void lmn(long l2) {
        HiLog.d("ActivityStatCommander", "onScreenExit with time: ".concat(String.valueOf((long)l2)));
        lmn lmn2 = this.klm;
        if (lmn2 != null && lmn2.ijk != 0L) {
            Bundle bundle = new Bundle();
            bundle.putString("$CurActivityName", this.klm.lmn);
            bundle.putString("$CurActivityClass", this.klm.klm);
            bundle.putString("$CurActivityId", this.klm.ikl);
            StringBuilder stringBuilder = new StringBuilder("onScreenExit duration cal: 1. ");
            stringBuilder.append(l2);
            stringBuilder.append(" 2. ");
            stringBuilder.append(this.klm.ijk);
            HiLog.d("ActivityStatCommander", stringBuilder.toString());
            bundle.putString("$Duration", String.valueOf((long)(l2 - this.klm.ijk)));
            HiLog.i("ActivityStatCommander", "onScreenExit: send ScreenExit event...");
            this.efg.lmn("$ExitScreen", new bt("$ExitScreen", bundle), l2);
            this.ghi = false;
            return;
        }
        HiLog.w("ActivityStatCommander", "onScreenExit: onScreenEnter should be invoked first.");
    }

    public final void lmn(lmn lmn2, Bundle bundle, long l2) {
        HiLog.d("ActivityStatCommander", "onScreenEnterSend");
        bundle.putString("$PrevActivityName", this.klm.lmn);
        bundle.putString("$PrevActivityClass", this.klm.klm);
        bundle.putString("$PrevActivityId", this.klm.ikl);
        bundle.putString("$CurActivityName", lmn2.lmn);
        bundle.putString("$CurActivityClass", lmn2.klm);
        bundle.putString("$CurActivityId", lmn2.ikl);
        this.efg.lmn("$EnterScreen", new bt("$EnterScreen", bundle), l2);
        this.hij = false;
        this.klm = lmn2;
    }

    public static final class lmn {
        public long ijk;
        public String ikl;
        public String klm;
        public String lmn;

        public lmn(String string2, String string3, String string4, long l2) {
            this.lmn = string2;
            this.klm = string3;
            this.ikl = string4;
            this.ijk = l2;
        }
    }

}

