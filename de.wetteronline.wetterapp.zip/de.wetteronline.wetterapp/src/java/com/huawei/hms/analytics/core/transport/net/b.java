/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  javax.security.auth.x500.X500Principal
 */
package com.huawei.hms.analytics.core.transport.net;

import javax.security.auth.x500.X500Principal;

public final class b {
    public final String a;
    public final int b;
    public int c;
    public int d;
    public int e;
    public int f;
    public char[] g;

    public b(X500Principal x500Principal) {
        String string2;
        this.a = string2 = x500Principal.getName("RFC2253");
        this.b = string2.length();
    }

    private int a(int n2) {
        block2 : {
            block6 : {
                block10 : {
                    int n3;
                    int n4;
                    block8 : {
                        char c2;
                        block9 : {
                            block7 : {
                                char[] arrc;
                                int n5;
                                block4 : {
                                    char c3;
                                    block5 : {
                                        block3 : {
                                            n5 = n2 + 1;
                                            if (n5 >= this.b) break block2;
                                            arrc = this.g;
                                            c3 = arrc[n2];
                                            if (c3 < '0' || c3 > '9') break block3;
                                            n4 = c3 - 48;
                                            break block4;
                                        }
                                        if (c3 < 'a' || c3 > 'f') break block5;
                                        n4 = c3 - 87;
                                        break block4;
                                    }
                                    if (c3 < 'A' || c3 > 'F') break block6;
                                    n4 = c3 - 55;
                                }
                                c2 = arrc[n5];
                                if (c2 < '0' || c2 > '9') break block7;
                                n3 = c2 - 48;
                                break block8;
                            }
                            if (c2 < 'a' || c2 > 'f') break block9;
                            n3 = c2 - 87;
                            break block8;
                        }
                        if (c2 < 'A' || c2 > 'F') break block10;
                        n3 = c2 - 55;
                    }
                    return n3 + (n4 << 4);
                }
                StringBuilder stringBuilder = new StringBuilder("Malformed DN: ");
                stringBuilder.append(this.a);
                throw new IllegalStateException(stringBuilder.toString());
            }
            StringBuilder stringBuilder = new StringBuilder("Malformed DN: ");
            stringBuilder.append(this.a);
            throw new IllegalStateException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder("Malformed DN: ");
        stringBuilder.append(this.a);
        throw new IllegalStateException(stringBuilder.toString());
    }

    private char e() {
        int n2 = this.a(this.c);
        this.c = 1 + this.c;
        if (n2 < 128) {
            return (char)n2;
        }
        if (n2 >= 192 && n2 <= 247) {
            int n3;
            int n4;
            if (n2 <= 223) {
                n3 = n2 & 31;
                n4 = 1;
            } else if (n2 <= 239) {
                n4 = 2;
                n3 = n2 & 15;
            } else {
                n4 = 3;
                n3 = n2 & 7;
            }
            for (int i2 = 0; i2 < n4; ++i2) {
                int n5;
                this.c = n5 = 1 + this.c;
                if (n5 != this.b) {
                    int n6;
                    if (this.g[n5] != '\\') {
                        return '?';
                    }
                    this.c = n6 = n5 + 1;
                    int n7 = this.a(n6);
                    this.c = 1 + this.c;
                    if ((n7 & 192) != 128) {
                        return '?';
                    }
                    n3 = (n3 << 6) + (n7 & 63);
                    continue;
                }
                return '?';
            }
            return (char)n3;
        }
        return '?';
    }

    public final String a() {
        int n2;
        int n3;
        char[] arrc;
        int n4;
        while ((n4 = this.c) < (n3 = this.b) && this.g[n4] == ' ') {
            this.c = n4 + 1;
        }
        if (n4 == n3) {
            return null;
        }
        this.d = n4;
        while ((n4 = (this.c = n4 + 1)) < (n2 = this.b) && (arrc = this.g)[n4] != '=' && arrc[n4] != ' ') {
        }
        if (n4 < n2) {
            char[] arrc2;
            int n5;
            this.e = n4;
            if (this.g[n4] == ' ') {
                char[] arrc3;
                int n6;
                int n7;
                while ((n7 = this.c) < (n6 = this.b) && (arrc3 = this.g)[n7] != '=' && arrc3[n7] == ' ') {
                    this.c = n7 + 1;
                }
                if (this.g[n7] != '=' || n7 == n6) {
                    StringBuilder stringBuilder = new StringBuilder("Unexpected end of DN: ");
                    stringBuilder.append(this.a);
                    throw new IllegalStateException(stringBuilder.toString());
                }
            }
            do {
                this.c = n5 = 1 + this.c;
            } while (n5 < this.b && this.g[n5] == ' ');
            int n8 = this.e;
            int n9 = this.d;
            if (!(n8 - n9 <= 4 || (arrc2 = this.g)[n9 + 3] != '.' || arrc2[n9] != 'O' && arrc2[n9] != 'o' || arrc2[n9 + 1] != 'I' && arrc2[n9 + 1] != 'i' || arrc2[n9 + 2] != 'D' && arrc2[n9 + 2] != 'd')) {
                this.d = n9 + 4;
            }
            char[] arrc4 = this.g;
            int n10 = this.d;
            return new String(arrc4, n10, n8 - n10);
        }
        StringBuilder stringBuilder = new StringBuilder("Unexpected end of DN: ");
        stringBuilder.append(this.a);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public final String b() {
        int n2 = this.c;
        if (n2 + 4 < this.b) {
            int n3;
            int n4;
            int n5;
            block6 : {
                char[] arrc;
                this.d = n2;
                while ((n2 = (this.c = n2 + 1)) != this.b && (arrc = this.g)[n2] != '+' && arrc[n2] != ',' && arrc[n2] != ';') {
                    if (arrc[n2] == ' ') {
                        this.e = n2;
                        while ((n2 = (this.c = n2 + 1)) < this.b && this.g[n2] == ' ') {
                        }
                        break block6;
                    }
                    if (arrc[n2] < 'A' || arrc[n2] > 'F') continue;
                    arrc[n2] = (char)(32 + arrc[n2]);
                }
                this.e = n2;
            }
            if ((n3 = (n4 = this.e) - (n5 = this.d)) >= 5 && (n3 & 1) != 0) {
                int n6 = n3 / 2;
                byte[] arrby = new byte[n6];
                int n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    arrby[i2] = (byte)this.a(n7);
                    n7 += 2;
                }
                return new String(this.g, this.d, n3);
            }
            StringBuilder stringBuilder = new StringBuilder("Unexpected end of DN: ");
            stringBuilder.append(this.a);
            throw new IllegalStateException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder("Unexpected end of DN: ");
        stringBuilder.append(this.a);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public final String c() {
        int n2;
        this.d = n2 = this.c;
        this.e = n2;
        do {
            int n3;
            char[] arrc;
            int n4;
            int n5;
            char[] arrc2;
            int n6;
            block3 : {
                char[] arrc3;
                block4 : {
                    block6 : {
                        block5 : {
                            if ((n5 = this.c) >= this.b) {
                                char[] arrc4 = this.g;
                                int n7 = this.d;
                                return new String(arrc4, n7, this.e - n7);
                            }
                            arrc3 = this.g;
                            char c2 = arrc3[n5];
                            if (c2 == ' ') break block3;
                            if (c2 == ';') break block4;
                            if (c2 == '\\') break block5;
                            if (c2 == '+' || c2 == ',') break block4;
                            int n8 = this.e;
                            this.e = n8 + 1;
                            arrc3[n8] = arrc3[n5];
                            break block6;
                        }
                        int n9 = this.e;
                        this.e = n9 + 1;
                        arrc3[n9] = this.d();
                        n5 = this.c;
                    }
                    this.c = n5 + 1;
                    continue;
                }
                int n10 = this.d;
                return new String(arrc3, n10, this.e - n10);
            }
            this.f = n4 = this.e;
            this.c = n5 + 1;
            this.e = n4 + 1;
            arrc3[n4] = 32;
            while ((n3 = this.c) < (n6 = this.b) && (arrc = this.g)[n3] == ' ') {
                int n11 = this.e;
                this.e = n11 + 1;
                arrc[n11] = 32;
                this.c = n3 + 1;
            }
            if (n3 == n6 || (arrc2 = this.g)[n3] == ',' || arrc2[n3] == '+' || arrc2[n3] == ';') break;
        } while (true);
        char[] arrc = this.g;
        int n12 = this.d;
        return new String(arrc, n12, this.f - n12);
    }

    public final char d() {
        int n2;
        this.c = n2 = 1 + this.c;
        if (n2 != this.b) {
            char[] arrc = this.g;
            char c2 = arrc[n2];
            if (c2 != ' ' && c2 != '%' && c2 != '\\' && c2 != '_' && c2 != '\"' && c2 != '#') {
                switch (c2) {
                    default: {
                        switch (c2) {
                            default: {
                                return this.e();
                            }
                            case ';': 
                            case '<': 
                            case '=': 
                            case '>': 
                        }
                    }
                    case '*': 
                    case '+': 
                    case ',': 
                }
            }
            return arrc[n2];
        }
        StringBuilder stringBuilder = new StringBuilder("Unexpected end of DN: ");
        stringBuilder.append(this.a);
        throw new IllegalStateException(stringBuilder.toString());
    }
}

