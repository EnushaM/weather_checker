/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.sqlite.SQLiteDatabase
 *  android.text.TextUtils
 *  com.huawei.hms.analytics.database.APIEventDao
 *  com.huawei.hms.analytics.database.DaoManager
 *  com.huawei.hms.analytics.database.DaoManager$lmn
 *  com.huawei.hms.analytics.database.DaoSession
 *  com.huawei.hms.analytics.database.EventDao
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.database.APIEvent;
import com.huawei.hms.analytics.database.APIEventDao;
import com.huawei.hms.analytics.database.DaoManager;
import com.huawei.hms.analytics.database.DaoSession;
import com.huawei.hms.analytics.database.EventDao;
import java.util.List;

public final class ae {
    private static ae klm;
    public DaoSession lmn;

    private ae(Context context, String string2) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2)) {
            try {
                this.lmn = new DaoManager(new DaoManager.lmn(context, string2, 0).getWritableDatabase()).newSession();
                return;
            }
            catch (Exception exception) {
                throw new lmn(exception.getMessage());
            }
        }
        throw new IllegalArgumentException("context is null,or dbName is empty");
    }

    private static void klm(Context context) {
        Class<ae> class_ = ae.class;
        synchronized (ae.class) {
            if (klm == null) {
                klm = new ae(context, "userEvent.db");
            }
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return;
        }
    }

    public static ae lmn(Context context) {
        if (klm == null) {
            ae.klm(context);
        }
        return klm;
    }

    public final List<APIEvent> klm() {
        return this.lmn.getAPIEventDao().loadAll();
    }

    public final void lmn() {
        this.lmn.getAPIEventDao().deleteAll();
    }

    public final void lmn(List<Event> list) {
        this.lmn.getEventDao().insertInTx(list);
    }

    public static final class lmn
    extends Exception {
        public lmn(String string2) {
            super(string2);
        }
    }

}

