/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.File
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.analytics;

import android.content.Context;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.bv;
import com.huawei.hms.analytics.core.crypto.HexUtil;
import com.huawei.hms.analytics.core.log.HiLog;
import java.io.File;
import java.io.IOException;

public final class ao {
    private String klm;
    public Context lmn;

    public ao() {
        Context context;
        this.lmn = context = aa.lmn().klm.bcd;
        this.klm = context.getFilesDir().getPath();
    }

    private String klm(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.klm);
        stringBuilder.append("/openness/component/".replace((CharSequence)"component", (CharSequence)string2));
        return stringBuilder.toString();
    }

    private static boolean klm(File file) {
        if (file.exists()) {
            return true;
        }
        try {
            boolean bl2 = file.createNewFile();
            return bl2;
        }
        catch (IOException iOException) {
            HiLog.w("ComponentCommander", "create new file error!");
            return false;
        }
    }

    public static boolean lmn() {
        ab ab2 = aa.lmn().klm;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(ab2.bcd.getFilesDir().getPath());
        stringBuilder.append("/openness");
        return ao.lmn(new File(stringBuilder.toString()));
    }

    private static boolean lmn(File file) {
        if (file != null && file.exists()) {
            if (!file.isDirectory()) {
                return false;
            }
            File[] arrfile = file.listFiles();
            if (arrfile != null) {
                if (arrfile.length == 0) {
                    return false;
                }
                for (File file2 : arrfile) {
                    if (file2.isFile()) {
                        if (file2.delete()) continue;
                        StringBuilder stringBuilder = new StringBuilder("delete file failed : ");
                        stringBuilder.append(file2.getName());
                        HiLog.i("ComponentCommander", stringBuilder.toString());
                        continue;
                    }
                    if (!file2.isDirectory()) continue;
                    ao.lmn(file2);
                }
                return file.delete();
            }
        }
        return false;
    }

    public final String lmn(String string2) {
        File file = new File(this.klm(string2), "hianalytics_".concat(String.valueOf((Object)string2)));
        if (ao.klm(file)) {
            return bv.lmn(file);
        }
        String string3 = HexUtil.initRandomKey(128);
        bv.lmn(file, string3);
        return string3;
    }

    public final void lmn(String string2, String string3) {
        File file = new File(this.klm(string2));
        File file2 = new File(this.klm(string2), "hianalytics_".concat(String.valueOf((Object)string2)));
        if (!file.exists() && file.mkdirs()) {
            HiLog.i("ComponentCommander", "file directory is mkdirs");
        }
        if (ao.klm(file2)) {
            bv.lmn(file2, string3);
            return;
        }
        HiLog.w("ComponentCommander", "refreshComponent():file is not found,and file is create failed");
    }
}

