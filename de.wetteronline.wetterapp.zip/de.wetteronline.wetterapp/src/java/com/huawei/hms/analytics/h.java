/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Parcelable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.bj;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.f;
import com.huawei.hms.analytics.l;
import com.huawei.hms.api.Api;
import com.huawei.hms.common.HuaweiApi;
import com.huawei.hms.common.internal.AbstractClientBuilder;
import com.huawei.hms.common.internal.AnyClient;
import com.huawei.hms.common.internal.TaskApiCall;
import org.json.JSONException;
import org.json.JSONObject;

public final class h
extends HuaweiApi<Api.ApiOptions.NoOptions> {
    private static final f lmn = new f();
    private Context klm;

    public h(Context context) {
        super(context, new Api(""), new Api.ApiOptions.NotRequiredOptions(){}, (AbstractClientBuilder)lmn);
        this.klm = context;
    }

    public final je.f<String> lmn(boolean bl2) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("method", (Object)"setKitEnable");
            jSONObject.put("pkg_name", (Object)aa.lmn().klm.bcd.getPackageName());
            jSONObject.put("3rd_aaid", (Object)bj.lmn().ikl);
            jSONObject.put("enable_collect", bl2);
        }
        catch (JSONException jSONException) {
            StringBuilder stringBuilder = new StringBuilder("unableCollect build json failed. ");
            stringBuilder.append(jSONException.getMessage());
            HiLog.e("HiAnalyticsClientWatchable", stringBuilder.toString());
        }
        l l4 = new l("hianalytics.analyticsInvokeService", jSONObject.toString());
        if (this.klm != null) {
            Intent intent = new Intent();
            l4.setParcelable((Parcelable)PendingIntent.getService((Context)this.klm, (int)1, (Intent)intent, (int)134217728));
        }
        return this.doWrite(l4);
    }
}

