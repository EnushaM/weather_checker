/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.huawei.hms.analytics;

public final class az {
    private long hij = System.currentTimeMillis();
    public String ijk = "";
    public String ikl = "";
    public String klm = "";
    public String lmn = "1";

    public final long lmn() {
        return System.currentTimeMillis() - this.hij;
    }

    public static interface lmn {
        public void lmn();

        public void lmn(String var1);
    }

}

