/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.UnsupportedEncodingException
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics.framework.c;

import com.huawei.hms.analytics.core.crypto.HexUtil;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.core.storage.IStorageHandler;
import com.huawei.hms.analytics.framework.b.d;
import com.huawei.hms.analytics.framework.c.a.a;
import com.huawei.hms.analytics.framework.c.a.b;
import com.huawei.hms.analytics.framework.c.e;
import com.huawei.hms.analytics.framework.config.DeviceAttributeCollector;
import com.huawei.hms.analytics.framework.config.EvtHeaderAttributeCollector;
import com.huawei.hms.analytics.framework.config.ICallback;
import com.huawei.hms.analytics.framework.config.ICollectorConfig;
import com.huawei.hms.analytics.framework.config.RomAttributeCollector;
import com.huawei.hms.analytics.framework.listener.IEventListener;
import com.huawei.hms.analytics.framework.policy.IStoragePolicy;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class c {
    public boolean a;
    private String b;
    private String c;
    private List<Event> d;
    private ICollectorConfig e;
    private ICallback f;

    public c(String string2, String string3, List<Event> list, ICallback iCallback) {
        this.b = string2;
        this.c = string3;
        this.d = list;
        this.f = iCallback;
        this.e = com.huawei.hms.analytics.framework.b.b.a().a(string2);
    }

    private b a(String string2, String string3) {
        d.a().b();
        if (d.a().a.c != null && !d.a().a.c.isEmpty()) {
            String string4 = this.e.getAppId();
            DeviceAttributeCollector deviceAttributeCollector = this.e.getDeviceAttribute(string2);
            JSONObject jSONObject = this.a(string4, string3, string2, d.a().a.c);
            EvtHeaderAttributeCollector evtHeaderAttributeCollector = this.e.getEvtCustomHeader(string2, jSONObject);
            RomAttributeCollector romAttributeCollector = this.e.getRomAttribute(string2);
            b b3 = new b(deviceAttributeCollector, evtHeaderAttributeCollector, romAttributeCollector, d.a().a.b, this.b);
            return b3;
        }
        return null;
    }

    private JSONObject a(String string2, String string3, String string4, String string5) {
        a a2 = new a();
        a2.b = string2;
        a2.a = string5;
        a2.e = string3;
        a2.c = this.b;
        StringBuffer stringBuffer = new StringBuffer("hmshi");
        stringBuffer.append(string4);
        stringBuffer.append("qrt");
        a2.f = stringBuffer.toString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(System.currentTimeMillis());
        a2.d = stringBuilder.toString();
        return a2.a();
    }

    private void a(List<Event> list, String string2, boolean bl2) {
        b b3 = this.a(this.c, string2);
        if (b3 == null) {
            HiLog.w("ReportAssignment", "uploadEvtModel is null");
            return;
        }
        byte[] arrby = c.a(b3, list, bl2);
        if (arrby.length == 0) {
            HiLog.w("ReportAssignment", "request body is empty");
            return;
        }
        e e2 = new e(arrby, this.b, this.c, string2, this.d);
        e2.a = this.f;
        e2.b = bl2;
        e2.run();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static byte[] a(b b3, List<Event> list, boolean bl2) {
        String string2;
        JSONObject jSONObject = b3.a(list, bl2);
        if (jSONObject != null) return com.huawei.hms.analytics.framework.g.a.a(jSONObject.toString().getBytes("UTF-8"));
        try {
            HiLog.w("ReportAssignment", "uploadEvents is null");
            return new byte[0];
        }
        catch (JSONException throwable) {
            string2 = "json exception";
        }
        catch (UnsupportedEncodingException throwable) {
            string2 = "sendData(): getBytes - Unsupported coding format!!";
        }
        HiLog.w("ReportAssignment", string2);
        return new byte[0];
    }

    public final void a() {
        IStoragePolicy iStoragePolicy;
        List<IEventListener> list;
        HiLog.d("ReportAssignment", "ReportProcessor is executing");
        String string2 = this.b;
        com.huawei.hms.analytics.framework.b.a a2 = (com.huawei.hms.analytics.framework.b.a)com.huawei.hms.analytics.framework.b.b.a().b.get((Object)string2);
        com.huawei.hms.analytics.framework.listener.a a3 = a2 != null ? a2.c : null;
        if (a3 != null && (list = a3.a) != null && list.size() != 0) {
            Iterator iterator = a3.a.iterator();
            while (iterator.hasNext()) {
                ((IEventListener)iterator.next()).init();
            }
        }
        if (!(iStoragePolicy = com.huawei.hms.analytics.framework.a.a.b(this.b)).decide(IStoragePolicy.PolicyType.PARAMS, this.c)) {
            if (this.a && this.d.size() == 1) {
                this.f.onResult(-1, -1L, this.d);
            }
            return;
        }
        Event event = this.e.getSpecialEvent(this.c);
        if (event != null) {
            ArrayList arrayList = new ArrayList();
            arrayList.add((Object)event);
            this.a((List<Event>)arrayList, HexUtil.initRandomKey(16), true);
        }
        int n2 = 1 + this.d.size() / 500;
        HiLog.i("ReportAssignment", "times :".concat(String.valueOf((int)n2)));
        for (int i2 = 0; i2 < n2; ++i2) {
            IStorageHandler iStorageHandler;
            int n3 = i2 * 500;
            List<Event> list2 = this.d;
            List list3 = list2.subList(n3, Math.min((int)list2.size(), (int)(n3 + 500)));
            String string3 = HexUtil.initRandomKey(16);
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            for (Event event2 : list3) {
                if (iStoragePolicy.decide(IStoragePolicy.PolicyType.STORAGECYCLY, this.c, Long.valueOf((String)event2.getEvttime()))) {
                    arrayList2.add((Object)event2);
                    continue;
                }
                arrayList.add((Object)event2);
            }
            if (arrayList.size() > 0) {
                this.a((List<Event>)arrayList, string3, this.a);
            } else {
                HiLog.w("ReportAssignment", "No data to report process");
            }
            if (arrayList2.size() <= 0 || (iStorageHandler = com.huawei.hms.analytics.framework.a.a.a(this.b)) == null) continue;
            iStorageHandler.deleteEvents((List<Event>)arrayList2);
        }
    }
}

