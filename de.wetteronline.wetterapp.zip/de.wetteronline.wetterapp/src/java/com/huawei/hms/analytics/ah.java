/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import com.huawei.hms.analytics.bt;
import com.huawei.hms.analytics.core.storage.Event;
import java.util.List;
import org.json.JSONObject;

public interface ah {
    public void ikl(List<Event> var1);

    public void klm(long var1);

    public void klm(List<JSONObject> var1);

    public void lmn();

    public void lmn(long var1);

    public void lmn(String var1, bt var2, long var3);

    public void lmn(List<JSONObject> var1);
}

