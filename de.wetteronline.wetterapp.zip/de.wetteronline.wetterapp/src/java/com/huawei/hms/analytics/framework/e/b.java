/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.UUID
 */
package com.huawei.hms.analytics.framework.e;

import com.huawei.hms.analytics.core.log.HiLog;
import java.util.UUID;

public final class b {
    public long a = 1800000L;
    public long b = 30000L;
    public volatile boolean c = false;
    public volatile long d = 0L;
    public a e = null;

    public final class a {
        public String a = UUID.randomUUID().toString().replace((CharSequence)"-", (CharSequence)"");
        public boolean b;
        public long c;

        public a(long l2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.a);
            stringBuilder.append("_");
            stringBuilder.append(l2);
            this.a = stringBuilder.toString();
            this.c = l2;
            this.b = true;
            b.this.c = false;
        }

        public final void a(long l2) {
            String string2;
            HiLog.i("SessionKeeper", "getNewSession() session is flush!");
            this.a = string2 = UUID.randomUUID().toString();
            this.a = string2.replace((CharSequence)"-", (CharSequence)"");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.a);
            stringBuilder.append("_");
            stringBuilder.append(l2);
            this.a = stringBuilder.toString();
            this.c = l2;
            this.b = true;
        }
    }

}

