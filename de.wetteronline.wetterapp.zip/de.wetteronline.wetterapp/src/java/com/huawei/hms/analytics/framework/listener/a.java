/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.List
 */
package com.huawei.hms.analytics.framework.listener;

import com.huawei.hms.analytics.framework.listener.IEventListener;
import java.util.List;

public final class a {
    public List<IEventListener> a;
}

