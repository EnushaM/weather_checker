/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IInterface
 *  java.lang.Object
 */
package com.huawei.hms.analytics;

import android.os.IInterface;
import com.huawei.hms.analytics.UploadInfo;
import com.huawei.hms.analytics.hij;

public interface ghi
extends IInterface {
    public void lmn(hij var1, UploadInfo var2);
}

