/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.InputStream
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.security.KeyStore
 *  java.security.cert.CertificateException
 *  java.security.cert.X509Certificate
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  javax.net.ssl.TrustManager
 *  javax.net.ssl.TrustManagerFactory
 *  javax.net.ssl.X509TrustManager
 */
package com.huawei.hms.analytics.core.transport.net;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.transport.net.f;
import java.io.Closeable;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

public final class e
implements X509TrustManager {
    public List<X509TrustManager> a;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public e(String var1_1) {
        super();
        this.a = new ArrayList();
        if (var1_1 == null || var1_1.isEmpty()) ** GOTO lbl16
        var2_2 = null;
        try {
            var2_2 = e.class.getResourceAsStream(var1_1);
            if (var2_2 != null) {
                var4_3 = TrustManagerFactory.getInstance((String)"X509");
                var5_4 = KeyStore.getInstance((String)"bks");
                var5_4.load(var2_2, "".toCharArray());
                var4_3.init(var5_4);
                var6_5 = var4_3.getTrustManagers();
                var7_6 = 0;
            } else {
                throw new IllegalArgumentException("caStream is null,can not read CA");
lbl16: // 1 sources:
                throw new IllegalArgumentException("ca path is null,can not read CA");
            }
lbl17: // 2 sources:
            do {
                if (var7_6 < var6_5.length) {
                    if (var6_5[var7_6] instanceof X509TrustManager) {
                        this.a.add((Object)((X509TrustManager)var6_5[var7_6]));
                    }
                    break;
                }
                var8_7 = this.a.isEmpty();
                if (!var8_7) {
                    f.a((Closeable)var2_2);
                    return;
                }
                throw new CertificateException("X509TrustManager is empty");
                break;
            } while (true);
        }
        catch (Throwable var3_8) {
            f.a((Closeable)var2_2);
            throw var3_8;
        }
        ++var7_6;
        ** while (true)
    }

    public final void checkClientTrusted(X509Certificate[] arrx509Certificate, String string2) {
        if (!this.a.isEmpty()) {
            ((X509TrustManager)this.a.get(0)).checkClientTrusted(arrx509Certificate, string2);
            return;
        }
        throw new CertificateException("checkClientTrusted CertificateException");
    }

    public final void checkServerTrusted(X509Certificate[] arrx509Certificate, String string2) {
        if (!this.a.isEmpty()) {
            ((X509TrustManager)this.a.get(0)).checkServerTrusted(arrx509Certificate, string2);
            return;
        }
        throw new CertificateException("checkServerTrusted CertificateException");
    }

    public final X509Certificate[] getAcceptedIssuers() {
        try {
            ArrayList arrayList = new ArrayList();
            Iterator iterator = this.a.iterator();
            while (iterator.hasNext()) {
                arrayList.addAll((Collection)Arrays.asList((Object[])((X509TrustManager)iterator.next()).getAcceptedIssuers()));
            }
            X509Certificate[] arrx509Certificate = (X509Certificate[])arrayList.toArray((Object[])new X509Certificate[arrayList.size()]);
            return arrx509Certificate;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder("getAcceptedIssuers exception : ");
            stringBuilder.append(exception.getMessage());
            HiLog.e("SecureX509TrustCommander", stringBuilder.toString());
            return new X509Certificate[0];
        }
    }
}

