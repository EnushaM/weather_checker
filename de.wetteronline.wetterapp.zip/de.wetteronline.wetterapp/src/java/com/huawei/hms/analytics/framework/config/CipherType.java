/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics.framework.config;

public final class CipherType
extends Enum<CipherType> {
    private static final /* synthetic */ CipherType[] $VALUES;
    public static final /* enum */ CipherType AESCBC;
    public static final /* enum */ CipherType AESGCM;

    public static {
        CipherType cipherType;
        CipherType cipherType2;
        AESCBC = cipherType = new CipherType();
        AESGCM = cipherType2 = new CipherType();
        $VALUES = new CipherType[]{cipherType, cipherType2};
    }

    public static CipherType valueOf(String string2) {
        return (CipherType)Enum.valueOf(CipherType.class, (String)string2);
    }

    public static CipherType[] values() {
        return (CipherType[])$VALUES.clone();
    }
}

