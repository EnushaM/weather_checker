/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 *  java.util.Set
 *  java.util.Timer
 *  java.util.TimerTask
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import android.content.Context;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.bu;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.efg;
import com.huawei.hms.analytics.ijk;
import com.huawei.hms.analytics.type.ReportPolicy;
import java.util.Iterator;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONException;
import org.json.JSONObject;

public final class ar {
    private static ar klm = new ar();
    private ah hij = ijk.lmn().lmn("_openness_config_tag");
    private boolean ijk = false;
    private lmn ikl;
    public JSONObject lmn;

    public static void klm() {
        efg.lmn().klm = false;
    }

    public static ar lmn() {
        return klm;
    }

    public static void lmn(long l2) {
        aa.lmn().klm.h = l2;
    }

    private void lmn(JSONObject jSONObject) {
        if (this.lmn != null) {
            Iterator iterator = jSONObject.keys();
            while (iterator.hasNext()) {
                String string2 = (String)iterator.next();
                this.lmn.remove(string2);
            }
            Iterator iterator2 = this.lmn.keys();
            if (iterator2.hasNext()) {
                String string3 = (String)iterator2.next();
                if ("onMoveBackgroundPolicy".equals((Object)string3)) {
                    efg.lmn().klm = false;
                } else if ("onScheduledTime".equals((Object)string3)) {
                    this.ikl.lmn();
                    this.ikl = null;
                } else if ("onCacheThreshold".equals((Object)string3)) {
                    ar.lmn(30L);
                }
            }
        }
        StringBuilder stringBuilder = new StringBuilder("save policies : ");
        stringBuilder.append(jSONObject.toString());
        HiLog.i("PoliceCommander", stringBuilder.toString());
        bu.lmn(aa.lmn().klm.bcd, "global_v2", "policies", jSONObject.toString());
    }

    private static void lmn(JSONObject jSONObject, String string2, Object object) {
        try {
            jSONObject.put(string2, object);
            return;
        }
        catch (JSONException jSONException) {
            HiLog.w("PoliceCommander", "jsonPut json Exception");
            return;
        }
    }

    public final void ijk() {
        if (this.ijk) {
            return;
        }
        if (this.hij != null) {
            this.ijk = true;
            HiLog.i("PoliceCommander", "onAppLaunchPolicy onReport");
            this.hij.lmn();
        }
    }

    public final void ikl() {
        JSONObject jSONObject;
        this.lmn = jSONObject = new JSONObject();
        try {
            jSONObject.put("onMoveBackgroundPolicy", (Object)"");
            this.lmn.put("onCacheThreshold", 30L);
            return;
        }
        catch (JSONException jSONException) {
            HiLog.w("PoliceCommander", "defPolicies json exception");
            return;
        }
    }

    public final void klm(long l2) {
        lmn lmn2 = this.ikl;
        if (lmn2 == null) {
            lmn lmn3;
            this.ikl = lmn3 = new lmn();
            lmn3.lmn(l2);
            return;
        }
        if (lmn2.klm(l2)) {
            lmn lmn4;
            this.ikl.lmn();
            this.ikl = lmn4 = new lmn();
            lmn4.lmn(l2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void lmn(Set<ReportPolicy> set) {
        ar ar2 = this;
        synchronized (ar2) {
            if (set != null && set.size() > 0) {
                JSONObject jSONObject = new JSONObject();
                for (ReportPolicy reportPolicy : set) {
                    int n2;
                    int n3 = 1.lmn[reportPolicy.ordinal()];
                    if (n3 != (n2 = 1)) {
                        if (n3 != 2) {
                            if (n3 != 3) {
                                if (n3 != 4) continue;
                                ar.lmn(jSONObject, "onMoveBackgroundPolicy", "");
                                efg.lmn().klm = n2;
                                continue;
                            }
                            long l2 = reportPolicy.getThreshold();
                            ar.lmn(jSONObject, "onCacheThreshold", l2);
                            ar.lmn(l2);
                            continue;
                        }
                        long l3 = reportPolicy.getThreshold();
                        ar.lmn(jSONObject, "onScheduledTime", l3);
                        JSONObject jSONObject2 = this.lmn;
                        if (jSONObject2 != null && jSONObject2.optLong("onScheduledTime", -1L) == l3) {
                            n2 = 0;
                        }
                        if (n2 == 0) continue;
                        this.klm(l3);
                        continue;
                    }
                    ar.lmn(jSONObject, "onAppLaunch", "");
                    this.ijk();
                }
                this.lmn(jSONObject);
                this.lmn = jSONObject;
            }
            return;
        }
    }

    public final class lmn
    extends TimerTask {
        private long ikl = -1L;
        private Timer klm = new Timer();

        public final boolean klm(long l2) {
            long l3 = this.ikl;
            return l3 != -1L && l3 != l2;
        }

        public final void lmn() {
            this.klm.cancel();
            this.klm.purge();
            this.klm = null;
        }

        public final void lmn(long l2) {
            this.ikl = l2;
            long l3 = l2 * 1000L;
            this.klm.schedule((TimerTask)this, l3, l3);
        }

        public final void run() {
            HiLog.i("PoliceCommander", "Timer report timer running");
            if (ar.this.hij != null) {
                ar.this.hij.lmn();
            }
        }
    }

}

