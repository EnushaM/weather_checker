/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.SecureRandom
 *  java.util.Locale
 */
package com.huawei.hms.analytics.core.crypto;

import com.huawei.hms.analytics.core.log.HiLog;
import java.security.SecureRandom;
import java.util.Locale;

public abstract class HexUtil {
    private static final char[] a = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    public static String byteArray2HexString(byte[] arrby) {
        if (arrby != null && arrby.length != 0) {
            StringBuilder stringBuilder = new StringBuilder(2 * arrby.length);
            for (byte by2 : arrby) {
                char[] arrc = a;
                stringBuilder.append(arrc[(by2 & 240) >> 4]);
                stringBuilder.append(arrc[by2 & 15]);
            }
            return stringBuilder.toString();
        }
        HiLog.w("HexToolsKit", "byteArray is empty");
        return "";
    }

    public static byte[] hexString2ByteArray(String string2) {
        if (string2 != null && string2.length() != 0) {
            String string3 = string2.toUpperCase(Locale.ENGLISH);
            int n2 = string3.length() / 2;
            char[] arrc = string3.toCharArray();
            byte[] arrby = new byte[n2];
            for (int i2 = 0; i2 < n2; ++i2) {
                int n3 = i2 * 2;
                if (n3 >= 0 && n3 < -1 + arrc.length) {
                    arrby[i2] = (byte)((byte)"0123456789ABCDEF".indexOf((int)arrc[n3]) << 4 | (byte)"0123456789ABCDEF".indexOf((int)arrc[n3 + 1]));
                    continue;
                }
                HiLog.e("HexToolsKit", "char error");
            }
            return arrby;
        }
        return new byte[0];
    }

    public static byte[] initRandomByte(int n2) {
        try {
            SecureRandom secureRandom = SecureRandom.getInstance((String)"SHA1PRNG");
            byte[] arrby = new byte[n2];
            secureRandom.nextBytes(arrby);
            return arrby;
        }
        catch (Exception exception) {
            HiLog.e("HexToolsKit", "generate secure random error");
            return new byte[0];
        }
    }

    public static String initRandomKey(int n2) {
        try {
            String string2 = HexUtil.byteArray2HexString(HexUtil.initRandomByte(n2));
            return string2;
        }
        catch (Exception exception) {
            HiLog.e("HexToolsKit", "generate secure random error: ");
            return "";
        }
    }
}

