/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.net.InetAddress
 *  java.net.Socket
 *  java.security.GeneralSecurityException
 *  java.security.KeyManagementException
 *  java.security.KeyStoreException
 *  java.security.NoSuchAlgorithmException
 *  java.security.SecureRandom
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  javax.net.SocketFactory
 *  javax.net.ssl.KeyManager
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLSocket
 *  javax.net.ssl.SSLSocketFactory
 *  javax.net.ssl.TrustManager
 *  javax.net.ssl.X509TrustManager
 */
package com.huawei.hms.analytics.core.transport.net;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.transport.ITransportHandler;
import com.huawei.hms.analytics.core.transport.net.d;
import com.huawei.hms.analytics.core.transport.net.e;
import com.huawei.hms.analytics.core.transport.net.g;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.security.GeneralSecurityException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.net.SocketFactory;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public final class a
extends SSLSocketFactory {
    public static final g a = new g();
    private static SocketFactory c;
    private final SSLContext b;
    private ITransportHandler.Protocols d;
    private boolean e;

    private a(String string2, ITransportHandler.Protocols protocols, boolean bl2) {
        SSLContext sSLContext;
        this.d = protocols;
        this.e = bl2;
        this.b = sSLContext = SSLContext.getInstance((String)protocols.getProtocol());
        sSLContext.init(null, (TrustManager[])new X509TrustManager[]{new e(string2)}, null);
    }

    public static SocketFactory a(String string2, ITransportHandler.Protocols protocols, boolean bl2) {
        return a.b(string2, protocols, bl2);
    }

    private void a(Socket socket) {
        if (socket instanceof SSLSocket) {
            SSLSocket sSLSocket = (SSLSocket)socket;
            this.a(sSLSocket);
            this.b(sSLSocket);
        }
    }

    private void a(List<String> list, String[] arrstring) {
        List<String> list2 = this.e ? d.b : d.a;
        for (int i2 = 0; i2 < arrstring.length; ++i2) {
            String string2 = arrstring[i2].toUpperCase(Locale.ENGLISH);
            if (!list2.contains((Object)string2)) continue;
            list.add((Object)string2);
        }
    }

    private void a(SSLSocket sSLSocket) {
        if (sSLSocket == null) {
            return;
        }
        if (this.d.getProtocol().equals((Object)"TLSv1.3")) {
            sSLSocket.setEnabledProtocols(new String[]{"TLSv1.3", "TLSv1.2"});
            return;
        }
        sSLSocket.setEnabledProtocols(new String[]{"TLSv1.2"});
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private static SocketFactory b(String string2, ITransportHandler.Protocols protocols, boolean bl2) {
        Class<a> class_ = a.class;
        // MONITORENTER : com.huawei.hms.analytics.core.transport.net.a.class
        if (c == null) {
            if (protocols != null) {
                c = new a(string2, protocols, bl2);
            } else {
                HiLog.e("SocketBoss", "protocol is null");
            }
        }
        SocketFactory socketFactory = c;
        // MONITOREXIT : class_
        return socketFactory;
        catch (IOException throwable2) {
            String string4;
            String string3;
            block12 : {
                string3 = "SocketBoss";
                string4 = "getLocalInstanceLock(): Failed to new SSLSocketFactory instance,IO!";
                break block12;
                catch (KeyManagementException throwable2) {
                    string3 = "SocketBoss";
                    string4 = "getLocalInstanceLock(): Failed to new SSLSocketFactory instance,Key Manage!";
                    break block12;
                }
                catch (GeneralSecurityException throwable2) {
                    string3 = "SocketBoss";
                    string4 = "getLocalInstanceLock(): GeneralSecurityException: Failed to new SSLSocketFactory instance";
                    break block12;
                }
                catch (KeyStoreException throwable2) {
                    string3 = "SocketBoss";
                    string4 = "getLocalInstanceLock(): Failed to new SSLSocketFactory instance,Key Store!";
                    break block12;
                }
                catch (NoSuchAlgorithmException throwable2) {
                    string3 = "SocketBoss";
                    string4 = "getLocalInstanceLock(): Failed to new SSLSocketFactory instance,Algorithm Exception!";
                }
            }
            HiLog.w(string3, string4);
            return null;
        }
    }

    private void b(List<String> list, String[] arrstring) {
        for (String string2 : arrstring) {
            boolean bl2;
            block2 : {
                List<String> list2 = this.e ? d.c : d.d;
                Iterator iterator = list2.iterator();
                while (iterator.hasNext()) {
                    if (!string2.contains((CharSequence)((String)iterator.next()))) continue;
                    bl2 = true;
                    break block2;
                }
                bl2 = false;
            }
            if (bl2) continue;
            list.add((Object)string2);
        }
    }

    private void b(SSLSocket sSLSocket) {
        String[] arrstring = sSLSocket.getEnabledCipherSuites();
        if (arrstring != null) {
            if (arrstring.length == 0) {
                return;
            }
            ArrayList arrayList = new ArrayList();
            this.a((List<String>)arrayList, arrstring);
            if (arrayList.size() == 0) {
                this.b((List<String>)arrayList, arrstring);
            }
            sSLSocket.setEnabledCipherSuites((String[])arrayList.toArray((Object[])new String[arrayList.size()]));
        }
    }

    public final Socket createSocket(String string2, int n2) {
        Socket socket = this.b.getSocketFactory().createSocket(string2, n2);
        this.a(socket);
        return socket;
    }

    public final Socket createSocket(String string2, int n2, InetAddress inetAddress, int n3) {
        return this.createSocket(string2, n2);
    }

    public final Socket createSocket(InetAddress inetAddress, int n2) {
        return this.createSocket(inetAddress.getHostAddress(), n2);
    }

    public final Socket createSocket(InetAddress inetAddress, int n2, InetAddress inetAddress2, int n3) {
        return this.createSocket(inetAddress.getHostAddress(), n2);
    }

    public final Socket createSocket(Socket socket, String string2, int n2, boolean bl2) {
        Socket socket2 = this.b.getSocketFactory().createSocket(socket, string2, n2, bl2);
        this.a(socket2);
        return socket2;
    }

    public final String[] getDefaultCipherSuites() {
        return new String[0];
    }

    public final String[] getSupportedCipherSuites() {
        return new String[0];
    }
}

