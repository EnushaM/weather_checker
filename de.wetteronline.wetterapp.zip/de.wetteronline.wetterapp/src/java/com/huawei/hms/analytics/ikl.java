/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.TextUtils
 *  com.huawei.hms.analytics.bg
 *  com.huawei.hms.analytics.c
 *  com.huawei.hms.analytics.klm
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.ExecutorService
 *  java.util.regex.Pattern
 *  je.f
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.ai;
import com.huawei.hms.analytics.ar;
import com.huawei.hms.analytics.az;
import com.huawei.hms.analytics.ba;
import com.huawei.hms.analytics.bf;
import com.huawei.hms.analytics.bg;
import com.huawei.hms.analytics.bi;
import com.huawei.hms.analytics.bj;
import com.huawei.hms.analytics.bn;
import com.huawei.hms.analytics.br;
import com.huawei.hms.analytics.bt;
import com.huawei.hms.analytics.bu;
import com.huawei.hms.analytics.c;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.def;
import com.huawei.hms.analytics.fgh;
import com.huawei.hms.analytics.framework.HAFrameworkInstance;
import com.huawei.hms.analytics.framework.config.ICallback;
import com.huawei.hms.analytics.framework.listener.IEventListener;
import com.huawei.hms.analytics.klm;
import com.huawei.hms.analytics.type.ReportPolicy;
import com.huawei.hms.analytics.y;
import com.huawei.hms.analytics.z;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.regex.Pattern;
import je.f;
import org.json.JSONObject;

public final class ikl
extends klm
implements ai {
    private def fgh;

    public ikl(Context context) {
        super(context, "_openness_config_tag");
        this.klm.addEventListener((IEventListener)new c());
        this.fgh = new def(context);
        this.lmn = this.klm.build(this.hij);
    }

    private void fgh() {
        bu.lmn(this.ijk, "stop_v2_1", new String[]{"stop_event"});
        bt bt2 = new bt("$StopAnalyticsCollection", new Bundle());
        this.lmn.onStreamEvent("oper", (List<JSONObject>)bt2.klm, (ICallback)new bg());
    }

    @Override
    public final f<String> ghi() {
        if (!this.ghi) {
            HiLog.w("instanceimpl", "IE-006", "The Analytics Kit is disabled");
            return null;
        }
        az az2 = ba.lmn("HiAnalyticsInstance#getAAID()");
        try {
            f<String> f2 = bj.lmn().klm;
            az2.lmn = "0";
            return f2;
        }
        finally {
            ba.lmn(az2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void hij() {
        Object object;
        if (!this.ghi) {
            HiLog.w("instanceimpl", "IE-006", "The Analytics Kit is disabled");
            return;
        }
        az az2 = ba.lmn("HiAnalyticsInstance#clearCachedData()");
        this.lmn.clearCacheData("oper");
        bj bj2 = bj.lmn();
        Context context = this.ijk;
        bj2.lmn.execute(new Runnable(bj2, context){
            public final /* synthetic */ bj klm;
            public final /* synthetic */ Context lmn;
            {
                this.klm = bj2;
                this.lmn = context;
            }

            /*
             * Exception decompiling
             */
            public final void run(}
        java.lang.IllegalStateException: Parameters not created
        
        