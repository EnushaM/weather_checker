/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Parcelable
 *  java.lang.Exception
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.content.Intent;
import android.os.Parcelable;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.i;
import com.huawei.hms.analytics.j;
import com.huawei.hms.common.ApiException;
import com.huawei.hms.common.internal.AnyClient;
import com.huawei.hms.common.internal.ResponseErrorCode;
import com.huawei.hms.common.internal.TaskApiCall;
import com.huawei.hms.support.api.client.Status;
import je.g;

public final class k
extends TaskApiCall<i, j> {
    public k(String string, String string2) {
        super(string, string2, null);
    }

    @Override
    public final /* synthetic */ void doExecute(AnyClient anyClient, ResponseErrorCode responseErrorCode, String string, g g2) {
        if (responseErrorCode != null && g2 != null) {
            if (responseErrorCode.getErrorCode() == 0) {
                j j2 = new j(string);
                if (responseErrorCode.getParcelable() != null) {
                    if (responseErrorCode.getParcelable() instanceof Intent) {
                        HiLog.i("HiAnalyticsTaskApiRequire", "HMS API call succeed.");
                        g2.b(new j((Intent)responseErrorCode.getParcelable()));
                        return;
                    }
                    HiLog.w("HiAnalyticsTaskApiRequire", "HMS API call failed. header.getParcelable() is not Intent");
                    g2.b(j2);
                    return;
                }
                HiLog.w("HiAnalyticsTaskApiRequire", "HMS API call failed. header.getParcelable() is null");
                g2.b(j2);
                return;
            }
            HiLog.w("HiAnalyticsTaskApiRequire", "HMS API call failed. header.getErrorCode() != CommonCode.OK");
            g2.a(new ApiException(new Status(responseErrorCode.getErrorCode(), responseErrorCode.getErrorReason())));
            return;
        }
        HiLog.w("HiAnalyticsTaskApiRequire", "HMS API call failed. header or taskCompletionSource is null");
    }

    @Override
    public final int getMinApkVersion() {
        return 40000000;
    }
}

