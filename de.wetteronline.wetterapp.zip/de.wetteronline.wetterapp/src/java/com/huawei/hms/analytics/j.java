/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.content.Intent;

public final class j {
    private String klm;
    public Intent lmn = null;

    public j(Intent intent) {
        this.lmn = intent;
    }

    public j(String string2) {
        this.klm = string2;
    }
}

