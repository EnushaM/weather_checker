/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 */
package com.huawei.hms.analytics;

import android.app.Application;
import android.content.Context;
import android.text.TextUtils;
import com.huawei.hms.analytics.core.log.HiLog;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class br {
    public static boolean ikl(Context context) {
        String string2 = br.lmn("debug.huawei.hms.analytics.app", "");
        if (context != null && !TextUtils.isEmpty((CharSequence)string2)) {
            return string2.equals((Object)context.getPackageName());
        }
        HiLog.i("DeviceToolsKit", "debugMode disabled.");
        return false;
    }

    /*
     * Exception decompiling
     */
    public static String klm(Context var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl36 : LDC : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static Application lmn() {
        String string2;
        try {
            Application application = (Application)Class.forName((String)"android.app.ActivityThread").getMethod("currentApplication", new Class[0]).invoke(null, null);
            return application;
        }
        catch (NoSuchMethodException throwable) {
            string2 = "getApplication(): NoSuchMethodException!";
        }
        catch (ClassNotFoundException throwable) {
            string2 = "getApplication(): ClassNotFoundException!";
        }
        catch (InvocationTargetException throwable) {
            string2 = "getApplication(): Invocation Target Exception!";
        }
        catch (IllegalArgumentException throwable) {
            string2 = "getApplication(): Illegal Argument!";
        }
        catch (IllegalAccessException throwable) {
            string2 = "getApplication(): method invoke Exception!";
        }
        HiLog.w("DeviceToolsKit", string2);
        return null;
    }

    public static Object lmn(String string2, String string3, Class[] arrclass, Object[] arrobject) {
        try {
            Object object = Class.forName((String)string2).getMethod(string3, arrclass).invoke(null, arrobject);
            return object;
        }
        catch (Exception exception) {
            HiLog.w("DeviceToolsKit", "invokeStaticFun() Exception");
            return null;
        }
    }

    /*
     * Exception decompiling
     */
    public static String lmn(Context var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl62 : ALOAD_1 : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static String lmn(String string2, String string3) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return string3;
        }
        String string4 = br.lmn("android.os.SystemProperties", string2, string3);
        if (TextUtils.isEmpty((CharSequence)string4)) {
            string4 = br.lmn("com.huawei.android.os.SystemPropertiesEx", string2, string3);
        }
        return string4;
    }

    public static String lmn(String string2, String string3, String string4) {
        Object object = br.lmn(string2, "get", new Class[]{String.class, String.class}, new Object[]{string3, string4});
        if (object != null) {
            string4 = (String)object;
        }
        return string4;
    }
}

