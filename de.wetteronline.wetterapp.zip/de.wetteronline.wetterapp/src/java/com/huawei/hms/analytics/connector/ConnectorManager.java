/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.TextUtils
 *  com.huawei.hms.analytics.aq
 *  com.huawei.hms.analytics.x
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.Map
 */
package com.huawei.hms.analytics.connector;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.aq;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.log.LogAdapter;
import com.huawei.hms.analytics.ijk;
import com.huawei.hms.analytics.x;
import java.util.HashMap;
import java.util.Map;

public class ConnectorManager {
    private static final String TAG = "InteractionManager";
    private x instance;
    private boolean isInitFlag;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public ConnectorManager(Context context, String string2, String string3) {
        HiLog.setLogAdapter((LogAdapter)new aq());
        if (context != null && !TextUtils.isEmpty((CharSequence)string2) && string2.length() <= 256 && !TextUtils.isEmpty((CharSequence)string3) && string3.length() <= 256) {
            try {
                Context context2 = context.getApplicationContext();
                ijk.lmn().lmn(context2);
                ah ah2 = ijk.lmn().lmn(string2);
                if (ah2 == null) {
                    x x2;
                    this.instance = x2 = new x(context2, string2);
                    x2.lmn(string3);
                    ijk.lmn().lmn(string2, (ah)this.instance);
                } else {
                    this.instance = (x)ah2;
                }
                this.isInitFlag = true;
                HiLog.i(TAG, "connector init success, tag\uff1a".concat(string2));
                return;
            }
            catch (Exception exception) {
                HiLog.e(TAG, "other exception,init connector instance error ");
                return;
            }
            catch (IllegalAccessException illegalAccessException) {
                StringBuilder stringBuilder = new StringBuilder("param error.");
                stringBuilder.append(illegalAccessException.getMessage());
                HiLog.e(TAG, stringBuilder.toString());
                return;
            }
        }
        HiLog.w(TAG, "connectManager param is not right");
    }

    public Map<String, String> getUserProfiles(boolean bl2) {
        if (this.isInitFlag) {
            return this.instance.lmn(bl2);
        }
        return new HashMap();
    }

    public void onEvent(String string2, Bundle bundle) {
        if (this.isInitFlag) {
            HiLog.i(TAG, "connectManager onEvent");
            this.instance.lmn(string2, bundle);
        }
    }

    public void onReport() {
        if (this.isInitFlag && aa.lmn().klm.abc) {
            HiLog.i(TAG, "connectManager onReport");
            this.instance.lmn();
        }
    }

    @Deprecated
    public void setEnableAndroidID(Boolean bl2) {
        if (this.isInitFlag) {
            this.instance.klm(bl2.booleanValue());
        }
    }
}

