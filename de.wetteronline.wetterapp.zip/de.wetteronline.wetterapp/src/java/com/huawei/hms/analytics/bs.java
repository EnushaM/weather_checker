/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Looper
 *  android.text.TextUtils
 *  com.huawei.hms.analytics.bs$lmn
 *  com.huawei.hms.analytics.core.transport.net.HttpTransportHandler
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.os.Build;
import android.os.Looper;
import android.text.TextUtils;
import b2.a;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ac;
import com.huawei.hms.analytics.az;
import com.huawei.hms.analytics.ba;
import com.huawei.hms.analytics.bs;
import com.huawei.hms.analytics.bu;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.transport.CallbackListener;
import com.huawei.hms.analytics.core.transport.ITransportHandler;
import com.huawei.hms.analytics.core.transport.net.HttpTransportHandler;
import com.huawei.hms.analytics.core.transport.net.Response;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

/*
 * Exception performing whole class analysis.
 */
public final class bs {
    public String klm;
    public final az lmn;

    public bs() {
        this.lmn = ba.lmn("GetPublicKey#execute");
    }

    public bs(String string2) {
        this();
        this.klm = string2;
    }

    private static boolean klm() {
        String string2;
        String string3;
        block4 : {
            ab ab2 = aa.lmn().klm;
            String string4 = bu.klm(ab2.bcd, "Privacy_MY", "pubK_info", "");
            if (TextUtils.isEmpty((CharSequence)string4)) {
                return true;
            }
            try {
                JSONObject jSONObject = new JSONObject(string4);
                String string5 = jSONObject.getString("timeInterval");
                long l2 = jSONObject.getLong("requestTime");
                string2 = jSONObject.getString("publicKey");
                string3 = jSONObject.getString("pubkey_version");
                int n2 = Integer.parseInt((String)string5);
                if (System.currentTimeMillis() - l2 <= (long)n2) break block4;
                return true;
            }
            catch (Exception exception) {
                bu.lmn(ab2.bcd, "Privacy_MY", new String[]{"pubK_info"});
                return true;
            }
        }
        ab2.k = string2;
        ab2.l = string3;
        return false;
    }

    private static String lmn(String string2) {
        if (string2 == null) {
            return null;
        }
        ac ac2 = aa.lmn().lmn(string2);
        if (ac2 != null) {
            Map<String, String> map = ac2.klm;
            if (map == null) {
                return null;
            }
            return (String)map.get((Object)"ha-sdk-service");
        }
        return null;
    }

    public static void lmn(Response response) {
        if (response.getHttpCode() == 200) {
            JSONObject jSONObject = new JSONObject(response.getContent());
            String string2 = jSONObject.getString("publicKey");
            String string3 = jSONObject.getString("pubkey_version");
            if (!TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3)) {
                jSONObject.put("requestTime", System.currentTimeMillis());
                ab ab2 = aa.lmn().klm;
                ab2.k = string2.trim();
                ab2.l = string3;
                bu.lmn(ab2.bcd, "Privacy_MY", "pubK_info", jSONObject.toString());
                return;
            }
            HiLog.e("getPubKey", "pub key or version is empty");
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void lmn() {
        Throwable throwable2222;
        if (!bs.klm()) {
            return;
        }
        String[] arrstring = aa.lmn().klm.lmn();
        int n2 = arrstring.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrstring[i2] = a.a(new StringBuilder(), arrstring[i2], "/getPublicKey");
        }
        HttpTransportHandler httpTransportHandler = new HttpTransportHandler();
        httpTransportHandler.setUrls(arrstring);
        ITransportHandler.Protocols protocols = Build.VERSION.SDK_INT >= 29 ? ITransportHandler.Protocols.TLS1_3 : ITransportHandler.Protocols.TLS1_2;
        httpTransportHandler.setSSLConfig(protocols, "/assets/hianalyticscas.bks", true);
        ab ab2 = aa.lmn().klm;
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"App-Id", (Object)ab2.klm);
        hashMap.put((Object)"x-hasdk-productid", (Object)ab2.ghi);
        hashMap.put((Object)"x-hasdk-resourceid", (Object)ab2.fgh);
        hashMap.put((Object)"x-hasdk-token", (Object)ab2.def);
        hashMap.put((Object)"x-hasdk-clientid", (Object)ab2.efg);
        hashMap.put((Object)"Sdk-Ver", (Object)"5.2.0.301");
        hashMap.put((Object)"Os", (Object)"0");
        hashMap.put((Object)"Os-Ver", (Object)Build.VERSION.RELEASE);
        if (bs.lmn(this.klm) != null) {
            hashMap.put((Object)"ha-sdk-service", (Object)bs.lmn(this.klm));
        }
        httpTransportHandler.setHttpHeaders((Map<String, String>)hashMap);
        if (Looper.myLooper() == Looper.getMainLooper()) {
            httpTransportHandler.execute((CallbackListener)new /* Unavailable Anonymous Inner Class!! */);
            return;
        }
        int n3 = -108;
        Response response = httpTransportHandler.execute();
        n3 = response.getHttpCode();
        HiLog.i("getPubKey", "result code : ".concat(String.valueOf((int)n3)));
        bs.lmn(response);
        this.lmn.lmn = "0";
        this.lmn(n3);
        return;
        {
            catch (Throwable throwable2222) {
            }
            catch (Exception exception) {}
            {
                HiLog.e("getPubKey", "GET pub key exception");
            }
            this.lmn(n3);
            return;
        }
        this.lmn(n3);
        throw throwable2222;
    }

    public final void lmn(int n2) {
        this.lmn.klm = String.valueOf((int)n2);
        ba.lmn(this.lmn);
    }
}

