/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.text.TextUtils
 *  java.io.File
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Map
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.huawei.hms.analytics.core.log.HiLog;
import java.io.File;
import java.util.Map;

public final class bu {
    private static SharedPreferences hij(Context context, String string2) {
        return context.getSharedPreferences(bu.lmn(context, string2), 0);
    }

    public static boolean ijk(Context context, String string2) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2)) {
            File file = context.getFilesDir();
            StringBuilder stringBuilder = new StringBuilder("../shared_prefs/");
            stringBuilder.append(string2);
            stringBuilder.append(".xml");
            File file2 = new File(file, stringBuilder.toString());
            return file2.exists() && file2.delete();
        }
        HiLog.w("SharedPreToolsKit", "deleteSPFile(): spName is empty,or context is null");
        return false;
    }

    public static long ikl(Context context, String string2) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2)) {
            File file = context.getFilesDir();
            StringBuilder stringBuilder = new StringBuilder("../shared_prefs/");
            stringBuilder.append(string2);
            stringBuilder.append(".xml");
            return new File(file, stringBuilder.toString()).length();
        }
        HiLog.w("SharedPreToolsKit", "deleteSPFile(): spName is empty,or context is null");
        return -1L;
    }

    public static long klm(Context context, String string2, String string3) {
        long l2 = -1L;
        if (context != null && !TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3)) {
            SharedPreferences sharedPreferences = bu.hij(context, string2);
            if (sharedPreferences != null) {
                l2 = sharedPreferences.getLong(string3, l2);
            }
            return l2;
        }
        HiLog.e("SharedPreToolsKit", "PE-001", "context is null or spName empty or spkey is empty");
        return l2;
    }

    public static String klm(Context context, String string2, String string3, String string4) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3)) {
            SharedPreferences sharedPreferences = bu.hij(context, string2);
            if (sharedPreferences != null) {
                string4 = sharedPreferences.getString(string3, string4);
            }
            return string4;
        }
        HiLog.e("SharedPreToolsKit", "PE-001", "context is null or spName empty or spkey is empty");
        return string4;
    }

    public static Map<String, ?> klm(Context context, String string2) {
        return bu.hij(context, string2).getAll();
    }

    public static boolean klm(Context context, String string2, String string3, boolean bl2) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3)) {
            SharedPreferences sharedPreferences = bu.hij(context, string2);
            if (sharedPreferences != null) {
                bl2 = sharedPreferences.getBoolean(string3, bl2);
            }
            return bl2;
        }
        HiLog.e("SharedPreToolsKit", "PE-001", "context is null or spName empty or spkey is empty");
        return bl2;
    }

    public static String lmn(Context context, String string2) {
        String string3 = context.getPackageName();
        StringBuilder stringBuilder = new StringBuilder("openness_");
        stringBuilder.append(string2);
        stringBuilder.append("_");
        stringBuilder.append(string3);
        return stringBuilder.toString();
    }

    public static void lmn(Context context, String string2, String string3, long l2) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3)) {
            SharedPreferences sharedPreferences = bu.hij(context, string2);
            if (sharedPreferences != null) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putLong(string3, l2);
                editor.commit();
            }
            return;
        }
        HiLog.e("SharedPreToolsKit", "PE-001", "context is null or spName empty or spkey is empty");
    }

    public static void lmn(Context context, String string2, String string3, String string4) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3)) {
            SharedPreferences sharedPreferences = bu.hij(context, string2);
            if (sharedPreferences != null) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(string3, string4);
                editor.commit();
            }
            return;
        }
        HiLog.e("SharedPreToolsKit", "PE-001", "context is null or spName empty or spkey is empty");
    }

    public static void lmn(Context context, String string2, String string3, boolean bl2) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3)) {
            SharedPreferences sharedPreferences = bu.hij(context, string2);
            if (sharedPreferences != null) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean(string3, bl2);
                editor.commit();
            }
            return;
        }
        HiLog.e("SharedPreToolsKit", "PE-001", "context is null or spName empty or spkey is empty");
    }

    public static /* varargs */ void lmn(Context context, String string2, String ... arrstring) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2)) {
            SharedPreferences sharedPreferences = bu.hij(context, string2);
            if (sharedPreferences != null) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                if (arrstring.length == 0) {
                    editor.clear();
                    editor.commit();
                    return;
                }
                for (String string3 : arrstring) {
                    if (!sharedPreferences.contains(string3)) continue;
                    editor.remove(string3);
                }
                editor.commit();
            }
            return;
        }
        HiLog.w("SharedPreToolsKit", "clearData(): parameter error.context,spname");
    }

    public static boolean lmn(Context context, String string2, String string3) {
        if (context != null && !TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3)) {
            SharedPreferences sharedPreferences = bu.hij(context, string2);
            if (sharedPreferences != null) {
                return sharedPreferences.contains(string3);
            }
            return false;
        }
        HiLog.e("SharedPreToolsKit", "PE-001", "context is null or spName empty or spkey is empty");
        return false;
    }
}

