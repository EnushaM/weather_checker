/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  j
 *  j$.util.concurrent.ConcurrentHashMap
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.text.TextUtils;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ac;
import com.huawei.hms.analytics.ap;
import com.huawei.hms.analytics.bu;
import com.huawei.hms.analytics.core.crypto.AesCipher;
import com.huawei.hms.analytics.core.log.HiLog;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public final class aa {
    private static aa ijk = new aa();
    private Map<String, ac> hij = new j.ConcurrentHashMap();
    public JSONObject ikl;
    public ab klm = new ab();
    public final Object lmn = new Object();

    private JSONObject ikl() {
        String string2 = ap.lmn().klm();
        String string3 = bu.klm(this.klm.bcd, "global_v2", "common_prop", "");
        if (TextUtils.isEmpty((CharSequence)string3)) {
            HiLog.i("DataCommander", "commonprop is empty");
            return null;
        }
        String string4 = AesCipher.decryptCbc(string3, string2);
        if (TextUtils.isEmpty((CharSequence)string4)) {
            HiLog.i("DataCommander", "userproperties is error");
            bu.lmn(this.klm.bcd, "global_v2", new String[]{"common_prop"});
            return null;
        }
        try {
            JSONObject jSONObject = new JSONObject(string4);
            return jSONObject;
        }
        catch (JSONException jSONException) {
            HiLog.i("DataCommander", "cache user properties is no json");
            return null;
        }
    }

    private boolean ikl(String string2) {
        JSONObject jSONObject = this.ikl;
        if (jSONObject == null) {
            return false;
        }
        if (jSONObject.has(string2)) {
            return true;
        }
        int n2 = this.ikl.length();
        HiLog.i("DataCommander", "propSize\uff1a".concat(String.valueOf((int)n2)));
        return n2 < 25;
    }

    private void klm(String string2) {
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            String string3 = AesCipher.encryptCbc(string2, ap.lmn().klm());
            bu.lmn(this.klm.bcd, "global_v2", "common_prop", string3);
        }
    }

    private void klm(String string2, String string3) {
        if (this.ikl != null && this.ikl(string2)) {
            if (string3 == null) {
                if (this.ikl.remove(string2) == null) {
                    HiLog.w("DataCommander", "the key doesn't exists ");
                    return;
                }
                HiLog.i("DataCommander", "delete the key ");
            } else {
                this.ikl.put(string2, (Object)string3);
            }
            this.klm(this.ikl.toString());
            return;
        }
        HiLog.w("DataCommander", "PE-005", "Too many userProperty parameters. Max number of parameters is 25.");
    }

    public static aa lmn() {
        return ijk;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final JSONObject klm() {
        Object object;
        Object object2 = object = this.lmn;
        synchronized (object2) {
            if (this.ikl != null) return this.ikl;
            this.ikl = this.ikl();
            return this.ikl;
        }
    }

    public final ac lmn(String string2) {
        return (ac)this.hij.get((Object)string2);
    }

    public final void lmn(String string2, ac ac2) {
        this.hij.put((Object)string2, (Object)ac2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final void lmn(String string2, String string3) {
        Object object;
        Object object2 = object = this.lmn;
        // MONITORENTER : object2
        if (this.ikl == null) {
            JSONObject jSONObject;
            this.ikl = jSONObject = this.ikl();
            if (jSONObject == null) {
                JSONObject jSONObject2;
                this.ikl = jSONObject2 = new JSONObject();
                if (string3 == null) {
                    HiLog.w("DataCommander", "the key doesn't exists ");
                    // MONITOREXIT : object2
                    return;
                }
                jSONObject2.put(string2, (Object)string3);
                this.klm(this.ikl.toString());
                return;
            }
        }
        this.klm(string2, string3);
        // MONITOREXIT : object2
    }
}

