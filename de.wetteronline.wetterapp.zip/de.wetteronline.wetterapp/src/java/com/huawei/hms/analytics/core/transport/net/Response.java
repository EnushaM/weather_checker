/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics.core.transport.net;

public class Response {
    private String content;
    private int httpCode;

    public Response(int n2, String string2) {
        this.httpCode = n2;
        this.content = string2;
    }

    public String getContent() {
        return this.content;
    }

    public int getHttpCode() {
        return this.httpCode;
    }

    public void setContent(String string2) {
        this.content = string2;
    }

    public void setHttpCode(int n2) {
        this.httpCode = n2;
    }
}

