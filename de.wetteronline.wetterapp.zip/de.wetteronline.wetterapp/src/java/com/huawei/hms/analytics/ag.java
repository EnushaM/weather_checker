/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  androidx.appcompat.app.n
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.SafeVarargs
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kt.e
 *  mt.a
 *  org.greenrobot.greendao.AbstractDao
 *  org.greenrobot.greendao.database.b
 *  ot.a
 */
package com.huawei.hms.analytics;

import android.text.TextUtils;
import androidx.appcompat.app.n;
import com.huawei.hms.analytics.core.log.HiLog;
import java.util.ArrayList;
import java.util.List;
import kt.e;
import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.database.b;
import ot.a;

public final class ag {
    @SafeVarargs
    public static /* varargs */ void klm(mt.a a2, Class<? extends AbstractDao<?, ?>> ... arrclass) {
        for (int i2 = 0; i2 <= 0; ++i2) {
            String string2 = new a((mt.a)a2, arrclass[0]).c;
            String string3 = n.a((String)string2, (String)"_TEMP");
            StringBuilder stringBuilder = new StringBuilder("ALTER TABLE ");
            stringBuilder.append(string2);
            stringBuilder.append(" RENAME TO ");
            stringBuilder.append(string3);
            String string4 = stringBuilder.toString();
            ((b)a2).o(string4);
        }
    }

    /*
     * Exception decompiling
     */
    private static List<String> lmn(mt.a var0, String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl48 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @SafeVarargs
    public static /* varargs */ void lmn(mt.a a2, Class<? extends AbstractDao<?, ?>> ... arrclass) {
        int n2 = 0;
        block2 : while (n2 <= 0) {
            a a3 = new a(a2, arrclass[n2]);
            String string2 = a3.c;
            String string3 = n.a((String)string2, (String)"_TEMP");
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            int n3 = a3.d.length;
            int n4 = 0;
            do {
                block14 : {
                    String string4;
                    String string5;
                    block10 : {
                        block11 : {
                            block12 : {
                                block13 : {
                                    if (n4 >= n3) break block13;
                                    string4 = a3.d[n4].e;
                                    if (ag.lmn(a2, string3).contains((Object)string4)) {
                                        arrayList.add((Object)string4);
                                        arrayList2.add((Object)string4);
                                    } else {
                                        try {
                                            Class class_ = a3.d[n4].b;
                                            boolean bl2 = class_.equals(String.class);
                                            if (bl2) {
                                                string5 = "TEXT";
                                                break block10;
                                            }
                                            if (class_.equals(Long.class) || class_.equals(Integer.class) || class_.equals((Object)Long.TYPE) || class_.equals((Object)Integer.TYPE)) break block11;
                                            if (!class_.equals(Boolean.class) && !class_.equals((Object)Boolean.TYPE)) {
                                                StringBuilder stringBuilder = new StringBuilder("Migration Helper ");
                                                stringBuilder.append(class_.toString());
                                                stringBuilder.append("does not match current parameter");
                                                throw new Exception(stringBuilder.toString());
                                            }
                                            break block12;
                                        }
                                        catch (Exception exception) {
                                            HiLog.w("MigrationDB", exception.getMessage());
                                        }
                                    }
                                    break block14;
                                }
                                StringBuilder stringBuilder = new StringBuilder("INSERT INTO ");
                                stringBuilder.append(string2);
                                stringBuilder.append(" (");
                                stringBuilder.append(TextUtils.join((CharSequence)",", (Iterable)arrayList));
                                stringBuilder.append(") SELECT ");
                                stringBuilder.append(TextUtils.join((CharSequence)",", (Iterable)arrayList2));
                                stringBuilder.append(" FROM ");
                                stringBuilder.append(string3);
                                stringBuilder.append(";");
                                String string6 = stringBuilder.toString();
                                b b3 = (b)a2;
                                b3.o(string6);
                                b3.o("DROP TABLE ".concat(String.valueOf((Object)string3)));
                                ++n2;
                                continue block2;
                            }
                            string5 = "BOOLEAN";
                            break block10;
                        }
                        string5 = "INTEGER";
                    }
                    if (string5.equals((Object)"INTEGER")) {
                        arrayList2.add((Object)"0 as ".concat(String.valueOf((Object)string4)));
                        arrayList.add((Object)string4);
                    }
                }
                ++n4;
            } while (true);
            break;
        }
        return;
    }
}

