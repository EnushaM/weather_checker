/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.analytics;

import android.os.Bundle;
import com.huawei.hms.analytics.core.log.HiLog;

public final class ay {
    private final Bundle lmn;

    public ay(Bundle bundle) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        this.lmn = bundle;
    }

    public final String klm(String string2) {
        try {
            String string3 = this.lmn.getString(string2);
            return string3;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder("getString exception: ");
            stringBuilder.append(exception.getMessage());
            HiLog.e("SafeParams", stringBuilder.toString());
            return "";
        }
    }

    public final Bundle lmn(String string2) {
        Bundle bundle;
        block2 : {
            try {
                bundle = this.lmn.getBundle(string2);
                if (bundle != null) break block2;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder("getBundle exception: ");
                stringBuilder.append(exception.getMessage());
                HiLog.e("SafeParams", stringBuilder.toString());
                return new Bundle();
            }
            bundle = new Bundle();
        }
        return bundle;
    }
}

