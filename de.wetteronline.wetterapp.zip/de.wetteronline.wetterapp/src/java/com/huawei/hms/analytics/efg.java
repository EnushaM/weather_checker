/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.Map
 */
package com.huawei.hms.analytics;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.fgh;
import java.util.Map;

public class efg
implements Application.ActivityLifecycleCallbacks {
    public static efg lmn;
    private Runnable fgh;
    private Handler ghi = new Handler(Looper.myLooper());
    private boolean hij = true;
    private boolean ijk = false;
    public ah ikl;
    public boolean klm = true;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static efg lmn() {
        Class<efg> class_ = efg.class;
        synchronized (efg.class) {
            if (lmn == null) {
                lmn = new efg();
            }
            // ** MonitorExit[var1] (shouldn't be in output)
            return lmn;
        }
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
        Runnable runnable;
        HiLog.i("LifecycleRingback", "onActivityPaused called.");
        this.hij = true;
        Runnable runnable2 = this.fgh;
        if (runnable2 != null) {
            this.ghi.removeCallbacks(runnable2);
        }
        final long l2 = System.currentTimeMillis();
        Handler handler = this.ghi;
        this.fgh = runnable = new Runnable(){

            public final void run() {
                if (efg.this.ijk && efg.this.hij) {
                    efg.this.ijk = false;
                    StringBuilder stringBuilder = new StringBuilder("Background. Pause time: ");
                    stringBuilder.append(l2);
                    HiLog.i("LifecycleRingback", stringBuilder.toString());
                    efg.this.ikl.klm(l2);
                    efg efg2 = efg.this;
                    if (efg2.klm) {
                        efg2.ikl.lmn();
                        return;
                    }
                } else {
                    HiLog.i("LifecycleRingback", "still foreground");
                }
            }
        };
        handler.postDelayed(runnable, 200L);
        if (!aa.lmn().klm.abc) {
            HiLog.w("LifecycleRingback", "auto collect is closed");
            return;
        }
        fgh fgh2 = fgh.lmn();
        HiLog.d("ActivityStatCommander", "onScreenExitDelayed with time: ".concat(String.valueOf((long)l2)));
        fgh2.ghi = true;
        fgh2.fgh.postDelayed(new Runnable(fgh2, activity, l2){
            public final /* synthetic */ fgh ikl;
            public final /* synthetic */ long klm;
            public final /* synthetic */ Activity lmn;
            {
                this.ikl = fgh2;
                this.lmn = activity;
                this.klm = l2;
            }

            public final void run() {
                if (fgh.klm(this.ikl)) {
                    HiLog.i("ActivityStatCommander", "isExitDelayed = true");
                    this.ikl.lmn(this.klm);
                }
            }
        }, 100L);
    }

    public void onActivityResumed(Activity activity) {
        HiLog.i("LifecycleRingback", "onActivityResumed called.");
        long l2 = System.currentTimeMillis();
        this.hij = false;
        boolean bl2 = true ^ this.ijk;
        this.ijk = true;
        Runnable runnable = this.fgh;
        if (runnable != null) {
            this.ghi.removeCallbacks(runnable);
        }
        long l3 = System.currentTimeMillis();
        if (bl2) {
            HiLog.i("LifecycleRingback", "foreground. Resume time: ".concat(String.valueOf((long)l3)));
            this.ikl.lmn(l3);
        } else {
            HiLog.i("LifecycleRingback", "still foreground.");
        }
        if (!aa.lmn().klm.abc) {
            HiLog.w("LifecycleRingback", "auto collect is closed");
            return;
        }
        String string2 = activity.getClass().getCanonicalName();
        fgh fgh2 = fgh.lmn();
        Bundle bundle = new Bundle();
        HiLog.d("ActivityStatCommander", "onScreenEnterDelayed with time: ".concat(String.valueOf((long)l2)));
        String string3 = activity.getClass().getCanonicalName();
        String string4 = String.valueOf((int)activity.getTaskId());
        fgh.lmn lmn2 = new fgh.lmn(string2, string3, string4, l2);
        fgh2.hij = true;
        Handler handler = fgh2.fgh;
        Runnable runnable2 = new Runnable(fgh2, activity, lmn2, bundle, l2){
            public final /* synthetic */ fgh hij;
            public final /* synthetic */ long ijk;
            public final /* synthetic */ Bundle ikl;
            public final /* synthetic */ fgh.lmn klm;
            public final /* synthetic */ Activity lmn;
            {
                this.hij = fgh2;
                this.lmn = activity;
                this.klm = lmn2;
                this.ikl = bundle;
                this.ijk = l2;
            }

            public final void run() {
                if (fgh.lmn(this.hij)) {
                    HiLog.i("ActivityStatCommander", "isEnterDelayed = true, no override screen event...");
                    fgh.lmn(this.hij, this.klm, this.ikl, this.ijk);
                }
            }
        };
        handler.postDelayed(runnable2, 100L);
        fgh2.ikl.clear();
        fgh2.ijk = null;
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity) {
    }

    public void onActivityStopped(Activity activity) {
    }

}

