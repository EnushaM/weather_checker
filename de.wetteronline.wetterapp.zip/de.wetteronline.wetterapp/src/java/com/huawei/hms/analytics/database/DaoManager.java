/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteDatabase$CursorFactory
 *  java.lang.Class
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Map
 *  mt.a
 *  nt.c
 *  org.greenrobot.greendao.database.a
 *  ot.a
 */
package com.huawei.hms.analytics.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import com.huawei.hms.analytics.ag;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.database.APIEventDao;
import com.huawei.hms.analytics.database.DaoSession;
import com.huawei.hms.analytics.database.EventDao;
import java.util.Map;
import nt.c;
import org.greenrobot.greendao.database.b;
import ot.a;

public class DaoManager
extends kt.b {
    public static final int SCHEMA_VERSION = 2;

    public DaoManager(SQLiteDatabase sQLiteDatabase) {
        this(new b(sQLiteDatabase));
    }

    public DaoManager(mt.a a2) {
        super(a2, 2);
        this.registerDaoClass(APIEventDao.class);
        this.registerDaoClass(EventDao.class);
    }

    public static void createAPIEventTable(mt.a a2, boolean bl2) {
        APIEventDao.createTable(a2, bl2);
    }

    public static void createAllTables(mt.a a2, boolean bl2) {
        APIEventDao.createTable(a2, bl2);
        EventDao.createTable(a2, bl2);
    }

    public static void createEventTable(mt.a a2, boolean bl2) {
        EventDao.createTable(a2, bl2);
    }

    public static void dropAllTables(mt.a a2, boolean bl2) {
        APIEventDao.dropTable(a2, bl2);
        EventDao.dropTable(a2, bl2);
    }

    public static DaoSession newDevSession(Context context, String string) {
        return new DaoManager(new klm(context, string){

            public final void onUpgrade(mt.a a2, int n2, int n3) {
                StringBuilder stringBuilder = new StringBuilder("Upgrading schema from version ");
                stringBuilder.append(n2);
                stringBuilder.append(" to ");
                stringBuilder.append(n3);
                stringBuilder.append(" by dropping all tables");
                HiLog.i("greenDAO", stringBuilder.toString());
                Class[] arrclass = new Class[]{EventDao.class};
                ag.klm(a2, arrclass);
                DaoManager.createEventTable(a2, false);
                ag.lmn(a2, arrclass);
            }
        }.getWritableDb()).newSession();
    }

    @Override
    public DaoSession newSession() {
        return new DaoSession(this.db, c.b, this.daoConfigMap);
    }

    @Override
    public DaoSession newSession(c c3) {
        return new DaoSession(this.db, c3, this.daoConfigMap);
    }

    public static abstract class klm
    extends org.greenrobot.greendao.database.a {
        public klm(Context context, String string) {
            super(context, string, 2);
        }

        public klm(Context context, String string, byte by) {
            super(context, string, null, 2);
        }

        public void onCreate(mt.a a2) {
            HiLog.i("greenDAO", "Creating tables for schema version 2");
            DaoManager.createAllTables(a2, false);
        }
    }

}

