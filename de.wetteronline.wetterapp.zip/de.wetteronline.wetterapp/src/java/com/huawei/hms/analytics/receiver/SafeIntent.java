/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  java.lang.Exception
 *  java.lang.String
 */
package com.huawei.hms.analytics.receiver;

import android.content.Intent;
import android.os.Bundle;

public class SafeIntent
extends Intent {
    public SafeIntent(Intent intent) {
        if (intent == null) {
            intent = new Intent();
        }
        super(intent);
    }

    public String getAction() {
        try {
            String string2 = super.getAction();
            if (string2 == null) {
                return "";
            }
            return string2;
        }
        catch (Exception exception) {
            return "";
        }
    }

    public Bundle getExtras() {
        Bundle bundle;
        block2 : {
            try {
                bundle = super.getExtras();
                if (bundle != null) break block2;
            }
            catch (Exception exception) {
                return new Bundle();
            }
            bundle = new Bundle();
        }
        return bundle;
    }
}

