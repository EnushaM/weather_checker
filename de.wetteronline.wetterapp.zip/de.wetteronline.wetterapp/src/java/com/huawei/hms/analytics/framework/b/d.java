/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.huawei.hms.analytics.framework.b;

import com.huawei.hms.analytics.core.crypto.HexUtil;
import com.huawei.hms.analytics.core.crypto.RsaCipher;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.framework.b.b;
import com.huawei.hms.analytics.framework.config.IMandatoryParameters;

public final class d {
    private static d b = new d();
    public a a = new a();

    public static /* synthetic */ a a(d d2) {
        return d2.a;
    }

    public static d a() {
        return b;
    }

    private void a(byte[] arrby, String string2, String string3, String string4, long l2) {
        this.a.c(string2);
        this.a.a(arrby);
        this.a.b(string3);
        this.a.a(string4);
        this.a.a(l2);
    }

    private static byte[] c() {
        return b.a().a.getRsaPublicKey();
    }

    public final void b() {
        long l2 = this.a.d;
        String string2 = b.a().a.getPubKeyVersion();
        if (l2 == 0L) {
            long l3 = System.currentTimeMillis();
            byte[] arrby = d.c();
            if (arrby != null && arrby.length != 0) {
                String string3 = HexUtil.initRandomKey(16);
                this.a(arrby, string2, RsaCipher.encrypt(arrby, string3), string3, l3);
                return;
            }
            HiLog.w("WorkKeyCommander", "get rsa pubkey config error");
            return;
        }
        if (!string2.equals((Object)this.a.e)) {
            byte[] arrby = d.c();
            String string4 = HexUtil.initRandomKey(16);
            this.a(arrby, string2, RsaCipher.encrypt(arrby, string4), string4, System.currentTimeMillis());
            return;
        }
        long l4 = System.currentTimeMillis();
        if (l4 - l2 > 43200000L) {
            byte[] arrby = this.a.a;
            String string5 = HexUtil.initRandomKey(16);
            this.a(arrby, string2, RsaCipher.encrypt(arrby, string5), string5, l4);
        }
    }

    public final class a {
        public byte[] a;
        public String b;
        public String c;
        public long d = 0L;
        public String e;

        public final void a(long l2) {
            d.a((d)d.this).d = l2;
        }

        public final void a(String string2) {
            d.a((d)d.this).b = string2;
        }

        public final void a(byte[] arrby) {
            d.a((d)d.this).a = (byte[])arrby.clone();
        }

        public final void b(String string2) {
            d.a((d)d.this).c = string2;
        }

        public final void c(String string2) {
            d.a((d)d.this).e = string2;
        }
    }

}

