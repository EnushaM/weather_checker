/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics.framework;

import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.framework.HAFrameworkInstance;
import com.huawei.hms.analytics.framework.b.c;
import com.huawei.hms.analytics.framework.config.ICallback;
import com.huawei.hms.analytics.framework.e.b;
import java.util.List;
import org.json.JSONObject;

public final class a
implements HAFrameworkInstance {
    private String a;

    public a(String string) {
        this.a = string;
    }

    @Override
    public final void clearCacheData(String string) {
        com.huawei.hms.analytics.framework.d.a.a().a(this.a, string);
    }

    @Override
    public final void onBackground(long l4) {
        b b2 = com.huawei.hms.analytics.framework.e.a.a().a(this.a);
        b2.c = true;
        b2.d = l4;
    }

    @Override
    public final void onEvent(String string, List<JSONObject> list, ICallback iCallback) {
        com.huawei.hms.analytics.framework.d.a.a().a(this.a, string, list, iCallback);
    }

    @Override
    public final void onEvent(List<Event> list, ICallback iCallback) {
        com.huawei.hms.analytics.framework.d.a.a().a(list, iCallback);
    }

    @Override
    public final void onForeground(long l4) {
        b b2 = com.huawei.hms.analytics.framework.e.a.a().a(this.a);
        if (b2.d == 0L) {
            HiLog.w("SessionKeeper", "OnBackground() need to be called before!");
            return;
        }
        boolean bl2 = l4 - b2.d > b2.b;
        b2.c = bl2;
        b2.d = 0L;
    }

    @Override
    public final void onReport(String string, ICallback iCallback) {
        com.huawei.hms.analytics.framework.d.a.a();
        com.huawei.hms.analytics.framework.d.a.a(this.a, string, iCallback);
    }

    @Override
    public final void onStreamEvent(String string, List<JSONObject> list, ICallback iCallback) {
        com.huawei.hms.analytics.framework.d.a.a();
        com.huawei.hms.analytics.framework.d.a.b(this.a, string, list, iCallback);
    }

    @Override
    public final void setMinSessionDuration(long l4) {
        com.huawei.hms.analytics.framework.e.a.a().a((String)this.a).b = l4;
    }

    @Override
    public final void setNeedRefreshSession(boolean bl2) {
        String string = this.a;
        c c3 = com.huawei.hms.analytics.framework.b.b.a().b(string);
        if (c3 != null) {
            c3.a = bl2;
        }
    }

    @Override
    public final void setSessionTimeoutDuration(long l4) {
        com.huawei.hms.analytics.framework.e.a.a().a((String)this.a).a = l4;
    }
}

