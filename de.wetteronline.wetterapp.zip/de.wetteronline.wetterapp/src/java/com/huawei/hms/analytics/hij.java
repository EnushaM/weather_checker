/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IInterface
 *  java.lang.Object
 *  java.util.List
 */
package com.huawei.hms.analytics;

import android.os.IInterface;
import com.huawei.hms.analytics.CustomEvent;
import java.util.List;

public interface hij
extends IInterface {
    public int lmn(List<CustomEvent> var1);
}

