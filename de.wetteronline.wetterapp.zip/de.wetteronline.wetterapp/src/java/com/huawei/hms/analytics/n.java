/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.os.IBinder;

interface n {
    public void lmn(IBinder var1);

    public void lmn(String var1);
}

