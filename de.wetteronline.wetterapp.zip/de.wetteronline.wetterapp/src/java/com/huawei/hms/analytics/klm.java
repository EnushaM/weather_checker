/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ac;
import com.huawei.hms.analytics.af;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.aj;
import com.huawei.hms.analytics.as;
import com.huawei.hms.analytics.av;
import com.huawei.hms.analytics.aw;
import com.huawei.hms.analytics.bg;
import com.huawei.hms.analytics.bp;
import com.huawei.hms.analytics.br;
import com.huawei.hms.analytics.bt;
import com.huawei.hms.analytics.core.storage.Event;
import com.huawei.hms.analytics.core.storage.IStorageHandler;
import com.huawei.hms.analytics.framework.HAFrameworkInstance;
import com.huawei.hms.analytics.framework.config.ICallback;
import com.huawei.hms.analytics.framework.config.ICollectorConfig;
import com.huawei.hms.analytics.framework.config.IMandatoryParameters;
import com.huawei.hms.analytics.framework.config.RomAttributeCollector;
import com.huawei.hms.analytics.framework.policy.IStoragePolicy;
import d5.z;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public abstract class klm
implements ah {
    public boolean ghi = false;
    public String hij;
    public Context ijk;
    public aj ikl;
    public HAFrameworkInstance.Builder klm;
    public HAFrameworkInstance lmn;

    public klm(Context context, String string) {
        HAFrameworkInstance.Builder builder;
        this.ijk = context;
        this.hij = string;
        this.ikl = aj.lmn(context);
        this.ghi = aa.lmn().klm.abc;
        this.klm = builder = new HAFrameworkInstance.Builder();
        builder.setStorageHandler(af.lmn(context)).setStoragePolicy(new aw(string)).setCollectorConfig(new as(string)).setMandatoryParameters(new av());
    }

    private ac klm() {
        ac ac2 = aa.lmn().lmn(this.hij);
        if (ac2 == null) {
            ac2 = new ac();
            aa.lmn().lmn(this.hij, ac2);
        }
        return ac2;
    }

    @Override
    public final void ikl(List<Event> list) {
        this.lmn.onEvent(list, new bg());
    }

    @Override
    public final void klm(long l4) {
        this.lmn.onBackground(l4);
    }

    public final void klm(String string, bt bt2) {
        aj.klm().lmn(this.hij, "oper", string, bt2.lmn);
        aj.lmn().lmn(string, bt2.lmn);
        bg bg2 = new bg();
        bg2.lmn = true;
        this.lmn.onStreamEvent("oper", (List<JSONObject>)bt2.klm, bg2);
    }

    @Override
    public final void klm(List<JSONObject> list) {
        this.lmn.onEvent("oper", list, new bg());
    }

    public final void klm(boolean bl2) {
        this.klm().lmn = bl2;
    }

    public Map<String, String> lmn(boolean bl2) {
        Map<String, String> map;
        block1 : {
            JSONObject jSONObject;
            block2 : {
                block0 : {
                    map = new Map<String, String>();
                    if (!bl2) break block0;
                    RomAttributeCollector romAttributeCollector = new as(this.hij).getRomAttribute("oper");
                    if (romAttributeCollector == null) break block1;
                    jSONObject = romAttributeCollector.doCollector();
                    break block2;
                }
                jSONObject = aa.lmn().klm();
            }
            map = bp.lmn(jSONObject);
        }
        return map;
    }

    @Override
    public final void lmn() {
        this.lmn.onReport("oper", new bg());
    }

    @Override
    public final void lmn(long l4) {
        this.lmn.onForeground(l4);
    }

    public final void lmn(String string) {
        if (!TextUtils.isEmpty((CharSequence)string)) {
            HashMap hashMap;
            this.klm().klm = hashMap = z.a("ha-sdk-service", string);
        }
    }

    /*
     * Exception decompiling
     */
    public final void lmn(String var1, bt var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl121 : ALOAD_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public final void lmn(String string, bt bt2, long l4) {
        if (br.ikl(this.ijk)) {
            aj.klm().lmn(this.hij, "oper", string, bt2.lmn, l4);
            aj.lmn().lmn(string, bt2.lmn);
            this.lmn.onStreamEvent("oper", (List<JSONObject>)bt2.klm, new bg());
            return;
        }
        aj.klm().lmn(this.hij, "oper", string, bt2.lmn);
        aj.lmn().lmn(string, bt2.lmn);
        this.lmn.onEvent("oper", (List<JSONObject>)bt2.klm, new bg());
    }

    @Override
    public final void lmn(List<JSONObject> list) {
        this.lmn.onStreamEvent("oper", list, new bg());
    }
}

