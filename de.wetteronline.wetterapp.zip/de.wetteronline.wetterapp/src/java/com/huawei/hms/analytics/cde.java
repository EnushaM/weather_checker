/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.ServiceConnection
 *  android.os.IBinder
 *  android.os.RemoteException
 *  android.text.TextUtils
 *  com.huawei.hms.analytics.ghi$lmn
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.TextUtils;
import com.huawei.hms.analytics.UploadInfo;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.az;
import com.huawei.hms.analytics.bj;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.ghi;
import com.huawei.hms.analytics.hij;

public final class cde
implements ServiceConnection {
    private az.lmn klm;
    private hij lmn;

    public cde(hij hij2, az.lmn lmn2) {
        this.lmn = hij2;
        this.klm = lmn2;
    }

    public final void onBindingDied(ComponentName componentName) {
        HiLog.e("HAServiceInteraction", "onBindingDied");
        aa.lmn().klm.d = false;
    }

    public final void onNullBinding(ComponentName componentName) {
        az.lmn lmn2 = this.klm;
        if (lmn2 != null) {
            lmn2.lmn("1");
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        HiLog.i("HAServiceInteraction", "onServiceConnected");
        az.lmn lmn2 = this.klm;
        if (lmn2 != null) {
            lmn2.lmn();
        }
        ab ab2 = aa.lmn().klm;
        ab2.d = true;
        ghi ghi2 = ghi.lmn.lmn((IBinder)iBinder);
        try {
            UploadInfo uploadInfo = new UploadInfo();
            uploadInfo.lmn = ab2.bcd.getPackageName();
            uploadInfo.klm = bj.lmn().ikl;
            uploadInfo.lmn(ab2.lmn());
            if (!TextUtils.isEmpty((CharSequence)uploadInfo.klm) && !TextUtils.isEmpty((CharSequence)uploadInfo.lmn) && uploadInfo.lmn().length > 0) {
                HiLog.i("HAServiceInteraction", "Upload info is correct");
                ghi2.lmn(this.lmn, uploadInfo);
                return;
            }
            HiLog.w("HAServiceInteraction", "Upload info is not correct");
            return;
        }
        catch (RuntimeException throwable2) {
            String string2;
            block5 : {
                string2 = "registerCallback RuntimeException";
                break block5;
                catch (RemoteException throwable2) {
                    string2 = "registerCallback RemoteException";
                }
            }
            HiLog.e("HAServiceInteraction", string2);
            return;
        }
    }

    public final void onServiceDisconnected(ComponentName componentName) {
        HiLog.e("HAServiceInteraction", "onServiceDisconnected");
        aa.lmn().klm.d = false;
        az.lmn lmn2 = this.klm;
        if (lmn2 != null) {
            lmn2.lmn("2");
        }
    }
}

