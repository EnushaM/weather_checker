/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 */
package com.huawei.hms.analytics;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class z {
    private static final String[] ijk;
    private static final String[] ikl;
    public static final List<String> klm;
    public static final List<String> lmn;

    public static {
        Object[] arrobject = new String[]{"$HA_NOTIFICATION_DISPLAY", "$DisplayNotification", "$HA_NOTIFICATION_CLICK", "$ClickNotification", "$HA_NOTIFICATION_CLEAR", "$ClearNotification", "$HA_APP_INSTALL", "$InstallApp", "$HA_APP_START", "$LaunchApp", "$HA_APP_UPDATE", "$UpdateApp", "$HA_FIRST_OPEN", "$AppFirstOpen", "$HA_SCREEN_ENTER", "$EnterScreen", "$HA_SCREEN_EXIT", "$ExitScreen", "$HA_CLEAR_DATA", "$ClearData", "$HA_CLEAR_CACHE", "$ClearCache", "$HA_APP_UNINSTALL", "$UninstallApp", "$InAppPurchase", "$RequestAd", "$DisplayAd", "$ClickAd", "$ObtainAdAward", "$StopAnalyticsCollection"};
        ikl = arrobject;
        Object[] arrobject2 = new String[]{"$OpenAppFromAppLinking", "$UpdateFromAppLinking", "$ReOpenAppFromAppLinking", "$DisplayAppMessaging", "$DismissInAppMessage", "$ClickInAppMessage"};
        ijk = arrobject2;
        lmn = Collections.unmodifiableList((List)Arrays.asList((Object[])arrobject));
        klm = Collections.unmodifiableList((List)Arrays.asList((Object[])arrobject2));
    }
}

