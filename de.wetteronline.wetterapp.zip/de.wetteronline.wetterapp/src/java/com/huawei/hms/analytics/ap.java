/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.text.TextUtils;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.an;
import com.huawei.hms.analytics.ao;
import com.huawei.hms.analytics.bu;
import com.huawei.hms.analytics.core.crypto.AesCipher;
import com.huawei.hms.analytics.core.crypto.HexUtil;
import com.huawei.hms.analytics.core.crypto.PBKDF2encrypt;
import com.huawei.hms.analytics.core.log.HiLog;

public final class ap {
    private static final Object ikl;
    private static final Object klm;
    private static ap lmn;
    private String hij;
    private String ijk;

    public static {
        klm = new Object();
        ikl = new Object();
    }

    private static boolean fgh() {
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String ghi() {
        if (TextUtils.isEmpty((CharSequence)this.ijk)) {
            Object object;
            Object object2 = object = ikl;
            synchronized (object2) {
                if (TextUtils.isEmpty((CharSequence)this.ijk)) {
                    String string2;
                    String string3;
                    String string4;
                    String string5;
                    ao ao2 = new ao();
                    long l2 = bu.klm(ao2.lmn, "Privacy_MY", "assemblyFlash");
                    long l3 = -1L LCMP l2;
                    int n2 = 0;
                    boolean bl2 = true;
                    if (l3 == false) {
                        HiLog.i("ComponentCommander", "First init components");
                    } else if (System.currentTimeMillis() - l2 <= 31536000000L) {
                        bl2 = false;
                    }
                    if (bl2) {
                        HiLog.i("ComponentCommander", "refresh components");
                        string3 = HexUtil.initRandomKey(128);
                        ao2.lmn("aprpap", string3);
                        string5 = HexUtil.initRandomKey(128);
                        ao2.lmn("febdoc", string5);
                        string2 = HexUtil.initRandomKey(128);
                        ao2.lmn("marfil", string2);
                        string4 = HexUtil.initRandomKey(128);
                        ao2.lmn("maywnj", string4);
                        bu.lmn(ao2.lmn, "Privacy_MY", "assemblyFlash", System.currentTimeMillis());
                    } else {
                        string3 = ao2.lmn("aprpap");
                        string5 = ao2.lmn("febdoc");
                        string2 = ao2.lmn("marfil");
                        string4 = ao2.lmn("maywnj");
                    }
                    byte[] arrby = HexUtil.hexString2ByteArray(string3);
                    byte[] arrby2 = HexUtil.hexString2ByteArray(string5);
                    byte[] arrby3 = HexUtil.hexString2ByteArray(string2);
                    byte[] arrby4 = HexUtil.hexString2ByteArray("f6040d0e807aaec325ecf44823765544e92905158169f694b282bf17388632cf95a83bae7d2d235c1f039b0df1dcca5fda619b6f7f459f2ff8d70ddb7b601592fe29fcae58c028f319b3b12495e67aa5390942a997a8cb572c8030b2df5c2b622608bea02b0c3e5d4dff3f72c9e3204049a45c0760cd3604af8d57f0e0c693cc");
                    int n3 = arrby.length;
                    if (n3 > arrby2.length) {
                        n3 = arrby2.length;
                    }
                    if (n3 > arrby3.length) {
                        n3 = arrby3.length;
                    }
                    if (n3 > arrby4.length) {
                        n3 = arrby4.length;
                    }
                    char[] arrc = new char[n3];
                    while (n2 < n3) {
                        arrc[n2] = (char)(arrby[n2] ^ arrby2[n2] ^ arrby3[n2] ^ arrby4[n2]);
                        ++n2;
                    }
                    this.ijk = HexUtil.byteArray2HexString(PBKDF2encrypt.pbkdf2(arrc, HexUtil.hexString2ByteArray(string4), 10000, 128));
                }
            }
        }
        return this.ijk;
    }

    private static void hij() {
        Class<ap> class_ = ap.class;
        synchronized (ap.class) {
            if (lmn == null) {
                lmn = new ap();
            }
            // ** MonitorExit[var1] (shouldn't be in output)
            return;
        }
    }

    public static boolean ikl() {
        long l2 = bu.klm(aa.lmn().klm.bcd, "Privacy_MY", "flashKeyTime");
        return System.currentTimeMillis() - l2 > 31536000000L;
    }

    private String klm(String string2) {
        if (ap.fgh()) {
            HiLog.i("RootKeyCommander", "load work key encrypt is gcm ks");
            return an.lmn("analytics_keystore", string2);
        }
        return AesCipher.encryptCbc(string2, this.ghi());
    }

    public static ap lmn() {
        if (lmn == null) {
            ap.hij();
        }
        return lmn;
    }

    private static void lmn(String string2) {
        ab ab2 = aa.lmn().klm;
        bu.lmn(ab2.bcd, "Privacy_MY", "PrivacyData", string2);
        bu.lmn(ab2.bcd, "Privacy_MY", "flashKeyTime", System.currentTimeMillis());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void ijk() {
        Object object;
        Object object2 = object = klm;
        synchronized (object2) {
            String string2;
            this.hij = string2 = HexUtil.initRandomKey(16);
            ap.lmn(this.klm(string2));
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final String klm() {
        Object object;
        Object object2 = object = klm;
        synchronized (object2) {
            block6 : {
                String string2;
                block8 : {
                    String string3;
                    block9 : {
                        block11 : {
                            block10 : {
                                String string4;
                                block7 : {
                                    if (!TextUtils.isEmpty((CharSequence)this.hij) || !TextUtils.isEmpty((CharSequence)this.hij)) break block6;
                                    string4 = bu.klm(aa.lmn().klm.bcd, "Privacy_MY", "PrivacyData", "");
                                    if (!TextUtils.isEmpty((CharSequence)string4)) break block7;
                                    string2 = HexUtil.initRandomKey(16);
                                    ap.lmn(this.klm(string2));
                                    break block8;
                                }
                                string3 = "";
                                if (ap.fgh()) {
                                    string3 = AesCipher.gcmDecrypt(an.lmn("analytics_keystore"), string4);
                                }
                                if (!TextUtils.isEmpty((CharSequence)string3)) break block9;
                                HiLog.i("RootKeyCommander", "deCrypt work key first");
                                string2 = AesCipher.decryptCbc(string4, this.ghi());
                                if (!TextUtils.isEmpty((CharSequence)string2)) break block10;
                                string2 = HexUtil.initRandomKey(16);
                                ap.lmn(this.klm(string2));
                                if (!ap.fgh()) break block8;
                                break block11;
                            }
                            if (!ap.fgh()) break block8;
                            ap.lmn(this.klm(string2));
                        }
                        ao.lmn();
                        break block8;
                    }
                    string2 = string3;
                }
                this.hij = string2;
            }
            return this.hij;
        }
    }
}

