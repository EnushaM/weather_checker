/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

public interface d {
    public void lmn(String var1);

    public void lmn(String var1, long var2);
}

