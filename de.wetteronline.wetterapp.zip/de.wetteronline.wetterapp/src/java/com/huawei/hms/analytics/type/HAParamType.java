/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics.type;

public interface HAParamType {
    public static final String ACHIEVEMENTID = "$AchievementId";
    public static final String ACOUNTTYPE = "$AcountType";
    public static final String BEGINDATE = "$BeginDate";
    public static final String BOOKINGDAYS = "$BookingDays";
    public static final String BOOKINGROOMS = "$BookingRooms";
    public static final String BRAND = "$Brand";
    public static final String CATEGORY = "$Category";
    public static final String CHANNEL = "$Channel";
    public static final String CLASS = "$Class";
    public static final String CLICKID = "$ClickId";
    public static final String COMMENTTYPE = "$CommentType";
    public static final String CONTENT = "$Content";
    public static final String CONTENTTYPE = "$ContentType";
    public static final String CURRNAME = "$CurrName";
    public static final String CURRVLEVEL = "$CurrvLevel";
    public static final String DESTINATION = "$Destination";
    public static final String DETAILS = "$Details";
    public static final String DURATION = "$Duration";
    public static final String ENDDATE = "$EndDate";
    public static final String ENTRY = "$Entry";
    public static final String EVTRESULT = "$EvtResult";
    public static final String EXPIREDATE = "$ExpireDate";
    public static final String EXTENDPARAM = "$ExtendParam";
    public static final String FILTERS = "$Filters";
    public static final String FLIGHTNO = "$FlightNo";
    public static final String KEYWORDS = "$Keywords";
    public static final String LEVEL = "$Level";
    public static final String LEVELID = "$LevelId";
    public static final String LEVELNAME = "$LevelName";
    public static final String LISTID = "$ListId";
    public static final String MATERIALNAME = "$MaterialName";
    public static final String MATERIALSLOT = "$MaterialSlot";
    public static final String MATERIALSLOTTYPE = "$MaterialSlotType";
    public static final String MEDIUM = "$Medium";
    public static final String OCCURREDTIME = "$OccurredTime";
    public static final String OPTION = "$Option";
    public static final String ORDERID = "$OrderId";
    public static final String ORIGINATINGPLACE = "$OriginatingPlace";
    public static final String PASSENGERSNUMBER = "$PassengersNumber";
    public static final String PAYTYPE = "$PayType";
    public static final String PLACE = "$Place";
    public static final String PLACEID = "$PlaceId";
    public static final String POSITIONID = "$PositionId";
    public static final String PREVLEVEL = "$PrevLevel";
    public static final String PRICE = "$Price";
    public static final String PRODUCTFEATURE = "$ProductFeature";
    public static final String PRODUCTID = "$ProductId";
    public static final String PRODUCTLIST = "$ProductList";
    public static final String PRODUCTNAME = "$ProductName";
    public static final String PROMOTIONNAME = "$PromotionName";
    public static final String PROPS = "$Props";
    public static final String PURCHASEENTRY = "$PurchaseEntry";
    public static final String QUANTITY = "$Quantity";
    public static final String REASON = "$Reason";
    public static final String REGISTMETHOD = "$RegistMethod";
    public static final String RESULT = "$Result";
    public static final String REVENUE = "$Revenue";
    public static final String ROLENAME = "$RoleName";
    public static final String SCORE = "$Score";
    public static final String SEARCHKEYWORDS = "$SearchKeywords";
    public static final String SERVICETYPE = "$ServiceType";
    public static final String SHIPPING = "$Shipping";
    public static final String SORTS = "$Sorts";
    public static final String SOURCE = "$Source";
    public static final String STEP = "$Step";
    public static final String STORENAME = "$StoreName";
    public static final String TAXFEE = "$TaxFee";
    public static final String TRANSACTIONID = "$TransactionId";
    public static final String USERGROUPID = "$UserGroupId";
    public static final String VIRTUALCURRNAME = "$VirtualCurrName";
    public static final String VOUCHER = "$Voucher";
    public static final String VOUCHERS = "$Vouchers";
    public static final String VOUCHERTYPE = "$VoucherType";
}

