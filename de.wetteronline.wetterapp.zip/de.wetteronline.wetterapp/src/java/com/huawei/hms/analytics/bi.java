/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 */
package com.huawei.hms.analytics;

import com.huawei.hms.analytics.core.log.HiLog;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class bi {
    private static bi ikl;
    private static bi klm;
    private static bi lmn;
    private ThreadPoolExecutor ijk;

    public static {
        lmn = new bi(3);
        klm = new bi(3);
        ikl = new bi(1);
    }

    private bi(int n2) {
        ThreadPoolExecutor threadPoolExecutor;
        LinkedBlockingQueue linkedBlockingQueue = new LinkedBlockingQueue(5000);
        this.ijk = threadPoolExecutor = new ThreadPoolExecutor(0, n2, 60000L, TimeUnit.MILLISECONDS, (BlockingQueue)linkedBlockingQueue);
    }

    public static bi ikl() {
        return ikl;
    }

    public static bi klm() {
        return klm;
    }

    public static bi lmn() {
        return lmn;
    }

    public final void lmn(Runnable runnable) {
        try {
            this.ijk.execute((Runnable)new lmn(runnable));
            return;
        }
        catch (RejectedExecutionException rejectedExecutionException) {
            HiLog.w("ThreadStock", "addToQueue() Exception has happened!Form rejected execution");
            return;
        }
    }

    public static final class lmn
    implements Runnable {
        private Runnable lmn;

        public lmn(Runnable runnable) {
            this.lmn = runnable;
        }

        public final void run() {
            Runnable runnable = this.lmn;
            if (runnable != null) {
                try {
                    runnable.run();
                    return;
                }
                catch (Throwable throwable) {
                    StringBuilder stringBuilder = new StringBuilder("InnerTask : Error has happened,From internal operations!");
                    stringBuilder.append(throwable.getMessage());
                    HiLog.w("ThreadStock", stringBuilder.toString());
                    return;
                }
                catch (Exception exception) {
                    StringBuilder stringBuilder = new StringBuilder("InnerTask : Exception has happened,From internal operations!");
                    stringBuilder.append(exception.getMessage());
                    HiLog.w("ThreadStock", stringBuilder.toString());
                }
            }
        }
    }

}

