/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.content.Context;
import com.huawei.hms.analytics.f;
import com.huawei.hms.api.Api;
import com.huawei.hms.common.HuaweiApi;
import com.huawei.hms.common.internal.AbstractClientBuilder;

public final class g
extends HuaweiApi<Api.ApiOptions.NoOptions> {
    private static final f klm = new f();
    public Context lmn;

    public g(Context context) {
        super(context, new Api(""), new Api.ApiOptions.NotRequiredOptions(){}, (AbstractClientBuilder)klm);
        this.lmn = context;
    }
}

