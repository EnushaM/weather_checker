/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.CountDownLatch
 */
package com.huawei.hms.analytics;

import java.util.concurrent.CountDownLatch;

public final class bw {
    private static boolean ikl;
    private static final CountDownLatch klm;
    private static final Object lmn;

    public static {
        lmn = new Object();
        klm = new CountDownLatch(1);
        ikl = false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void ikl() {
        Object object;
        Object object2 = object = lmn;
        synchronized (object2) {
            ikl = true;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean klm() {
        Object object;
        Object object2 = object = lmn;
        synchronized (object2) {
            return ikl;
        }
    }

    public static CountDownLatch lmn() {
        return klm;
    }
}

