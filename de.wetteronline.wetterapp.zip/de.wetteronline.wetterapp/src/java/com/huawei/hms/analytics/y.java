/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.regex.Pattern
 */
package com.huawei.hms.analytics;

import java.util.regex.Pattern;

public interface y {
    public static final Pattern ikl;
    public static final Pattern klm;
    public static final Pattern lmn;

    public static {
        lmn = Pattern.compile((String)"^[a-zA-Z0-9_-]+(\\s+[a-zA-Z0-9_-]+)*$");
        klm = Pattern.compile((String)"[a-zA-Z_][a-zA-Z0-9_]*|[\\$][a-zA-Z0-9]*");
        ikl = Pattern.compile((String)"[a-zA-Z][a-zA-Z0-9_]*|[\\$][a-zA-Z0-9]*");
    }
}

