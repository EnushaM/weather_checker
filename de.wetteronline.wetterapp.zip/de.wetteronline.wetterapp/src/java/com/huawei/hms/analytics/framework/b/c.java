/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  j
 *  j$.util.concurrent.ConcurrentHashMap
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.huawei.hms.analytics.framework.b;

import com.huawei.hms.analytics.core.storage.IStorageHandler;
import java.util.Map;

public final class c {
    public boolean a = false;
    public IStorageHandler b;
    private Map<String, Long> c = new j.ConcurrentHashMap();

    public final long a(String string2) {
        Long l2 = (Long)this.c.get((Object)string2);
        if (l2 != null) {
            return l2;
        }
        return 0L;
    }

    public final void a(String string2, long l2) {
        this.c.put((Object)string2, (Object)l2);
    }
}

