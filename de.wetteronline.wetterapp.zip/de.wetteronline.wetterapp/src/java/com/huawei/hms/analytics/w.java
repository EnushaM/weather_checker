/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.IBinder
 *  android.text.TextUtils
 *  com.huawei.hms.analytics.q
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.os.IBinder;
import android.text.TextUtils;
import com.huawei.hms.analytics.a;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.q;
import java.lang.reflect.Method;

public final class w
extends q {
    public w(Context context, a.lmn lmn2) {
        super(context, lmn2);
    }

    private String klm() {
        Object object;
        block3 : {
            try {
                Class class_ = Class.forName((String)"com.android.id.impl.IdProviderImpl");
                Object object2 = class_.newInstance();
                Method method = class_.getMethod("getOAID", new Class[]{Context.class});
                Object[] arrobject = new Object[]{this.ikl};
                object = method.invoke(object2, arrobject);
                if (object != null) break block3;
                return "";
            }
            catch (Exception exception) {
                HiLog.w("miOaid", "invoke Exception");
                return "";
            }
        }
        String string = (String)object;
        return string;
    }

    public final void lmn() {
        String string = this.klm();
        if (TextUtils.isEmpty((CharSequence)string)) {
            super.lmn("id is empty, begin get gaid");
            return;
        }
        this.klm.lmn(string, "");
    }

    public final void lmn(IBinder iBinder) {
    }

    public final void lmn(String string) {
        super.lmn(string);
    }
}

