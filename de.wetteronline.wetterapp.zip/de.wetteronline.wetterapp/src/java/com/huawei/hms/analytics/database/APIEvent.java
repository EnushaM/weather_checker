/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.LinkedHashMap
 *  java.util.Map
 */
package com.huawei.hms.analytics.database;

import java.util.LinkedHashMap;
import java.util.Map;

public class APIEvent {
    private String code;
    private String costTime;
    private String errorCode;
    private String eventCnt;
    private String eventId;
    private Long id;
    private String name;
    private String result;
    private String timestamp;
    private String type;

    public APIEvent() {
    }

    public APIEvent(Long l2, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10) {
        this.id = l2;
        this.code = string2;
        this.timestamp = string3;
        this.type = string4;
        this.name = string5;
        this.result = string6;
        this.errorCode = string7;
        this.eventId = string8;
        this.eventCnt = string9;
        this.costTime = string10;
    }

    public APIEvent(String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10) {
        this.code = string2;
        this.timestamp = string3;
        this.type = string4;
        this.name = string5;
        this.result = string6;
        this.errorCode = string7;
        this.eventId = string8;
        this.eventCnt = string9;
        this.costTime = string10;
    }

    public String getCode() {
        return this.code;
    }

    public String getCostTime() {
        return this.costTime;
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public String getEventCnt() {
        return this.eventCnt;
    }

    public String getEventId() {
        return this.eventId;
    }

    public Long getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getResult() {
        return this.result;
    }

    public String getTimestamp() {
        return this.timestamp;
    }

    public String getType() {
        return this.type;
    }

    public void setCode(String string2) {
        this.code = string2;
    }

    public void setCostTime(String string2) {
        this.costTime = string2;
    }

    public void setErrorCode(String string2) {
        this.errorCode = string2;
    }

    public void setEventCnt(String string2) {
        this.eventCnt = string2;
    }

    public void setEventId(String string2) {
        this.eventId = string2;
    }

    public void setId(Long l2) {
        this.id = l2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setResult(String string2) {
        this.result = string2;
    }

    public void setTimestamp(String string2) {
        this.timestamp = string2;
    }

    public void setType(String string2) {
        this.type = string2;
    }

    public Map toMap() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put((Object)"id", (Object)this.code);
        linkedHashMap.put((Object)"timestamp", (Object)this.timestamp);
        linkedHashMap.put((Object)"api_type", (Object)this.type);
        linkedHashMap.put((Object)"api_name", (Object)this.name);
        linkedHashMap.put((Object)"result", (Object)this.result);
        linkedHashMap.put((Object)"error_code", (Object)this.errorCode);
        linkedHashMap.put((Object)"event_id", (Object)this.eventId);
        linkedHashMap.put((Object)"event_cnt", (Object)this.eventCnt);
        linkedHashMap.put((Object)"cost_time", (Object)this.costTime);
        return linkedHashMap;
    }
}

