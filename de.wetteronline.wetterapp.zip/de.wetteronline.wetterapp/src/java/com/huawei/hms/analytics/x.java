/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  com.huawei.hms.analytics.klm
 *  java.lang.String
 *  java.lang.System
 *  java.util.List
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.os.Bundle;
import com.huawei.hms.analytics.bn;
import com.huawei.hms.analytics.bt;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.framework.HAFrameworkInstance;
import com.huawei.hms.analytics.klm;
import com.huawei.hms.analytics.z;
import java.util.List;

public final class x
extends klm {
    public x(Context context, String string) {
        super(context, string);
        this.lmn = this.klm.build(string);
    }

    public final void lmn(String string, Bundle bundle) {
        if (!this.ghi) {
            HiLog.w("interactionInstance", "The Analytics Kit is disabled");
            return;
        }
        if (bn.lmn(string)) {
            bt bt2 = new bt(string, this.hij);
            if (!bt2.lmn(bundle)) {
                HiLog.w("interactionInstance", "PE-006", "bundle params is invalid.");
                return;
            }
            if (bn.lmn(string, z.klm)) {
                this.lmn(string, bt2, System.currentTimeMillis());
                return;
            }
            this.lmn(string, bt2);
        }
    }
}

