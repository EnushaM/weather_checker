/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.huawei.hms.analytics.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ah;
import com.huawei.hms.analytics.ay;
import com.huawei.hms.analytics.az;
import com.huawei.hms.analytics.ba;
import com.huawei.hms.analytics.bt;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.ijk;
import com.huawei.hms.analytics.receiver.SafeIntent;

public class HiAnalyticsSvcEvtReceiver
extends BroadcastReceiver {
    /*
     * Enabled aggressive block sorting
     */
    public void onReceive(Context context, Intent intent) {
        HiLog.i("HiAnalyticsSvcEvtAccepter", "onReceive is running");
        if (!aa.lmn().klm.abc) {
            HiLog.w("HiAnalyticsSvcEvtAccepter", "isAnalyticsEnabled is false");
            return;
        }
        if (context != null && intent != null) {
            if (aa.lmn().klm.bcd == null) {
                HiLog.w("SvcEvtReceiverHolder", "Check whether the SDK is initialized.");
                return;
            }
            SafeIntent safeIntent = new SafeIntent(intent);
            ay ay2 = new ay(safeIntent.getExtras());
            if (!"com.huawei.hms.analytics.pps.event".equals((Object)safeIntent.getAction())) {
                HiLog.w("SvcEvtReceiverHolder", "onReceive : event is not ads");
                return;
            }
            HiLog.i("SvcEvtReceiverHolder", "onReceive : event is ads");
            ay ay3 = new ay(ay2.lmn("event_detail"));
            String string2 = ay3.klm("event_type");
            boolean bl2 = TextUtils.isEmpty((CharSequence)string2);
            String string3 = "";
            if (bl2 || !"$RequestAd".equals((Object)string2) && !"$DisplayAd".equals((Object)string2) && !"$ClickAd".equals((Object)string2) && !"$ObtainAdAward".equals((Object)string2)) {
                string2 = string3;
            }
            String string4 = ay3.klm("package_name");
            az az2 = ba.lmn("SvcEvtReceiverHandler#handlerADSEvt(Bundle)");
            if (!TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string4)) {
                if (!string4.equals((Object)aa.lmn().klm.bcd.getPackageName())) {
                    HiLog.w("SvcEvtReceiverHolder", "3rd package names are not equal");
                    az2.ijk = string2;
                    ba.lmn(az2);
                    return;
                }
                Bundle bundle = new Bundle();
                String string5 = ay3.klm("slot_id");
                String string6 = ay3.klm("activity_name");
                String string7 = ay3.klm("sub_type");
                String.valueOf((long)System.currentTimeMillis());
                if (TextUtils.isEmpty((CharSequence)string5)) {
                    string5 = string3;
                }
                bundle.putString("$MaterialSlot", string5);
                if (TextUtils.isEmpty((CharSequence)string6)) {
                    string6 = string3;
                }
                bundle.putString("$CurActivityName", string6);
                bundle.putString("$EvtType", "Supplier");
                if (!TextUtils.isEmpty((CharSequence)string7)) {
                    string3 = string7;
                }
                bundle.putString("$AdReqType", string3);
                HiLog.i("SvcEvtReceiverHolder", "start onEvent");
                ah ah2 = ijk.lmn().lmn("_openness_config_tag");
                if (ah2 != null) {
                    ah2.lmn(string2, new bt(string2, bundle), System.currentTimeMillis());
                }
                az2.ijk = string2;
                az2.lmn = "0";
                ba.lmn(az2);
                return;
            }
            HiLog.w("SvcEvtReceiverHolder", "event_type or package_name is empty");
            az2.ijk = string2;
            ba.lmn(az2);
            return;
        }
        HiLog.e("SvcEvtReceiverHolder", "context or intent is null");
    }
}

