/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteStatement
 *  java.lang.Class
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  mt.a
 *  mt.b
 *  ot.a
 */
package com.huawei.hms.analytics.database;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import com.huawei.hms.analytics.database.APIEvent;
import com.huawei.hms.analytics.database.DaoSession;
import kt.c;
import kt.e;
import org.greenrobot.greendao.database.b;
import ot.a;

public class APIEventDao
extends kt.a<APIEvent, Long> {
    public static final String TABLENAME = "APIEVENT";

    public APIEventDao(a a2) {
        super(a2);
    }

    public APIEventDao(a a2, DaoSession daoSession) {
        super(a2, daoSession);
    }

    public static void createTable(mt.a a2, boolean bl2) {
        String string = bl2 ? "IF NOT EXISTS " : "";
        StringBuilder stringBuilder = new StringBuilder("CREATE TABLE ");
        stringBuilder.append(string);
        stringBuilder.append("\"APIEVENT\" (\"_id\" INTEGER PRIMARY KEY AUTOINCREMENT ,\"CODE\" TEXT,\"TIMESTAMP\" TEXT,\"TYPE\" TEXT,\"NAME\" TEXT,\"RESULT\" TEXT,\"ERROR_CODE\" TEXT,\"EVENT_ID\" TEXT,\"EVENT_CNT\" TEXT,\"COST_TIME\" TEXT);");
        String string2 = stringBuilder.toString();
        ((b)a2).o(string2);
    }

    public static void dropTable(mt.a a2, boolean bl2) {
        StringBuilder stringBuilder = new StringBuilder("DROP TABLE ");
        String string = bl2 ? "IF EXISTS " : "";
        String string2 = b2.a.a(stringBuilder, string, "\"APIEVENT\"");
        ((b)a2).o(string2);
    }

    @Override
    public final void bindValues(SQLiteStatement sQLiteStatement, APIEvent aPIEvent) {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        String string6;
        String string7;
        String string8;
        String string9;
        sQLiteStatement.clearBindings();
        Long l4 = aPIEvent.getId();
        if (l4 != null) {
            sQLiteStatement.bindLong(1, l4.longValue());
        }
        if ((string5 = aPIEvent.getCode()) != null) {
            sQLiteStatement.bindString(2, string5);
        }
        if ((string9 = aPIEvent.getTimestamp()) != null) {
            sQLiteStatement.bindString(3, string9);
        }
        if ((string = aPIEvent.getType()) != null) {
            sQLiteStatement.bindString(4, string);
        }
        if ((string7 = aPIEvent.getName()) != null) {
            sQLiteStatement.bindString(5, string7);
        }
        if ((string4 = aPIEvent.getResult()) != null) {
            sQLiteStatement.bindString(6, string4);
        }
        if ((string2 = aPIEvent.getErrorCode()) != null) {
            sQLiteStatement.bindString(7, string2);
        }
        if ((string3 = aPIEvent.getEventId()) != null) {
            sQLiteStatement.bindString(8, string3);
        }
        if ((string8 = aPIEvent.getEventCnt()) != null) {
            sQLiteStatement.bindString(9, string8);
        }
        if ((string6 = aPIEvent.getCostTime()) != null) {
            sQLiteStatement.bindString(10, string6);
        }
    }

    @Override
    public final void bindValues(mt.b b2, APIEvent aPIEvent) {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        String string6;
        String string7;
        String string8;
        String string9;
        b b3 = (b)b2;
        b3.g();
        Long l4 = aPIEvent.getId();
        if (l4 != null) {
            b3.c(1, l4);
        }
        if ((string9 = aPIEvent.getCode()) != null) {
            b3.e(2, string9);
        }
        if ((string = aPIEvent.getTimestamp()) != null) {
            b3.e(3, string);
        }
        if ((string7 = aPIEvent.getType()) != null) {
            b3.e(4, string7);
        }
        if ((string5 = aPIEvent.getName()) != null) {
            b3.e(5, string5);
        }
        if ((string2 = aPIEvent.getResult()) != null) {
            b3.e(6, string2);
        }
        if ((string4 = aPIEvent.getErrorCode()) != null) {
            b3.e(7, string4);
        }
        if ((string8 = aPIEvent.getEventId()) != null) {
            b3.e(8, string8);
        }
        if ((string6 = aPIEvent.getEventCnt()) != null) {
            b3.e(9, string6);
        }
        if ((string3 = aPIEvent.getCostTime()) != null) {
            b3.e(10, string3);
        }
    }

    @Override
    public Long getKey(APIEvent aPIEvent) {
        if (aPIEvent != null) {
            return aPIEvent.getId();
        }
        return null;
    }

    @Override
    public boolean hasKey(APIEvent aPIEvent) {
        return aPIEvent.getId() != null;
    }

    @Override
    public final boolean isEntityUpdateable() {
        return true;
    }

    @Override
    public APIEvent readEntity(Cursor cursor, int n2) {
        int n3 = n2 + 0;
        Long l4 = cursor.isNull(n3) ? null : Long.valueOf((long)cursor.getLong(n3));
        int n4 = n2 + 1;
        String string = cursor.isNull(n4) ? null : cursor.getString(n4);
        int n5 = n2 + 2;
        String string2 = cursor.isNull(n5) ? null : cursor.getString(n5);
        int n6 = n2 + 3;
        String string3 = cursor.isNull(n6) ? null : cursor.getString(n6);
        int n7 = n2 + 4;
        String string4 = cursor.isNull(n7) ? null : cursor.getString(n7);
        int n8 = n2 + 5;
        String string5 = cursor.isNull(n8) ? null : cursor.getString(n8);
        int n9 = n2 + 6;
        String string6 = cursor.isNull(n9) ? null : cursor.getString(n9);
        int n10 = n2 + 7;
        String string7 = cursor.isNull(n10) ? null : cursor.getString(n10);
        int n11 = n2 + 8;
        String string8 = cursor.isNull(n11) ? null : cursor.getString(n11);
        int n12 = n2 + 9;
        String string9 = cursor.isNull(n12) ? null : cursor.getString(n12);
        APIEvent aPIEvent = new APIEvent(l4, string, string2, string3, string4, string5, string6, string7, string8, string9);
        return aPIEvent;
    }

    @Override
    public void readEntity(Cursor cursor, APIEvent aPIEvent, int n2) {
        int n3 = n2 + 0;
        Long l4 = cursor.isNull(n3) ? null : Long.valueOf((long)cursor.getLong(n3));
        aPIEvent.setId(l4);
        int n4 = n2 + 1;
        String string = cursor.isNull(n4) ? null : cursor.getString(n4);
        aPIEvent.setCode(string);
        int n5 = n2 + 2;
        String string2 = cursor.isNull(n5) ? null : cursor.getString(n5);
        aPIEvent.setTimestamp(string2);
        int n6 = n2 + 3;
        String string3 = cursor.isNull(n6) ? null : cursor.getString(n6);
        aPIEvent.setType(string3);
        int n7 = n2 + 4;
        String string4 = cursor.isNull(n7) ? null : cursor.getString(n7);
        aPIEvent.setName(string4);
        int n8 = n2 + 5;
        String string5 = cursor.isNull(n8) ? null : cursor.getString(n8);
        aPIEvent.setResult(string5);
        int n9 = n2 + 6;
        String string6 = cursor.isNull(n9) ? null : cursor.getString(n9);
        aPIEvent.setErrorCode(string6);
        int n10 = n2 + 7;
        String string7 = cursor.isNull(n10) ? null : cursor.getString(n10);
        aPIEvent.setEventId(string7);
        int n11 = n2 + 8;
        String string8 = cursor.isNull(n11) ? null : cursor.getString(n11);
        aPIEvent.setEventCnt(string8);
        int n12 = n2 + 9;
        String string9 = cursor.isNull(n12) ? null : cursor.getString(n12);
        aPIEvent.setCostTime(string9);
    }

    @Override
    public Long readKey(Cursor cursor, int n2) {
        int n3 = n2 + 0;
        if (cursor.isNull(n3)) {
            return null;
        }
        return cursor.getLong(n3);
    }

    @Override
    public final Long updateKeyAfterInsert(APIEvent aPIEvent, long l4) {
        aPIEvent.setId(l4);
        return l4;
    }

}

