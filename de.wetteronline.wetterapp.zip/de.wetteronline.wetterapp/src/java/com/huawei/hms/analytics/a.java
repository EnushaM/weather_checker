/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

public interface a {

    public static interface lmn {
        public void lmn(String var1, String var2);
    }

}

