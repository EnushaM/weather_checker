/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.IBinder
 *  android.text.TextUtils
 *  com.huawei.hms.analytics.o
 *  com.huawei.hms.analytics.q
 *  com.huawei.hms.analytics.t
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.content.Context;
import android.os.IBinder;
import android.text.TextUtils;
import com.huawei.hms.analytics.a;
import com.huawei.hms.analytics.n;
import com.huawei.hms.analytics.o;
import com.huawei.hms.analytics.q;
import com.huawei.hms.analytics.t;

public final class p
extends q {
    public o lmn = null;

    public p(Context context, a.lmn lmn2) {
        super(context, lmn2);
        this.lmn = new o(context, "com.uodis.opendevice.OPENIDS_SERVICE", "com.huawei.hwid", (n)((Object)this));
    }

    public final void lmn() {
        try {
            this.lmn.lmn();
            return;
        }
        catch (Exception exception) {
            super.lmn("getOaid,bindService error, begin get gaid");
            return;
        }
    }

    public final void lmn(IBinder iBinder) {
        t t2 = new t("com.uodis.opendevice.aidl.OpenDeviceIdentifierService", iBinder);
        String string = t2.lmn();
        if (!TextUtils.isEmpty((CharSequence)string)) {
            boolean bl = t2.klm();
            this.klm.lmn(string, String.valueOf((boolean)(bl ^ true)));
            return;
        }
        throw new IllegalArgumentException("oaid is mepty");
    }

    public final void lmn(String string) {
        super.lmn(string);
    }
}

