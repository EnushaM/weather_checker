/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.huawei.hms.analytics.framework.a;

import com.huawei.hms.analytics.core.storage.IStorageHandler;
import com.huawei.hms.analytics.framework.b.b;
import com.huawei.hms.analytics.framework.b.c;
import com.huawei.hms.analytics.framework.policy.IStoragePolicy;
import java.util.Map;

public final class a {
    public static IStorageHandler a(String string2) {
        c c2 = b.a().b(string2);
        if (c2 != null) {
            return c2.b;
        }
        return null;
    }

    public static IStoragePolicy b(String string2) {
        com.huawei.hms.analytics.framework.b.a a2 = (com.huawei.hms.analytics.framework.b.a)b.a().b.get((Object)string2);
        if (a2 != null) {
            return a2.b;
        }
        return null;
    }
}

