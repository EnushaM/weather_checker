/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.analytics;

import android.os.Build;
import com.huawei.hms.analytics.aa;
import com.huawei.hms.analytics.ab;
import com.huawei.hms.analytics.ap;
import com.huawei.hms.analytics.bl;
import com.huawei.hms.analytics.core.log.HiLog;
import com.huawei.hms.analytics.core.transport.ITransportHandler;
import com.huawei.hms.analytics.framework.config.CipherType;
import com.huawei.hms.analytics.framework.config.IMandatoryParameters;

public final class av
implements IMandatoryParameters {
    @Override
    public final String getAppVer() {
        return aa.lmn().klm.ikl;
    }

    @Override
    public final String getCaCertificatePath() {
        return "/assets/hianalyticscas.bks";
    }

    @Override
    public final CipherType getCipherType() {
        return CipherType.AESGCM;
    }

    @Override
    public final String getLoadWorkKey() {
        return ap.lmn().klm();
    }

    @Override
    public final String getModel() {
        return Build.MODEL;
    }

    @Override
    public final ITransportHandler.Protocols getProtocols() {
        if (Build.VERSION.SDK_INT >= 29) {
            return ITransportHandler.Protocols.TLS1_3;
        }
        return ITransportHandler.Protocols.TLS1_2;
    }

    @Override
    public final String getPubKeyVersion() {
        return aa.lmn().klm.l;
    }

    @Override
    public final byte[] getRsaPublicKey() {
        String string = aa.lmn().klm.k;
        if (string != null && !string.isEmpty()) {
            byte[] arrby = new byte[]{};
            try {
                byte[] arrby2 = bl.lmn(string);
                return arrby2;
            }
            catch (Exception exception) {
                HiLog.e("OpennessDutyParams", "decode failed");
                return arrby;
            }
        }
        return new byte[0];
    }

    @Override
    public final boolean isGCMParameterSpec() {
        return true;
    }

    @Override
    public final boolean isHighCipher() {
        return true;
    }
}

