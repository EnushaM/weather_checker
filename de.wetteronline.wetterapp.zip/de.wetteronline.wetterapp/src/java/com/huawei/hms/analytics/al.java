/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.json.JSONObject
 */
package com.huawei.hms.analytics;

import java.util.List;
import org.json.JSONObject;

public interface al {
    public void klm(String var1, List<JSONObject> var2);

    public String lmn(String var1);

    public void lmn(String var1, List<JSONObject> var2);
}

