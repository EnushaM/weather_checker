/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  java.io.UnsupportedEncodingException
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 */
package com.huawei.hms.analytics;

import android.text.TextUtils;
import com.huawei.hms.analytics.core.log.HiLog;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class bq {
    private static final String[] lmn = new String[]{"SHA-256", "SHA-384", "SHA-512"};

    public static String lmn(String string2) {
        return bq.lmn(string2, "SHA-256");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static String lmn(String string2, String string3) {
        String string4;
        int n2;
        block13 : {
            String string5;
            block12 : {
                boolean bl2;
                block10 : {
                    block11 : {
                        if (!TextUtils.isEmpty((CharSequence)string2) && !TextUtils.isEmpty((CharSequence)string3)) break block11;
                        string5 = "content or algorithm is null.";
                        break block12;
                    }
                    String[] arrstring = lmn;
                    int n3 = arrstring.length;
                    n2 = 0;
                    for (int i2 = 0; i2 < n3; ++i2) {
                        if (!arrstring[i2].equals((Object)string3)) continue;
                        bl2 = true;
                        break block10;
                    }
                    bl2 = false;
                }
                if (bl2) break block13;
                string5 = "algorithm is not safe or legal";
            }
            HiLog.e("SHA", string5);
            return "";
        }
        try {
            MessageDigest messageDigest = MessageDigest.getInstance((String)string3);
            messageDigest.update(string2.getBytes("UTF-8"));
            byte[] arrby = messageDigest.digest();
            if (arrby == null) return "";
            if (arrby.length == 0) return "";
            StringBuilder stringBuilder = new StringBuilder();
            while (n2 < arrby.length) {
                String string6 = Integer.toHexString((int)(255 & arrby[n2]));
                if (string6.length() == 1) {
                    stringBuilder.append('0');
                }
                stringBuilder.append(string6);
                ++n2;
            }
            return stringBuilder.toString();
        }
        catch (NoSuchAlgorithmException throwable) {
            string4 = "Error in generate SHA NoSuchAlgorithmException";
        }
        catch (UnsupportedEncodingException throwable) {
            string4 = "Error in generate SHA UnsupportedEncodingException";
        }
        HiLog.e("SHA", string4);
        return "";
    }
}

