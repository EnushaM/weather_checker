/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.support.v4.media.b
 *  android.text.TextUtils
 *  com.huawei.hms.support.log.HMSLog
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassCastException
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.Locale
 */
package com.huawei.hms.android;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.media.b;
import android.text.TextUtils;
import com.huawei.hms.android.HwBuildEx;
import com.huawei.hms.support.log.HMSLog;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

public class SystemUtils {
    public static String a() {
        return SystemUtils.getSystemProperties("ro.product.locale", "");
    }

    public static String b() {
        return SystemUtils.getSystemProperties("ro.product.locale.region", "");
    }

    public static String getLocalCountry() {
        Locale locale = Locale.getDefault();
        if (locale != null) {
            return locale.getCountry();
        }
        return "";
    }

    public static String getNetType(Context context) {
        NetworkInfo networkInfo;
        ConnectivityManager connectivityManager;
        if (context != null && (connectivityManager = (ConnectivityManager)context.getSystemService("connectivity")) != null && (networkInfo = connectivityManager.getActiveNetworkInfo()) != null && networkInfo.isAvailable()) {
            return networkInfo.getTypeName();
        }
        return "";
    }

    public static String getSystemProperties(String string2, String string3) {
        try {
            Class class_ = Class.forName((String)"android.os.SystemProperties");
            String string4 = (String)class_.getDeclaredMethod("get", new Class[]{String.class, String.class}).invoke((Object)class_, new Object[]{string2, string3});
            return string4;
        }
        catch (ClassCastException | ClassNotFoundException | IllegalAccessException | IllegalArgumentException | NoSuchMethodException | InvocationTargetException throwable) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("An exception occurred while reading: getSystemProperties:");
            stringBuilder.append(string2);
            HMSLog.e((String)"SystemUtils", (String)stringBuilder.toString());
            return string3;
        }
    }

    public static boolean isChinaROM() {
        String string2 = SystemUtils.b();
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            return "cn".equalsIgnoreCase(string2);
        }
        String string3 = SystemUtils.a();
        if (!TextUtils.isEmpty((CharSequence)string3)) {
            return string3.toLowerCase(Locale.US).contains((CharSequence)"cn");
        }
        String string4 = SystemUtils.getLocalCountry();
        if (!TextUtils.isEmpty((CharSequence)string4)) {
            return "cn".equalsIgnoreCase(string4);
        }
        return false;
    }

    public static boolean isEMUI() {
        StringBuilder stringBuilder = b.a((String)"is Emui :");
        int n2 = HwBuildEx.VERSION.EMUI_SDK_INT;
        stringBuilder.append(n2);
        HMSLog.i((String)"SystemUtils", (String)stringBuilder.toString());
        return n2 > 0;
    }

    public static boolean isSystemApp(Context context, String string2) {
        PackageInfo packageInfo;
        try {
            packageInfo = context.getPackageManager().getPackageInfo(string2, 16384);
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("isSystemApp Exception: ");
            stringBuilder.append((Object)nameNotFoundException);
            HMSLog.e((String)"SystemUtils", (String)stringBuilder.toString());
            packageInfo = null;
        }
        return packageInfo != null && (1 & packageInfo.applicationInfo.flags) > 0;
    }

    public static boolean isTVDevice() {
        return SystemUtils.getSystemProperties("ro.build.characteristics", "default").equalsIgnoreCase("tv");
    }
}

