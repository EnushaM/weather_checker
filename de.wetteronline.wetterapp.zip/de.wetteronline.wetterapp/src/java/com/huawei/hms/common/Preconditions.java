/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  android.text.TextUtils
 *  java.lang.AssertionError
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Locale
 *  java.util.Objects
 */
package com.huawei.hms.common;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import java.util.Locale;
import java.util.Objects;

public class Preconditions {
    public Preconditions() {
        throw new AssertionError((Object)"illegal Argument");
    }

    public static void checkArgument(boolean bl2) {
        if (bl2) {
            return;
        }
        throw new IllegalArgumentException();
    }

    public static void checkArgument(boolean bl2, Object object) {
        if (bl2) {
            return;
        }
        throw new IllegalArgumentException(String.valueOf((Object)object));
    }

    public static /* varargs */ void checkArgument(boolean bl2, String string2, Object ... arrobject) {
        if (bl2) {
            return;
        }
        throw new IllegalArgumentException(String.format((Locale)Locale.ROOT, (String)string2, (Object[])arrobject));
    }

    public static void checkHandlerThread(Handler handler) {
        if (Looper.myLooper() == handler.getLooper()) {
            return;
        }
        throw new IllegalStateException("The given thread is not the current thread.");
    }

    public static void checkMainThread(String string2) {
        if (Preconditions.isMainThread()) {
            return;
        }
        throw new IllegalStateException(string2);
    }

    public static String checkNotEmpty(String string2) {
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            return string2;
        }
        throw new IllegalArgumentException("The input parameter is empty.");
    }

    public static String checkNotEmpty(String string2, Object object) {
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            return string2;
        }
        throw new IllegalArgumentException(String.valueOf((Object)object));
    }

    public static void checkNotMainThread() {
        Preconditions.checkNotMainThread("The given thread is main thread.");
    }

    public static void checkNotMainThread(String string2) {
        if (!Preconditions.isMainThread()) {
            return;
        }
        throw new IllegalStateException(string2);
    }

    public static <T> T checkNotNull(T t2) {
        Objects.requireNonNull(t2, (String)"The input parameter is null.");
        return t2;
    }

    public static <T> T checkNotNull(T t2, Object object) {
        if (t2 != null) {
            return t2;
        }
        throw new NullPointerException(String.valueOf((Object)object));
    }

    public static int checkNotZero(int n2) {
        if (n2 != 0) {
            return n2;
        }
        throw new IllegalArgumentException("The input parameter is 0.");
    }

    public static int checkNotZero(int n2, Object object) {
        if (n2 != 0) {
            return n2;
        }
        throw new IllegalArgumentException(String.valueOf((Object)object));
    }

    public static long checkNotZero(long l2) {
        if (l2 != 0L) {
            return l2;
        }
        throw new IllegalArgumentException("The input parameter is 0.");
    }

    public static long checkNotZero(long l2, Object object) {
        if (l2 != 0L) {
            return l2;
        }
        throw new IllegalArgumentException(String.valueOf((Object)object));
    }

    public static void checkState(boolean bl2) {
        if (bl2) {
            return;
        }
        throw new IllegalStateException();
    }

    public static void checkState(boolean bl2, Object object) {
        if (bl2) {
            return;
        }
        throw new IllegalStateException(String.valueOf((Object)object));
    }

    public static /* varargs */ void checkState(boolean bl2, String string2, Object ... arrobject) {
        if (bl2) {
            return;
        }
        throw new IllegalStateException(String.format((Locale)Locale.ROOT, (String)string2, (Object[])arrobject));
    }

    public static boolean isMainThread() {
        return Looper.getMainLooper() == Looper.myLooper();
    }
}

