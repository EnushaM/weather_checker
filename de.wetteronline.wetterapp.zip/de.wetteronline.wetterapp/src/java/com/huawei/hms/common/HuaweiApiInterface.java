/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.common;

import com.huawei.hms.common.ApiException;

public interface HuaweiApiInterface {
    public void setInnerHms();

    public void setSubAppId(String var1) throws ApiException;
}

