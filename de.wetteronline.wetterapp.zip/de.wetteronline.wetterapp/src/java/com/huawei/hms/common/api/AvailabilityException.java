/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.huawei.hms.adapter.a
 *  com.huawei.hms.support.log.HMSLog
 *  java.lang.Exception
 *  java.lang.String
 */
package com.huawei.hms.common.api;

import android.content.Context;
import com.huawei.hms.adapter.a;
import com.huawei.hms.api.Api;
import com.huawei.hms.api.ConnectionResult;
import com.huawei.hms.api.HuaweiApiAvailability;
import com.huawei.hms.common.HuaweiApi;
import com.huawei.hms.common.api.HuaweiApiCallable;
import com.huawei.hms.support.log.HMSLog;

public class AvailabilityException
extends Exception {
    private String TAG = "AvailabilityException";
    private String message = null;

    private ConnectionResult generateConnectionResult(int n2) {
        a.a((String)"The availability check result is: ", (int)n2, (String)this.TAG);
        this.setMessage(n2);
        return new ConnectionResult(n2);
    }

    private void setMessage(int n2) {
        if (n2 != 21) {
            if (n2 != 0) {
                if (n2 != 1) {
                    if (n2 != 2) {
                        if (n2 != 3) {
                            this.message = "INTERNAL_ERROR";
                            return;
                        }
                        this.message = "SERVICE_DISABLED";
                        return;
                    }
                    this.message = "SERVICE_VERSION_UPDATE_REQUIRED";
                    return;
                }
                this.message = "SERVICE_MISSING";
                return;
            }
            this.message = "success";
            return;
        }
        this.message = "ANDROID_VERSION_UNSUPPORT";
    }

    public ConnectionResult getConnectionResult(HuaweiApi<? extends Api.ApiOptions> huaweiApi) {
        if (huaweiApi == null) {
            HMSLog.e((String)this.TAG, (String)"The huaweiApi is null.");
            return this.generateConnectionResult(8);
        }
        Context context = huaweiApi.getContext();
        return this.generateConnectionResult(HuaweiApiAvailability.getInstance().isHuaweiMobileServicesAvailable(context, 30000000));
    }

    public ConnectionResult getConnectionResult(HuaweiApiCallable huaweiApiCallable) {
        if (huaweiApiCallable != null && huaweiApiCallable.getHuaweiApi() != null) {
            Context context = huaweiApiCallable.getHuaweiApi().getContext();
            return this.generateConnectionResult(HuaweiApiAvailability.getInstance().isHuaweiMobileServicesAvailable(context, 30000000));
        }
        HMSLog.e((String)this.TAG, (String)"The huaweiApi is null.");
        return this.generateConnectionResult(8);
    }

    public String getMessage() {
        return this.message;
    }
}

