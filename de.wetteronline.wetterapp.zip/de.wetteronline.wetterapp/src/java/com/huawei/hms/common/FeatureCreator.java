/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.huawei.hms.common.Feature
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.common;

import android.os.Parcel;
import android.os.Parcelable;
import com.huawei.hms.common.Feature;
import com.huawei.hms.common.internal.safeparcel.SafeParcelReader;

public final class FeatureCreator
implements Parcelable.Creator<Feature> {
    public final Feature createFromParcel(Parcel parcel) {
        int n2 = SafeParcelReader.validateObjectHeader(parcel);
        long l2 = -1L;
        String string2 = null;
        int n3 = 0;
        for (int i2 = 0; i2 <= n2 && parcel.dataPosition() < n2; ++i2) {
            int n4 = SafeParcelReader.readHeader(parcel);
            int n5 = SafeParcelReader.getFieldId(n4);
            if (n5 != 1) {
                if (n5 != 2) {
                    if (n5 != 3) {
                        SafeParcelReader.skipUnknownField(parcel, n4);
                        continue;
                    }
                    l2 = SafeParcelReader.readLong(parcel, n4);
                    continue;
                }
                n3 = SafeParcelReader.readInt(parcel, n4);
                continue;
            }
            string2 = SafeParcelReader.createString(parcel, n4);
        }
        SafeParcelReader.ensureAtEnd(parcel, n2);
        return new Feature(string2, n3, l2);
    }

    public final Feature[] newArray(int n2) {
        return new Feature[n2];
    }
}

