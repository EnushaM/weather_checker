/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.huawei.hms.support.api.client.Status
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.common;

import com.huawei.hms.support.api.client.Status;

public class ApiException
extends Exception {
    public final Status mStatus;

    public ApiException(Status status) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(status.getStatusCode());
        stringBuilder.append(": ");
        String string2 = status.getStatusMessage() != null ? status.getStatusMessage() : "";
        stringBuilder.append(string2);
        super(stringBuilder.toString());
        this.mStatus = status;
    }

    public int getStatusCode() {
        return this.mStatus.getStatusCode();
    }

    @Deprecated
    public String getStatusMessage() {
        return this.mStatus.getStatusMessage();
    }
}

