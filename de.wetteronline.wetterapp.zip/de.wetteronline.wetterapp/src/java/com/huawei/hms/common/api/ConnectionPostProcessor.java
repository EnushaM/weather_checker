/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  com.huawei.hms.api.HuaweiApiClient
 *  java.lang.Object
 *  java.lang.ref.WeakReference
 */
package com.huawei.hms.common.api;

import android.app.Activity;
import com.huawei.hms.api.HuaweiApiClient;
import java.lang.ref.WeakReference;

public interface ConnectionPostProcessor {
    public void run(HuaweiApiClient var1, WeakReference<Activity> var2);
}

