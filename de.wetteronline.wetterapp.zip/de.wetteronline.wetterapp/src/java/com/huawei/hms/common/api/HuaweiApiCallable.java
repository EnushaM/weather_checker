/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.huawei.hms.common.api;

import com.huawei.hms.common.HuaweiApi;

public interface HuaweiApiCallable {
    public HuaweiApi getHuaweiApi();
}

