/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Looper
 *  android.support.v4.media.b
 *  android.text.TextUtils
 *  com.huawei.hms.common.internal.BaseHmsClient
 *  com.huawei.hms.common.internal.HuaweiApiManager$ConnectionManager
 *  com.huawei.hms.support.api.client.Status
 *  com.huawei.hms.support.api.client.SubAppInfo
 *  com.huawei.hms.support.api.entity.auth.Scope
 *  com.huawei.hms.support.hianalytics.b
 *  com.huawei.hms.support.log.HMSLog
 *  com.huawei.hms.utils.Checker
 *  com.huawei.hms.utils.HMSBIInitializer
 *  com.huawei.hms.utils.HMSPackageManager
 *  com.huawei.hms.utils.Util
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.ref.WeakReference
 *  java.util.Collections
 *  java.util.List
 *  je.a
 *  je.f
 *  je.g
 *  ke.e
 */
package com.huawei.hms.common;

import android.app.Activity;
import android.content.Context;
import android.os.Looper;
import android.support.v4.media.b;
import android.text.TextUtils;
import com.huawei.hms.api.Api;
import com.huawei.hms.common.ApiException;
import com.huawei.hms.common.internal.AbstractClientBuilder;
import com.huawei.hms.common.internal.AnyClient;
import com.huawei.hms.common.internal.BaseHmsClient;
import com.huawei.hms.common.internal.ClientSettings;
import com.huawei.hms.common.internal.ConnectionManagerKey;
import com.huawei.hms.common.internal.HuaweiApiManager;
import com.huawei.hms.common.internal.TaskApiCall;
import com.huawei.hms.support.api.client.Status;
import com.huawei.hms.support.api.client.SubAppInfo;
import com.huawei.hms.support.api.entity.auth.Scope;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.utils.Checker;
import com.huawei.hms.utils.HMSBIInitializer;
import com.huawei.hms.utils.HMSPackageManager;
import com.huawei.hms.utils.Util;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;
import je.a;
import je.f;
import je.g;
import ke.e;

public class HuaweiApi<TOption extends Api.ApiOptions> {
    private static final String TAG = "HuaweiApi";
    private int apiLevel = 1;
    private String innerHmsPkg;
    private boolean isFirstReqSent = false;
    private WeakReference<Activity> mActivity;
    private String mAppID;
    private AbstractClientBuilder<?, TOption> mClientBuilder;
    private ConnectionManagerKey<TOption> mConnectionManagerKey;
    private Context mContext;
    private String mHostAppid;
    private HuaweiApiManager mHuaweiApiManager;
    private int mKitSdkVersion;
    private TOption mOption;
    private SubAppInfo mSubAppInfo;

    public HuaweiApi(Activity activity, Api<TOption> api, TOption TOption, AbstractClientBuilder abstractClientBuilder) {
        Checker.checkNonNull((Object)activity, (String)"Null activity is not permitted.");
        this.mActivity = new WeakReference((Object)activity);
        this.init((Context)activity, api, TOption, abstractClientBuilder, 0, null);
    }

    public HuaweiApi(Activity activity, Api<TOption> api, TOption TOption, AbstractClientBuilder abstractClientBuilder, int n2) {
        Checker.checkNonNull((Object)activity, (String)"Null activity is not permitted.");
        this.mActivity = new WeakReference((Object)activity);
        this.init((Context)activity, api, TOption, abstractClientBuilder, n2, null);
    }

    public HuaweiApi(Activity activity, Api<TOption> api, TOption TOption, AbstractClientBuilder abstractClientBuilder, int n2, String string2) {
        Checker.checkNonNull((Object)activity, (String)"Null activity is not permitted.");
        this.mActivity = new WeakReference((Object)activity);
        this.init((Context)activity, api, TOption, abstractClientBuilder, n2, string2);
    }

    public HuaweiApi(Context context, Api<TOption> api, TOption TOption, AbstractClientBuilder abstractClientBuilder) {
        Checker.checkNonNull((Object)context, (String)"Null context is not permitted.");
        this.init(context, api, TOption, abstractClientBuilder, 0, null);
    }

    public HuaweiApi(Context context, Api<TOption> api, TOption TOption, AbstractClientBuilder abstractClientBuilder, int n2) {
        Checker.checkNonNull((Object)context, (String)"Null context is not permitted.");
        this.init(context, api, TOption, abstractClientBuilder, n2, null);
    }

    public HuaweiApi(Context context, Api<TOption> api, TOption TOption, AbstractClientBuilder abstractClientBuilder, int n2, String string2) {
        Checker.checkNonNull((Object)context, (String)"Null context is not permitted.");
        this.init(context, api, TOption, abstractClientBuilder, n2, string2);
    }

    private void init(Context context, Api<TOption> api, TOption TOption, AbstractClientBuilder abstractClientBuilder, int n2, String string2) {
        String string3;
        Context context2;
        this.mContext = context2 = context.getApplicationContext();
        this.mHuaweiApiManager = HuaweiApiManager.getInstance(context2);
        this.mConnectionManagerKey = ConnectionManagerKey.createConnectionManagerKey(context, api, TOption, string2);
        this.mOption = TOption;
        this.mClientBuilder = abstractClientBuilder;
        this.mHostAppid = string3 = Util.getAppId((Context)context);
        this.mAppID = string3;
        this.mSubAppInfo = new SubAppInfo("");
        this.mKitSdkVersion = n2;
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            if (string2.equals((Object)this.mHostAppid)) {
                HMSLog.e((String)TAG, (String)"subAppId is host appid");
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("subAppId is ");
                stringBuilder.append(string2);
                HMSLog.i((String)TAG, (String)stringBuilder.toString());
                this.mSubAppInfo = new SubAppInfo(string2);
            }
        }
        this.initBI(context);
    }

    private void initBI(Context context) {
        HMSBIInitializer.getInstance((Context)context).initBI();
    }

    private <TResult, TClient extends AnyClient> f<TResult> sendRequest(TaskApiCall<TClient, TResult> taskApiCall) {
        g g2 = taskApiCall.getToken() == null ? new g() : new g(taskApiCall.getToken());
        this.mHuaweiApiManager.sendRequest(this, taskApiCall, g2);
        return g2.a;
    }

    public f<Boolean> disconnectService() {
        g g2 = new g();
        this.mHuaweiApiManager.disconnectService(this, (g<Boolean>)g2);
        return g2.a;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public <TResult, TClient extends AnyClient> f<TResult> doWrite(TaskApiCall<TClient, TResult> taskApiCall) {
        this.isFirstReqSent = true;
        if (taskApiCall == null) {
            Object object;
            HMSLog.e((String)TAG, (String)"in doWrite:taskApiCall is null");
            e e2 = new e();
            ApiException apiException = new ApiException(Status.FAILURE);
            Object object2 = object = e2.a;
            synchronized (object2) {
                if (!e2.b) {
                    e2.b = true;
                    e2.e = apiException;
                    e2.a.notifyAll();
                    e2.i();
                }
                return e2;
            }
        }
        String string2 = TextUtils.isEmpty((CharSequence)this.mSubAppInfo.getSubAppID()) ? this.mAppID : this.mSubAppInfo.getSubAppID();
        com.huawei.hms.support.hianalytics.b.a((Context)this.mContext, (String)taskApiCall.getUri(), (String)string2, (String)taskApiCall.getTransactionId(), (String)String.valueOf((int)this.getKitSdkVersion()));
        return this.sendRequest(taskApiCall);
    }

    public Activity getActivity() {
        WeakReference<Activity> weakReference = this.mActivity;
        if (weakReference != null) {
            return (Activity)weakReference.get();
        }
        return null;
    }

    public int getApiLevel() {
        return this.apiLevel;
    }

    public String getAppID() {
        return this.mAppID;
    }

    public AnyClient getClient(Looper looper, HuaweiApiManager.ConnectionManager connectionManager) {
        return this.mClientBuilder.buildClient(this.mContext, this.getClientSetting(), (BaseHmsClient.OnConnectionFailedListener)connectionManager, (BaseHmsClient.ConnectionCallbacks)connectionManager);
    }

    public ClientSettings getClientSetting() {
        ClientSettings clientSettings = new ClientSettings(this.mContext.getPackageName(), this.mContext.getClass().getName(), this.getScopes(), this.mHostAppid, null, this.mSubAppInfo);
        if (TextUtils.isEmpty((CharSequence)this.innerHmsPkg)) {
            this.innerHmsPkg = HMSPackageManager.getInstance((Context)this.mContext).getHMSPackageName();
            StringBuilder stringBuilder = b.a((String)"inner hms is empty,hms pkg name is ");
            stringBuilder.append(this.innerHmsPkg);
            HMSLog.i((String)TAG, (String)stringBuilder.toString());
        }
        clientSettings.setInnerHmsPkg(this.innerHmsPkg);
        WeakReference<Activity> weakReference = this.mActivity;
        if (weakReference != null) {
            clientSettings.setCpActivity((Activity)weakReference.get());
        }
        return clientSettings;
    }

    public ConnectionManagerKey<TOption> getConnectionManagerKey() {
        return this.mConnectionManagerKey;
    }

    public Context getContext() {
        return this.mContext;
    }

    public int getKitSdkVersion() {
        return this.mKitSdkVersion;
    }

    public TOption getOption() {
        return this.mOption;
    }

    public List<Scope> getScopes() {
        return Collections.emptyList();
    }

    public String getSubAppID() {
        return this.mSubAppInfo.getSubAppID();
    }

    public void setApiLevel(int n2) {
        this.apiLevel = n2;
    }

    public void setInnerHms() {
        this.innerHmsPkg = this.mContext.getPackageName();
        StringBuilder stringBuilder = b.a((String)"init inner hms pkg info:");
        stringBuilder.append(this.innerHmsPkg);
        HMSLog.i((String)TAG, (String)stringBuilder.toString());
    }

    public void setKitSdkVersion(int n2) {
        this.mKitSdkVersion = n2;
    }

    public void setSubAppId(String string2) throws ApiException {
        if (this.setSubAppInfo(new SubAppInfo(string2))) {
            return;
        }
        throw new ApiException(Status.FAILURE);
    }

    @Deprecated
    public boolean setSubAppInfo(SubAppInfo subAppInfo) {
        HMSLog.i((String)TAG, (String)"Enter setSubAppInfo");
        SubAppInfo subAppInfo2 = this.mSubAppInfo;
        if (subAppInfo2 != null && !TextUtils.isEmpty((CharSequence)subAppInfo2.getSubAppID())) {
            HMSLog.e((String)TAG, (String)"subAppInfo is already set");
            return false;
        }
        if (subAppInfo == null) {
            HMSLog.e((String)TAG, (String)"subAppInfo is null");
            return false;
        }
        String string2 = subAppInfo.getSubAppID();
        if (TextUtils.isEmpty((CharSequence)string2)) {
            HMSLog.e((String)TAG, (String)"subAppId is empty");
            return false;
        }
        if (string2.equals((Object)this.mHostAppid)) {
            HMSLog.e((String)TAG, (String)"subAppId is host appid");
            return false;
        }
        if (this.isFirstReqSent) {
            HMSLog.e((String)TAG, (String)"Client has sent request to Huawei Mobile Services, setting subAppId is not allowed");
            return false;
        }
        this.mSubAppInfo = new SubAppInfo(subAppInfo);
        return true;
    }
}

