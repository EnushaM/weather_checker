/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.huawei.hms.base.availableupdate;

public final class R {
    private R() {
    }

    public static final class color {
        public static final int emui_color_gray_1 = 2131099764;
        public static final int emui_color_gray_10 = 2131099765;
        public static final int emui_color_gray_7 = 2131099766;
        public static final int upsdk_color_gray_1 = 2131099912;
        public static final int upsdk_color_gray_10 = 2131099913;
        public static final int upsdk_color_gray_7 = 2131099914;

        private color() {
        }
    }

    public static final class dimen {
        public static final int upsdk_margin_l = 2131165748;
        public static final int upsdk_margin_m = 2131165749;
        public static final int upsdk_margin_xs = 2131165750;
        public static final int upsdk_master_body_2 = 2131165751;
        public static final int upsdk_master_subtitle = 2131165752;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int upsdk_cancel_bg = 2131231659;
        public static final int upsdk_cancel_normal = 2131231660;
        public static final int upsdk_cancel_pressed_bg = 2131231661;
        public static final int upsdk_third_download_bg = 2131231662;

        private drawable() {
        }
    }

    public static final class id {
        public static final int action = 2131296317;
        public static final int allsize_textview = 2131296376;
        public static final int appsize_textview = 2131296397;
        public static final int cancel_bg = 2131296481;
        public static final int cancel_imageview = 2131296483;
        public static final int content_layout = 2131296547;
        public static final int content_textview = 2131296548;
        public static final int divider = 2131296624;
        public static final int download_info_progress = 2131296626;
        public static final int enable_service_text = 2131296654;
        public static final int hms_message_text = 2131296725;
        public static final int hms_progress_bar = 2131296726;
        public static final int hms_progress_text = 2131296727;
        public static final int name_layout = 2131296966;
        public static final int name_textview = 2131296967;
        public static final int scroll_layout = 2131297177;
        public static final int size_layout = 2131297231;
        public static final int third_app_dl_progress_text = 2131297381;
        public static final int third_app_dl_progressbar = 2131297382;
        public static final int third_app_warn_text = 2131297383;
        public static final int version_layout = 2131297439;
        public static final int version_textview = 2131297440;

        private id() {
        }
    }

    public static final class layout {
        public static final int activity_endisable_service = 2131492895;
        public static final int hms_download_progress = 2131492946;
        public static final int upsdk_app_dl_progress_dialog = 2131493150;
        public static final int upsdk_ota_update_view = 2131493151;

        private layout() {
        }
    }

    public static final class string {
        public static final int app_name = 2131820597;
        public static final int hms_abort = 2131820863;
        public static final int hms_abort_message = 2131820864;
        public static final int hms_bindfaildlg_message = 2131820865;
        public static final int hms_bindfaildlg_title = 2131820866;
        public static final int hms_cancel = 2131820867;
        public static final int hms_check_failure = 2131820868;
        public static final int hms_checking = 2131820869;
        public static final int hms_confirm = 2131820870;
        public static final int hms_download_failure = 2131820871;
        public static final int hms_download_no_space = 2131820872;
        public static final int hms_download_retry = 2131820873;
        public static final int hms_downloading_loading = 2131820874;
        public static final int hms_install = 2131820875;
        public static final int hms_install_message = 2131820876;
        public static final int hms_is_spoof = 2131820877;
        public static final int hms_retry = 2131820878;
        public static final int hms_spoof_hints = 2131820879;
        public static final int hms_update = 2131820880;
        public static final int hms_update_continue = 2131820881;
        public static final int hms_update_message = 2131820882;
        public static final int hms_update_message_new = 2131820883;
        public static final int hms_update_nettype = 2131820884;
        public static final int hms_update_title = 2131820885;
        public static final int upsdk_app_download_info_new = 2131821554;
        public static final int upsdk_app_download_installing = 2131821555;
        public static final int upsdk_app_size = 2131821556;
        public static final int upsdk_app_version = 2131821557;
        public static final int upsdk_appstore_install = 2131821558;
        public static final int upsdk_cancel = 2131821559;
        public static final int upsdk_checking_update_prompt = 2131821560;
        public static final int upsdk_choice_update = 2131821561;
        public static final int upsdk_detail = 2131821562;
        public static final int upsdk_getting_message_fail_prompt_toast = 2131821563;
        public static final int upsdk_mobile_dld_warn = 2131821564;
        public static final int upsdk_no_available_network_prompt_toast = 2131821565;
        public static final int upsdk_ota_app_name = 2131821566;
        public static final int upsdk_ota_cancel = 2131821567;
        public static final int upsdk_ota_force_cancel_new = 2131821568;
        public static final int upsdk_ota_notify_updatebtn = 2131821569;
        public static final int upsdk_ota_title = 2131821570;
        public static final int upsdk_storage_utils = 2131821571;
        public static final int upsdk_store_url = 2131821572;
        public static final int upsdk_third_app_dl_cancel_download_prompt_ex = 2131821573;
        public static final int upsdk_third_app_dl_install_failed = 2131821574;
        public static final int upsdk_third_app_dl_sure_cancel_download = 2131821575;
        public static final int upsdk_update_check_no_new_version = 2131821576;

        private string() {
        }
    }

    public static final class style {
        public static final int Base_Translucent = 2131886320;

        private style() {
        }
    }

}

