/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.huawei.hms.base.ui;

import android.text.TextUtils;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class a {
    public static final Pattern a = Pattern.compile((String)"[0-9]*[a-z|A-Z]*[\u4e00-\u9fa5]*");

    public static String a(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return string2;
        }
        int n2 = 1;
        int n3 = string2.length();
        if (n2 == n3) {
            return String.valueOf((char)'*');
        }
        StringBuilder stringBuilder = new StringBuilder(n3);
        for (int i2 = 0; i2 < n3; ++i2) {
            int n4 = string2.charAt(i2);
            if (a.matcher((CharSequence)String.valueOf((char)n4)).matches()) {
                if (n2 % 2 == 0) {
                    n4 = 42;
                }
                ++n2;
            }
            stringBuilder.append((char)n4);
        }
        return stringBuilder.toString();
    }

    public static String a(String string2, boolean bl2) {
        StringBuilder stringBuilder = new StringBuilder(512);
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            if (bl2) {
                stringBuilder.append(a.a(string2));
            } else {
                stringBuilder.append(string2);
            }
        }
        return stringBuilder.toString();
    }

    public static void a(String string2, String string3) {
        if (TextUtils.isEmpty((CharSequence)string3)) {
            return;
        }
        a.a(string3, false);
    }

    public static void a(String string2, String string3, boolean bl2) {
        if (TextUtils.isEmpty((CharSequence)string3)) {
            return;
        }
        a.a(string3, bl2);
    }
}

