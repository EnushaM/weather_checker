/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Process
 *  android.util.Log
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.text.SimpleDateFormat
 *  java.util.Locale
 */
package com.huawei.hms.base.log;

import android.os.Process;
import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class c {
    public final StringBuilder a = new StringBuilder();
    public String b = null;
    public String c = "HMS";
    public int d = 0;
    public long e = 0L;
    public long f = 0L;
    public String g;
    public int h;
    public int i;
    public int j = 0;

    public c(int n2, String string2, int n3, String string3) {
        this.j = n2;
        this.b = string2;
        this.d = n3;
        if (string3 != null) {
            this.c = string3;
        }
        this.b();
    }

    public static String a(int n2) {
        if (n2 != 3) {
            if (n2 != 4) {
                if (n2 != 5) {
                    if (n2 != 6) {
                        return String.valueOf((int)n2);
                    }
                    return "E";
                }
                return "W";
            }
            return "I";
        }
        return "D";
    }

    public <T> c a(T t2) {
        this.a.append(t2);
        return this;
    }

    public c a(Throwable throwable) {
        this.a((T)Character.valueOf((char)'\n')).a(Log.getStackTraceString((Throwable)throwable));
        return this;
    }

    public String a() {
        StringBuilder stringBuilder = new StringBuilder();
        this.a(stringBuilder);
        return stringBuilder.toString();
    }

    public final StringBuilder a(StringBuilder stringBuilder) {
        stringBuilder.append(' ');
        stringBuilder.append(this.a.toString());
        return stringBuilder;
    }

    public final c b() {
        int n2;
        this.e = System.currentTimeMillis();
        Thread thread = Thread.currentThread();
        this.f = thread.getId();
        this.h = Process.myPid();
        StackTraceElement[] arrstackTraceElement = thread.getStackTrace();
        int n3 = arrstackTraceElement.length;
        if (n3 > (n2 = this.j)) {
            StackTraceElement stackTraceElement = arrstackTraceElement[n2];
            this.g = stackTraceElement.getFileName();
            this.i = stackTraceElement.getLineNumber();
        }
        return this;
    }

    public final StringBuilder b(StringBuilder stringBuilder) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault());
        stringBuilder.append('[');
        stringBuilder.append(simpleDateFormat.format((Object)this.e));
        String string2 = c.a(this.d);
        stringBuilder.append(' ');
        stringBuilder.append(string2);
        stringBuilder.append('/');
        stringBuilder.append(this.c);
        stringBuilder.append('/');
        stringBuilder.append(this.b);
        stringBuilder.append(' ');
        stringBuilder.append(this.h);
        stringBuilder.append(':');
        stringBuilder.append(this.f);
        stringBuilder.append(' ');
        stringBuilder.append(this.g);
        stringBuilder.append(':');
        stringBuilder.append(this.i);
        stringBuilder.append(']');
        return stringBuilder;
    }

    public String c() {
        StringBuilder stringBuilder = new StringBuilder();
        this.b(stringBuilder);
        return stringBuilder.toString();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        this.b(stringBuilder);
        this.a(stringBuilder);
        return stringBuilder.toString();
    }
}

