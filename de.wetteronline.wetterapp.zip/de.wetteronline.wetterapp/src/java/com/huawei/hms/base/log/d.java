/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.base.log;

import android.content.Context;
import android.util.Log;
import com.huawei.hms.base.log.b;

public class d
implements b {
    public b a;

    @Override
    public void a(Context context, String string) {
        b b2 = this.a;
        if (b2 != null) {
            b2.a(context, string);
        }
    }

    @Override
    public void a(String string, int n2, String string2, String string3) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("HMSSDK_");
        stringBuilder.append(string2);
        Log.println((int)n2, (String)stringBuilder.toString(), (String)string3);
        b b2 = this.a;
        if (b2 != null) {
            b2.a(string, n2, string2, string3);
        }
    }
}

