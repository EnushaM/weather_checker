/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.base.log;

import android.content.Context;

public interface b {
    public void a(Context var1, String var2);

    public void a(String var1, int var2, String var3, String var4);
}

