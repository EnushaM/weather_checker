/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.huawei.hms.base.ui;

public final class R {
    private R() {
    }

    public static final class color {
        public static final int emui_color_gray_1 = 2131099764;
        public static final int emui_color_gray_10 = 2131099765;
        public static final int emui_color_gray_7 = 2131099766;

        private color() {
        }
    }

    public static final class id {
        public static final int enable_service_text = 2131296654;

        private id() {
        }
    }

    public static final class layout {
        public static final int activity_endisable_service = 2131492895;

        private layout() {
        }
    }

    public static final class string {
        public static final int hms_abort = 2131820863;
        public static final int hms_abort_message = 2131820864;
        public static final int hms_bindfaildlg_message = 2131820865;
        public static final int hms_bindfaildlg_title = 2131820866;
        public static final int hms_cancel = 2131820867;
        public static final int hms_check_failure = 2131820868;
        public static final int hms_checking = 2131820869;
        public static final int hms_confirm = 2131820870;
        public static final int hms_download_failure = 2131820871;
        public static final int hms_download_no_space = 2131820872;
        public static final int hms_download_retry = 2131820873;
        public static final int hms_downloading_loading = 2131820874;
        public static final int hms_install = 2131820875;
        public static final int hms_install_message = 2131820876;
        public static final int hms_is_spoof = 2131820877;
        public static final int hms_retry = 2131820878;
        public static final int hms_spoof_hints = 2131820879;
        public static final int hms_update = 2131820880;
        public static final int hms_update_continue = 2131820881;
        public static final int hms_update_message = 2131820882;
        public static final int hms_update_message_new = 2131820883;
        public static final int hms_update_nettype = 2131820884;
        public static final int hms_update_title = 2131820885;

        private string() {
        }
    }

    public static final class style {
        public static final int Base_Translucent = 2131886320;

        private style() {
        }
    }

}

