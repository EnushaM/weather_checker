/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Log
 *  com.huawei.hms.base.log.d
 *  e.g
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.huawei.hms.base.log;

import android.content.Context;
import android.util.Log;
import com.huawei.hms.base.log.b;
import com.huawei.hms.base.log.c;
import com.huawei.hms.base.log.d;
import e.g;

public class a {
    public static final b c = new d();
    public int a = 4;
    public String b;

    public final c a(int n2, String string2, String string3, Throwable throwable) {
        c c2 = new c(8, this.b, n2, string2);
        c2.a(string3);
        c2.a(throwable);
        return c2;
    }

    public void a(int n2, String string2, String string3) {
        if (this.a(n2)) {
            c c2 = this.a(n2, string2, string3, null);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(c2.c());
            stringBuilder.append(c2.a());
            String string4 = stringBuilder.toString();
            c.a(string4, n2, string2, string3);
        }
    }

    public void a(Context context, int n2, String string2) {
        this.a = n2;
        this.b = string2;
        c.a(context, "HMSCore");
    }

    public void a(String string2, String string3) {
        c c2 = this.a(4, string2, string3, null);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(c2.c());
        stringBuilder.append('\n');
        stringBuilder.append(c2.a());
        String string4 = stringBuilder.toString();
        c.a(string4, 4, string2, string3);
    }

    public boolean a(int n2) {
        return n2 >= this.a;
    }

    public void b(int n2, String string2, String string3, Throwable throwable) {
        if (this.a(n2)) {
            c c2 = this.a(n2, string2, string3, throwable);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(c2.c());
            stringBuilder.append(c2.a());
            String string4 = stringBuilder.toString();
            b b3 = c;
            StringBuilder stringBuilder2 = g.a((String)string3, (char)'\n');
            stringBuilder2.append(Log.getStackTraceString((Throwable)throwable));
            b3.a(string4, n2, string2, stringBuilder2.toString());
        }
    }
}

