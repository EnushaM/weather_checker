/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  com.huawei.hms.support.log.HMSLog
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 */
package com.huawei.hms.availableupdate;

import android.app.Activity;
import com.huawei.hms.support.log.HMSLog;
import java.lang.ref.WeakReference;

public class a {
    public static final a b = new a();
    public WeakReference<Activity> a;

    public final Activity a() {
        WeakReference<Activity> weakReference = this.a;
        if (weakReference == null) {
            return null;
        }
        return (Activity)weakReference.get();
    }

    public boolean a(Activity activity) {
        HMSLog.i((String)"UpdateAdapterMgr", (String)"onActivityCreate");
        if (this.a() != null) {
            activity.finish();
            HMSLog.i((String)"UpdateAdapterMgr", (String)"finish one");
            return false;
        }
        this.a = new WeakReference((Object)activity);
        return true;
    }

    public void b(Activity activity) {
        HMSLog.i((String)"UpdateAdapterMgr", (String)"onActivityDestroy");
        Activity activity2 = this.a();
        if (activity != null && activity.equals((Object)activity2)) {
            HMSLog.i((String)"UpdateAdapterMgr", (String)"reset");
            this.a = null;
        }
    }
}

