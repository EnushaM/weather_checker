/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.Looper
 *  android.support.v4.media.b
 *  android.text.TextUtils
 *  android.view.KeyEvent
 *  androidx.appcompat.app.n
 *  com.huawei.hms.activity.IBridgeActivityDelegate
 *  com.huawei.hms.availableupdate.a0
 *  com.huawei.hms.availableupdate.d
 *  com.huawei.hms.availableupdate.e
 *  com.huawei.hms.availableupdate.h0$b
 *  com.huawei.hms.availableupdate.p
 *  com.huawei.hms.availableupdate.s
 *  com.huawei.hms.availableupdate.y
 *  com.huawei.hms.support.log.HMSLog
 *  com.huawei.hms.update.provider.UpdateProvider
 *  com.huawei.hms.update.ui.UpdateBean
 *  com.huawei.hms.utils.FileUtil
 *  com.huawei.hms.utils.HMSPackageManager
 *  com.huawei.hms.utils.PackageManagerHelper
 *  com.huawei.hms.utils.ResourceLoaderUtil
 *  com.huawei.updatesdk.UpdateSdkAPI
 *  com.huawei.updatesdk.service.appmgr.bean.ApkUpgradeInfo
 *  com.huawei.updatesdk.service.otaupdate.CheckUpdateCallBack
 *  e0.o
 *  java.io.File
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalStateException
 *  java.lang.InstantiationException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.availableupdate;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.KeyEvent;
import androidx.appcompat.app.n;
import com.huawei.hms.activity.IBridgeActivityDelegate;
import com.huawei.hms.adapter.sysobs.SystemManager;
import com.huawei.hms.android.SystemUtils;
import com.huawei.hms.availableupdate.a0;
import com.huawei.hms.availableupdate.d;
import com.huawei.hms.availableupdate.d0;
import com.huawei.hms.availableupdate.e;
import com.huawei.hms.availableupdate.e0;
import com.huawei.hms.availableupdate.f;
import com.huawei.hms.availableupdate.f0;
import com.huawei.hms.availableupdate.g;
import com.huawei.hms.availableupdate.h;
import com.huawei.hms.availableupdate.h0;
import com.huawei.hms.availableupdate.i;
import com.huawei.hms.availableupdate.p;
import com.huawei.hms.availableupdate.q;
import com.huawei.hms.availableupdate.s;
import com.huawei.hms.availableupdate.v;
import com.huawei.hms.availableupdate.w;
import com.huawei.hms.availableupdate.x;
import com.huawei.hms.availableupdate.y;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.update.provider.UpdateProvider;
import com.huawei.hms.update.ui.UpdateBean;
import com.huawei.hms.utils.FileUtil;
import com.huawei.hms.utils.HMSPackageManager;
import com.huawei.hms.utils.PackageManagerHelper;
import com.huawei.hms.utils.ResourceLoaderUtil;
import com.huawei.updatesdk.UpdateSdkAPI;
import com.huawei.updatesdk.service.appmgr.bean.ApkUpgradeInfo;
import com.huawei.updatesdk.service.otaupdate.CheckUpdateCallBack;
import e0.o;
import java.io.File;
import java.io.Serializable;

public class h0
extends p
implements g {
    public f j;
    public h k;
    public int l = 0;

    public static Uri a(Context context, File file) {
        PackageManagerHelper packageManagerHelper = new PackageManagerHelper(context);
        String string = context.getPackageName();
        String string2 = n.a((String)string, (String)".hms.update.provider");
        boolean bl = Build.VERSION.SDK_INT > 23 && (context.getApplicationInfo().targetSdkVersion > 23 || packageManagerHelper.hasProvider(string, string2));
        if (bl) {
            return UpdateProvider.getUriForFile((Context)context, (String)string2, (File)file);
        }
        return Uri.fromFile((File)file);
    }

    public static void a(g g2, int n2, h h2) {
        if (g2 != null) {
            new Handler(Looper.getMainLooper()).post(new Runnable(g2, n2, h2){
                public final /* synthetic */ g a;
                public final /* synthetic */ int b;
                public final /* synthetic */ h c;
                {
                    this.a = g2;
                    this.b = n2;
                    this.c = h2;
                }

                public void run() {
                    this.a.a(this.b, this.c);
                }
            });
        }
    }

    public static /* synthetic */ void a(h0 h02, Intent intent, g g2) {
        h02.a(intent, g2);
    }

    @Override
    public void a(int n2, int n3, int n4, File file) {
        StringBuilder stringBuilder = android.support.v4.media.b.a((String)"Enter onDownloadPackage, status: ");
        stringBuilder.append(i.a(n2));
        stringBuilder.append(", reveived: ");
        stringBuilder.append(n3);
        stringBuilder.append(", total: ");
        stringBuilder.append(n4);
        HMSLog.i((String)"UpdateWizard", (String)stringBuilder.toString());
        if (n2 != 2000) {
            if (n2 != 2100) {
                if (n2 != 2101) {
                    switch (n2) {
                        default: {
                            return;
                        }
                        case 2203: 
                        case 2204: {
                            this.a(f0.class);
                            return;
                        }
                        case 2202: {
                            this.a(w.class);
                            return;
                        }
                        case 2201: 
                    }
                    this.a(e0.class);
                    return;
                }
            } else {
                q q2 = this.d;
                if (q2 != null && q2 instanceof y) {
                    int n6 = 0;
                    if (n3 >= 0) {
                        n6 = 0;
                        if (n4 > 0) {
                            n6 = (int)(100L * (long)n3 / (long)n4);
                        }
                    }
                    this.l = n6;
                    ((y)q2).b(n6);
                    return;
                }
            }
        } else {
            this.a();
            if (file == null) {
                this.e();
                return;
            }
            if (FileUtil.verifyHash((String)this.k.e, (File)file)) {
                this.a(file);
                return;
            }
            HMSLog.i((String)"UpdateWizard", (String)"Hash value mismatch for download file");
        }
    }

    @Override
    public void a(int n2, h h2) {
        StringBuilder stringBuilder = android.support.v4.media.b.a((String)"Enter onCheckUpdate, status: ");
        stringBuilder.append(i.a(n2));
        HMSLog.i((String)"UpdateWizard", (String)stringBuilder.toString());
        if (n2 != 1000) {
            switch (n2) {
                default: {
                    this.a(d0.class);
                    return;
                }
                case 1201: 
                case 1202: 
                case 1203: 
            }
            this.a(d0.class);
            return;
        }
        this.k = h2;
        this.d();
    }

    public final void a(Intent intent, g g2) {
        int n2;
        try {
            n2 = intent.getIntExtra("status", -99);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("CheckUpdateCallBack status is ");
            stringBuilder.append(n2);
            HMSLog.i((String)"UpdateWizard", (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = android.support.v4.media.b.a((String)"intent has some error");
            stringBuilder.append(exception.getMessage());
            HMSLog.e((String)"UpdateWizard", (String)stringBuilder.toString());
            h0.a(g2, 1201, null);
            return;
        }
        String string = intent.getStringExtra("failreason");
        if (!TextUtils.isEmpty((CharSequence)string)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("checkTargetAppUpdate reason is ");
            stringBuilder.append(string);
            HMSLog.e((String)"UpdateWizard", (String)stringBuilder.toString());
        }
        if (n2 == 7) {
            Serializable serializable = intent.getSerializableExtra("updatesdk_update_info");
            if (serializable instanceof ApkUpgradeInfo) {
                ApkUpgradeInfo apkUpgradeInfo = (ApkUpgradeInfo)serializable;
                String string2 = apkUpgradeInfo.getPackage_();
                int n3 = apkUpgradeInfo.getVersionCode_();
                String string3 = apkUpgradeInfo.getDownurl_();
                int n4 = apkUpgradeInfo.getSize_();
                String string4 = apkUpgradeInfo.getSha256_();
                if (!TextUtils.isEmpty((CharSequence)string2) && string2.equals((Object)this.c.b())) {
                    if (n3 < this.c.c()) {
                        StringBuilder stringBuilder = o.a((String)"CheckUpdateCallBack versionCode is ", (int)n3, (String)"bean.getClientVersionCode() is ");
                        stringBuilder.append(this.c.c());
                        HMSLog.e((String)"UpdateWizard", (String)stringBuilder.toString());
                        h0.a(g2, 1203, null);
                        return;
                    }
                    if (!TextUtils.isEmpty((CharSequence)string3) && !TextUtils.isEmpty((CharSequence)string4)) {
                        h h2 = new h(string2, n3, string3, n4, string4);
                        h0.a(g2, 1000, h2);
                        return;
                    }
                    h0.a(g2, 1201, null);
                    return;
                }
                h0.a(g2, 1201, null);
                return;
            }
        } else {
            if (n2 == 3) {
                h0.a(g2, 1202, null);
                return;
            }
            h0.a(g2, 1201, null);
        }
    }

    public final void a(g g2) {
        if (g2 == null) {
            return;
        }
        Activity activity = this.b();
        if (activity != null && !activity.isFinishing()) {
            if (!this.a(activity)) {
                return;
            }
            UpdateSdkAPI.checkTargetAppUpdate((Context)activity, (String)this.c.b(), (CheckUpdateCallBack)new b(this, g2));
            return;
        }
        h0.a(g2, 1201, null);
    }

    public void a(q q2) {
        HMSLog.i((String)"UpdateWizard", (String)"Enter onCancel.");
        if (q2 instanceof a0) {
            this.g();
            return;
        }
        if (q2 instanceof s) {
            this.c();
            this.g();
            return;
        }
        if (q2 instanceof y) {
            this.c();
            this.a(x.class);
            return;
        }
        if (q2 instanceof x) {
            this.a(y.class);
            this.f();
            return;
        }
        if (q2 instanceof w) {
            this.g();
            return;
        }
        if (q2 instanceof v) {
            this.g();
            return;
        }
        this.e();
    }

    public final void a(File file) {
        Activity activity = this.b();
        if (activity != null) {
            if (activity.isFinishing()) {
                return;
            }
            Uri uri = h0.a((Context)activity, file);
            if (uri == null) {
                HMSLog.e((String)"UpdateWizard", (String)"In startInstaller, Failed to creates a Uri from a file.");
                this.e();
                return;
            }
            if (!this.a(activity)) {
                return;
            }
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.setFlags(3);
            intent.putExtra("android.intent.extra.NOT_UNKNOWN_SOURCE", true);
            try {
                activity.startActivityForResult(intent, this.getRequestCode());
                return;
            }
            catch (ActivityNotFoundException activityNotFoundException) {
                StringBuilder stringBuilder = android.support.v4.media.b.a((String)"In startInstaller, Failed to start package installer.");
                stringBuilder.append(activityNotFoundException.getMessage());
                HMSLog.e((String)"UpdateWizard", (String)stringBuilder.toString());
                this.e();
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(Class<? extends q> class_) {
        void var2_8;
        if (!this.a(this.b())) {
            return;
        }
        this.a();
        try {
            int n2;
            q q2 = (q)class_.newInstance();
            if (!TextUtils.isEmpty((CharSequence)this.h) && q2 instanceof a0) {
                String string;
                this.h = string = ResourceLoaderUtil.getString((String)"hms_update_title");
                ((a0)q2).a(string);
            }
            if ((n2 = this.l) > 0 && q2 instanceof y) {
                ((y)q2).a(n2);
            }
            q2.a(this);
            this.d = q2;
            return;
        }
        catch (IllegalStateException illegalStateException) {
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (InstantiationException instantiationException) {
            // empty catch block
        }
        StringBuilder stringBuilder = android.support.v4.media.b.a((String)"In showDialog, Failed to show the dialog.");
        stringBuilder.append(var2_8.getMessage());
        HMSLog.e((String)"UpdateWizard", (String)stringBuilder.toString());
    }

    public final boolean a(Activity activity) {
        if (HMSPackageManager.getInstance((Context)activity).isApkUpdateNecessary(this.c.c())) {
            return true;
        }
        this.a();
        SystemManager.getInstance().notifyUpdateResult(0);
        return false;
    }

    public void b(q q2) {
        HMSLog.i((String)"UpdateWizard", (String)"Enter onDoWork.");
        if (q2 instanceof a0) {
            q2.b();
            this.a(s.class);
            this.a(this);
            return;
        }
        if (q2 instanceof x) {
            q2.b();
            this.g();
            return;
        }
        if (q2 instanceof w) {
            this.a(y.class);
            this.f();
            return;
        }
        if (q2 instanceof v) {
            this.a(y.class);
            this.f();
            return;
        }
        if (q2 instanceof d0) {
            this.e();
            return;
        }
        if (q2 instanceof e0) {
            this.e();
            return;
        }
        if (q2 instanceof f0) {
            this.e();
        }
    }

    public final void c() {
        f f2 = this.j;
        if (f2 != null) {
            f2.a();
            this.j = null;
        }
    }

    public final void d() {
        Activity activity = this.b();
        String string = activity != null ? SystemUtils.getNetType(activity.getBaseContext()) : "";
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("current network is ");
        stringBuilder.append(string);
        HMSLog.i((String)"UpdateWizard", (String)stringBuilder.toString());
        if ("WIFI".equals((Object)string)) {
            this.a(y.class);
            this.f();
            HMSLog.i((String)"UpdateWizard", (String)"current network is wifi");
            return;
        }
        this.a(v.class);
        HMSLog.i((String)"UpdateWizard", (String)"current network is not wifi");
    }

    public final void e() {
        if (!this.a(false)) {
            this.c(8, this.f);
            return;
        }
        this.a(8, this.f);
    }

    public final void f() {
        Activity activity = this.b();
        if (activity != null && !activity.isFinishing()) {
            if (!this.a(activity)) {
                return;
            }
            this.c();
            d d2 = new d((f)new e((Context)activity));
            this.j = d2;
            d2.a(this, this.k);
            return;
        }
        this.a(e0.class);
    }

    public void g() {
        this.c(13, this.f);
    }

    public int getRequestCode() {
        return 2006;
    }

    public void onBridgeActivityCreate(Activity activity) {
        super.onBridgeActivityCreate(activity);
        if (this.c == null) {
            return;
        }
        this.f = 6;
        if (!this.a(activity)) {
            return;
        }
        if (this.c.isNeedConfirm() && !TextUtils.isEmpty((CharSequence)this.h)) {
            this.a(a0.class);
            return;
        }
        this.a(s.class);
        this.a(this);
    }

    public void onBridgeActivityDestroy() {
        this.c();
        super.onBridgeActivityDestroy();
    }

    public boolean onBridgeActivityResult(int n2, int n3, Intent intent) {
        IBridgeActivityDelegate iBridgeActivityDelegate;
        if (this.e && (iBridgeActivityDelegate = this.b) != null) {
            return iBridgeActivityDelegate.onBridgeActivityResult(n2, n3, intent);
        }
        if (this.f == 6 && n2 == this.getRequestCode()) {
            if (this.a(this.g, this.i)) {
                this.c(0, this.f);
            } else {
                this.e();
            }
            return true;
        }
        return false;
    }

    public void onKeyUp(int n2, KeyEvent keyEvent) {
        IBridgeActivityDelegate iBridgeActivityDelegate;
        if (this.e && (iBridgeActivityDelegate = this.b) != null) {
            iBridgeActivityDelegate.onKeyUp(n2, keyEvent);
            return;
        }
        if (4 == n2) {
            HMSLog.i((String)"UpdateWizard", (String)"In onKeyUp, Call finish.");
            Activity activity = this.b();
            if (activity != null && !activity.isFinishing()) {
                activity.setResult(0, null);
                activity.finish();
            }
        }
    }
}

