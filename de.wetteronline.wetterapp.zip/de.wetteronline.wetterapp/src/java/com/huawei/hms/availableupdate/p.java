/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.support.v4.media.b
 *  android.text.TextUtils
 *  android.view.KeyEvent
 *  androidx.appcompat.app.n
 *  com.huawei.hms.activity.IBridgeActivityDelegate
 *  com.huawei.hms.common.util.AGCUtils
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassCastException
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalStateException
 *  java.lang.InstantiationException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.ref.WeakReference
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Map
 */
package com.huawei.hms.availableupdate;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v4.media.b;
import android.text.TextUtils;
import android.view.KeyEvent;
import androidx.appcompat.app.n;
import com.huawei.hms.activity.IBridgeActivityDelegate;
import com.huawei.hms.android.SystemUtils;
import com.huawei.hms.availableupdate.g0;
import com.huawei.hms.availableupdate.h0;
import com.huawei.hms.availableupdate.q;
import com.huawei.hms.availableupdate.r;
import com.huawei.hms.availableupdate.z;
import com.huawei.hms.common.util.AGCUtils;
import com.huawei.hms.support.hianalytics.HiAnalyticsUtils;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.update.ui.UpdateBean;
import com.huawei.hms.utils.NetWorkUtil;
import com.huawei.hms.utils.PackageManagerHelper;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class p
implements IBridgeActivityDelegate {
    public WeakReference<Activity> a;
    public IBridgeActivityDelegate b;
    public UpdateBean c = null;
    public q d = null;
    public boolean e = false;
    public int f = -1;
    public String g = null;
    public String h = null;
    public int i = 0;

    public static String a(int n2) {
        if (n2 != 0) {
            if (n2 != 5) {
                if (n2 != 6) {
                    if (n2 != 7) {
                        return "";
                    }
                    return r.class.getName();
                }
                return h0.class.getName();
            }
            return z.class.getName();
        }
        return g0.class.getName();
    }

    public void a() {
        q q2 = this.d;
        if (q2 == null) {
            return;
        }
        try {
            q2.b();
            this.d = null;
            return;
        }
        catch (IllegalStateException illegalStateException) {
            StringBuilder stringBuilder = b.a((String)"In dismissDialog, Failed to dismiss the dialog.");
            stringBuilder.append(illegalStateException.getMessage());
            HMSLog.e("AbsUpdateWizard", stringBuilder.toString());
            return;
        }
    }

    public void a(int n2, int n3) {
        if (!SystemUtils.isChinaROM()) {
            HMSLog.i("AbsUpdateWizard", "not ChinaROM ");
            return;
        }
        Activity activity = this.b();
        if (activity != null) {
            if (activity.isFinishing()) {
                return;
            }
            int n4 = new PackageManagerHelper((Context)activity).getPackageVersionCode(this.g);
            HashMap hashMap = new HashMap();
            hashMap.put((Object)"package", (Object)activity.getPackageName());
            hashMap.put((Object)"target_package", (Object)this.g);
            hashMap.put((Object)"target_ver", (Object)String.valueOf((int)n4));
            hashMap.put((Object)"sdk_ver", (Object)String.valueOf((int)50300301));
            hashMap.put((Object)"app_id", (Object)AGCUtils.getAppId((Context)activity));
            hashMap.put((Object)"trigger_api", (Object)"core.connnect");
            hashMap.put((Object)"update_type", (Object)String.valueOf((int)n3));
            hashMap.put((Object)"net_type", (Object)String.valueOf((int)NetWorkUtil.getNetworkType((Context)activity)));
            hashMap.put((Object)"result", (Object)this.b(n2, n3));
            HiAnalyticsUtils.getInstance().onEvent((Context)activity, "HMS_SDK_UPDATE", (Map<String, String>)hashMap);
        }
    }

    public void a(q q2) {
    }

    public final void a(UpdateBean updateBean) {
        this.c = updateBean;
    }

    public abstract void a(Class<? extends q> var1);

    public final void a(ArrayList arrayList) {
        void var3_7;
        String string = arrayList != null && arrayList.size() > 0 ? p.a((Integer)arrayList.get(0)) : null;
        if (string == null) {
            return;
        }
        try {
            this.b = (IBridgeActivityDelegate)Class.forName(string).asSubclass(IBridgeActivityDelegate.class).newInstance();
            return;
        }
        catch (ClassNotFoundException classNotFoundException) {
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (InstantiationException instantiationException) {
        }
        catch (ClassCastException classCastException) {
            // empty catch block
        }
        StringBuilder stringBuilder = b.a((String)"getBridgeActivityDelegate error");
        stringBuilder.append(var3_7.getMessage());
        HMSLog.e("AbsUpdateWizard", stringBuilder.toString());
    }

    public boolean a(String string, int n2) {
        if (TextUtils.isEmpty((CharSequence)string)) {
            return false;
        }
        Activity activity = this.b();
        boolean bl2 = false;
        if (activity != null) {
            if (activity.isFinishing()) {
                return false;
            }
            int n3 = new PackageManagerHelper((Context)activity).getPackageVersionCode(string);
            bl2 = false;
            if (n3 >= n2) {
                bl2 = true;
            }
        }
        return bl2;
    }

    public boolean a(boolean bl2) {
        Activity activity = this.b();
        if (activity == null) {
            return false;
        }
        ArrayList arrayList = this.c.getTypeList();
        if (arrayList.size() > 0) {
            arrayList.remove(0);
        }
        if (this.b == null) {
            this.a(arrayList);
        }
        IBridgeActivityDelegate iBridgeActivityDelegate = this.b;
        boolean bl3 = false;
        if (iBridgeActivityDelegate != null) {
            this.e = bl3 = true;
            this.c.setTypeList(arrayList);
            this.c.setNeedConfirm(bl2);
            IBridgeActivityDelegate iBridgeActivityDelegate2 = this.b;
            if (iBridgeActivityDelegate2 instanceof p) {
                ((p)iBridgeActivityDelegate2).a(this.c);
            }
            this.b.onBridgeActivityCreate(activity);
        }
        return bl3;
    }

    public Activity b() {
        WeakReference<Activity> weakReference = this.a;
        if (weakReference == null) {
            return null;
        }
        return (Activity)weakReference.get();
    }

    public final String b(int n2, int n3) {
        String string = String.valueOf((int)n2);
        if (n3 != 0) {
            if (n3 != 5) {
                if (n3 != 6) {
                    return string;
                }
                return n.a((String)"4000", (String)string);
            }
            return n.a((String)"5000", (String)string);
        }
        return n.a((String)"0000", (String)string);
    }

    public void b(q q2) {
    }

    public void c(int n2, int n3) {
        Activity activity = this.b();
        if (activity != null) {
            if (activity.isFinishing()) {
                return;
            }
            this.a(n2, n3);
            Intent intent = new Intent();
            intent.putExtra("intent.extra.DELEGATE_CLASS_OBJECT", this.getClass().getName());
            intent.putExtra("intent.extra.RESULT", n2);
            activity.setResult(-1, intent);
            activity.finish();
        }
    }

    public void onBridgeActivityCreate(Activity activity) {
        this.a = new WeakReference((Object)activity);
        if (this.c == null) {
            UpdateBean updateBean;
            Intent intent = activity.getIntent();
            if (intent == null) {
                return;
            }
            this.c = updateBean = (UpdateBean)intent.getSerializableExtra("intent.extra.update.info");
            if (updateBean == null) {
                return;
            }
        }
        this.g = this.c.b();
        this.h = this.c.getClientAppName();
        this.i = this.c.c();
        this.c.a();
        this.b = null;
        this.e = false;
        this.f = -1;
    }

    public void onBridgeActivityDestroy() {
        IBridgeActivityDelegate iBridgeActivityDelegate;
        this.a = null;
        this.a();
        if (this.e && (iBridgeActivityDelegate = this.b) != null) {
            iBridgeActivityDelegate.onBridgeActivityDestroy();
        }
    }

    public void onBridgeConfigurationChanged() {
        IBridgeActivityDelegate iBridgeActivityDelegate;
        if (this.e && (iBridgeActivityDelegate = this.b) != null) {
            iBridgeActivityDelegate.onBridgeConfigurationChanged();
            return;
        }
        q q2 = this.d;
        if (q2 == null) {
            return;
        }
        Class class_ = q2.getClass();
        this.d.b();
        this.d = null;
        this.a((Class<? extends q>)class_);
    }

    public void onKeyUp(int n2, KeyEvent keyEvent) {
        IBridgeActivityDelegate iBridgeActivityDelegate;
        if (this.e && (iBridgeActivityDelegate = this.b) != null) {
            iBridgeActivityDelegate.onKeyUp(n2, keyEvent);
        }
    }
}

