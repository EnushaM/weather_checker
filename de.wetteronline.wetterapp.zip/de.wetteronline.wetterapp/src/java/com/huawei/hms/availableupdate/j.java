/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 */
package com.huawei.hms.availableupdate;

public class j
extends Exception {
    public j(String string2) {
        super(string2);
    }
}

