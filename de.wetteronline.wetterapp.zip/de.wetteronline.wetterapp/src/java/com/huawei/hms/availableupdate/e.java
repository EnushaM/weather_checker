/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Environment
 *  android.text.TextUtils
 *  java.io.File
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 */
package com.huawei.hms.availableupdate;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import com.huawei.hms.availableupdate.b;
import com.huawei.hms.availableupdate.c;
import com.huawei.hms.availableupdate.f;
import com.huawei.hms.availableupdate.g;
import com.huawei.hms.availableupdate.h;
import com.huawei.hms.availableupdate.j;
import com.huawei.hms.availableupdate.k;
import com.huawei.hms.availableupdate.l;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.update.provider.UpdateProvider;
import com.huawei.hms.utils.Checker;
import com.huawei.hms.utils.FileUtil;
import com.huawei.hms.utils.IOUtils;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

public class e
implements f {
    public final Context a;
    public final l b = new k();
    public final b c = new b();
    public g d;
    public File e;

    public e(Context context) {
        this.a = context.getApplicationContext();
    }

    public final c a(File file, final int n2, final String string) throws IOException {
        c c3 = new c(file, n2){
            public long b;
            public int c;
            {
                super(file, n22);
                this.b = 0L;
                this.c = e.this.c.a();
            }

            public final void a(int n22) {
                e.this.c.a(e.this.b(), n22, string);
                e.this.a(2100, n22, n2);
            }

            @Override
            public void write(byte[] arrby, int n22, int n3) throws IOException {
                int n4;
                int n5;
                super.write(arrby, n22, n3);
                this.c = n4 = n3 + this.c;
                if (n4 > 209715200) {
                    return;
                }
                long l4 = System.currentTimeMillis();
                if (Math.abs((long)(l4 - this.b)) > 1000L) {
                    this.b = l4;
                    this.a(this.c);
                }
                if ((n5 = this.c) == n2) {
                    this.a(n5);
                }
            }
        };
        return c3;
    }

    @Override
    public void a() {
        HMSLog.i("UpdateDownload", "Enter cancel.");
        this.a((g)null);
        this.b.a();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(int n2, int n3, int n4) {
        e e2 = this;
        synchronized (e2) {
            g g2 = this.d;
            if (g2 != null) {
                g2.a(n2, n3, n4, this.e);
            }
            return;
        }
    }

    public final void a(g g2) {
        e e2 = this;
        synchronized (e2) {
            this.d = g2;
            return;
        }
    }

    @Override
    public void a(g g2, h h2) {
        Checker.checkNonNull(g2, "callback must not be null.");
        HMSLog.i("UpdateDownload", "Enter downloadPackage.");
        this.a(g2);
        if (h2 != null && h2.a()) {
            File file;
            if (!"mounted".equals((Object)Environment.getExternalStorageState())) {
                HMSLog.e("UpdateDownload", "In downloadPackage, Invalid external storage for downloading file.");
                this.a(2204, 0, 0);
                return;
            }
            String string = h2.b;
            if (TextUtils.isEmpty((CharSequence)string)) {
                HMSLog.e("UpdateDownload", "In DownloadHelper.downloadPackage, Download the package,  packageName is null: ");
                this.a(2201, 0, 0);
                return;
            }
            Context context = this.a;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string);
            stringBuilder.append(".apk");
            this.e = file = UpdateProvider.getLocalFile(context, stringBuilder.toString());
            if (file == null) {
                HMSLog.e("UpdateDownload", "In downloadPackage, Failed to get local file for downloading.");
                this.a(2204, 0, 0);
                return;
            }
            File file2 = file.getParentFile();
            if (file2 != null && (file2.mkdirs() || file2.isDirectory())) {
                if (file2.getUsableSpace() < (long)(3 * h2.d)) {
                    HMSLog.e("UpdateDownload", "In downloadPackage, No space for downloading file.");
                    this.a(2203, 0, 0);
                    return;
                }
                try {
                    this.a(h2);
                    return;
                }
                catch (j j2) {
                    HMSLog.w("UpdateDownload", "In downloadPackage, Canceled to download the update file.");
                    this.a(2101, 0, 0);
                    return;
                }
            }
            HMSLog.e("UpdateDownload", "In downloadPackage, Failed to create directory for downloading file.");
            this.a(2201, 0, 0);
            return;
        }
        HMSLog.e("UpdateDownload", "In downloadPackage, Invalid update info.");
        this.a(2201, 0, 0);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void a(h var1_1) throws j {
        block13 : {
            block12 : {
                block11 : {
                    block10 : {
                        block14 : {
                            block9 : {
                                block8 : {
                                    HMSLog.i("UpdateDownload", "Enter downloadPackage.");
                                    var2_2 = null;
                                    var8_3 = var1_1.b;
                                    if (!TextUtils.isEmpty((CharSequence)var8_3)) break block8;
                                    HMSLog.e("UpdateDownload", "In DownloadHelper.downloadPackage, Download the package,  packageName is null: ");
                                    this.a(2201, 0, 0);
                                    this.b.close();
                                    IOUtils.closeQuietly(null);
                                    return;
                                }
                                this.c.a(this.b(), var8_3);
                                var9_4 = this.c.b(var1_1.c, var1_1.d, var1_1.e);
                                var2_2 = null;
                                if (!var9_4) ** GOTO lbl36
                                var10_5 = this.c.a();
                                var11_6 = this.c.b();
                                var2_2 = null;
                                if (var10_5 != var11_6) ** GOTO lbl33
                                var12_7 = FileUtil.verifyHash(var1_1.e, this.e);
                                var2_2 = null;
                                if (!var12_7) break block9;
                                this.a(2000, 0, 0);
                                this.b.close();
                                IOUtils.closeQuietly(null);
                                return;
                            }
                            this.c.a(var1_1.c, var1_1.d, var1_1.e);
                            var2_2 = this.a(this.e, var1_1.d, var8_3);
                            break block14;
lbl33: // 1 sources:
                            var2_2 = this.a(this.e, var1_1.d, var8_3);
                            var2_2.a(this.c.a());
                            break block14;
lbl36: // 1 sources:
                            this.c.a(var1_1.c, var1_1.d, var1_1.e);
                            var2_2 = this.a(this.e, var1_1.d, var8_3);
                        }
                        var13_8 = this.b;
                        var14_9 = var1_1.c;
                        var15_10 = this.c.a();
                        var16_11 = this.c.b();
                        var17_12 = this.a;
                        var18_13 = var13_8.a(var14_9, var2_2, var15_10, var16_11, var17_12);
                        if (var18_13 == 200 || var18_13 == 206) break block10;
                        var19_14 = new StringBuilder();
                        var19_14.append("In DownloadHelper.downloadPackage, Download the package, HTTP code: ");
                        var19_14.append(var18_13);
                        HMSLog.e("UpdateDownload", var19_14.toString());
                        this.a(2201, 0, 0);
                        this.b.close();
                        IOUtils.closeQuietly(var2_2);
                        return;
                    }
                    if (FileUtil.verifyHash(var1_1.e, this.e)) break block11;
                    this.a(2202, 0, 0);
                    this.b.close();
                    IOUtils.closeQuietly(var2_2);
                    return;
                }
                try {
                    this.a(2000, 0, 0);
                    break block12;
                }
                catch (Throwable var7_15) {
                    break block13;
                }
                catch (IOException var3_16) {
                    var4_17 = new StringBuilder();
                    var4_17.append("In DownloadHelper.downloadPackage, Failed to download.");
                    var4_17.append(var3_16.getMessage());
                    HMSLog.e("UpdateDownload", var4_17.toString());
                    this.a(2201, 0, 0);
                }
            }
            this.b.close();
            IOUtils.closeQuietly(var2_2);
            return;
        }
        this.b.close();
        IOUtils.closeQuietly(var2_2);
        throw var7_15;
    }

    public Context b() {
        return this.a;
    }

}

