/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.ProgressDialog
 *  android.content.Context
 *  java.lang.CharSequence
 */
package com.huawei.hms.availableupdate;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import com.huawei.hms.availableupdate.q;
import com.huawei.hms.utils.ResourceLoaderUtil;

public class s
extends q {
    @Override
    public AlertDialog g() {
        ProgressDialog progressDialog = new ProgressDialog((Context)this.e(), this.f());
        progressDialog.setMessage((CharSequence)ResourceLoaderUtil.getString("hms_checking"));
        progressDialog.setCanceledOnTouchOutside(false);
        return progressDialog;
    }
}

