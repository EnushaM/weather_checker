/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.huawei.hms.support.log.HMSLog
 *  com.huawei.hms.utils.IOUtils
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.io.RandomAccessFile
 *  java.lang.String
 */
package com.huawei.hms.availableupdate;

import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.utils.IOUtils;
import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;

public class c
extends OutputStream {
    public RandomAccessFile a;

    public c(File file, int n2) {
        try {
            RandomAccessFile randomAccessFile;
            this.a = randomAccessFile = new RandomAccessFile(file, "rwd");
            randomAccessFile.setLength((long)n2);
            return;
        }
        catch (IOException iOException) {
            IOUtils.closeQuietly((Closeable)this.a);
            HMSLog.e((String)"RandomFileOutputStream", (String)"create  file stream failed");
            return;
        }
        catch (FileNotFoundException fileNotFoundException) {
            HMSLog.e((String)"RandomFileOutputStream", (String)"create  file stream failed");
            return;
        }
    }

    public void a(long l2) throws IOException {
        RandomAccessFile randomAccessFile = this.a;
        if (randomAccessFile != null) {
            randomAccessFile.seek(l2);
        }
    }

    public void close() throws IOException {
        RandomAccessFile randomAccessFile = this.a;
        if (randomAccessFile != null) {
            randomAccessFile.close();
        }
    }

    public void write(int n2) throws IOException {
        byte[] arrby = new byte[]{(byte)n2};
        this.write(arrby, 0, 1);
    }

    public void write(byte[] arrby, int n2, int n3) throws IOException {
        RandomAccessFile randomAccessFile = this.a;
        if (randomAccessFile != null) {
            randomAccessFile.write(arrby, n2, n3);
        }
    }
}

