/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.huawei.hms.availableupdate.u
 *  com.huawei.hms.utils.ResourceLoaderUtil
 *  java.lang.String
 */
package com.huawei.hms.availableupdate;

import com.huawei.hms.availableupdate.t;
import com.huawei.hms.availableupdate.u;
import com.huawei.hms.utils.ResourceLoaderUtil;

public class x
extends u {
    public x() {
        super(null);
    }

    public int h() {
        return ResourceLoaderUtil.getStringId((String)"hms_abort_message");
    }

    public int i() {
        return ResourceLoaderUtil.getStringId((String)"hms_cancel");
    }

    public int j() {
        return ResourceLoaderUtil.getStringId((String)"hms_abort");
    }
}

