/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ActivityNotFoundException
 *  android.content.BroadcastReceiver
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Handler
 *  android.support.v4.media.b
 *  android.text.TextUtils
 *  android.view.KeyEvent
 *  com.huawei.hms.activity.IBridgeActivityDelegate
 *  com.huawei.hms.adapter.a
 *  com.huawei.hms.availableupdate.p
 *  com.huawei.hms.availableupdate.y
 *  com.huawei.hms.support.log.HMSLog
 *  com.huawei.hms.ui.SafeBundle
 *  com.huawei.hms.update.ui.UpdateBean
 *  com.huawei.hms.utils.ResourceLoaderUtil
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalStateException
 *  java.lang.InstantiationException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.huawei.hms.availableupdate;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.text.TextUtils;
import android.view.KeyEvent;
import com.huawei.hms.activity.IBridgeActivityDelegate;
import com.huawei.hms.availableupdate.g0;
import com.huawei.hms.availableupdate.o;
import com.huawei.hms.availableupdate.p;
import com.huawei.hms.availableupdate.q;
import com.huawei.hms.availableupdate.y;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.ui.SafeBundle;
import com.huawei.hms.update.ui.UpdateBean;
import com.huawei.hms.utils.ResourceLoaderUtil;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class g0
extends p {
    public BroadcastReceiver j;
    public Handler k = new Handler();
    public int l = 0;
    public Handler m = new Handler(this){
        public final /* synthetic */ g0 a;
        {
            this.a = g02;
        }

        public void handleMessage(android.os.Message message) {
            SafeBundle safeBundle = new SafeBundle((android.os.Bundle)message.obj);
            switch (message.what) {
                default: {
                    return;
                }
                case 103: {
                    g0.c(this.a, safeBundle);
                    return;
                }
                case 102: {
                    g0.b(this.a, safeBundle);
                    return;
                }
                case 101: 
            }
            g0.a(this.a, safeBundle);
        }
    };

    public static /* synthetic */ void a(g0 g02, SafeBundle safeBundle) {
        g02.a(safeBundle);
    }

    public static /* synthetic */ void b(g0 g02, SafeBundle safeBundle) {
        g02.b(safeBundle);
    }

    public static /* synthetic */ void c(g0 g02, SafeBundle safeBundle) {
        g02.c(safeBundle);
    }

    public final void a(SafeBundle safeBundle) {
        String string = safeBundle.containsKey("UpgradePkgName") ? safeBundle.getString("UpgradePkgName") : null;
        if (string != null) {
            if (!string.equals((Object)this.g)) {
                return;
            }
            if (safeBundle.containsKey("downloadtask.status")) {
                int n2 = safeBundle.getInt("downloadtask.status");
                com.huawei.hms.adapter.a.a((String)"handleDownloadStatus-status is ", (int)n2, (String)"SilentUpdateWizard");
                if (n2 != 3 && n2 != 5 && n2 != 6 && n2 != 8) {
                    if (n2 == 4) {
                        this.b(60000);
                        return;
                    }
                    this.b(20000);
                    return;
                }
                this.c(n2);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(Class<? extends q> class_) {
        void var2_7;
        try {
            q q2 = (q)class_.newInstance();
            int n2 = this.l;
            if (n2 > 0 && q2 instanceof y) {
                ((y)q2).a(n2);
            }
            q2.a(this);
            this.d = q2;
            return;
        }
        catch (IllegalStateException illegalStateException) {
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (InstantiationException instantiationException) {
            // empty catch block
        }
        StringBuilder stringBuilder = android.support.v4.media.b.a((String)"In showDialog, Failed to show the dialog.");
        stringBuilder.append(var2_7.getMessage());
        HMSLog.e((String)"SilentUpdateWizard", (String)stringBuilder.toString());
    }

    public final boolean a(Activity activity) {
        if (TextUtils.isEmpty((CharSequence)this.g)) {
            return false;
        }
        Intent intent = new Intent("com.huawei.appmarket.intent.action.ThirdUpdateAction");
        intent.setPackage("com.huawei.appmarket");
        JSONArray jSONArray = new JSONArray();
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("pkgName", (Object)this.g);
            jSONObject.put("versioncode", this.i);
        }
        catch (JSONException jSONException) {
            StringBuilder stringBuilder = android.support.v4.media.b.a((String)"create hmsJsonObject fail");
            stringBuilder.append(jSONException.getMessage());
            HMSLog.e((String)"SilentUpdateWizard", (String)stringBuilder.toString());
            return false;
        }
        jSONArray.put((Object)jSONObject);
        intent.putExtra("params", jSONArray.toString());
        intent.putExtra("isHmsOrApkUpgrade", this.c.d());
        intent.putExtra("buttonDlgY", ResourceLoaderUtil.getString((String)"hms_install"));
        intent.putExtra("buttonDlgN", ResourceLoaderUtil.getString((String)"hms_cancel"));
        intent.putExtra("upgradeDlgContent", ResourceLoaderUtil.getString((String)"hms_update_message_new", (Object[])new Object[]{"%P"}));
        try {
            HMSLog.i((String)"SilentUpdateWizard", (String)"start silent activity of AppMarket");
            activity.startActivityForResult(intent, this.getRequestCode());
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            HMSLog.e((String)"SilentUpdateWizard", (String)"ActivityNotFoundException");
            return false;
        }
        HMSLog.i((String)"SilentUpdateWizard", (String)"start silent activity finished");
        return true;
    }

    public final void b(int n2) {
        this.k.removeCallbacksAndMessages(null);
        this.k.postDelayed(new Runnable(null){
            {
                this();
            }

            public void run() {
                g0.this.c(14);
            }
        }, (long)n2);
    }

    public final void b(SafeBundle safeBundle) {
        String string = safeBundle.containsKey("UpgradePkgName") ? safeBundle.getString("UpgradePkgName") : null;
        if (string != null) {
            if (!string.equals((Object)this.g)) {
                return;
            }
            if (safeBundle.containsKey("UpgradeDownloadProgress") && safeBundle.containsKey("UpgradeAppName")) {
                q q2;
                int n2 = safeBundle.getInt("UpgradeDownloadProgress");
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("handlerDownloadProgress-progress is ");
                stringBuilder.append(n2);
                HMSLog.i((String)"SilentUpdateWizard", (String)stringBuilder.toString());
                this.b(20000);
                if (n2 >= 99) {
                    n2 = 99;
                }
                this.l = n2;
                if (this.d == null) {
                    this.a(y.class);
                }
                if ((q2 = this.d) != null) {
                    ((y)q2).b(n2);
                }
            }
        }
    }

    public final void c() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.huawei.appmarket.service.downloadservice.Receiver");
        intentFilter.addAction("com.huawei.appmarket.service.downloadservice.progress.Receiver");
        intentFilter.addAction("com.huawei.appmarket.service.installerservice.Receiver");
        this.j = new o(this.m);
        Activity activity = this.b();
        if (activity != null) {
            activity.registerReceiver(this.j, intentFilter);
        }
    }

    public final void c(int n2) {
        this.k.removeCallbacksAndMessages(null);
        this.d();
        this.a();
        if (!this.a(false)) {
            this.c(n2, this.f);
            return;
        }
        this.a(n2, this.f);
    }

    public final void c(SafeBundle safeBundle) {
        if (safeBundle.containsKey("packagename") && safeBundle.containsKey("status")) {
            String string = safeBundle.getString("packagename");
            int n2 = safeBundle.getInt("status");
            com.huawei.hms.adapter.a.a((String)"handlerInstallStatus-status is ", (int)n2, (String)"SilentUpdateWizard");
            if (string != null) {
                if (!string.equals((Object)this.g)) {
                    return;
                }
                if (n2 == 2) {
                    this.k.removeCallbacksAndMessages(null);
                    q q2 = this.d;
                    if (q2 != null) {
                        ((y)q2).b(100);
                    }
                    this.c(0, this.f);
                    return;
                }
                if (n2 != -1 && n2 != -2) {
                    this.b(60000);
                    return;
                }
                this.c(n2);
            }
        }
    }

    public final void d() {
        BroadcastReceiver broadcastReceiver;
        Activity activity = this.b();
        if (activity != null && (broadcastReceiver = this.j) != null) {
            activity.unregisterReceiver(broadcastReceiver);
            this.j = null;
        }
    }

    public void e() {
        this.c(13, this.f);
    }

    public int getRequestCode() {
        return 2000;
    }

    public void onBridgeActivityCreate(Activity activity) {
        super.onBridgeActivityCreate(activity);
        if (this.c == null) {
            return;
        }
        this.f = 0;
        if (!this.a(activity)) {
            if (!this.a(true)) {
                this.c(8, this.f);
                return;
            }
            this.a(8, this.f);
        }
    }

    public void onBridgeActivityDestroy() {
        this.k.removeCallbacksAndMessages(null);
        this.d();
        super.onBridgeActivityDestroy();
    }

    public boolean onBridgeActivityResult(int n2, int n3, Intent intent) {
        IBridgeActivityDelegate iBridgeActivityDelegate;
        if (this.e && (iBridgeActivityDelegate = this.b) != null) {
            return iBridgeActivityDelegate.onBridgeActivityResult(n2, n3, intent);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onBridgeActivityResult requestCode is ");
        stringBuilder.append(n2);
        stringBuilder.append("resultCode is ");
        stringBuilder.append(n3);
        HMSLog.i((String)"SilentUpdateWizard", (String)stringBuilder.toString());
        if (n2 == this.getRequestCode()) {
            if (n3 == 0) {
                this.c();
                this.b(20000);
                return true;
            }
            if (n3 == 4) {
                this.e();
                return true;
            }
            if (!this.a(true)) {
                this.c(n3, this.f);
                return true;
            }
            this.a(n3, this.f);
            return true;
        }
        return false;
    }

    public void onBridgeConfigurationChanged() {
        super.onBridgeConfigurationChanged();
    }

    public void onKeyUp(int n2, KeyEvent keyEvent) {
        super.onKeyUp(n2, keyEvent);
    }

}

