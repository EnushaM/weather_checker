/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.availableupdate;

public class h {
    public int a = 0;
    public String b = "";
    public String c = "";
    public int d = 0;
    public String e = "";

    public h(String string2, int n2, String string3, int n3, String string4) {
        this.b = string2;
        this.a = n2;
        this.c = string3;
        this.d = n3;
        this.e = string4;
    }

    public boolean a() {
        String string2;
        return this.a > 0 && this.d > 0 && (string2 = this.c) != null && !string2.isEmpty();
    }
}

