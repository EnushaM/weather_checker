/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package com.huawei.hms.availableupdate;

import android.app.Activity;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class m {
    public static final m c = new m();
    public static final Object d = new Object();
    public final AtomicBoolean a = new AtomicBoolean(false);
    public List<Activity> b = new ArrayList(1);

    public AtomicBoolean a() {
        return this.a;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(Activity activity) {
        Object object;
        Object object2 = object = d;
        synchronized (object2) {
            Iterator iterator = this.b.iterator();
            do {
                if (!iterator.hasNext()) {
                    this.b.add((Object)activity);
                    return;
                }
                Activity activity2 = (Activity)iterator.next();
                if (activity2 == null || activity2 == activity || activity2.isFinishing()) continue;
                activity2.finish();
            } while (true);
        }
    }

    public void a(boolean bl2) {
        this.a.set(bl2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void b(Activity activity) {
        Object object;
        Object object2 = object = d;
        synchronized (object2) {
            this.b.remove((Object)activity);
            return;
        }
    }
}

