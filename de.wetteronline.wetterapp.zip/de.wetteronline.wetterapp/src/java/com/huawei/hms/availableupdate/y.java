/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnKeyListener
 *  android.view.KeyEvent
 *  android.view.View
 *  android.widget.ProgressBar
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.text.NumberFormat
 */
package com.huawei.hms.availableupdate;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.huawei.hms.availableupdate.q;
import com.huawei.hms.availableupdate.y;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.utils.ResourceLoaderUtil;
import java.text.NumberFormat;

public class y
extends q {
    public ProgressBar c;
    public TextView d;
    public int e = 0;
    public DialogInterface.OnKeyListener f = new DialogInterface.OnKeyListener(null){
        {
            this();
        }

        public boolean onKey(DialogInterface dialogInterface, int n2, KeyEvent keyEvent) {
            return n2 == 4 && keyEvent.getRepeatCount() == 0;
        }
    };

    public void a(int n2) {
        this.e = n2;
    }

    public void b(int n2) {
        Activity activity = this.e();
        if (activity != null && !activity.isFinishing()) {
            if (this.d != null) {
                ProgressBar progressBar = this.c;
                if (progressBar == null) {
                    return;
                }
                progressBar.setProgress(n2);
                String string = NumberFormat.getPercentInstance().format((double)((float)n2 / 100.0f));
                this.d.setText((CharSequence)string);
            }
            return;
        }
        HMSLog.w("DownloadProgress", "In setDownloading, The activity is null or finishing.");
    }

    @Override
    public AlertDialog g() {
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this.e(), this.f());
        View view = View.inflate((Context)this.e(), (int)ResourceLoaderUtil.getLayoutId("hms_download_progress"), null);
        builder.setView(view);
        builder.setCancelable(false);
        builder.setOnKeyListener(this.f);
        this.c = (ProgressBar)view.findViewById(ResourceLoaderUtil.getIdId("download_info_progress"));
        this.d = (TextView)view.findViewById(ResourceLoaderUtil.getIdId("hms_progress_text"));
        this.b(this.e);
        return builder.create();
    }

}

