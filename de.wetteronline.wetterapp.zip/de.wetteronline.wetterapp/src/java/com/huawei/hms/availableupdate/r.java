/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.support.v4.media.b
 *  android.text.TextUtils
 *  android.view.KeyEvent
 *  com.huawei.hms.activity.IBridgeActivityDelegate
 *  com.huawei.hms.availableupdate.a0
 *  com.huawei.hms.availableupdate.p
 *  com.huawei.hms.support.log.HMSLog
 *  com.huawei.hms.update.ui.UpdateBean
 *  com.huawei.hms.utils.ResourceLoaderUtil
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalStateException
 *  java.lang.InstantiationException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 *  java.util.List
 */
package com.huawei.hms.availableupdate;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.support.v4.media.b;
import android.text.TextUtils;
import android.view.KeyEvent;
import com.huawei.hms.activity.IBridgeActivityDelegate;
import com.huawei.hms.availableupdate.a0;
import com.huawei.hms.availableupdate.p;
import com.huawei.hms.availableupdate.q;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.update.ui.UpdateBean;
import com.huawei.hms.utils.ResourceLoaderUtil;
import java.util.Iterator;
import java.util.List;

public class r
extends p {
    public final void a(Intent intent) {
        String string;
        Intent intent2 = new Intent("com.apptouch.intent.action.update_hms");
        List list = this.b().getPackageManager().queryIntentServices(intent2, 0);
        if (list != null && !list.isEmpty()) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ServiceInfo serviceInfo = ((ResolveInfo)iterator.next()).serviceInfo;
                if (serviceInfo == null || TextUtils.isEmpty((CharSequence)(string = serviceInfo.packageName))) continue;
                break;
            }
        } else {
            string = null;
        }
        if (!TextUtils.isEmpty(string)) {
            intent.setPackage(string);
        }
    }

    public void a(q q2) {
        HMSLog.i((String)"AppTouchWizard", (String)"Enter onCancel.");
        if (q2 instanceof a0) {
            this.d();
        }
    }

    public void a(Class<? extends q> class_) {
        void var2_7;
        this.a();
        try {
            q q2 = (q)class_.newInstance();
            if (!TextUtils.isEmpty((CharSequence)this.h) && q2 instanceof a0) {
                String string;
                this.h = string = ResourceLoaderUtil.getString((String)"hms_update_title");
                ((a0)q2).a(string);
            }
            q2.a(this);
            this.d = q2;
            return;
        }
        catch (IllegalStateException illegalStateException) {
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (InstantiationException instantiationException) {
            // empty catch block
        }
        StringBuilder stringBuilder = b.a((String)"In showDialog, Failed to show the dialog.");
        stringBuilder.append(var2_7.getMessage());
        HMSLog.e((String)"AppTouchWizard", (String)stringBuilder.toString());
    }

    public void b(q q2) {
        HMSLog.i((String)"AppTouchWizard", (String)"Enter onDoWork.");
        if (q2 instanceof a0) {
            q2.b();
            if (!this.c()) {
                this.a(8, this.f);
            }
        }
    }

    /*
     * Exception decompiling
     */
    public final boolean c() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl44 : ICONST_0 : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public void d() {
        this.c(13, this.f);
    }

    public int getRequestCode() {
        return 2007;
    }

    public void onBridgeActivityCreate(Activity activity) {
        super.onBridgeActivityCreate(activity);
        UpdateBean updateBean = this.c;
        if (updateBean == null) {
            return;
        }
        this.f = 7;
        if (updateBean.isNeedConfirm() && !TextUtils.isEmpty((CharSequence)this.h)) {
            this.a(a0.class);
            return;
        }
        if (!this.c()) {
            this.a(8, this.f);
        }
    }

    public void onBridgeActivityDestroy() {
        super.onBridgeActivityDestroy();
    }

    public boolean onBridgeActivityResult(int n2, int n3, Intent intent) {
        IBridgeActivityDelegate iBridgeActivityDelegate;
        if (this.e && (iBridgeActivityDelegate = this.b) != null) {
            return iBridgeActivityDelegate.onBridgeActivityResult(n2, n3, intent);
        }
        if (this.f == 7 && n2 == this.getRequestCode()) {
            if (this.a(this.g, this.i)) {
                this.c(0, this.f);
            } else {
                this.c(8, this.f);
            }
            return true;
        }
        return false;
    }

    public void onBridgeConfigurationChanged() {
        super.onBridgeConfigurationChanged();
    }

    public void onKeyUp(int n2, KeyEvent keyEvent) {
        IBridgeActivityDelegate iBridgeActivityDelegate;
        if (this.e && (iBridgeActivityDelegate = this.b) != null) {
            iBridgeActivityDelegate.onKeyUp(n2, keyEvent);
            return;
        }
        if (4 == n2) {
            HMSLog.i((String)"AppTouchWizard", (String)"In onKeyUp, Call finish.");
            Activity activity = this.b();
            if (activity != null && !activity.isFinishing()) {
                activity.setResult(0, null);
                activity.finish();
            }
        }
    }
}

