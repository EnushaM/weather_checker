/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.availableupdate;

import android.content.Context;
import android.content.SharedPreferences;

public class b {
    public String a;
    public int b;
    public String c;
    public int d;

    public int a() {
        return this.d;
    }

    public void a(Context context, int n2, String string2) {
        this.d = n2;
        this.b(context, string2);
    }

    public void a(Context context, String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("com.huawei.hms.update.DOWNLOAD_RECORD");
        stringBuilder.append(string2);
        SharedPreferences sharedPreferences = context.getSharedPreferences(stringBuilder.toString(), 0);
        this.a = sharedPreferences.getString("mUri", "");
        this.b = sharedPreferences.getInt("mSize", 0);
        this.c = sharedPreferences.getString("mHash", "");
        this.d = sharedPreferences.getInt("mReceived", 0);
    }

    public void a(String string2, int n2, String string3) {
        this.a = string2;
        this.b = n2;
        this.c = string3;
        this.d = 0;
    }

    public int b() {
        return this.b;
    }

    public final void b(Context context, String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("com.huawei.hms.update.DOWNLOAD_RECORD");
        stringBuilder.append(string2);
        SharedPreferences.Editor editor = context.getSharedPreferences(stringBuilder.toString(), 0).edit();
        editor.putString("mUri", this.a);
        editor.putInt("mSize", this.b);
        editor.putString("mHash", this.c);
        editor.putInt("mReceived", this.d);
        editor.commit();
    }

    public boolean b(String string2, int n2, String string3) {
        String string4;
        String string5;
        return string2 != null && string3 != null && (string4 = this.a) != null && string4.equals((Object)string2) && this.b == n2 && (string5 = this.c) != null && string5.equals((Object)string3) && this.d <= this.b;
    }
}

