/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.huawei.hms.availableupdate.c0
 *  com.huawei.hms.utils.ResourceLoaderUtil
 *  java.lang.String
 */
package com.huawei.hms.availableupdate;

import com.huawei.hms.availableupdate.b0;
import com.huawei.hms.availableupdate.c0;
import com.huawei.hms.utils.ResourceLoaderUtil;

public class f0
extends c0 {
    public f0() {
        super(null);
    }

    public int h() {
        return ResourceLoaderUtil.getStringId((String)"hms_download_no_space");
    }
}

