/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.res.Resources
 *  com.huawei.hms.availableupdate.p
 *  com.huawei.hms.support.log.HMSLog
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.availableupdate;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import com.huawei.hms.availableupdate.p;
import com.huawei.hms.support.log.HMSLog;

public abstract class q {
    public AlertDialog a;
    public p b;

    public static int a(Context context) {
        if (context == null) {
            return 0;
        }
        return context.getResources().getIdentifier("androidhwext:style/Theme.Emui", null, null);
    }

    public void a() {
        AlertDialog alertDialog = this.a;
        if (alertDialog != null) {
            alertDialog.cancel();
        }
    }

    public void a(p p2) {
        this.b = p2;
        if (this.e() != null && !this.e().isFinishing()) {
            AlertDialog alertDialog;
            this.a = alertDialog = this.g();
            alertDialog.setCanceledOnTouchOutside(false);
            this.a.setOnCancelListener(new DialogInterface.OnCancelListener(){

                public void onCancel(DialogInterface dialogInterface) {
                    q.this.c();
                }
            });
            this.a.show();
            return;
        }
        HMSLog.e((String)"AbstractDialog", (String)"In show, The activity is null or finishing.");
    }

    public void b() {
        AlertDialog alertDialog = this.a;
        if (alertDialog != null) {
            alertDialog.dismiss();
        }
    }

    public void c() {
        p p2 = this.b;
        if (p2 != null) {
            p2.a(this);
        }
    }

    public void d() {
        p p2 = this.b;
        if (p2 != null) {
            p2.b(this);
        }
    }

    public Activity e() {
        p p2 = this.b;
        if (p2 != null) {
            return p2.b();
        }
        return null;
    }

    public int f() {
        if (q.a((Context)this.e()) != 0) {
            return 0;
        }
        return 3;
    }

    public abstract AlertDialog g();

}

