/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.support.v4.media.b
 *  com.google.firebase.perf.network.FirebasePerfUrlConnection
 *  java.io.BufferedInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.URL
 *  java.net.URLConnection
 *  java.security.KeyManagementException
 *  java.security.KeyStoreException
 *  java.security.NoSuchAlgorithmException
 *  java.security.cert.CertificateException
 *  javax.net.ssl.HttpsURLConnection
 *  javax.net.ssl.SSLSocketFactory
 *  of.d
 */
package com.huawei.hms.availableupdate;

import android.content.Context;
import android.support.v4.media.b;
import com.google.firebase.perf.network.FirebasePerfUrlConnection;
import com.huawei.hms.availableupdate.j;
import com.huawei.hms.availableupdate.l;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.utils.IOUtils;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import of.d;

public class k
implements l {
    public HttpsURLConnection a;
    public volatile int b = -1;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int a(String string, OutputStream outputStream, int n2, int n3, Context context) throws IOException, j {
        int n4;
        InputStream inputStream;
        block9 : {
            block8 : {
                HttpsURLConnection httpsURLConnection;
                block7 : {
                    inputStream = null;
                    try {
                        this.a(string, context);
                        httpsURLConnection = this.a;
                        if (httpsURLConnection != null) break block7;
                        HMSLog.i("HttpRequestHelper", "mConnection is null");
                    }
                    catch (Throwable throwable) {
                        IOUtils.closeQuietly(inputStream);
                        throw throwable;
                    }
                    IOUtils.closeQuietly(null);
                    return -1;
                }
                httpsURLConnection.setRequestMethod("GET");
                inputStream = null;
                if (n2 > 0) {
                    HttpsURLConnection httpsURLConnection2 = this.a;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("bytes=");
                    stringBuilder.append(n2);
                    stringBuilder.append("-");
                    stringBuilder.append(n3);
                    httpsURLConnection2.addRequestProperty("Range", stringBuilder.toString());
                }
                n4 = this.a.getResponseCode();
                if (n2 > 0 && n4 == 206) break block8;
                inputStream = null;
                if (n2 > 0) break block9;
                inputStream = null;
                if (n4 != 200) break block9;
            }
            inputStream = this.a.getInputStream();
            this.a((InputStream)new BufferedInputStream(inputStream, 4096), outputStream);
            outputStream.flush();
        }
        IOUtils.closeQuietly(inputStream);
        return n4;
    }

    @Override
    public void a() {
        this.b = 1;
    }

    public final void a(InputStream inputStream, OutputStream outputStream) throws IOException, j {
        int n2;
        byte[] arrby = new byte[4096];
        while (-1 != (n2 = inputStream.read(arrby))) {
            outputStream.write(arrby, 0, n2);
            if (this.b != 1) continue;
            throw new j("HTTP(s) request was canceled.");
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(String string, Context context) throws IOException {
        void var4_12;
        URLConnection uRLConnection;
        if (this.b == 0) {
            HMSLog.e("HttpRequestHelper", "Not allowed to repeat open http(s) connection.");
        }
        if ((uRLConnection = (URLConnection)FirebasePerfUrlConnection.instrument((Object)new URL(string).openConnection())) == null) {
            HMSLog.i("HttpRequestHelper", "urlConnection is null");
            return;
        }
        if (!(uRLConnection instanceof HttpsURLConnection)) {
            HMSLog.i("HttpRequestHelper", "current request is http not allow connection");
            this.a = null;
            return;
        }
        this.a = (HttpsURLConnection)uRLConnection;
        try {
            d d2 = d.b((Context)context);
            if (d2 != null) {
                this.a.setSSLSocketFactory((SSLSocketFactory)d2);
            }
            this.a.setSSLSocketFactory((SSLSocketFactory)d2);
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (IllegalArgumentException illegalArgumentException) {
        }
        catch (KeyStoreException keyStoreException) {
        }
        catch (CertificateException certificateException) {
        }
        catch (IOException iOException) {
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
        }
        catch (KeyManagementException keyManagementException) {
            // empty catch block
        }
        this.a.setConnectTimeout(30000);
        this.a.setReadTimeout(30000);
        this.a.setDoInput(true);
        this.a.setDoOutput(true);
        this.a.setUseCaches(false);
        this.a.setInstanceFollowRedirects(true);
        this.b = 0;
        return;
        StringBuilder stringBuilder = b.a((String)"Failed to new TLSSocketFactory instance.");
        stringBuilder.append(var4_12.getMessage());
        HMSLog.e("HttpRequestHelper", stringBuilder.toString());
        throw new IOException("Failed to create SSLSocketFactory.");
    }

    @Override
    public void close() {
        this.b = -1;
        HttpsURLConnection httpsURLConnection = this.a;
        if (httpsURLConnection != null) {
            httpsURLConnection.disconnect();
        }
    }
}

