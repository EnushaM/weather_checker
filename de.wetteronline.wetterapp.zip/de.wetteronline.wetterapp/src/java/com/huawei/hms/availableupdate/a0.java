/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.availableupdate;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import com.huawei.hms.availableupdate.a0;
import com.huawei.hms.availableupdate.q;
import com.huawei.hms.utils.ResourceLoaderUtil;

public class a0
extends q {
    public String c = ResourceLoaderUtil.getString("hms_update_title");

    public void a(String string) {
        this.c = string;
    }

    @Override
    public AlertDialog g() {
        int n2 = ResourceLoaderUtil.getStringId("hms_update_message_new");
        int n3 = ResourceLoaderUtil.getStringId("hms_install");
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this.e(), this.f());
        Activity activity = this.e();
        Object[] arrobject = new Object[]{this.c};
        builder.setMessage((CharSequence)activity.getString(n2, arrobject));
        builder.setPositiveButton(n3, new DialogInterface.OnClickListener(this){
            public final /* synthetic */ a0 a;
            {
                this.a = a02;
            }

            public void onClick(DialogInterface dialogInterface, int n2) {
                this.a.d();
            }
        });
        builder.setNegativeButton(ResourceLoaderUtil.getStringId("hms_cancel"), new DialogInterface.OnClickListener(this){
            public final /* synthetic */ a0 a;
            {
                this.a = a02;
            }

            public void onClick(DialogInterface dialogInterface, int n2) {
                this.a.a();
            }
        });
        return builder.create();
    }
}

