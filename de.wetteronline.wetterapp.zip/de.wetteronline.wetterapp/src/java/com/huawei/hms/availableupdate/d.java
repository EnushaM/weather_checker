/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  java.io.File
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.Executor
 *  java.util.concurrent.Executors
 */
package com.huawei.hms.availableupdate;

import android.os.Handler;
import android.os.Looper;
import com.huawei.hms.availableupdate.d;
import com.huawei.hms.availableupdate.f;
import com.huawei.hms.availableupdate.g;
import com.huawei.hms.availableupdate.h;
import com.huawei.hms.utils.Checker;
import java.io.File;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class d
implements f {
    public static final Executor b = Executors.newSingleThreadExecutor();
    public final f a;

    public d(f f2) {
        Checker.checkNonNull(f2, "update must not be null.");
        this.a = f2;
    }

    public static /* synthetic */ f a(d d2) {
        return d2.a;
    }

    public static /* synthetic */ g a(g g2) {
        return d.b(g2);
    }

    public static g b(final g g2) {
        return new g(){

            @Override
            public void a(int n2, int n3, int n4, File file) {
                Handler handler = new Handler(Looper.getMainLooper());
                Runnable runnable = new Runnable(this, n2, n3, n4, file){
                    public final /* synthetic */ int a;
                    public final /* synthetic */ int b;
                    public final /* synthetic */ int c;
                    public final /* synthetic */ File d;
                    public final /* synthetic */ a e;
                    {
                        this.e = a2;
                        this.a = n2;
                        this.b = n3;
                        this.c = n4;
                        this.d = file;
                    }

                    public void run() {
                        this.e.g2.a(this.a, this.b, this.c, this.d);
                    }
                };
                handler.post(runnable);
            }

            @Override
            public void a(int n2, h h2) {
                new Handler(Looper.getMainLooper()).post(new Runnable(this, n2, h2){
                    public final /* synthetic */ int a;
                    public final /* synthetic */ h b;
                    public final /* synthetic */ a c;
                    {
                        this.c = a2;
                        this.a = n2;
                        this.b = h2;
                    }

                    public void run() {
                        this.c.g2.a(this.a, this.b);
                    }
                });
            }
        };
    }

    @Override
    public void a() {
        this.a.a();
    }

    @Override
    public void a(g g2, h h2) {
        b.execute(new Runnable(this, g2, h2){
            public final /* synthetic */ g a;
            public final /* synthetic */ h b;
            public final /* synthetic */ d c;
            {
                this.c = d2;
                this.a = g2;
                this.b = h2;
            }

            public void run() {
                d.a(this.c).a(d.a(this.a), this.b);
            }
        });
    }

}

