/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 */
package com.huawei.hms.availableupdate;

import com.huawei.hms.availableupdate.h;
import java.io.File;

public interface g {
    public void a(int var1, int var2, int var3, File var4);

    public void a(int var1, h var2);
}

