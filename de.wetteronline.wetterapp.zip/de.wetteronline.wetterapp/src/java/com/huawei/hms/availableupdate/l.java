/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.availableupdate;

import android.content.Context;
import com.huawei.hms.availableupdate.j;
import java.io.IOException;
import java.io.OutputStream;

public interface l {
    public int a(String var1, OutputStream var2, int var3, int var4, Context var5) throws IOException, j;

    public void a();

    public void close();
}

