/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.net.Uri$Builder
 *  com.huawei.hms.utils.Checker
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.availableupdate;

import android.content.Context;
import android.net.Uri;
import com.huawei.hms.utils.Checker;
import java.io.File;
import java.io.IOException;

public class n {
    public Context a;
    public String b;

    public static File a(File file) {
        if (file == null) {
            return null;
        }
        try {
            File file2 = file.getCanonicalFile();
            return file2;
        }
        catch (IOException iOException) {
            return null;
        }
    }

    public static String b(File file) {
        if (file == null) {
            return null;
        }
        try {
            String string2 = file.getCanonicalPath();
            return string2;
        }
        catch (IOException iOException) {
            return null;
        }
    }

    public Uri a(File file, String string2) {
        String string3 = n.b(file);
        if (string3 == null) {
            return null;
        }
        String string4 = this.b(string3);
        if (string4 == null) {
            return null;
        }
        return new Uri.Builder().scheme("content").authority(string2).encodedPath(string4).build();
    }

    public File a(Uri uri) {
        String string2 = uri.getEncodedPath();
        if (string2 == null) {
            return null;
        }
        String string3 = this.c(string2);
        if (string3 == null) {
            return null;
        }
        return n.a(new File(string3));
    }

    public File a(String string2) {
        String string3 = this.a();
        if (string3 == null) {
            return null;
        }
        return n.a(new File(string3, string2));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final String a() {
        Context context = (Context)Checker.assertNonNull((Object)this.a, (String)"mContext is null, call setContext first.");
        n n2 = this;
        synchronized (n2) {
            if (this.b != null) return this.b;
            this.b = context.getExternalCacheDir() != null ? n.b(context.getExternalCacheDir()) : n.b(context.getFilesDir());
            return this.b;
        }
    }

    public void a(Context context) {
        if (this.a == null) {
            Checker.checkNonNull((Object)context, (String)"context must not be null.");
            this.a = context;
        }
    }

    public final String b(String string2) {
        String string3 = this.a();
        if (string3 == null) {
            return null;
        }
        if (!string2.startsWith(string3)) {
            return null;
        }
        int n2 = string3.endsWith("/") ? string3.length() : 1 + string3.length();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Uri.encode((String)"ContentUriHelper"));
        stringBuilder.append('/');
        stringBuilder.append(string2.substring(n2));
        return stringBuilder.toString();
    }

    public final String c(String string2) {
        String string3 = this.a();
        if (string3 == null) {
            return null;
        }
        int n2 = string2.indexOf(47, 1);
        if (n2 < 0) {
            return null;
        }
        if (!"ContentUriHelper".equals((Object)Uri.decode((String)string2.substring(1, n2)))) {
            return null;
        }
        String string4 = n.b(new File(string3, Uri.decode((String)string2.substring(n2 + 1))));
        if (string4 == null) {
            return null;
        }
        if (!string4.startsWith(string3)) {
            return null;
        }
        return string4;
    }
}

