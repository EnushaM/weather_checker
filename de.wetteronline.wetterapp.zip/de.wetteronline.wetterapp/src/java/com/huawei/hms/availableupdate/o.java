/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Message
 *  com.huawei.hms.ui.SafeIntent
 *  java.lang.Object
 *  java.lang.String
 */
package com.huawei.hms.availableupdate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.huawei.hms.ui.SafeIntent;

public class o
extends BroadcastReceiver {
    public Handler a;

    public o(Handler handler) {
        this.a = handler;
    }

    public void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }
        SafeIntent safeIntent = new SafeIntent(intent);
        String string2 = safeIntent.getAction();
        if ("com.huawei.appmarket.service.downloadservice.Receiver".equals((Object)string2)) {
            Bundle bundle = safeIntent.getExtras();
            if (bundle == null) {
                return;
            }
            Message message = new Message();
            message.what = 101;
            message.obj = bundle;
            this.a.sendMessage(message);
            return;
        }
        if ("com.huawei.appmarket.service.downloadservice.progress.Receiver".equals((Object)string2)) {
            Bundle bundle = safeIntent.getExtras();
            if (bundle == null) {
                return;
            }
            Message message = new Message();
            message.what = 102;
            message.obj = bundle;
            this.a.sendMessage(message);
            return;
        }
        if ("com.huawei.appmarket.service.installerservice.Receiver".equals((Object)string2)) {
            Bundle bundle = safeIntent.getExtras();
            if (bundle == null) {
                return;
            }
            Message message = new Message();
            message.what = 103;
            message.obj = bundle;
            this.a.sendMessage(message);
        }
    }
}

