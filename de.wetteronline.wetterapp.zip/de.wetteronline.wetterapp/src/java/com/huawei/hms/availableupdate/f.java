/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.huawei.hms.availableupdate;

import com.huawei.hms.availableupdate.g;
import com.huawei.hms.availableupdate.h;

public interface f {
    public void a();

    public void a(g var1, h var2);
}

