/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.huawei.hms.core.aidl.IMessageEntity
 *  com.huawei.hms.core.aidl.a
 *  com.huawei.hms.core.aidl.b
 *  com.huawei.hms.core.aidl.c
 *  com.huawei.hms.core.aidl.d
 *  com.huawei.hms.core.aidl.e
 *  com.huawei.hms.support.api.client.AidlApiClient
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.huawei.hms.api;

import android.os.Bundle;
import com.huawei.hms.api.HuaweiApiClientImpl;
import com.huawei.hms.api.IPCCallback;
import com.huawei.hms.api.ProtocolNegotiate;
import com.huawei.hms.core.aidl.IMessageEntity;
import com.huawei.hms.core.aidl.RequestHeader;
import com.huawei.hms.core.aidl.a;
import com.huawei.hms.core.aidl.b;
import com.huawei.hms.core.aidl.c;
import com.huawei.hms.core.aidl.d;
import com.huawei.hms.core.aidl.e;
import com.huawei.hms.support.api.client.AidlApiClient;
import com.huawei.hms.support.api.client.ApiClient;
import com.huawei.hms.support.api.transport.DatagramTransport;
import com.huawei.hms.support.log.HMSLog;
import java.util.List;

public class IPCTransport
implements DatagramTransport {
    private final String a;
    private final IMessageEntity b;
    private final Class<? extends IMessageEntity> c;
    private int d;

    public IPCTransport(String string, IMessageEntity iMessageEntity, Class<? extends IMessageEntity> class_) {
        this.a = string;
        this.b = iMessageEntity;
        this.c = class_;
    }

    public IPCTransport(String string, IMessageEntity iMessageEntity, Class<? extends IMessageEntity> class_, int n2) {
        this.a = string;
        this.b = iMessageEntity;
        this.c = class_;
        this.d = n2;
    }

    private int a(ApiClient apiClient, c c3) {
        if (apiClient instanceof HuaweiApiClientImpl) {
            HuaweiApiClientImpl huaweiApiClientImpl;
            b b2;
            block7 : {
                b2 = new b(this.a, ProtocolNegotiate.getInstance().getVersion());
                e e2 = a.a((int)b2.c());
                b2.a(e2.a(this.b, new Bundle()));
                RequestHeader requestHeader = new RequestHeader();
                requestHeader.setAppID(apiClient.getAppID());
                requestHeader.setPackageName(apiClient.getPackageName());
                requestHeader.setSdkVersion(50300301);
                requestHeader.setApiNameList(((HuaweiApiClientImpl)((Object)apiClient)).getApiNameList());
                requestHeader.setSessionId(apiClient.getSessionId());
                requestHeader.setApiLevel(this.d);
                b2.b = e2.a((IMessageEntity)requestHeader, new Bundle());
                try {
                    huaweiApiClientImpl = (HuaweiApiClientImpl)((Object)apiClient);
                    if (huaweiApiClientImpl.getService() != null) break block7;
                    HMSLog.e("IPCTransport", "HuaweiApiClient is not binded to service yet.");
                    return 907135001;
                }
                catch (Exception exception) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("sync call ex:");
                    stringBuilder.append((Object)exception);
                    HMSLog.e("IPCTransport", stringBuilder.toString());
                    return 907135001;
                }
            }
            huaweiApiClientImpl.getService().a(b2, c3);
            return 0;
        }
        if (apiClient instanceof AidlApiClient) {
            AidlApiClient aidlApiClient = (AidlApiClient)apiClient;
            int n2 = ProtocolNegotiate.getInstance().getVersion();
            b b3 = new b(this.a, n2);
            b3.a(a.a((int)b3.c()).a(this.b, new Bundle()));
            try {
                aidlApiClient.getService().a(b3, c3);
                return 0;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("sync call ex:");
                stringBuilder.append((Object)exception);
                HMSLog.e("IPCTransport", stringBuilder.toString());
            }
        }
        return 907135001;
    }

    @Override
    public final void post(ApiClient apiClient, DatagramTransport.a a2) {
        this.send(apiClient, a2);
    }

    @Override
    public final void send(ApiClient apiClient, DatagramTransport.a a2) {
        int n2 = this.a(apiClient, new IPCCallback(this.c, a2));
        if (n2 != 0) {
            a2.a(n2, null);
        }
    }
}

