/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package com.huawei.hms.api;

import android.app.Activity;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class a {
    public static final a b = new a();
    private static final Object c = new Object();
    public List<Activity> a = new ArrayList(1);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(Activity activity) {
        Object object;
        Object object2 = object = c;
        synchronized (object2) {
            Iterator iterator = this.a.iterator();
            do {
                if (!iterator.hasNext()) {
                    this.a.add((Object)activity);
                    return;
                }
                Activity activity2 = (Activity)iterator.next();
                if (activity2 == null || activity2 == activity || activity2.isFinishing()) continue;
                activity2.finish();
            } while (true);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void b(Activity activity) {
        Object object;
        Object object2 = object = c;
        synchronized (object2) {
            this.a.remove((Object)activity);
            return;
        }
    }
}

