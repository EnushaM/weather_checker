/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.view.KeyEvent
 *  com.huawei.hms.activity.IBridgeActivityDelegate
 *  com.huawei.hms.activity.internal.BusResponseCallback
 *  com.huawei.hms.activity.internal.BusResponseResult
 *  com.huawei.hms.activity.internal.ForegroundBusResponseMgr
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 */
package com.huawei.hms.api;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.KeyEvent;
import com.huawei.hms.activity.IBridgeActivityDelegate;
import com.huawei.hms.activity.internal.BusResponseCallback;
import com.huawei.hms.activity.internal.BusResponseResult;
import com.huawei.hms.activity.internal.ForegroundBusResponseMgr;
import com.huawei.hms.api.HuaweiApiAvailability;
import com.huawei.hms.support.log.HMSLog;
import java.lang.ref.WeakReference;

public class ResolutionDelegate
implements IBridgeActivityDelegate {
    public static final String CALLBACK_METHOD = "CALLBACK_METHOD";
    private WeakReference<Activity> a;

    private BusResponseCallback a(String string) {
        return ForegroundBusResponseMgr.getInstance().get(string);
    }

    private void a() {
        Activity activity = this.b();
        if (activity != null) {
            if (activity.isFinishing()) {
                return;
            }
            activity.finish();
        }
    }

    private Activity b() {
        WeakReference<Activity> weakReference = this.a;
        if (weakReference == null) {
            return null;
        }
        return (Activity)weakReference.get();
    }

    public int getRequestCode() {
        return 1002;
    }

    public void onBridgeActivityCreate(Activity activity) {
        this.a = new WeakReference((Object)activity);
        Bundle bundle = activity.getIntent().getExtras();
        if (bundle != null) {
            activity.startActivityForResult((Intent)bundle.getParcelable("resolution"), 1002);
        }
    }

    public void onBridgeActivityDestroy() {
        this.a = null;
    }

    public boolean onBridgeActivityResult(int n2, int n3, Intent intent) {
        if (n2 != this.getRequestCode()) {
            return false;
        }
        BusResponseCallback busResponseCallback = this.a(CALLBACK_METHOD);
        Activity activity = (Activity)this.a.get();
        int n4 = HuaweiApiAvailability.getInstance().isHuaweiMobileServicesAvailable((Context)activity, 30000000);
        if (n3 == -1 && n4 == 0) {
            HMSLog.i("ResolutionDelegate", "Make service available success.");
        } else {
            busResponseCallback.innerError((Activity)this.a.get(), n3, "Make service available failed.");
        }
        this.a();
        return true;
    }

    public void onBridgeConfigurationChanged() {
    }

    public void onKeyUp(int n2, KeyEvent keyEvent) {
    }
}

