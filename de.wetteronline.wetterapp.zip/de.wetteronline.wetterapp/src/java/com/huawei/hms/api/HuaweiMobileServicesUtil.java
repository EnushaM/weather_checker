/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Dialog
 *  android.app.Fragment
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.Resources
 *  com.huawei.hms.support.common.ActivityMgr
 *  com.huawei.hms.support.log.HMSLog
 *  com.huawei.hms.utils.Checker
 *  com.huawei.hms.utils.HMSPackageManager
 *  com.huawei.hms.utils.PackageManagerHelper
 *  com.huawei.hms.utils.PackageManagerHelper$PackageStates
 *  com.huawei.hms.utils.ReadApkFileUtil
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.api;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import com.huawei.hms.android.HwBuildEx;
import com.huawei.hms.api.HuaweiApiAvailability;
import com.huawei.hms.support.common.ActivityMgr;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.utils.Checker;
import com.huawei.hms.utils.HMSPackageManager;
import com.huawei.hms.utils.PackageManagerHelper;
import com.huawei.hms.utils.ReadApkFileUtil;

public abstract class HuaweiMobileServicesUtil {
    public static final String HMS_ERROR_DIALOG = "HuaweiMobileServicesErrorDialog";

    public static Dialog getErrorDialog(int n2, Activity activity, int n3) {
        return HuaweiApiAvailability.getInstance().getErrorDialog(activity, n2, n3, null);
    }

    public static Dialog getErrorDialog(int n2, Activity activity, int n3, DialogInterface.OnCancelListener onCancelListener) {
        return HuaweiApiAvailability.getInstance().getErrorDialog(activity, n2, n3, onCancelListener);
    }

    public static String getErrorString(int n2) {
        return HuaweiApiAvailability.getInstance().getErrorString(n2);
    }

    @Deprecated
    public static String getOpenSourceSoftwareLicenseInfo(Context context) {
        return "";
    }

    public static Context getRemoteContext(Context context) {
        try {
            Context context2 = context.createPackageContext(HMSPackageManager.getInstance((Context)context).getHMSPackageName(), 2);
            return context2;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return null;
        }
    }

    public static Resources getRemoteResource(Context context) {
        try {
            Resources resources = context.getPackageManager().getResourcesForApplication(HMSPackageManager.getInstance((Context)context).getHMSPackageName());
            return resources;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return null;
        }
    }

    public static int isHuaweiMobileServicesAvailable(Context context) {
        return HuaweiApiAvailability.getInstance().isHuaweiMobileServicesAvailable(context);
    }

    public static int isHuaweiMobileServicesAvailable(Context context, int n2) {
        String string2;
        Checker.checkNonNull((Object)context, (String)"context must not be null.");
        PackageManagerHelper packageManagerHelper = new PackageManagerHelper(context);
        String string3 = HMSPackageManager.getInstance((Context)context).getHMSPackageName();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("hmsPackageName is ");
        stringBuilder.append(string3);
        HMSLog.i((String)"HuaweiMobileServicesUtil", (String)stringBuilder.toString());
        PackageManagerHelper.PackageStates packageStates = HMSPackageManager.getInstance((Context)context).getHMSPackageStates();
        PackageManagerHelper.PackageStates packageStates2 = PackageManagerHelper.PackageStates.NOT_INSTALLED;
        if (packageStates2.equals((Object)packageStates)) {
            HMSLog.i((String)"HuaweiMobileServicesUtil", (String)"HMS is not installed");
            return 1;
        }
        String string4 = ReadApkFileUtil.getHmsPath((Context)context);
        if (HwBuildEx.VERSION.EMUI_SDK_INT < 5 && packageManagerHelper.getPackageVersionCode(string3) < 20500000 && ReadApkFileUtil.isCertFound((String)string4)) {
            String string5 = packageManagerHelper.getPackageSignature(string3);
            if (!("B92825C2BD5D6D6D1E7F39EECD17843B7D9016F611136B75441BC6F4D3F00F05".equalsIgnoreCase(string5) || "3517262215D8D3008CBF888750B6418EDC4D562AC33ED6874E0D73ABA667BC3C".equalsIgnoreCase(string5) || "3517262215D8D3008CBF888750B6418EDC4D562AC33ED6874E0D73ABA667BC3C".equalsIgnoreCase(string5))) {
                return 9;
            }
            return 2;
        }
        if (PackageManagerHelper.PackageStates.SPOOF.equals((Object)packageStates)) {
            HMSLog.i((String)"HuaweiMobileServicesUtil", (String)"HMS is spoofed");
            return 9;
        }
        if (PackageManagerHelper.PackageStates.DISABLED.equals((Object)packageStates)) {
            HMSLog.i((String)"HuaweiMobileServicesUtil", (String)"HMS is disabled");
            return 3;
        }
        if (packageStates2.equals((Object)packageStates) && !"B92825C2BD5D6D6D1E7F39EECD17843B7D9016F611136B75441BC6F4D3F00F05".equalsIgnoreCase(string2 = packageManagerHelper.getPackageSignature(string3)) && !"3517262215D8D3008CBF888750B6418EDC4D562AC33ED6874E0D73ABA667BC3C".equalsIgnoreCase(string2) && !"3517262215D8D3008CBF888750B6418EDC4D562AC33ED6874E0D73ABA667BC3C".equalsIgnoreCase(string2)) {
            return 9;
        }
        int n3 = HMSPackageManager.getInstance((Context)context).getHmsVersionCode();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("connect versionCode:");
        stringBuilder2.append(n3);
        HMSLog.i((String)"HuaweiMobileServicesUtil", (String)stringBuilder2.toString());
        if (HMSPackageManager.getInstance((Context)context).isApkUpdateNecessary(n2)) {
            HMSLog.i((String)"HuaweiMobileServicesUtil", (String)"The current version does not meet the minimum version requirements");
            return 2;
        }
        return 0;
    }

    public static boolean isUserRecoverableError(int n2) {
        return HuaweiApiAvailability.getInstance().isUserResolvableError(n2);
    }

    public static boolean popupErrDlgFragment(int n2, Activity activity, int n3, DialogInterface.OnCancelListener onCancelListener) {
        return HuaweiApiAvailability.getInstance().showErrorDialogFragment(activity, n2, n3, onCancelListener);
    }

    public static boolean popupErrDlgFragment(int n2, Activity activity, Fragment fragment, int n3, DialogInterface.OnCancelListener onCancelListener) {
        return HuaweiApiAvailability.getInstance().showErrorDialogFragment(activity, n2, fragment, n3, onCancelListener);
    }

    public static void setApplication(Application application) {
        ActivityMgr.INST.init(application);
    }

    public static boolean showErrorDialogFragment(int n2, Activity activity, int n3) {
        return HuaweiApiAvailability.getInstance().showErrorDialogFragment(activity, n2, n3, null);
    }

    public static void showErrorNotification(int n2, Context context) {
        HuaweiApiAvailability.getInstance().showErrorNotification(context, n2);
    }
}

