/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.huawei.hms.support.api.entity.auth.PermissionInfo
 *  com.huawei.hms.support.api.entity.auth.Scope
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.List
 */
package com.huawei.hms.api;

import com.huawei.hms.common.api.ConnectionPostProcessor;
import com.huawei.hms.support.api.entity.auth.PermissionInfo;
import com.huawei.hms.support.api.entity.auth.Scope;
import java.util.Collections;
import java.util.List;

public class Api<O extends ApiOptions> {
    private final String a;
    private final Options<O> b;
    public List<ConnectionPostProcessor> mConnetctPostList;

    public Api(String string2) {
        this.a = string2;
        this.b = null;
    }

    public Api(String string2, Options<O> options) {
        this.a = string2;
        this.b = options;
    }

    public String getApiName() {
        return this.a;
    }

    public Options<O> getOptions() {
        return this.b;
    }

    public List<ConnectionPostProcessor> getmConnetctPostList() {
        return this.mConnetctPostList;
    }

    public void setmConnetctPostList(List<ConnectionPostProcessor> list) {
        this.mConnetctPostList = list;
    }

    public static interface ApiOptions {
    }

    public static abstract class Options<O> {
        public List<PermissionInfo> getPermissionInfoList(O o2) {
            return Collections.emptyList();
        }

        public List<Scope> getScopeList(O o2) {
            return Collections.emptyList();
        }
    }

}

