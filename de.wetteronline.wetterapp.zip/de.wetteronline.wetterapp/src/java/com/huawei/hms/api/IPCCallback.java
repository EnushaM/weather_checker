/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.RemoteException
 *  android.support.v4.media.b
 *  android.text.TextUtils
 *  com.huawei.hms.core.aidl.IMessageEntity
 *  com.huawei.hms.core.aidl.ResponseHeader
 *  com.huawei.hms.core.aidl.a
 *  com.huawei.hms.core.aidl.b
 *  com.huawei.hms.core.aidl.c
 *  com.huawei.hms.core.aidl.c$a
 *  com.huawei.hms.core.aidl.e
 *  com.huawei.hms.support.api.transport.DatagramTransport
 *  com.huawei.hms.support.api.transport.DatagramTransport$a
 *  com.huawei.hms.support.log.HMSLog
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.InstantiationException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.huawei.hms.api;

import android.os.Bundle;
import android.os.RemoteException;
import android.text.TextUtils;
import com.huawei.hms.core.aidl.IMessageEntity;
import com.huawei.hms.core.aidl.ResponseHeader;
import com.huawei.hms.core.aidl.a;
import com.huawei.hms.core.aidl.b;
import com.huawei.hms.core.aidl.c;
import com.huawei.hms.core.aidl.e;
import com.huawei.hms.support.api.transport.DatagramTransport;
import com.huawei.hms.support.log.HMSLog;

public class IPCCallback
extends c.a {
    private final Class<? extends IMessageEntity> a;
    private final DatagramTransport.a b;

    public IPCCallback(Class<? extends IMessageEntity> class_, DatagramTransport.a a2) {
        this.a = class_;
        this.b = a2;
    }

    public void call(b b2) throws RemoteException {
        if (b2 != null && !TextUtils.isEmpty((CharSequence)b2.a)) {
            e e2 = a.a((int)b2.c());
            int n2 = b2.b();
            IMessageEntity iMessageEntity = null;
            if (n2 > 0 && (iMessageEntity = this.newResponseInstance()) != null) {
                e2.a(b2.a(), iMessageEntity);
            }
            if (b2.b != null) {
                ResponseHeader responseHeader = new ResponseHeader();
                e2.a(b2.b, (IMessageEntity)responseHeader);
                this.b.a(responseHeader.getStatusCode(), iMessageEntity);
                return;
            }
            this.b.a(0, iMessageEntity);
            return;
        }
        HMSLog.e((String)"IPCCallback", (String)"In call, URI cannot be empty.");
        throw new RemoteException();
    }

    public IMessageEntity newResponseInstance() {
        Class<? extends IMessageEntity> class_ = this.a;
        if (class_ != null) {
            void var2_5;
            try {
                IMessageEntity iMessageEntity = (IMessageEntity)class_.newInstance();
                return iMessageEntity;
            }
            catch (InstantiationException instantiationException) {
            }
            catch (IllegalAccessException illegalAccessException) {
                // empty catch block
            }
            StringBuilder stringBuilder = android.support.v4.media.b.a((String)"In newResponseInstance, instancing exception.");
            stringBuilder.append(var2_5.getMessage());
            HMSLog.e((String)"IPCCallback", (String)stringBuilder.toString());
        }
        return null;
    }
}

