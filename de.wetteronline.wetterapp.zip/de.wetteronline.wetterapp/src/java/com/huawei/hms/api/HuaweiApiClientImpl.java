/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.PendingIntent
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.RemoteException
 *  android.support.v4.media.b
 *  android.text.TextUtils
 *  com.huawei.hms.adapter.a
 *  com.huawei.hms.api.HuaweiApiClientImpl$a
 *  com.huawei.hms.api.HuaweiApiClientImpl$f
 *  com.huawei.hms.api.HuaweiApiClientImpl$g
 *  com.huawei.hms.api.HuaweiApiClientImpl$h
 *  com.huawei.hms.api.IPCTransport
 *  com.huawei.hms.core.aidl.IMessageEntity
 *  com.huawei.hms.core.aidl.RequestHeader
 *  com.huawei.hms.core.aidl.a
 *  com.huawei.hms.core.aidl.b
 *  com.huawei.hms.core.aidl.c
 *  com.huawei.hms.core.aidl.c$a
 *  com.huawei.hms.core.aidl.d
 *  com.huawei.hms.core.aidl.d$a
 *  com.huawei.hms.core.aidl.e
 *  com.huawei.hms.support.api.PendingResultImpl
 *  com.huawei.hms.support.api.ResolveResult
 *  com.huawei.hms.support.api.client.ApiClient
 *  com.huawei.hms.support.api.client.BundleResult
 *  com.huawei.hms.support.api.client.InnerApiClient
 *  com.huawei.hms.support.api.client.PendingResult
 *  com.huawei.hms.support.api.client.Result
 *  com.huawei.hms.support.api.client.ResultCallback
 *  com.huawei.hms.support.api.client.Status
 *  com.huawei.hms.support.api.client.SubAppInfo
 *  com.huawei.hms.support.api.core.ConnectService
 *  com.huawei.hms.support.api.entity.auth.PermissionInfo
 *  com.huawei.hms.support.api.entity.auth.Scope
 *  com.huawei.hms.support.api.entity.core.CheckConnectInfo
 *  com.huawei.hms.support.api.entity.core.ConnectInfo
 *  com.huawei.hms.support.api.entity.core.ConnectResp
 *  com.huawei.hms.support.api.entity.core.DisconnectInfo
 *  com.huawei.hms.support.api.entity.core.DisconnectResp
 *  com.huawei.hms.support.log.HMSLog
 *  com.huawei.hms.utils.Checker
 *  com.huawei.hms.utils.HMSPackageManager
 *  com.huawei.hms.utils.PackageManagerHelper
 *  com.huawei.hms.utils.UIUtil
 *  com.huawei.hms.utils.Util
 *  com.huawei.updatesdk.UpdateSdkAPI
 *  com.huawei.updatesdk.service.otaupdate.CheckUpdateCallBack
 *  java.io.FileDescriptor
 *  java.io.PrintWriter
 *  java.lang.CharSequence
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.ref.WeakReference
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.TimeUnit
 *  java.util.concurrent.atomic.AtomicInteger
 *  java.util.concurrent.locks.Condition
 *  java.util.concurrent.locks.ReentrantLock
 */
package com.huawei.hms.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.huawei.hms.api.Api;
import com.huawei.hms.api.CheckUpdatelistener;
import com.huawei.hms.api.ConnectionResult;
import com.huawei.hms.api.HuaweiApiAvailability;
import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.api.HuaweiApiClientImpl;
import com.huawei.hms.api.HuaweiMobileServicesUtil;
import com.huawei.hms.api.IPCTransport;
import com.huawei.hms.api.ProtocolNegotiate;
import com.huawei.hms.common.api.ConnectionPostProcessor;
import com.huawei.hms.common.internal.AutoLifecycleFragment;
import com.huawei.hms.core.aidl.IMessageEntity;
import com.huawei.hms.core.aidl.RequestHeader;
import com.huawei.hms.core.aidl.c;
import com.huawei.hms.core.aidl.d;
import com.huawei.hms.support.api.PendingResultImpl;
import com.huawei.hms.support.api.ResolveResult;
import com.huawei.hms.support.api.client.ApiClient;
import com.huawei.hms.support.api.client.BundleResult;
import com.huawei.hms.support.api.client.InnerApiClient;
import com.huawei.hms.support.api.client.PendingResult;
import com.huawei.hms.support.api.client.Result;
import com.huawei.hms.support.api.client.ResultCallback;
import com.huawei.hms.support.api.client.Status;
import com.huawei.hms.support.api.client.SubAppInfo;
import com.huawei.hms.support.api.core.ConnectService;
import com.huawei.hms.support.api.entity.auth.PermissionInfo;
import com.huawei.hms.support.api.entity.auth.Scope;
import com.huawei.hms.support.api.entity.core.CheckConnectInfo;
import com.huawei.hms.support.api.entity.core.ConnectInfo;
import com.huawei.hms.support.api.entity.core.ConnectResp;
import com.huawei.hms.support.api.entity.core.DisconnectInfo;
import com.huawei.hms.support.api.entity.core.DisconnectResp;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.utils.Checker;
import com.huawei.hms.utils.HMSPackageManager;
import com.huawei.hms.utils.PackageManagerHelper;
import com.huawei.hms.utils.UIUtil;
import com.huawei.hms.utils.Util;
import com.huawei.updatesdk.UpdateSdkAPI;
import com.huawei.updatesdk.service.otaupdate.CheckUpdateCallBack;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/*
 * Exception performing whole class analysis.
 */
public class HuaweiApiClientImpl
extends HuaweiApiClient
implements InnerApiClient,
ServiceConnection {
    private static final Object B;
    private static final Object C;
    public static final String DEFAULT_ACCOUNT = "<<default account>>";
    public static final int SIGN_IN_MODE_OPTIONAL = 2;
    public static final int SIGN_IN_MODE_REQUIRED = 1;
    private CheckUpdateCallBack A;
    private int a;
    private final Context b;
    private final String c;
    private String d;
    private String e;
    private volatile com.huawei.hms.core.aidl.d f;
    private String g;
    private WeakReference<Activity> h;
    private WeakReference<Activity> i;
    private boolean j;
    private AtomicInteger k;
    private List<Scope> l;
    private List<PermissionInfo> m;
    private Map<Api<?>, Api.ApiOptions> n;
    private SubAppInfo o;
    private long p;
    private int q;
    private final Object r;
    private final ReentrantLock s;
    private final Condition t;
    private ConnectionResult u;
    private HuaweiApiClient.ConnectionCallbacks v;
    private HuaweiApiClient.OnConnectionFailedListener w;
    private Handler x;
    private Handler y;
    private CheckUpdatelistener z;

    public static {
        B = new Object();
        C = new Object();
    }

    public HuaweiApiClientImpl(Context context) {
        String string;
        ReentrantLock reentrantLock;
        this.a = -1;
        this.j = false;
        this.k = new AtomicInteger(1);
        this.p = 0L;
        this.q = 0;
        this.r = new Object();
        this.s = reentrantLock = new ReentrantLock();
        this.t = reentrantLock.newCondition();
        this.x = null;
        this.y = null;
        this.z = null;
        this.b = context;
        this.c = string = Util.getAppId((Context)context);
        this.d = string;
        this.e = Util.getCpId((Context)context);
    }

    public static /* synthetic */ CheckUpdatelistener a(HuaweiApiClientImpl huaweiApiClientImpl) {
        return huaweiApiClientImpl.z;
    }

    public static /* synthetic */ CheckUpdatelistener a(HuaweiApiClientImpl huaweiApiClientImpl, CheckUpdatelistener checkUpdatelistener) {
        huaweiApiClientImpl.z = checkUpdatelistener;
        return checkUpdatelistener;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void a() {
        Object object;
        Intent intent = new Intent("com.huawei.hms.core.aidlservice");
        HMSPackageManager.getInstance((Context)this.b).refresh();
        intent.setPackage(HMSPackageManager.getInstance((Context)this.b).getHMSPackageName());
        Object object2 = object = B;
        synchronized (object2) {
            if (this.b.bindService(intent, (ServiceConnection)this, 1)) {
                this.i();
                return;
            }
        }
        this.c(1);
        HMSLog.e((String)"HuaweiApiClientImpl", (String)"In connect, bind core service fail");
        this.b();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void a(int n3) {
        Object object;
        if (n3 == 2) {
            Object object2;
            Object object3 = object2 = B;
            synchronized (object3) {
                Handler handler = this.x;
                if (handler != null) {
                    handler.removeMessages(n3);
                    this.x = null;
                }
            }
        }
        if (n3 == 3) {
            Object object4;
            Object object5 = object4 = C;
            synchronized (object5) {
                Handler handler = this.y;
                if (handler != null) {
                    handler.removeMessages(n3);
                    this.y = null;
                }
            }
        }
        Object object6 = object = B;
        synchronized (object6) {
            Handler handler = this.x;
            if (handler != null) {
                handler.removeMessages(2);
                this.x = null;
            }
            return;
        }
    }

    public static /* synthetic */ void a(HuaweiApiClientImpl huaweiApiClientImpl, int n3) {
        huaweiApiClientImpl.c(n3);
    }

    public static /* synthetic */ void a(HuaweiApiClientImpl huaweiApiClientImpl, ResolveResult resolveResult) {
        huaweiApiClientImpl.b((ResolveResult<DisconnectResp>)resolveResult);
    }

    private void a(ResolveResult<ConnectResp> resolveResult) {
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"Enter onConnectionResult");
        if (this.f != null && this.k.get() == 2) {
            SubAppInfo subAppInfo;
            String string;
            this.a(3);
            ConnectResp connectResp = (ConnectResp)resolveResult.getValue();
            if (connectResp != null) {
                this.g = connectResp.sessionId;
            }
            if (!TextUtils.isEmpty((CharSequence)(string = (subAppInfo = this.o) == null ? null : subAppInfo.getSubAppID()))) {
                this.d = string;
            }
            int n3 = resolveResult.getStatus().getStatusCode();
            com.huawei.hms.adapter.a.a((String)"Enter onConnectionResult, connect to server result: ", (int)n3, (String)"HuaweiApiClientImpl");
            if (Status.SUCCESS.equals((Object)resolveResult.getStatus())) {
                if (resolveResult.getValue() != null) {
                    ProtocolNegotiate.getInstance().negotiate((List<Integer>)((ConnectResp)resolveResult.getValue()).protocolVersion);
                }
                this.c(3);
                this.u = null;
                HuaweiApiClient.ConnectionCallbacks connectionCallbacks = this.v;
                if (connectionCallbacks != null) {
                    connectionCallbacks.onConnected();
                }
                if (this.h != null) {
                    this.n();
                }
                for (Map.Entry entry : this.getApiMap().entrySet()) {
                    if (((Api)entry.getKey()).getmConnetctPostList() == null || ((Api)entry.getKey()).getmConnetctPostList().isEmpty()) continue;
                    HMSLog.i((String)"HuaweiApiClientImpl", (String)"Enter onConnectionResult, get the ConnetctPostList ");
                    for (ConnectionPostProcessor connectionPostProcessor : ((Api)entry.getKey()).getmConnetctPostList()) {
                        HMSLog.i((String)"HuaweiApiClientImpl", (String)"Enter onConnectionResult, processor.run");
                        connectionPostProcessor.run(this, this.h);
                    }
                }
            } else if (resolveResult.getStatus() != null && resolveResult.getStatus().getStatusCode() == 1001) {
                this.o();
                this.c(1);
                HuaweiApiClient.ConnectionCallbacks connectionCallbacks = this.v;
                if (connectionCallbacks != null) {
                    connectionCallbacks.onConnectionSuspended(3);
                    return;
                }
            } else {
                this.o();
                this.c(1);
                if (this.w != null) {
                    WeakReference<Activity> weakReference = this.h;
                    PendingIntent pendingIntent = null;
                    if (weakReference != null) {
                        Object object = weakReference.get();
                        pendingIntent = null;
                        if (object != null) {
                            pendingIntent = HuaweiApiAvailability.getInstance().getResolveErrorPendingIntent((Activity)this.h.get(), n3);
                        }
                    }
                    ConnectionResult connectionResult = new ConnectionResult(n3, pendingIntent);
                    this.w.onConnectionFailed(connectionResult);
                    this.u = connectionResult;
                }
            }
            return;
        }
        HMSLog.e((String)"HuaweiApiClientImpl", (String)"Invalid onConnectionResult");
    }

    public static /* synthetic */ boolean a(HuaweiApiClientImpl huaweiApiClientImpl, boolean bl) {
        huaweiApiClientImpl.j = bl;
        return bl;
    }

    public static /* synthetic */ AtomicInteger b(HuaweiApiClientImpl huaweiApiClientImpl) {
        return huaweiApiClientImpl.k;
    }

    private void b() {
        this.o();
        if (this.w != null) {
            int n3 = UIUtil.isBackground((Context)this.b) ? 7 : 6;
            WeakReference<Activity> weakReference = this.h;
            PendingIntent pendingIntent = null;
            if (weakReference != null) {
                Object object = weakReference.get();
                pendingIntent = null;
                if (object != null) {
                    pendingIntent = HuaweiApiAvailability.getInstance().getResolveErrorPendingIntent((Activity)this.h.get(), n3);
                }
            }
            ConnectionResult connectionResult = new ConnectionResult(n3, pendingIntent);
            this.w.onConnectionFailed(connectionResult);
            this.u = connectionResult;
        }
    }

    private void b(int n3) {
        PendingIntent pendingIntent;
        WeakReference<Activity> weakReference = this.h;
        if (weakReference != null && weakReference.get() != null) {
            pendingIntent = HuaweiApiAvailability.getInstance().getResolveErrorPendingIntent((Activity)this.h.get(), n3);
            com.huawei.hms.adapter.a.a((String)"connect 2.0 fail: ", (int)n3, (String)"HuaweiApiClientImpl");
        } else {
            pendingIntent = null;
        }
        ConnectionResult connectionResult = new ConnectionResult(n3, pendingIntent);
        this.w.onConnectionFailed(connectionResult);
        this.u = connectionResult;
    }

    public static /* synthetic */ void b(HuaweiApiClientImpl huaweiApiClientImpl, ResolveResult resolveResult) {
        huaweiApiClientImpl.a((ResolveResult<ConnectResp>)resolveResult);
    }

    private void b(ResolveResult<DisconnectResp> resolveResult) {
        StringBuilder stringBuilder = android.support.v4.media.b.a((String)"Enter onDisconnectionResult, disconnect from server result: ");
        stringBuilder.append(resolveResult.getStatus().getStatusCode());
        HMSLog.i((String)"HuaweiApiClientImpl", (String)stringBuilder.toString());
        this.o();
        this.c(1);
    }

    private ConnectInfo c() {
        SubAppInfo subAppInfo;
        String string = new PackageManagerHelper(this.b).getPackageSignature(this.b.getPackageName());
        if (string == null) {
            string = "";
        }
        String string2 = (subAppInfo = this.o) == null ? null : subAppInfo.getSubAppID();
        return new ConnectInfo(this.getApiNameList(), this.l, string, string2);
    }

    private void c(int n3) {
        this.k.set(n3);
        if (n3 == 1 || n3 == 3 || n3 == 2) {
            this.s.lock();
            this.t.signalAll();
        }
        return;
        finally {
            this.s.unlock();
        }
    }

    public static /* synthetic */ void c(HuaweiApiClientImpl huaweiApiClientImpl) {
        huaweiApiClientImpl.b();
    }

    private DisconnectInfo d() {
        ArrayList arrayList = new ArrayList();
        Map<Api<?>, Api.ApiOptions> map = this.n;
        if (map != null) {
            Iterator iterator = map.keySet().iterator();
            while (iterator.hasNext()) {
                arrayList.add((Object)((Api)iterator.next()).getApiName());
            }
        }
        return new DisconnectInfo(this.l, (List)arrayList);
    }

    public static /* synthetic */ WeakReference d(HuaweiApiClientImpl huaweiApiClientImpl) {
        return huaweiApiClientImpl.h;
    }

    private int e() {
        int n3 = Util.getHmsVersion((Context)this.b);
        if (n3 != 0 && n3 >= 20503000) {
            return n3;
        }
        int n4 = this.f();
        if (this.h()) {
            if (n4 < 20503000) {
                return 20503000;
            }
            return n4;
        }
        if (n4 < 20600000) {
            n4 = 20600000;
        }
        return n4;
    }

    private int f() {
        Map<Api<?>, Api.ApiOptions> map = this.getApiMap();
        int n3 = 0;
        if (map == null) {
            return 0;
        }
        Iterator iterator = map.keySet().iterator();
        while (iterator.hasNext()) {
            int n4;
            Integer n6;
            String string = ((Api)iterator.next()).getApiName();
            if (TextUtils.isEmpty((CharSequence)string) || (n6 = (Integer)HuaweiApiAvailability.getApiMap().get((Object)string)) == null || (n4 = n6.intValue()) <= n3) continue;
            n3 = n4;
        }
        return n3;
    }

    private void g() {
        this.A = new a(this);
    }

    private boolean h() {
        Map<Api<?>, Api.ApiOptions> map = this.n;
        if (map != null) {
            Iterator iterator = map.keySet().iterator();
            while (iterator.hasNext()) {
                if (!"HuaweiGame.API".equals((Object)((Api)iterator.next()).getApiName())) continue;
                return true;
            }
        }
        return false;
    }

    private void i() {
        Handler handler = this.x;
        if (handler != null) {
            handler.removeMessages(2);
        } else {
            this.x = new Handler(Looper.getMainLooper(), new Handler.Callback(this){
                public final /* synthetic */ HuaweiApiClientImpl a;
                {
                    this.a = huaweiApiClientImpl;
                }

                public boolean handleMessage(android.os.Message message) {
                    if (message != null && message.what == 2) {
                        HMSLog.e((String)"HuaweiApiClientImpl", (String)"In connect, bind core service time out");
                        if (HuaweiApiClientImpl.b(this.a).get() == 5) {
                            HuaweiApiClientImpl.a(this.a, 1);
                            HuaweiApiClientImpl.c(this.a);
                        }
                        return true;
                    }
                    return false;
                }
            });
        }
        this.x.sendEmptyMessageDelayed(2, 5000L);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void j() {
        Object object;
        Object object2 = object = C;
        synchronized (object2) {
            Handler handler = this.y;
            if (handler != null) {
                handler.removeMessages(3);
            } else {
                this.y = new Handler(Looper.getMainLooper(), new Handler.Callback(this){
                    public final /* synthetic */ HuaweiApiClientImpl a;
                    {
                        this.a = huaweiApiClientImpl;
                    }

                    public boolean handleMessage(android.os.Message message) {
                        if (message != null && message.what == 3) {
                            HMSLog.e((String)"HuaweiApiClientImpl", (String)"In connect, process time out");
                            if (HuaweiApiClientImpl.b(this.a).get() == 2) {
                                HuaweiApiClientImpl.a(this.a, 1);
                                HuaweiApiClientImpl.c(this.a);
                            }
                            return true;
                        }
                        return false;
                    }
                });
            }
            boolean bl = this.y.sendEmptyMessageDelayed(3, 3000L);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("sendEmptyMessageDelayed for onConnectionResult 3 seconds. the result is : ");
            stringBuilder.append(bl);
            HMSLog.d((String)"HuaweiApiClientImpl", (String)stringBuilder.toString());
            return;
        }
    }

    private void k() {
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"Enter sendConnectApiServceRequest.");
        ConnectService.connect((ApiClient)this, (ConnectInfo)this.c()).setResultCallback((ResultCallback)new /* Unavailable Anonymous Inner Class!! */);
    }

    private void l() {
        ConnectService.disconnect((ApiClient)this, (DisconnectInfo)this.d()).setResultCallback((ResultCallback)new /* Unavailable Anonymous Inner Class!! */);
    }

    private void m() {
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"Enter sendForceConnectApiServceRequest.");
        ConnectService.forceConnect((ApiClient)this, (ConnectInfo)this.c()).setResultCallback((ResultCallback)new /* Unavailable Anonymous Inner Class!! */);
    }

    private void n() {
        if (this.j) {
            HMSLog.i((String)"HuaweiApiClientImpl", (String)"Connect notice has been shown.");
            return;
        }
        if (HuaweiApiAvailability.getInstance().isHuaweiMobileNoticeAvailable(this.b) == 0) {
            ConnectService.getNotice((ApiClient)this, (int)0, (String)"5.3.0.301").setResultCallback((ResultCallback)new /* Unavailable Anonymous Inner Class!! */);
        }
    }

    private void o() {
        Util.unBindServiceCatchException((Context)this.b, (ServiceConnection)this);
        this.f = null;
    }

    public int asyncRequest(Bundle bundle, String string, int n3, ResultCallback<BundleResult> resultCallback) {
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"Enter asyncRequest.");
        if (resultCallback != null && string != null && bundle != null) {
            if (!this.innerIsConnected()) {
                HMSLog.e((String)"HuaweiApiClientImpl", (String)"client is unConnect.");
                return 907135003;
            }
            com.huawei.hms.core.aidl.b b3 = new com.huawei.hms.core.aidl.b(string, n3);
            com.huawei.hms.core.aidl.e e3 = com.huawei.hms.core.aidl.a.a((int)b3.c());
            b3.a(bundle);
            RequestHeader requestHeader = new RequestHeader(this.getAppID(), this.getPackageName(), 50300301, this.getSessionId());
            requestHeader.setApiNameList(this.getApiNameList());
            b3.b = e3.a((IMessageEntity)requestHeader, new Bundle());
            try {
                this.getService().a(b3, (com.huawei.hms.core.aidl.c)new c.a(this, resultCallback){
                    public final /* synthetic */ ResultCallback a;
                    {
                        this.a = resultCallback;
                    }

                    public void call(com.huawei.hms.core.aidl.b b3) {
                        if (b3 != null) {
                            com.huawei.hms.core.aidl.e e3 = com.huawei.hms.core.aidl.a.a((int)b3.c());
                            com.huawei.hms.core.aidl.ResponseHeader responseHeader = new com.huawei.hms.core.aidl.ResponseHeader();
                            e3.a(b3.b, (IMessageEntity)responseHeader);
                            BundleResult bundleResult = new BundleResult(responseHeader.getStatusCode(), b3.a());
                            HMSLog.i((String)"HuaweiApiClientImpl", (String)"Exit asyncRequest onResult");
                            this.a.onResult((Object)bundleResult);
                            return;
                        }
                        HMSLog.i((String)"HuaweiApiClientImpl", (String)"Exit asyncRequest onResult -1");
                        this.a.onResult((Object)new BundleResult(-1, null));
                    }
                });
                return 0;
            }
            catch (RemoteException remoteException) {
                StringBuilder stringBuilder = android.support.v4.media.b.a((String)"remote exception:");
                stringBuilder.append(remoteException.getMessage());
                HMSLog.e((String)"HuaweiApiClientImpl", (String)stringBuilder.toString());
                return 907135001;
            }
        }
        HMSLog.e((String)"HuaweiApiClientImpl", (String)"arguments is invalid.");
        return 907135000;
    }

    @Override
    public void checkUpdate(Activity activity, CheckUpdatelistener checkUpdatelistener) {
        if (Util.isAvailableLibExist((Context)this.b)) {
            HMSLog.i((String)"HuaweiApiClientImpl", (String)"Enter checkUpdate");
            if (checkUpdatelistener == null) {
                HMSLog.e((String)"HuaweiApiClientImpl", (String)"listener is null!");
                return;
            }
            if (activity != null && !activity.isFinishing()) {
                this.z = checkUpdatelistener;
                if (this.A == null) {
                    this.g();
                }
                UpdateSdkAPI.checkClientOTAUpdate((Context)activity, (CheckUpdateCallBack)this.A, (boolean)true, (int)0, (boolean)true);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("checkUpdate, activity is illegal: ");
            stringBuilder.append((Object)activity);
            HMSLog.e((String)"HuaweiApiClientImpl", (String)stringBuilder.toString());
            checkUpdatelistener.onResult(-1);
            return;
        }
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"available lib does not exist.");
    }

    @Override
    public void connect(int n3) {
        this.connect(null);
    }

    @Override
    public void connect(Activity activity) {
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"====== HMSSDK version: 50300301 ======");
        int n3 = this.k.get();
        com.huawei.hms.adapter.a.a((String)"Enter connect, Connection Status: ", (int)n3, (String)"HuaweiApiClientImpl");
        if (n3 != 3 && n3 != 5 && n3 != 2) {
            if (n3 == 4) {
                return;
            }
            if (activity != null) {
                this.h = new WeakReference((Object)activity);
                this.i = new WeakReference((Object)activity);
            }
            String string = TextUtils.isEmpty((CharSequence)this.c) ? Util.getAppId((Context)this.b) : this.c;
            this.d = string;
            int n4 = this.e();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("connect minVersion:");
            stringBuilder.append(n4);
            HMSLog.i((String)"HuaweiApiClientImpl", (String)stringBuilder.toString());
            HuaweiApiAvailability.setServicesVersionCode(n4);
            int n6 = HuaweiMobileServicesUtil.isHuaweiMobileServicesAvailable(this.b, n4);
            com.huawei.hms.adapter.a.a((String)"In connect, isHuaweiMobileServicesAvailable result: ", (int)n6, (String)"HuaweiApiClientImpl");
            this.q = HMSPackageManager.getInstance((Context)this.b).getHmsVersionCode();
            if (n6 == 0) {
                this.c(5);
                if (this.f == null) {
                    this.a();
                    return;
                }
                this.c(2);
                this.k();
                this.j();
                return;
            }
            if (this.w != null) {
                this.b(n6);
            }
        }
    }

    @Override
    public void connectForeground() {
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"====== HMSSDK version: 50300301 ======");
        int n3 = this.k.get();
        com.huawei.hms.adapter.a.a((String)"Enter forceConnect, Connection Status: ", (int)n3, (String)"HuaweiApiClientImpl");
        if (n3 != 3 && n3 != 5 && n3 != 2) {
            if (n3 == 4) {
                return;
            }
            String string = TextUtils.isEmpty((CharSequence)this.c) ? Util.getAppId((Context)this.b) : this.c;
            this.d = string;
            this.m();
        }
    }

    @Override
    public void disableLifeCycleManagement(Activity activity) {
        if (this.a >= 0) {
            AutoLifecycleFragment autoLifecycleFragment = AutoLifecycleFragment.getInstance(activity);
            if (autoLifecycleFragment == null) {
                return;
            }
            autoLifecycleFragment.stopAutoManage(this.a);
            return;
        }
        throw new IllegalStateException("disableLifeCycleManagement failed");
    }

    @Override
    public PendingResult<Status> discardAndReconnect() {
        return new e((ApiClient)this, null, null);
    }

    @Override
    public void disconnect() {
        int n3 = this.k.get();
        com.huawei.hms.adapter.a.a((String)"Enter disconnect, Connection Status: ", (int)n3, (String)"HuaweiApiClientImpl");
        if (n3 != 2) {
            if (n3 != 3) {
                if (n3 != 5) {
                    return;
                }
                this.a(2);
                this.c(4);
                return;
            }
            this.c(4);
            this.l();
            return;
        }
        this.c(4);
    }

    @Override
    public Map<Api<?>, Api.ApiOptions> getApiMap() {
        return this.n;
    }

    public List<String> getApiNameList() {
        ArrayList arrayList = new ArrayList();
        Map<Api<?>, Api.ApiOptions> map = this.n;
        if (map != null) {
            Iterator iterator = map.keySet().iterator();
            while (iterator.hasNext()) {
                arrayList.add((Object)((Api)iterator.next()).getApiName());
            }
        }
        return arrayList;
    }

    public String getAppID() {
        return this.d;
    }

    @Override
    public ConnectionResult getConnectionResult(Api<?> api) {
        if (this.isConnected()) {
            this.u = null;
            return new ConnectionResult(0, null);
        }
        ConnectionResult connectionResult = this.u;
        if (connectionResult != null) {
            return connectionResult;
        }
        return new ConnectionResult(13, null);
    }

    public Context getContext() {
        return this.b;
    }

    public String getCpID() {
        return this.e;
    }

    public String getPackageName() {
        return this.b.getPackageName();
    }

    @Override
    public List<PermissionInfo> getPermissionInfos() {
        return this.m;
    }

    @Override
    public List<Scope> getScopes() {
        return this.l;
    }

    public com.huawei.hms.core.aidl.d getService() {
        return this.f;
    }

    public String getSessionId() {
        return this.g;
    }

    public final SubAppInfo getSubAppInfo() {
        return this.o;
    }

    @Override
    public Activity getTopActivity() {
        WeakReference<Activity> weakReference = this.i;
        if (weakReference == null) {
            return null;
        }
        return (Activity)weakReference.get();
    }

    public String getTransportName() {
        return IPCTransport.class.getName();
    }

    @Override
    public boolean hasConnectedApi(Api<?> api) {
        return this.isConnected();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean hasConnectionFailureListener(HuaweiApiClient.OnConnectionFailedListener onConnectionFailedListener) {
        Object object;
        Checker.checkNonNull((Object)onConnectionFailedListener, (String)"onConnectionFailedListener should not be null");
        Object object2 = object = this.r;
        synchronized (object2) {
            return this.w == onConnectionFailedListener;
            {
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean hasConnectionSuccessListener(HuaweiApiClient.ConnectionCallbacks connectionCallbacks) {
        Object object;
        Checker.checkNonNull((Object)connectionCallbacks, (String)"connectionCallbacksListener should not be null");
        Object object2 = object = this.r;
        synchronized (object2) {
            return this.v == connectionCallbacks;
            {
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public ConnectionResult holdUpConnect() {
        block10 : {
            block9 : {
                boolean bl;
                if (Looper.myLooper() == Looper.getMainLooper()) throw new IllegalStateException("blockingConnect must not be called on the UI thread");
                this.s.lock();
                this.connect(null);
                while (bl = this.isConnecting()) {
                    try {
                        this.t.await();
                    }
                    catch (InterruptedException interruptedException) {
                        Thread.currentThread().interrupt();
                        ConnectionResult connectionResult = new ConnectionResult(15, null);
                        this.s.unlock();
                        return connectionResult;
                    }
                }
                if (!this.isConnected()) break block9;
                this.u = null;
                ConnectionResult connectionResult = new ConnectionResult(0, null);
                this.s.unlock();
                return connectionResult;
            }
            ConnectionResult connectionResult = this.u;
            if (connectionResult == null) break block10;
            this.s.unlock();
            return connectionResult;
        }
        try {
            ConnectionResult connectionResult = new ConnectionResult(13, null);
            return connectionResult;
        }
        finally {
            this.s.unlock();
        }
    }

    @Override
    public ConnectionResult holdUpConnect(long l2, TimeUnit timeUnit) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            block14 : {
                block13 : {
                    this.s.lock();
                    this.connect(null);
                    long l3 = timeUnit.toNanos(l2);
                    while (this.isConnecting()) {
                        if (l3 > 0L) break block12;
                    }
                    {
                        block12 : {
                            this.disconnect();
                            ConnectionResult connectionResult = new ConnectionResult(14, null);
                            return connectionResult;
                        }
                        try {
                            l3 = this.t.awaitNanos(l3);
                            continue;
                        }
                        catch (InterruptedException interruptedException) {
                            Thread.currentThread().interrupt();
                            ConnectionResult connectionResult = new ConnectionResult(15, null);
                            this.s.unlock();
                            return connectionResult;
                        }
                    }
                    if (!this.isConnected()) break block13;
                    this.u = null;
                    ConnectionResult connectionResult = new ConnectionResult(0, null);
                    this.s.unlock();
                    return connectionResult;
                }
                ConnectionResult connectionResult = this.u;
                if (connectionResult == null) break block14;
                this.s.unlock();
                return connectionResult;
            }
            ConnectionResult connectionResult = new ConnectionResult(13, null);
            this.s.unlock();
            return connectionResult;
            finally {
                this.s.unlock();
            }
        }
        throw new IllegalStateException("blockingConnect must not be called on the UI thread");
    }

    public boolean innerIsConnected() {
        return this.k.get() == 3 || this.k.get() == 4;
        {
        }
    }

    @Override
    public boolean isConnected() {
        if (this.q == 0) {
            this.q = HMSPackageManager.getInstance((Context)this.b).getHmsVersionCode();
        }
        if (this.q < 20504000) {
            long l2 = System.currentTimeMillis() - this.p;
            if (l2 > 0L && l2 < 300000L) {
                return this.innerIsConnected();
            }
            if (this.innerIsConnected()) {
                Status status = ((ResolveResult)ConnectService.checkconnect((ApiClient)this, (CheckConnectInfo)new CheckConnectInfo()).awaitOnAnyThread(2000L, TimeUnit.MILLISECONDS)).getStatus();
                if (status.isSuccess()) {
                    this.p = System.currentTimeMillis();
                    return true;
                }
                int n3 = status.getStatusCode();
                com.huawei.hms.adapter.a.a((String)"isConnected is false, statuscode:", (int)n3, (String)"HuaweiApiClientImpl");
                if (n3 != 907135004) {
                    this.o();
                    this.c(1);
                    this.p = System.currentTimeMillis();
                }
            }
            return false;
        }
        return this.innerIsConnected();
    }

    @Override
    public boolean isConnecting() {
        int n3 = this.k.get();
        return n3 == 2 || n3 == 5;
        {
        }
    }

    @Override
    public void onPause(Activity activity) {
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"onPause");
    }

    @Override
    public void onResume(Activity activity) {
        if (activity != null) {
            HMSLog.i((String)"HuaweiApiClientImpl", (String)"onResume");
            this.i = new WeakReference((Object)activity);
        }
    }

    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"Enter onServiceConnected.");
        this.a(2);
        this.f = d.a.a((IBinder)iBinder);
        if (this.f == null) {
            HMSLog.e((String)"HuaweiApiClientImpl", (String)"In onServiceConnected, mCoreService must not be null.");
            this.o();
            this.c(1);
            if (this.w != null) {
                WeakReference<Activity> weakReference = this.h;
                PendingIntent pendingIntent = null;
                if (weakReference != null) {
                    Object object = weakReference.get();
                    pendingIntent = null;
                    if (object != null) {
                        pendingIntent = HuaweiApiAvailability.getInstance().getResolveErrorPendingIntent((Activity)this.h.get(), 10);
                    }
                }
                ConnectionResult connectionResult = new ConnectionResult(10, pendingIntent);
                this.w.onConnectionFailed(connectionResult);
                this.u = connectionResult;
            }
            return;
        }
        if (this.k.get() == 5) {
            this.c(2);
            this.k();
            this.j();
            return;
        }
        if (this.k.get() != 3) {
            this.o();
        }
    }

    public void onServiceDisconnected(ComponentName componentName) {
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"Enter onServiceDisconnected.");
        this.f = null;
        this.c(1);
        HuaweiApiClient.ConnectionCallbacks connectionCallbacks = this.v;
        if (connectionCallbacks != null) {
            connectionCallbacks.onConnectionSuspended(1);
        }
    }

    @Override
    public void print(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
    }

    @Override
    public void reconnect() {
        this.disconnect();
        this.connect(null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void removeConnectionFailureListener(HuaweiApiClient.OnConnectionFailedListener onConnectionFailedListener) {
        Object object;
        Checker.checkNonNull((Object)onConnectionFailedListener, (String)"onConnectionFailedListener should not be null");
        Object object2 = object = this.r;
        synchronized (object2) {
            if (this.w != onConnectionFailedListener) {
                HMSLog.w((String)"HuaweiApiClientImpl", (String)"unregisterConnectionFailedListener: this onConnectionFailedListener has not been registered");
            } else {
                this.w = null;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void removeConnectionSuccessListener(HuaweiApiClient.ConnectionCallbacks connectionCallbacks) {
        Object object;
        Checker.checkNonNull((Object)connectionCallbacks, (String)"connectionCallbacksListener should not be null");
        Object object2 = object = this.r;
        synchronized (object2) {
            if (this.v != connectionCallbacks) {
                HMSLog.w((String)"HuaweiApiClientImpl", (String)"unregisterConnectionCallback: this connectionCallbacksListener has not been registered");
            } else {
                this.v = null;
            }
            return;
        }
    }

    public void setApiMap(Map<Api<?>, Api.ApiOptions> map) {
        this.n = map;
    }

    public void setAutoLifecycleClientId(int n3) {
        this.a = n3;
    }

    @Override
    public void setConnectionCallbacks(HuaweiApiClient.ConnectionCallbacks connectionCallbacks) {
        this.v = connectionCallbacks;
    }

    @Override
    public void setConnectionFailedListener(HuaweiApiClient.OnConnectionFailedListener onConnectionFailedListener) {
        this.w = onConnectionFailedListener;
    }

    public void setHasShowNotice(boolean bl) {
        this.j = bl;
    }

    public void setPermissionInfos(List<PermissionInfo> list) {
        this.m = list;
    }

    public void setScopes(List<Scope> list) {
        this.l = list;
    }

    @Override
    public boolean setSubAppInfo(SubAppInfo subAppInfo) {
        HMSLog.i((String)"HuaweiApiClientImpl", (String)"Enter setSubAppInfo");
        if (subAppInfo == null) {
            HMSLog.e((String)"HuaweiApiClientImpl", (String)"subAppInfo is null");
            return false;
        }
        String string = subAppInfo.getSubAppID();
        if (TextUtils.isEmpty((CharSequence)string)) {
            HMSLog.e((String)"HuaweiApiClientImpl", (String)"subAppId is empty");
            return false;
        }
        String string2 = TextUtils.isEmpty((CharSequence)this.c) ? Util.getAppId((Context)this.b) : this.c;
        if (string.equals((Object)string2)) {
            HMSLog.e((String)"HuaweiApiClientImpl", (String)"subAppId is host appid");
            return false;
        }
        this.o = new SubAppInfo(subAppInfo);
        return true;
    }

    public static class e
    extends PendingResultImpl<Status, IMessageEntity> {
        public e(ApiClient apiClient, String string, IMessageEntity iMessageEntity) {
            super(apiClient, string, iMessageEntity);
        }

        public Status onComplete(IMessageEntity iMessageEntity) {
            return new Status(0);
        }
    }

}

