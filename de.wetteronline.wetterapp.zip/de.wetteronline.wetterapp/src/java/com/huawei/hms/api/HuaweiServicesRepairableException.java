/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.String
 */
package com.huawei.hms.api;

import android.content.Intent;
import com.huawei.hms.api.UserRecoverableException;

public class HuaweiServicesRepairableException
extends UserRecoverableException {
    private final int b;

    public HuaweiServicesRepairableException(int n2, String string, Intent intent) {
        super(string, intent);
        this.b = n2;
    }

    public int getConnectionStatusCode() {
        return this.b;
    }
}

