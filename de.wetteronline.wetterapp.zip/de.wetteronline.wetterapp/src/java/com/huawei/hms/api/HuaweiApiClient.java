/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Handler
 *  android.support.v4.media.b
 *  android.view.View
 *  com.huawei.hms.api.Api$ApiOptions$HasOptions
 *  com.huawei.hms.api.Api$ApiOptions$NotRequiredOptions
 *  com.huawei.hms.api.HuaweiApiClientImpl
 *  com.huawei.hms.support.api.client.AidlApiClient
 *  com.huawei.hms.support.api.client.PendingResult
 *  com.huawei.hms.support.api.client.Status
 *  com.huawei.hms.support.api.client.SubAppInfo
 *  com.huawei.hms.support.api.entity.auth.PermissionInfo
 *  com.huawei.hms.support.api.entity.auth.Scope
 *  com.huawei.hms.support.hianalytics.HiAnalyticsUtil
 *  com.huawei.hms.support.log.HMSLog
 *  com.huawei.hms.utils.Checker
 *  com.huawei.hms.utils.HMSBIInitializer
 *  com.huawei.hms.utils.ResourceLoaderUtil
 *  java.io.FileDescriptor
 *  java.io.PrintWriter
 *  java.lang.IllegalArgumentException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.UnsupportedOperationException
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.TimeUnit
 */
package com.huawei.hms.api;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.support.v4.media.b;
import android.view.View;
import com.huawei.hms.api.Api;
import com.huawei.hms.api.CheckUpdatelistener;
import com.huawei.hms.api.ConnectionResult;
import com.huawei.hms.api.HuaweiApiClientImpl;
import com.huawei.hms.common.internal.AutoLifecycleFragment;
import com.huawei.hms.common.internal.Preconditions;
import com.huawei.hms.support.api.client.AidlApiClient;
import com.huawei.hms.support.api.client.PendingResult;
import com.huawei.hms.support.api.client.Status;
import com.huawei.hms.support.api.client.SubAppInfo;
import com.huawei.hms.support.api.entity.auth.PermissionInfo;
import com.huawei.hms.support.api.entity.auth.Scope;
import com.huawei.hms.support.hianalytics.HiAnalyticsUtil;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.utils.Checker;
import com.huawei.hms.utils.HMSBIInitializer;
import com.huawei.hms.utils.ResourceLoaderUtil;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public abstract class HuaweiApiClient
implements AidlApiClient {
    public abstract void checkUpdate(Activity var1, CheckUpdatelistener var2);

    public void connect(int n2) {
        throw new UnsupportedOperationException();
    }

    public abstract void connect(Activity var1);

    public abstract void connectForeground();

    public abstract void disableLifeCycleManagement(Activity var1);

    public abstract PendingResult<Status> discardAndReconnect();

    public abstract void disconnect();

    public abstract Map<Api<?>, Api.ApiOptions> getApiMap();

    public abstract ConnectionResult getConnectionResult(Api<?> var1);

    public abstract List<PermissionInfo> getPermissionInfos();

    public abstract List<Scope> getScopes();

    public abstract Activity getTopActivity();

    public abstract boolean hasConnectedApi(Api<?> var1);

    public abstract boolean hasConnectionFailureListener(OnConnectionFailedListener var1);

    public abstract boolean hasConnectionSuccessListener(ConnectionCallbacks var1);

    public abstract ConnectionResult holdUpConnect();

    public abstract ConnectionResult holdUpConnect(long var1, TimeUnit var3);

    public abstract boolean isConnected();

    public abstract boolean isConnecting();

    public abstract void onPause(Activity var1);

    public abstract void onResume(Activity var1);

    public abstract void print(String var1, FileDescriptor var2, PrintWriter var3, String[] var4);

    public abstract void reconnect();

    public abstract void removeConnectionFailureListener(OnConnectionFailedListener var1);

    public abstract void removeConnectionSuccessListener(ConnectionCallbacks var1);

    public abstract void setConnectionCallbacks(ConnectionCallbacks var1);

    public abstract void setConnectionFailedListener(OnConnectionFailedListener var1);

    public abstract boolean setSubAppInfo(SubAppInfo var1);

}

