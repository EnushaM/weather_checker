/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.util.List
 */
package com.huawei.hms.api;

import java.util.List;

public class ProtocolNegotiate {
    private static ProtocolNegotiate b = new ProtocolNegotiate();
    private int a = 1;

    public static ProtocolNegotiate getInstance() {
        return b;
    }

    public int getVersion() {
        return this.a;
    }

    public int negotiate(List<Integer> list) {
        if (list != null && !list.isEmpty()) {
            this.a = !list.contains((Object)2) ? (Integer)list.get(list.size() - 1) : 2;
            return this.a;
        }
        this.a = 1;
        return 1;
    }
}

