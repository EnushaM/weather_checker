/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.Dialog
 *  android.app.Fragment
 *  android.app.FragmentManager
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.support.v4.media.b
 *  com.huawei.hms.activity.BridgeActivity
 *  com.huawei.hms.activity.EnableServiceActivity
 *  com.huawei.hms.activity.ForegroundIntentBuilder
 *  com.huawei.hms.activity.internal.BusResponseCallback
 *  com.huawei.hms.activity.internal.BusResponseResult
 *  com.huawei.hms.adapter.a
 *  com.huawei.hms.update.note.AppSpoofResolution
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 */
package com.huawei.hms.api;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import com.huawei.hms.activity.BridgeActivity;
import com.huawei.hms.activity.EnableServiceActivity;
import com.huawei.hms.activity.ForegroundIntentBuilder;
import com.huawei.hms.activity.internal.BusResponseCallback;
import com.huawei.hms.activity.internal.BusResponseResult;
import com.huawei.hms.api.Api;
import com.huawei.hms.api.BindingFailedResolution;
import com.huawei.hms.api.ConnectionResult;
import com.huawei.hms.api.HuaweiApiAvailability;
import com.huawei.hms.api.HuaweiMobileServicesUtil;
import com.huawei.hms.api.ResolutionDelegate;
import com.huawei.hms.common.ErrorDialogFragment;
import com.huawei.hms.common.HuaweiApi;
import com.huawei.hms.common.api.AvailabilityException;
import com.huawei.hms.common.api.HuaweiApiCallable;
import com.huawei.hms.common.internal.ConnectionErrorMessages;
import com.huawei.hms.common.internal.DialogRedirect;
import com.huawei.hms.common.internal.Preconditions;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.update.manager.UpdateManager;
import com.huawei.hms.update.note.AppSpoofResolution;
import com.huawei.hms.update.ui.UpdateBean;
import com.huawei.hms.utils.Checker;
import com.huawei.hms.utils.HMSPackageManager;
import com.huawei.hms.utils.PackageManagerHelper;
import com.huawei.hms.utils.ResourceLoaderUtil;
import com.huawei.hms.utils.Util;
import je.f;
import je.g;
import ke.e;

final class b
extends HuaweiApiAvailability {
    private static final b b = new b();

    private b() {
    }

    public static int a(Activity activity) {
        if (b.a((Context)activity) != 0) {
            return 0;
        }
        return 3;
    }

    private static int a(Context context) {
        if (context == null) {
            return 0;
        }
        return context.getResources().getIdentifier("androidhwext:style/Theme.Emui", null, null);
    }

    private static Dialog a(Activity activity, int n2, DialogRedirect dialogRedirect, DialogInterface.OnCancelListener onCancelListener) {
        if (n2 == 0) {
            return null;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)activity, b.a(activity));
        builder.setMessage((CharSequence)ConnectionErrorMessages.getErrorMessage(activity, n2));
        if (onCancelListener != null) {
            builder.setOnCancelListener(onCancelListener);
        }
        builder.setPositiveButton((CharSequence)ConnectionErrorMessages.getErrorDialogButtonMessage(activity, n2), (DialogInterface.OnClickListener)dialogRedirect);
        String string = ConnectionErrorMessages.getErrorTitle(activity, n2);
        if (string != null) {
            builder.setTitle((CharSequence)string);
        }
        return builder.create();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Intent a(Activity activity, int n2) {
        com.huawei.hms.adapter.a.a((String)"getErrorResolutionIntent, errorCode: ", (int)n2, (String)"HuaweiApiAvailabilityImpl");
        if (n2 != 1 && n2 != 2) {
            if (n2 == 6) return BridgeActivity.getIntentStartBridgeActivity((Activity)activity, (String)BindingFailedResolution.class.getName());
            if (n2 != 9 || !Util.isAvailableLibExist((Context)activity)) return null;
            return BridgeActivity.getIntentStartBridgeActivity((Activity)activity, (String)AppSpoofResolution.class.getName());
        }
        if (!Util.isAvailableLibExist((Context)activity)) return null;
        return UpdateManager.startUpdateIntent(activity);
    }

    private static Intent a(Activity activity, String string) {
        return BridgeActivity.getIntentStartBridgeActivity((Activity)activity, (String)string);
    }

    private static Intent a(Context context, String string) {
        return BridgeActivity.getIntentStartBridgeActivity((Context)context, (String)string);
    }

    private static void a(Activity activity, Dialog dialog, String string, DialogInterface.OnCancelListener onCancelListener) {
        Checker.checkNonNull(activity, "activity must not be null.");
        ErrorDialogFragment.newInstance(dialog, onCancelListener).show(activity.getFragmentManager(), string);
    }

    private void a(Object object) throws AvailabilityException {
        AvailabilityException availabilityException = new AvailabilityException();
        ConnectionResult connectionResult = object instanceof HuaweiApi ? availabilityException.getConnectionResult((HuaweiApi)object) : availabilityException.getConnectionResult((HuaweiApiCallable)object);
        if (connectionResult.getErrorCode() == 0) {
            return;
        }
        StringBuilder stringBuilder = android.support.v4.media.b.a((String)"The service is unavailable: ");
        stringBuilder.append(availabilityException.getMessage());
        HMSLog.i("HuaweiApiAvailabilityImpl", stringBuilder.toString());
        throw availabilityException;
    }

    public static b getInstance() {
        return b;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public Intent a(Context context, int n2) {
        com.huawei.hms.adapter.a.a((String)"Enter getResolveErrorIntent, errorCode: ", (int)n2, (String)"HuaweiApiAvailabilityImpl");
        if (n2 != 1 && n2 != 2) {
            if (n2 == 6) return b.a(context, BindingFailedResolution.class.getName());
            if (n2 != 9 || !Util.isAvailableLibExist(context)) return null;
            return b.a(context, AppSpoofResolution.class.getName());
        }
        if (!Util.isAvailableLibExist(context)) return null;
        UpdateBean updateBean = new UpdateBean();
        updateBean.setHmsOrApkUpgrade(true);
        updateBean.setClientPackageName(HMSPackageManager.getInstance(context.getApplicationContext()).getHMSPackageName());
        updateBean.setClientVersionCode(HuaweiApiAvailability.getServicesVersionCode());
        updateBean.setClientAppId("C10132067");
        if (ResourceLoaderUtil.getmContext() == null) {
            ResourceLoaderUtil.setmContext(context.getApplicationContext());
        }
        updateBean.setClientAppName(ResourceLoaderUtil.getString("hms_update_title"));
        return UpdateManager.getStartUpdateIntent(context, updateBean);
    }

    public PendingIntent b(Context context, int n2) {
        com.huawei.hms.adapter.a.a((String)"Enter getResolveErrorPendingIntent, errorCode: ", (int)n2, (String)"HuaweiApiAvailabilityImpl");
        Intent intent = this.a(context, n2);
        if (intent != null) {
            return PendingIntent.getActivity((Context)context, (int)0, (Intent)intent, (int)134217728);
        }
        return null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public /* varargs */ f<Void> checkApiAccessible(HuaweiApi<?> var1_1, HuaweiApi<?> ... var2_2) {
        block3 : {
            var3_3 = new e<Void>();
            if (var1_1 == null) ** GOTO lbl5
            try {
                this.a(var1_1);
lbl5: // 2 sources:
                if (var2_2 == null) return var3_3;
                var4_4 = var2_2.length;
                var5_5 = 0;
                break block3;
            }
            catch (AvailabilityException var6_6) {}
            var7_7 = android.support.v4.media.b.a((String)"checkApi has AvailabilityException ");
            var7_7.append(var6_6.getMessage());
            HMSLog.i("HuaweiApiAvailabilityImpl", var7_7.toString());
            return var3_3;
        }
        while (var5_5 < var4_4) {
            this.a(var2_2[var5_5]);
            ++var5_5;
        }
        return var3_3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public /* varargs */ f<Void> checkApiAccessible(HuaweiApiCallable var1_1, HuaweiApiCallable ... var2_2) {
        block3 : {
            var3_3 = new e<Void>();
            if (var1_1 == null) ** GOTO lbl5
            try {
                this.a(var1_1);
lbl5: // 2 sources:
                if (var2_2 == null) return var3_3;
                var4_4 = var2_2.length;
                var5_5 = 0;
                break block3;
            }
            catch (AvailabilityException var6_6) {}
            var7_7 = android.support.v4.media.b.a((String)"HuaweiApiCallable checkApi has AvailabilityException ");
            var7_7.append(var6_6.getMessage());
            HMSLog.i("HuaweiApiAvailabilityImpl", var7_7.toString());
            return var3_3;
        }
        while (var5_5 < var4_4) {
            this.a(var2_2[var5_5]);
            ++var5_5;
        }
        return var3_3;
    }

    @Override
    public PendingIntent getErrPendingIntent(Context context, int n2, int n3) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Enter getResolveErrorPendingIntent, errorCode: ");
        stringBuilder.append(n2);
        stringBuilder.append(" requestCode: ");
        stringBuilder.append(n3);
        HMSLog.i("HuaweiApiAvailabilityImpl", stringBuilder.toString());
        Intent intent = this.a(context, n2);
        if (intent != null) {
            return PendingIntent.getActivity((Context)context, (int)n3, (Intent)intent, (int)134217728);
        }
        return null;
    }

    @Override
    public PendingIntent getErrPendingIntent(Context context, ConnectionResult connectionResult) {
        Preconditions.checkNotNull(context);
        Preconditions.checkNotNull(connectionResult);
        return this.b(context, connectionResult.getErrorCode());
    }

    @Override
    public Dialog getErrorDialog(Activity activity, int n2, int n3) {
        Checker.checkNonNull(activity, "activity must not be null.");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Enter getErrorDialog, errorCode: ");
        stringBuilder.append(n2);
        HMSLog.i("HuaweiApiAvailabilityImpl", stringBuilder.toString());
        return this.getErrorDialog(activity, n2, n3, null);
    }

    @Override
    public Dialog getErrorDialog(Activity activity, int n2, int n3, DialogInterface.OnCancelListener onCancelListener) {
        Checker.checkNonNull(activity, "activity must not be null.");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Enter getErrorDialog, errorCode: ");
        stringBuilder.append(n2);
        HMSLog.i("HuaweiApiAvailabilityImpl", stringBuilder.toString());
        return b.a(activity, n2, DialogRedirect.getInstance(activity, this.a(activity, n2), n3), onCancelListener);
    }

    @Override
    public String getErrorString(int n2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Enter getErrorString, errorCode: ");
        stringBuilder.append(n2);
        HMSLog.i("HuaweiApiAvailabilityImpl", stringBuilder.toString());
        return ConnectionResult.a(n2);
    }

    @Override
    public f<Void> getHuaweiServicesReady(Activity activity) {
        Preconditions.checkNotNull(activity);
        final g[] arrg = new g[]{new g()};
        e<Void> e2 = arrg[0].a;
        int n2 = this.isHuaweiMobileServicesAvailable(activity.getApplicationContext(), 30000000);
        Intent intent = this.getResolveErrorIntent(activity, n2);
        Intent intent2 = BridgeActivity.getIntentStartBridgeActivity((Activity)activity, (String)ResolutionDelegate.class.getName());
        if (intent != null) {
            ForegroundIntentBuilder.registerResponseCallback((String)"CALLBACK_METHOD", (BusResponseCallback)new BusResponseCallback(this){

                public BusResponseResult innerError(Activity activity, int n2, String string) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Test foreground bus error: resultCode ");
                    stringBuilder.append(n2);
                    stringBuilder.append(", errMessage");
                    stringBuilder.append(string);
                    HMSLog.e("HuaweiApiAvailabilityImpl", stringBuilder.toString());
                    arrg[0].a(new AvailabilityException());
                    return null;
                }

                public BusResponseResult succeedReturn(Activity activity, int n2, Intent intent) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Test foreground bus success: resultCode ");
                    stringBuilder.append(n2);
                    stringBuilder.append(", data");
                    stringBuilder.append((Object)intent);
                    HMSLog.i("HuaweiApiAvailabilityImpl", stringBuilder.toString());
                    return null;
                }
            });
            Bundle bundle = new Bundle();
            bundle.putParcelable("resolution", (Parcelable)intent);
            intent2.putExtras(bundle);
            activity.startActivity(intent2);
            return e2;
        }
        if (n2 == 3) {
            Intent intent3 = new Intent();
            intent3.setClass((Context)activity, EnableServiceActivity.class);
            activity.startActivity(intent3);
            return e2;
        }
        if (n2 == 0) {
            HMSLog.i("HuaweiApiAvailabilityImpl", "The HMS service is available.");
            return e2;
        }
        HMSLog.e("HuaweiApiAvailabilityImpl", "Framework can not solve the availability problem.");
        arrg[0].a(new AvailabilityException());
        return e2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public Intent getResolveErrorIntent(Activity activity, int n2) {
        com.huawei.hms.adapter.a.a((String)"Enter getResolveErrorIntent, errorCode: ", (int)n2, (String)"HuaweiApiAvailabilityImpl");
        if (n2 != 1 && n2 != 2) {
            if (n2 == 6) return b.a(activity, BindingFailedResolution.class.getName());
            if (n2 != 9 || !Util.isAvailableLibExist((Context)activity)) return null;
            return b.a(activity, AppSpoofResolution.class.getName());
        }
        if (!Util.isAvailableLibExist((Context)activity)) return null;
        UpdateBean updateBean = new UpdateBean();
        updateBean.setHmsOrApkUpgrade(true);
        updateBean.setClientPackageName(HMSPackageManager.getInstance(activity.getApplicationContext()).getHMSPackageName());
        updateBean.setClientVersionCode(HuaweiApiAvailability.getServicesVersionCode());
        updateBean.setClientAppId("C10132067");
        if (ResourceLoaderUtil.getmContext() == null) {
            ResourceLoaderUtil.setmContext(activity.getApplicationContext());
        }
        updateBean.setClientAppName(ResourceLoaderUtil.getString("hms_update_title"));
        return UpdateManager.getStartUpdateIntent(activity, updateBean);
    }

    @Override
    public PendingIntent getResolveErrorPendingIntent(Activity activity, int n2) {
        com.huawei.hms.adapter.a.a((String)"Enter getResolveErrorPendingIntent, errorCode: ", (int)n2, (String)"HuaweiApiAvailabilityImpl");
        Intent intent = this.getResolveErrorIntent(activity, n2);
        if (intent != null) {
            return PendingIntent.getActivity((Context)activity, (int)0, (Intent)intent, (int)134217728);
        }
        return null;
    }

    @Override
    public int isHuaweiMobileNoticeAvailable(Context context) {
        Checker.checkNonNull(context, "context must not be null.");
        PackageManagerHelper.PackageStates packageStates = new PackageManagerHelper(context).getPackageStates(HMSPackageManager.getInstance(context).getHMSPackageName());
        if (PackageManagerHelper.PackageStates.NOT_INSTALLED.equals((Object)packageStates)) {
            return 1;
        }
        if (HMSPackageManager.getInstance(context).isApkUpdateNecessary(20600000)) {
            return 2;
        }
        return 0;
    }

    @Override
    public int isHuaweiMobileServicesAvailable(Context context) {
        Checker.checkNonNull(context, "context must not be null.");
        return HuaweiMobileServicesUtil.isHuaweiMobileServicesAvailable(context, HuaweiApiAvailability.getServicesVersionCode());
    }

    @Override
    public int isHuaweiMobileServicesAvailable(Context context, int n2) {
        Checker.checkNonNull(context, "context must not be null.");
        return HuaweiMobileServicesUtil.isHuaweiMobileServicesAvailable(context, n2);
    }

    @Override
    public boolean isUserResolvableError(int n2) {
        return this.isUserResolvableError(n2, null);
    }

    @Override
    public boolean isUserResolvableError(int n2, PendingIntent pendingIntent) {
        if (n2 == 0) {
            return false;
        }
        if (pendingIntent != null) {
            return true;
        }
        return n2 == 1 || n2 == 2 || n2 == 6 || n2 == 9;
    }

    @Override
    public void popupErrNotification(Context context, ConnectionResult connectionResult) {
        Preconditions.checkNotNull(context);
        Preconditions.checkNotNull(connectionResult);
        this.showErrorNotification(context, connectionResult.getErrorCode());
    }

    @Override
    public void resolveError(Activity activity, int n2, int n3) {
        this.resolveError(activity, n2, n3, null);
    }

    /*
     * Exception decompiling
     */
    @Override
    public void resolveError(Activity var1, int var2, int var3, PendingIntent var4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl53 : RETURN : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public boolean showErrorDialogFragment(Activity activity, int n2, int n3) {
        return this.showErrorDialogFragment(activity, n2, n3, null);
    }

    @Override
    public boolean showErrorDialogFragment(Activity activity, int n2, int n3, DialogInterface.OnCancelListener onCancelListener) {
        Dialog dialog = this.getErrorDialog(activity, n2, n3, onCancelListener);
        if (dialog == null) {
            return false;
        }
        b.a(activity, dialog, "HuaweiMobileServicesErrorDialog", onCancelListener);
        return true;
    }

    @Override
    public boolean showErrorDialogFragment(Activity activity, int n2, Fragment fragment, int n3, DialogInterface.OnCancelListener onCancelListener) {
        return this.showErrorDialogFragment(activity, n2, n3, onCancelListener);
    }

    @Override
    public void showErrorNotification(Context context, int n2) {
        Checker.checkNonNull(context, "context must not be null.");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Enter showErrorNotification, errorCode: ");
        stringBuilder.append(n2);
        HMSLog.i("HuaweiApiAvailabilityImpl", stringBuilder.toString());
        Dialog dialog = this.getErrorDialog((Activity)context, n2, 0);
        if (dialog == null) {
            HMSLog.i("HuaweiApiAvailabilityImpl", "showErrorNotification errorDialog can not be null");
            return;
        }
        dialog.show();
    }

}

