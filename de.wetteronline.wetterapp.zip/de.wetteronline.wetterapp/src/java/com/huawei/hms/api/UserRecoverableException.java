/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Exception
 *  java.lang.String
 */
package com.huawei.hms.api;

import android.content.Intent;

public class UserRecoverableException
extends Exception {
    private final Intent a;

    public UserRecoverableException(String string2, Intent intent) {
        super(string2);
        this.a = intent;
    }

    public Intent getIntent() {
        return new Intent(this.a);
    }
}

