/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.IBinder
 *  android.os.Looper
 *  android.support.v4.media.b
 *  android.view.KeyEvent
 *  com.huawei.hms.activity.IBridgeActivityDelegate
 *  com.huawei.hms.ui.AbstractPromptDialog
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.huawei.hms.api;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.KeyEvent;
import com.huawei.hms.activity.IBridgeActivityDelegate;
import com.huawei.hms.api.BindingFailedResolution;
import com.huawei.hms.common.internal.BindResolveClients;
import com.huawei.hms.support.log.HMSLog;
import com.huawei.hms.ui.AbstractDialog;
import com.huawei.hms.ui.AbstractPromptDialog;
import com.huawei.hms.utils.HMSPackageManager;
import com.huawei.hms.utils.ResourceLoaderUtil;
import com.huawei.hms.utils.UIUtil;
import com.huawei.hms.utils.Util;

public class BindingFailedResolution
implements IBridgeActivityDelegate,
ServiceConnection {
    private static final Object f = new Object();
    private Activity a;
    private boolean b = true;
    private d c;
    private Handler d = null;
    private Handler e = null;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void a() {
        Object object;
        Activity activity = this.getActivity();
        if (activity == null) {
            HMSLog.e("BindingFailedResolution", "In connect, bind core try fail");
            this.a(false);
            return;
        }
        Intent intent = new Intent("com.huawei.hms.core.aidlservice");
        intent.setPackage(HMSPackageManager.getInstance(activity.getApplicationContext()).getHMSPackageName());
        Object object2 = object = f;
        synchronized (object2) {
            if (activity.bindService(intent, (ServiceConnection)this, 1)) {
                this.c();
                return;
            }
        }
        HMSLog.e("BindingFailedResolution", "In connect, bind core try fail");
        this.a(false);
    }

    private void a(int n2) {
        Activity activity = this.getActivity();
        if (activity != null) {
            if (activity.isFinishing()) {
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("finishBridgeActivity\uff1a");
            stringBuilder.append(n2);
            HMSLog.i("BindingFailedResolution", stringBuilder.toString());
            Intent intent = new Intent();
            intent.putExtra("intent.extra.RESULT", n2);
            activity.setResult(-1, intent);
            activity.finish();
        }
    }

    private void a(Activity activity) {
        Intent intent = new Intent();
        intent.putExtra("intent.extra.isfullscreen", UIUtil.isActivityFullscreen(activity));
        intent.setClassName(HMSPackageManager.getInstance(activity.getApplicationContext()).getHMSPackageName(), "com.huawei.hms.core.activity.JumpActivity");
        HMSLog.i("BindingFailedResolution", "onBridgeActivityCreate\uff1atry to start HMS");
        try {
            activity.startActivityForResult(intent, this.getRequestCode());
            return;
        }
        catch (Throwable throwable) {
            StringBuilder stringBuilder = android.support.v4.media.b.a((String)"ActivityNotFoundException\uff1a");
            stringBuilder.append(throwable.getMessage());
            HMSLog.e("BindingFailedResolution", stringBuilder.toString());
            Handler handler = this.e;
            if (handler != null) {
                handler.removeMessages(3);
                this.e = null;
            }
            this.a();
            return;
        }
    }

    public static /* synthetic */ void a(BindingFailedResolution bindingFailedResolution, boolean bl2) {
        bindingFailedResolution.a(bl2);
    }

    private void a(boolean bl2) {
        if (this.b) {
            this.b = false;
            this.onStartResult(bl2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void b() {
        Object object;
        Object object2 = object = f;
        synchronized (object2) {
            Handler handler = this.d;
            if (handler != null) {
                handler.removeMessages(2);
                this.d = null;
            }
            return;
        }
    }

    private void c() {
        Handler handler = this.d;
        if (handler != null) {
            handler.removeMessages(2);
        } else {
            this.d = new Handler(Looper.getMainLooper(), new Handler.Callback(this){
                public final /* synthetic */ BindingFailedResolution a;
                {
                    this.a = bindingFailedResolution;
                }

                public boolean handleMessage(android.os.Message message) {
                    if (message != null) {
                        if (message.what != 2) {
                            return false;
                        }
                        HMSLog.e("BindingFailedResolution", "In connect, bind core try timeout");
                        BindingFailedResolution.a(this.a, false);
                        return true;
                    }
                    return false;
                }
            });
        }
        this.d.sendEmptyMessageDelayed(2, 5000L);
    }

    private void d() {
        Handler handler = this.e;
        if (handler != null) {
            handler.removeMessages(3);
        } else {
            this.e = new Handler(Looper.getMainLooper(), new Handler.Callback(this){
                public final /* synthetic */ BindingFailedResolution a;
                {
                    this.a = bindingFailedResolution;
                }

                public boolean handleMessage(android.os.Message message) {
                    if (message != null && message.what == 3) {
                        BindingFailedResolution.a(this.a, 8);
                        return true;
                    }
                    return false;
                }
            });
        }
        this.e.sendEmptyMessageDelayed(3, 4000L);
    }

    private void e() {
        Activity activity = this.getActivity();
        if (activity != null) {
            if (activity.isFinishing()) {
                return;
            }
            d d2 = this.c;
            if (d2 == null) {
                this.c = new AbstractPromptDialog(null){
                    {
                        this();
                    }

                    public String onGetMessageString(Context context) {
                        return ResourceLoaderUtil.getString("hms_bindfaildlg_message", Util.getAppName(context, null), Util.getAppName(context, HMSPackageManager.getInstance(context).getHMSPackageName()));
                    }

                    public String onGetPositiveButtonString(Context context) {
                        return ResourceLoaderUtil.getString("hms_confirm");
                    }
                };
            } else {
                ((AbstractDialog)((Object)d2)).dismiss();
            }
            HMSLog.i("BindingFailedResolution", "showPromptdlg to resolve conn error");
            ((AbstractDialog)((Object)this.c)).show(activity, new AbstractDialog.Callback(){

                @Override
                public void onCancel(AbstractDialog abstractDialog) {
                    BindingFailedResolution.this.c = null;
                    BindResolveClients.getInstance().unRegisterAll();
                    BindingFailedResolution.this.a(8);
                }

                @Override
                public void onDoWork(AbstractDialog abstractDialog) {
                    BindingFailedResolution.this.c = null;
                    BindResolveClients.getInstance().unRegisterAll();
                    BindingFailedResolution.this.a(8);
                }
            });
        }
    }

    public Activity getActivity() {
        return this.a;
    }

    public int getRequestCode() {
        return 2003;
    }

    public void onBridgeActivityCreate(Activity activity) {
        this.a = activity;
        com.huawei.hms.api.a.b.a(activity);
        this.d();
        this.a(activity);
    }

    public void onBridgeActivityDestroy() {
        this.b();
        com.huawei.hms.api.a.b.b(this.a);
        this.a = null;
    }

    public boolean onBridgeActivityResult(int n2, int n3, Intent intent) {
        if (n2 != this.getRequestCode()) {
            return false;
        }
        HMSLog.i("BindingFailedResolution", "onBridgeActivityResult");
        Handler handler = this.e;
        if (handler != null) {
            handler.removeMessages(3);
            this.e = null;
        }
        this.a();
        return true;
    }

    public void onBridgeConfigurationChanged() {
        if (this.c == null) {
            return;
        }
        HMSLog.i("BindingFailedResolution", "re show prompt dialog");
        this.e();
    }

    public void onKeyUp(int n2, KeyEvent keyEvent) {
        HMSLog.i("BindingFailedResolution", "On key up when resolve conn error");
    }

    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        this.b();
        this.a(true);
        Activity activity = this.getActivity();
        if (activity == null) {
            return;
        }
        Util.unBindServiceCatchException((Context)activity, this);
        HMSLog.i("BindingFailedResolution", "test connect success, try to reConnect and reply message");
        BindResolveClients.getInstance().notifyClientReconnect();
    }

    public void onServiceDisconnected(ComponentName componentName) {
    }

    public void onStartResult(boolean bl2) {
        if (this.getActivity() == null) {
            return;
        }
        if (bl2) {
            this.a(0);
            return;
        }
        this.e();
    }

}

