/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 */
package com.huawei.hms.api;

public final class HuaweiServicesNotAvailableException
extends Exception {
    public final int errorCode;

    public HuaweiServicesNotAvailableException(int n2) {
        this.errorCode = n2;
    }
}

