/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.NotificationManager
 *  androidx.work.impl.foreground.SystemForegroundService
 *  java.lang.Object
 *  java.lang.Runnable
 */
package b4;

import android.app.Notification;
import android.app.NotificationManager;
import androidx.work.impl.foreground.SystemForegroundService;

public class c
implements Runnable {
    public final /* synthetic */ int b;
    public final /* synthetic */ Notification c;
    public final /* synthetic */ SystemForegroundService d;

    public c(SystemForegroundService systemForegroundService, int n2, Notification notification) {
        this.d = systemForegroundService;
        this.b = n2;
        this.c = notification;
    }

    public void run() {
        this.d.f.notify(this.b, this.c);
    }
}

