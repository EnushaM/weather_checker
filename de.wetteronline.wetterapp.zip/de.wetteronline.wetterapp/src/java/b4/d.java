/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.NotificationManager
 *  androidx.work.impl.foreground.SystemForegroundService
 *  java.lang.Object
 *  java.lang.Runnable
 */
package b4;

import android.app.NotificationManager;
import androidx.work.impl.foreground.SystemForegroundService;

public class d
implements Runnable {
    public final /* synthetic */ int b;
    public final /* synthetic */ SystemForegroundService c;

    public d(SystemForegroundService systemForegroundService, int n2) {
        this.c = systemForegroundService;
        this.b = n2;
    }

    public void run() {
        this.c.f.cancel(this.b);
    }
}

