/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.work.impl.WorkDatabase
 *  androidx.work.impl.foreground.a
 *  c4.p
 *  c4.q
 *  c4.r
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Map
 *  java.util.Set
 *  y3.d
 */
package b4;

import androidx.work.impl.WorkDatabase;
import androidx.work.impl.foreground.a;
import c4.p;
import c4.q;
import c4.r;
import java.util.Map;
import java.util.Set;
import y3.d;

public class b
implements Runnable {
    public final /* synthetic */ WorkDatabase b;
    public final /* synthetic */ String c;
    public final /* synthetic */ a d;

    public b(a a3, WorkDatabase workDatabase, String string) {
        this.d = a3;
        this.b = workDatabase;
        this.c = string;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void run() {
        String string;
        q q3 = this.b.s();
        p p2 = ((r)q3).i(string = this.c);
        if (p2 != null && p2.b()) {
            Object object;
            Object object2 = object = this.d.e;
            synchronized (object2) {
                this.d.h.put((Object)this.c, (Object)p2);
                this.d.i.add((Object)p2);
                a a3 = this.d;
                a3.j.b((Iterable)a3.i);
                return;
            }
        }
    }
}

