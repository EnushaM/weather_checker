/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.net.Uri
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Message
 *  androidx.fragment.app.a
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Objects
 *  java.util.Set
 */
package b3;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Set;

public final class a {
    public static final Object f = new Object();
    public static a g;
    public final Context a;
    public final HashMap<BroadcastReceiver, ArrayList<c>> b = new HashMap();
    public final HashMap<String, ArrayList<c>> c = new HashMap();
    public final ArrayList<b> d = new ArrayList();
    public final Handler e;

    public a(Context context) {
        this.a = context;
        this.e = new Handler(context.getMainLooper()){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void handleMessage(Message message) {
                if (message.what != 1) {
                    super.handleMessage(message);
                    return;
                }
                a a3 = a.this;
                block3 : do {
                    HashMap<BroadcastReceiver, ArrayList<c>> hashMap;
                    Object[] arrobject;
                    int n2;
                    HashMap<BroadcastReceiver, ArrayList<c>> hashMap2 = hashMap = a3.b;
                    synchronized (hashMap2) {
                        n2 = a3.d.size();
                        if (n2 <= 0) {
                            return;
                        }
                        arrobject = new b[n2];
                        a3.d.toArray(arrobject);
                        a3.d.clear();
                    }
                    int n3 = 0;
                    do {
                        if (n3 >= n2) continue block3;
                        Object object = arrobject[n3];
                        int n4 = ((b)object).b.size();
                        for (int i2 = 0; i2 < n4; ++i2) {
                            c c3 = (c)((b)object).b.get(i2);
                            if (c3.d) continue;
                            c3.b.onReceive(a3.a, ((b)object).a);
                        }
                        ++n3;
                    } while (true);
                    break;
                } while (true);
            }
        };
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static a a(Context context) {
        Object object;
        Object object2 = object = f;
        synchronized (object2) {
            if (g != null) return g;
            g = new a(context.getApplicationContext());
            return g;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void b(BroadcastReceiver broadcastReceiver, IntentFilter intentFilter) {
        HashMap<BroadcastReceiver, ArrayList<c>> hashMap;
        HashMap<BroadcastReceiver, ArrayList<c>> hashMap2 = hashMap = this.b;
        synchronized (hashMap2) {
            c c3 = new c(intentFilter, broadcastReceiver);
            ArrayList arrayList = (ArrayList)this.b.get((Object)broadcastReceiver);
            if (arrayList == null) {
                arrayList = new ArrayList(1);
                this.b.put((Object)broadcastReceiver, (Object)arrayList);
            }
            arrayList.add((Object)c3);
            int n2 = 0;
            while (n2 < intentFilter.countActions()) {
                String string = intentFilter.getAction(n2);
                ArrayList arrayList2 = (ArrayList)this.c.get((Object)string);
                if (arrayList2 == null) {
                    arrayList2 = new ArrayList(1);
                    this.c.put((Object)string, (Object)arrayList2);
                }
                arrayList2.add((Object)c3);
                ++n2;
            }
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public boolean c(Intent var1_1) {
        block17 : {
            block15 : {
                var32_3 = var2_2 = this.b;
                // MONITORENTER : var32_3
                var4_4 = var1_1.getAction();
                var5_5 = var1_1.resolveTypeIfNeeded(this.a.getContentResolver());
                var6_6 = var1_1.getData();
                var7_7 = var1_1.getScheme();
                var8_8 = var1_1.getCategories();
                var9_9 = (8 & var1_1.getFlags()) != 0;
                if (var9_9) {
                    var1_1.toString();
                }
                if ((var11_10 = (ArrayList)this.c.get((Object)var1_1.getAction())) == null) break block15;
                if (var9_9) {
                    var11_10.toString();
                }
                var13_11 = 0;
                var14_12 = null;
                while (var13_11 < var11_10.size()) {
                    block16 : {
                        var19_13 = (c)var11_10.get(var13_11);
                        if (var9_9) {
                            Objects.toString((Object)var19_13.a);
                        }
                        if (!var19_13.c) break block16;
                        var21_14 = var13_11;
                        var22_15 = var11_10;
                        var23_16 = var4_4;
                        var24_17 = var5_5;
                        var25_18 = var14_12;
                        ** GOTO lbl-1000
                    }
                    var26_19 = var19_13.a;
                    var27_20 = var4_4;
                    var28_21 = var5_5;
                    var21_14 = var13_11;
                    var23_16 = var4_4;
                    var25_18 = var14_12;
                    var22_15 = var11_10;
                    var24_17 = var5_5;
                    var29_22 = var26_19.match(var27_20, var28_21, var7_7, var6_6, var8_8, "LocalBroadcastManager");
                    if (var29_22 >= 0) {
                        if (var9_9) {
                            Integer.toHexString((int)var29_22);
                        }
                        var14_12 = var25_18 == null ? new ArrayList() : var25_18;
                        var14_12.add((Object)var19_13);
                        var19_13.c = true;
                    } else lbl-1000: // 2 sources:
                    {
                        var14_12 = var25_18;
                    }
                    var13_11 = var21_14 + 1;
                    var4_4 = var23_16;
                    var11_10 = var22_15;
                    var5_5 = var24_17;
                }
                var15_23 = var14_12;
                if (var15_23 != null) break block17;
            }
            // MONITOREXIT : var32_3
            return false;
        }
        for (var16_24 = 0; var16_24 < var15_23.size(); ++var16_24) {
            ((c)var15_23.get((int)var16_24)).c = false;
        }
        this.d.add((Object)new b(var1_1, var15_23));
        if (!this.e.hasMessages(1)) {
            this.e.sendEmptyMessage(1);
        }
        // MONITOREXIT : var32_3
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void d(BroadcastReceiver broadcastReceiver) {
        HashMap<BroadcastReceiver, ArrayList<c>> hashMap;
        HashMap<BroadcastReceiver, ArrayList<c>> hashMap2 = hashMap = this.b;
        synchronized (hashMap2) {
            ArrayList arrayList = (ArrayList)this.b.remove((Object)broadcastReceiver);
            if (arrayList == null) {
                return;
            }
            int n2 = arrayList.size() - 1;
            block2 : while (n2 >= 0) {
                c c3 = (c)arrayList.get(n2);
                c3.d = true;
                int n3 = 0;
                do {
                    block11 : {
                        ArrayList arrayList2;
                        String string;
                        block12 : {
                            block10 : {
                                if (n3 >= c3.a.countActions()) break block10;
                                string = c3.a.getAction(n3);
                                arrayList2 = (ArrayList)this.c.get((Object)string);
                                if (arrayList2 == null) break block11;
                                break block12;
                            }
                            --n2;
                            continue block2;
                        }
                        int n4 = arrayList2.size() - 1;
                        do {
                            if (n4 >= 0) {
                                c c4 = (c)arrayList2.get(n4);
                                if (c4.b == broadcastReceiver) {
                                    c4.d = true;
                                    arrayList2.remove(n4);
                                }
                            } else {
                                if (arrayList2.size() > 0) break;
                                this.c.remove((Object)string);
                                break;
                            }
                            --n4;
                        } while (true);
                    }
                    ++n3;
                } while (true);
                break;
            }
            return;
        }
    }

    public static final class b {
        public final Intent a;
        public final ArrayList<c> b;

        public b(Intent intent, ArrayList<c> arrayList) {
            this.a = intent;
            this.b = arrayList;
        }
    }

    public static final class c {
        public final IntentFilter a;
        public final BroadcastReceiver b;
        public boolean c;
        public boolean d;

        public c(IntentFilter intentFilter, BroadcastReceiver broadcastReceiver) {
            this.a = intentFilter;
            this.b = broadcastReceiver;
        }

        public String toString() {
            StringBuilder stringBuilder = androidx.fragment.app.a.a((int)128, (String)"Receiver{");
            stringBuilder.append((Object)this.b);
            stringBuilder.append(" filter=");
            stringBuilder.append((Object)this.a);
            if (this.d) {
                stringBuilder.append(" DEAD");
            }
            stringBuilder.append("}");
            return stringBuilder.toString();
        }
    }

}

