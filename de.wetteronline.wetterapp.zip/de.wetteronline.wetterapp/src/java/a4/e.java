/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.net.ConnectivityManager
 *  android.net.ConnectivityManager$NetworkCallback
 *  android.net.Network
 *  android.net.NetworkCapabilities
 *  android.net.NetworkInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.Throwable
 *  t3.k
 *  y3.b
 */
package a4;

import a4.d;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import t3.k;

public class e
extends d<y3.b> {
    public static final String j = k.e((String)"NetworkStateTracker");
    public final ConnectivityManager g;
    public b h;
    public a i;

    public e(Context context, f4.a a2) {
        super(context, a2);
        this.g = (ConnectivityManager)this.b.getSystemService("connectivity");
        if (e.g()) {
            this.h = new ConnectivityManager.NetworkCallback(){

                public void onCapabilitiesChanged(Network network, NetworkCapabilities networkCapabilities) {
                    k.c().a(e.j, String.format((String)"Network capabilities changed: %s", (Object[])new Object[]{networkCapabilities}), new Throwable[0]);
                    e e2 = e.this;
                    e2.c(e2.f());
                }

                public void onLost(Network network) {
                    k.c().a(e.j, "Network connection lost", new Throwable[0]);
                    e e2 = e.this;
                    e2.c(e2.f());
                }
            };
            return;
        }
        this.i = new BroadcastReceiver(){

            public void onReceive(Context context, Intent intent) {
                if (intent != null) {
                    if (intent.getAction() == null) {
                        return;
                    }
                    if (intent.getAction().equals((Object)"android.net.conn.CONNECTIVITY_CHANGE")) {
                        k.c().a(e.j, "Network broadcast received", new Throwable[0]);
                        e e2 = e.this;
                        e2.c(e2.f());
                    }
                }
            }
        };
    }

    public static boolean g() {
        return Build.VERSION.SDK_INT >= 24;
    }

    @Override
    public Object a() {
        return this.f();
    }

    @Override
    public void d() {
        if (e.g()) {
            void var2_3;
            try {
                k.c().a(j, "Registering network callback", new Throwable[0]);
                this.g.registerDefaultNetworkCallback((ConnectivityManager.NetworkCallback)this.h);
                return;
            }
            catch (SecurityException securityException) {
            }
            catch (IllegalArgumentException illegalArgumentException) {
                // empty catch block
            }
            k.c().b(j, "Received exception while registering network callback", new Throwable[]{var2_3});
            return;
        }
        k.c().a(j, "Registering broadcast receiver", new Throwable[0]);
        this.b.registerReceiver((BroadcastReceiver)this.i, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
    }

    @Override
    public void e() {
        if (e.g()) {
            void var1_3;
            try {
                k.c().a(j, "Unregistering network callback", new Throwable[0]);
                this.g.unregisterNetworkCallback((ConnectivityManager.NetworkCallback)this.h);
                return;
            }
            catch (SecurityException securityException) {
            }
            catch (IllegalArgumentException illegalArgumentException) {
                // empty catch block
            }
            k.c().b(j, "Received exception while unregistering network callback", new Throwable[]{var1_3});
            return;
        }
        k.c().a(j, "Unregistering broadcast receiver", new Throwable[0]);
        this.b.unregisterReceiver((BroadcastReceiver)this.i);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public y3.b f() {
        boolean bl;
        boolean bl2;
        boolean bl3;
        NetworkInfo networkInfo;
        block4 : {
            block3 : {
                networkInfo = this.g.getActiveNetworkInfo();
                bl2 = true;
                bl = networkInfo != null && networkInfo.isConnected() ? bl2 : false;
                try {
                    boolean bl4;
                    Network network = this.g.getActiveNetwork();
                    NetworkCapabilities networkCapabilities = this.g.getNetworkCapabilities(network);
                    if (networkCapabilities == null || !(bl4 = networkCapabilities.hasCapability(16))) break block3;
                    bl3 = bl2;
                    break block4;
                }
                catch (SecurityException securityException) {
                    k k2 = k.c();
                    String string = j;
                    Throwable[] arrthrowable = new Throwable[bl2];
                    arrthrowable[0] = securityException;
                    k2.b(string, "Unable to validate active network", arrthrowable);
                }
            }
            bl3 = false;
        }
        boolean bl5 = this.g.isActiveNetworkMetered();
        if (networkInfo != null && !networkInfo.isRoaming()) {
            return new y3.b(bl, bl3, bl5, bl2);
        }
        bl2 = false;
        return new y3.b(bl, bl3, bl5, bl2);
    }

}

