/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a4.c
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  f4.a
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Objects
 *  t3.k
 */
package a4;

import a4.c;
import a4.d;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import f4.a;
import java.util.Objects;
import t3.k;

public class f
extends c<Boolean> {
    public static final String i = k.e((String)"StorageNotLowTracker");

    public f(Context context, a a2) {
        super(context, a2);
    }

    public Object a() {
        Context context = ((d)this).b;
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.DEVICE_STORAGE_OK");
        intentFilter.addAction("android.intent.action.DEVICE_STORAGE_LOW");
        Intent intent = context.registerReceiver(null, intentFilter);
        if (intent != null && intent.getAction() != null) {
            String string = intent.getAction();
            Objects.requireNonNull((Object)string);
            if (!string.equals((Object)"android.intent.action.DEVICE_STORAGE_LOW")) {
                if (!string.equals((Object)"android.intent.action.DEVICE_STORAGE_OK")) {
                    return null;
                }
                return Boolean.TRUE;
            }
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    public IntentFilter f() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.DEVICE_STORAGE_OK");
        intentFilter.addAction("android.intent.action.DEVICE_STORAGE_LOW");
        return intentFilter;
    }

    public void g(Context context, Intent intent) {
        if (intent.getAction() == null) {
            return;
        }
        k k2 = k.c();
        String string = i;
        Object[] arrobject = new Object[]{intent.getAction()};
        k2.a(string, String.format((String)"Received %s", (Object[])arrobject), new Throwable[0]);
        String string2 = intent.getAction();
        Objects.requireNonNull((Object)string2);
        if (!string2.equals((Object)"android.intent.action.DEVICE_STORAGE_LOW")) {
            if (!string2.equals((Object)"android.intent.action.DEVICE_STORAGE_OK")) {
                return;
            }
            ((d)((Object)this)).c(Boolean.TRUE);
            return;
        }
        ((d)((Object)this)).c(Boolean.FALSE);
    }
}

