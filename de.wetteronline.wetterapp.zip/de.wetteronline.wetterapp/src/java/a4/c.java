/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  t3.k
 */
package a4;

import a4.c;
import a4.d;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import t3.k;

public abstract class c<T>
extends d<T> {
    public static final String h = k.e((String)"BrdcstRcvrCnstrntTrckr");
    public final BroadcastReceiver g = new BroadcastReceiver(this){
        public final /* synthetic */ c a;
        {
            this.a = c3;
        }

        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                this.a.g(context, intent);
            }
        }
    };

    public c(Context context, f4.a a2) {
        super(context, a2);
    }

    @Override
    public void d() {
        k k2 = k.c();
        String string = h;
        Object[] arrobject = new Object[]{this.getClass().getSimpleName()};
        k2.a(string, String.format((String)"%s: registering receiver", (Object[])arrobject), new Throwable[0]);
        this.b.registerReceiver(this.g, this.f());
    }

    @Override
    public void e() {
        k k2 = k.c();
        String string = h;
        Object[] arrobject = new Object[]{this.getClass().getSimpleName()};
        k2.a(string, String.format((String)"%s: unregistering receiver", (Object[])arrobject), new Throwable[0]);
        this.b.unregisterReceiver(this.g);
    }

    public abstract IntentFilter f();

    public abstract void g(Context var1, Intent var2);
}

