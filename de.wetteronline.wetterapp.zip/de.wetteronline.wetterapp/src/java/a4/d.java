/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  f4.a
 *  f4.b
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.LinkedHashSet
 *  java.util.List
 *  java.util.Set
 *  java.util.concurrent.Executor
 *  t3.k
 *  y3.a
 */
package a4;

import android.content.Context;
import f4.b;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import t3.k;

public abstract class d<T> {
    public static final String f = k.e((String)"ConstraintTracker");
    public final f4.a a;
    public final Context b;
    public final Object c = new Object();
    public final Set<y3.a<T>> d = new LinkedHashSet();
    public T e;

    public d(Context context, f4.a a3) {
        this.b = context.getApplicationContext();
        this.a = a3;
    }

    public abstract T a();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void b(y3.a<T> a3) {
        Object object;
        Object object2 = object = this.c;
        synchronized (object2) {
            if (this.d.remove(a3) && this.d.isEmpty()) {
                this.e();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void c(T t) {
        Object object;
        Object object2 = object = this.c;
        synchronized (object2) {
            T t2 = this.e;
            if (!(t2 == t || t2 != null && t2.equals(t))) {
                this.e = t;
                ArrayList arrayList = new ArrayList(this.d);
                ((b)this.a).c.execute(new Runnable((List)arrayList){
                    public final /* synthetic */ List b;
                    {
                        this.b = list;
                    }

                    public void run() {
                        Iterator iterator = this.b.iterator();
                        while (iterator.hasNext()) {
                            ((y3.a)iterator.next()).a(d.this.e);
                        }
                    }
                });
                return;
            }
            return;
        }
    }

    public abstract void d();

    public abstract void e();

}

