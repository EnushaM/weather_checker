/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.SparseArray
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.collection.a
 *  androidx.collection.b
 *  androidx.collection.d
 *  androidx.compose.runtime.collection.b
 *  androidx.compose.ui.platform.AndroidComposeView
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  c1.b
 *  c1.d
 *  c1.g
 *  c1.j
 *  c1.k
 *  c1.l
 *  c1.l$a
 *  c1.m
 *  c1.n
 *  c1.r
 *  co.a
 *  co.h
 *  com.criteo.publisher.m0.q
 *  com.criteo.publisher.model.u
 *  com.criteo.publisher.model.v
 *  com.google.android.gms.internal.measurement.c
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Objects
 *  kotlin.collections.e
 *  o9.a
 *  o9.b
 *  o9.j
 *  os.g1
 *  qb.a
 *  r2.c
 *  r6.g
 *  ri.d
 *  sr.g
 *  um.o
 *  wt.i
 *  wt.j
 *  yl.s
 *  yu.x
 *  z1.f
 */
package a4;

import a.a;
import a.b;
import a4.e;
import a4.f;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Build;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.compose.ui.platform.AndroidComposeView;
import androidx.constraintlayout.widget.ConstraintLayout;
import bn.j;
import bn.r;
import c1.l;
import c1.m;
import com.criteo.publisher.m0.q;
import com.criteo.publisher.model.u;
import com.criteo.publisher.model.v;
import com.google.android.gms.internal.measurement.c;
import e.h;
import e.k;
import f1.a0;
import fm.c;
import hr.t;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import kj.n;
import l9.d;
import l9.l;
import os.g1;
import um.o;
import wt.i;
import yl.s;
import yu.x;

public class g
implements o9.j {
    public static g f;
    public Object b;
    public Object c;
    public Object d;
    public Object e;

    public g(int n2) {
        if (n2 != 4) {
            if (n2 != 5) {
                this.b = new z1.d(256, 0);
                this.c = new z1.d(256, 0);
                this.d = new z1.d(256, 0);
                this.e = new z1.f[32];
                return;
            }
            super();
            this.b = new androidx.collection.a();
            this.c = new SparseArray();
            this.d = new androidx.collection.b();
            this.e = new androidx.collection.a();
            return;
        }
        super();
        this.b = new z1.d(10, 1);
        this.c = new androidx.collection.d();
        this.d = new ArrayList();
        this.e = new HashSet();
    }

    public g(b b2, a a2, ComponentName componentName) {
        this.b = new Object();
        this.c = b2;
        this.d = a2;
        this.e = componentName;
    }

    public g(g g2, c1.c c3) {
        this.d = new HashMap();
        this.e = new HashMap();
        this.b = g2;
        this.c = c3;
    }

    public g(ag.i i2, Boolean bl, String string, String string2) {
        this.b = i2;
        this.c = bl;
        this.d = string;
        this.e = string2;
    }

    public g(Context context) {
        this.b = context;
        this.c = "PREFERENCES";
        this.d = context.getSharedPreferences("PREFERENCES", 0);
        this.e = new ri.d();
        this.k();
        this.c();
    }

    public g(Context context, f4.a a2) {
        Context context2 = context.getApplicationContext();
        this.b = new a4.a(context2, a2);
        this.c = new a4.b(context2, a2);
        this.d = new e(context2, a2);
        this.e = new f(context2, a2);
    }

    public g(ViewGroup viewGroup, rr.l l2) {
        this.b = viewGroup;
        this.c = l2;
        this.d = t.b;
    }

    public g(v v2, r6.g g2) {
        this.b = "";
        this.c = q.b;
        this.d = v2;
        this.e = g2;
    }

    public g(f1.f f2) {
        ma.e.f(f2, "root");
        this.b = f2;
        this.c = new zu.d(f2.B);
        this.d = new c1.l();
        this.e = new ArrayList();
    }

    public g(Throwable throwable, qb.a a2) {
        this.b = throwable.getLocalizedMessage();
        this.c = throwable.getClass().getName();
        this.d = a2.a(throwable.getStackTrace());
        Throwable throwable2 = throwable.getCause();
        g g2 = throwable2 != null ? new g(throwable2, a2) : null;
        this.e = g2;
    }

    public g(o9.a a2, o9.k k2, o9.b b2, o9.j j3) {
        this.b = a2;
        this.c = k2;
        this.d = b2;
        this.e = j3;
    }

    public g(wt.j j3, i i2) {
        this.b = j3;
        this.c = i2;
        this.d = null;
        this.e = null;
    }

    public static g f(Context context, f4.a a2) {
        Class<g> class_ = g.class;
        synchronized (g.class) {
            if (f == null) {
                f = new g(context, a2);
            }
            g g2 = f;
            // ** MonitorExit[var4_2] (shouldn't be in output)
            return g2;
        }
    }

    public void a(jl.c c3, boolean bl) {
        c3.b.d.setActivated(bl);
        c.a.a(c3, bl, false, false, 6, null);
    }

    public void b(T t3) {
        boolean bl = ((androidx.collection.d)this.c).f(t3) >= 0;
        if (!bl) {
            ((androidx.collection.d)this.c).put(t3, null);
        }
    }

    public void c() {
        if (Build.VERSION.SDK_INT >= 24) {
            ((Context)this.b).deleteSharedPreferences((String)this.c);
            return;
        }
        ((SharedPreferences)this.d).edit().clear().apply();
    }

    public void d(T t3, ArrayList<T> arrayList, HashSet<T> hashSet) {
        if (arrayList.contains(t3)) {
            return;
        }
        if (!hashSet.contains(t3)) {
            hashSet.add(t3);
            ArrayList arrayList2 = (ArrayList)((androidx.collection.d)this.c).getOrDefault(t3, null);
            if (arrayList2 != null) {
                int n2 = arrayList2.size();
                for (int i2 = 0; i2 < n2; ++i2) {
                    this.d(arrayList2.get(i2), arrayList, hashSet);
                }
            }
            hashSet.remove(t3);
            arrayList.add(t3);
            return;
        }
        throw new RuntimeException("This graph contains cyclic dependencies");
    }

    public ArrayList<T> e() {
        ArrayList arrayList = (ArrayList)((r2.c)this.b).b();
        if (arrayList == null) {
            arrayList = new ArrayList();
        }
        return arrayList;
    }

    public jl.c g(int n2) {
        Object object = ((ViewGroup)this.b).getChildAt(n2).getTag();
        Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type de.wetteronline.components.features.stream.content.forecast.dayparts.DayPartViewHolder");
        return (jl.c)object;
    }

    public void h(Integer n2) {
        jl.c c3;
        jl.c c4 = (jl.c)this.e;
        if (c4 != null) {
            this.a(c4, false);
        }
        if (n2 == null) {
            c3 = null;
        } else {
            c3 = this.g(n2);
            this.a(c3, true);
        }
        this.e = c3;
    }

    public n i(ViewGroup viewGroup) {
        Context context = viewGroup.getContext();
        ma.e.e((Object)context, "parent.context");
        View view = o.p((Context)context).inflate(2131492952, viewGroup, false);
        int n2 = 2131296400;
        Object t3 = k.m(view, n2);
        if (t3 != null) {
            TextView textView;
            ImageView imageView;
            Object t4;
            TextView textView2;
            TextView textView3;
            ImageView imageView2;
            kj.g g2 = kj.g.b(t3);
            LinearLayout linearLayout = (LinearLayout)view;
            n2 = 2131296590;
            TextView textView4 = (TextView)k.m(view, n2);
            if (textView4 != null && (imageView2 = (ImageView)k.m(view, n2 = 2131296611)) != null && (imageView = (ImageView)k.m(view, n2 = 2131297089)) != null && (textView = (TextView)k.m(view, n2 = 2131297090)) != null && (textView3 = (TextView)k.m(view, n2 = 2131297350)) != null && (textView2 = (TextView)k.m(view, n2 = 2131297392)) != null && (t4 = k.m(view, n2 = 2131297478)) != null) {
                kj.c c3 = kj.c.b(t4);
                n n3 = new n(linearLayout, g2, linearLayout, textView4, imageView2, imageView, textView, textView3, textView2, c3);
                return n3;
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n2)));
    }

    public void j(ViewGroup viewGroup, View view, int n2) {
        if (view == null) {
            n n3 = this.i(viewGroup);
            n3.b().setTag((Object)new jl.c(n3));
            viewGroup.addView((View)n3.b());
            view = n3.b();
            ma.e.e((Object)view, "inflateView(parent).also\u2026w(it.root)\n        }.root");
        }
        Object object = view.getTag();
        Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type de.wetteronline.components.features.stream.content.forecast.dayparts.DayPartViewHolder");
        jl.c c3 = (jl.c)object;
        s s3 = (s)((List)this.d).get(n2);
        rr.l l2 = (rr.l)this.c;
        ma.e.f((Object)s3, "model");
        ma.e.f(l2, "clickListener");
        n n4 = c3.b;
        n4.d.setActivated(false);
        n4.i.setText((CharSequence)s3.d());
        ((ImageView)n4.j.c).setImageResource(s3.d);
        ((ImageView)n4.j.c).setContentDescription((CharSequence)s3.e);
        n4.g.setText((CharSequence)s3.m);
        n4.h.setText((CharSequence)s3.k);
        n4.h.setTextColor(s3.l);
        n4.e.setTextColor(s3.l);
        int n6 = s3.g;
        Integer n7 = s3.h;
        String string = s3.i;
        Integer n8 = s3.j;
        c3.c.o(n6, n7, string, n8);
        int n9 = s3.f;
        String string2 = s3.n;
        c3.c.p(n9, string2);
        com.criteo.publisher.model.r r3 = s3.o;
        kj.g g2 = c3.b.c;
        if (r3 != null) {
            ((TextView)g2.d).setText((CharSequence)((String)r3.c));
            TextView textView = (TextView)g2.d;
            ma.e.e((Object)textView, "aqiValue");
            co.h.a((TextView)textView, (int)r3.d);
        }
        ConstraintLayout constraintLayout = (ConstraintLayout)g2.c;
        ma.e.e((Object)constraintLayout, "aqiContainer");
        boolean bl = false;
        if (r3 != null) {
            bl = true;
        }
        g1.g((View)constraintLayout, (boolean)bl);
        n4.d.setOnClickListener((View.OnClickListener)new jl.b(l2, n2));
    }

    public void k() {
        if (this.l()) {
            ri.d d2 = (ri.d)this.e;
            boolean bl = ((SharedPreferences)this.d).getBoolean("ratingConfirm", false);
            j j3 = d2.a;
            zr.j[] arrj = ri.d.f;
            j3.i(arrj[0], bl);
            long l2 = ((SharedPreferences)this.d).getLong("ratingLast", 0L) * (long)1000;
            d2.c.c((Object)d2, arrj[2], l2);
            int n2 = ((SharedPreferences)this.d).getInt("ratingCount", 0);
            d2.d.i(arrj[3], n2);
            d2.a((int)((SharedPreferences)this.d).getLong("sessionCount", 0L));
        }
    }

    public boolean l() {
        return ((SharedPreferences)this.d).contains("ratingLast");
    }

    public void m(ArrayList<T> arrayList) {
        arrayList.clear();
        ((r2.c)this.b).a(arrayList);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public int n(c1.d var1_1, c1.r var2_2) {
        var3_3 = (c1.l)this.d;
        Objects.requireNonNull((Object)var3_3);
        var5_4 = new LinkedHashMap(((List)var1_1.c).size());
        var6_5 = (List)var1_1.c;
        var7_6 = -1 + var6_5.size();
        if (var7_6 >= 0) {
            var52_7 = 0;
            do {
                var53_23 = var52_7 + 1;
                var54_24 = (m)var6_5.get(var52_7);
                var55_25 = (l.a)var3_3.a.get((Object)new c1.j(var54_24.a));
                if (var55_25 == null) {
                    var85_21 = var54_24.b;
                    var87_22 = var54_24.d;
                    var63_30 = var85_21;
                    var66_9 = var87_22;
                    var65_8 = false;
                } else {
                    var56_26 = var55_25.a;
                    var58_27 = var55_25.c;
                    var59_28 = var55_25.b;
                    var61_29 = ((AndroidComposeView)var2_2).F(var59_28);
                    var63_30 = var56_26;
                    var65_8 = var58_27;
                    var66_9 = var61_29;
                }
                var68_10 = var54_24.a;
                var70_11 = new c1.j(var68_10);
                var71_12 = var54_24.b;
                var73_13 = var54_24.d;
                var75_14 = var54_24.e;
                var76_15 = var6_5;
                var77_16 = new c1.k(var68_10, var71_12, var73_13, var75_14, var63_30, var66_9, var65_8, new c1.b(false, false, 3), var54_24.f, null);
                var5_4.put((Object)var70_11, (Object)var77_16);
                var79_17 = var54_24.e;
                if (var79_17) {
                    var81_18 = var3_3.a;
                    var82_19 = new c1.j(var54_24.a);
                    var83_20 = new l.a(var54_24.b, var54_24.c, var79_17, null);
                    var81_18.put((Object)var82_19, (Object)var83_20);
                } else {
                    var3_3.a.remove((Object)new c1.j(var54_24.a));
                }
                if (var53_23 > var7_6) break;
                var52_7 = var53_23;
                var6_5 = var76_15;
            } while (true);
        }
        var8_31 = new c1.c((Map)var5_4, (MotionEvent)var1_1.b);
        var9_32 = var8_31.b.values().iterator();
        do {
            block18 : {
                block19 : {
                    block17 : {
                        var10_33 = var9_32.hasNext();
                        var11_34 = 1;
                        if (!var10_33) break block17;
                        var23_35 = (c1.k)var9_32.next();
                        ma.e.f((Object)var23_35, "<this>");
                        var24_36 = var23_35.g == false && var23_35.d != false ? var11_34 : 0;
                        if (var24_36 == 0) continue;
                        var25_37 = (f1.f)this.b;
                        var26_38 = var23_35.c;
                        var28_39 = (List)this.e;
                        Objects.requireNonNull((Object)var25_37);
                        ma.e.f((Object)var28_39, "hitPointerInputFilters");
                        var30_40 = var25_37.C.g.u0(var26_38);
                        var25_37.C.g.A0(var30_40, (List<c1.n>)var28_39);
                        if (!(var11_34 ^ ((List)this.e).isEmpty())) continue;
                        var32_41 = (zu.d)this.c;
                        var33_42 = var23_35.a;
                        var35_43 = (List)this.e;
                        Objects.requireNonNull((Object)var32_41);
                        ma.e.f((Object)var35_43, "pointerInputFilters");
                        var37_44 = (c1.g)var32_41.d;
                        var38_45 = -1 + var35_43.size();
                        if (var38_45 < 0) break block18;
                        break block19;
                    }
                    ((c1.g)((zu.d)this.c).d).e();
                    var12_56 = (zu.d)this.c;
                    Objects.requireNonNull((Object)var12_56);
                    var14_57 = ((c1.g)var12_56.d).c(var8_31.b, (e1.h)var12_56.c, var8_31);
                    var15_58 = !((c1.g)var12_56.d).b() && !var14_57 ? 0 : var11_34;
                    var16_59 = var8_31.b.values().iterator();
                    var17_60 = 0;
                    while (var16_59.hasNext()) {
                        var19_61 = (c1.k)var16_59.next();
                        if (h.g(var19_61)) {
                            var20_62 = (zu.d)this.c;
                            var21_63 = var19_61.a;
                            ((c1.g)var20_62.d).d(var21_63);
                        }
                        if (!h.z(var19_61)) continue;
                        var17_60 = var11_34;
                    }
                    if (var17_60 != 0) {
                        var18_64 = 2;
                        return var15_58 | var18_64;
                    }
                    var18_64 = 0;
                    return var15_58 | var18_64;
                }
                var39_46 = 0;
                do {
                    block16 : {
                        var40_47 = var39_46 + 1;
                        var41_48 = (c1.n)var35_43.get(var39_46);
                        if (var11_34 == 0) ** GOTO lbl118
                        var45_50 = var37_44.a;
                        var46_51 = var45_50.d;
                        if (var46_51 > 0) {
                            var50_54 = var45_50.b;
                            var51_55 = 0;
                            do {
                                var47_52 = var50_54[var51_55];
                                if (ma.e.a((Object)((c1.f)var47_52).b, (Object)var41_48)) break block16;
                            } while (++var51_55 < var46_51);
                        }
                        var47_52 = null;
                    }
                    if ((var48_53 = (c1.f)var47_52) != null) {
                        if (!var48_53.c.g((Object)new c1.j(var33_42))) {
                            var48_53.c.b((Object)new c1.j(var33_42));
                        }
                        var37_44 = var48_53;
                    } else {
                        var11_34 = 0;
lbl118: // 2 sources:
                        var42_49 = new c1.f(var41_48);
                        var42_49.c.b((Object)new c1.j(var33_42));
                        var37_44.a.b((Object)var42_49);
                        var37_44 = var42_49;
                    }
                    if (var40_47 > var38_45) break;
                    var39_46 = var40_47;
                } while (true);
            }
            ((List)this.e).clear();
        } while (true);
    }

    public void o() {
        yr.f f2 = co.a.Q((int)0, (int)(((ViewGroup)this.b).getChildCount() - ((List)this.d).size()));
        ViewGroup viewGroup = (ViewGroup)this.b;
        Iterator iterator = f2.iterator();
        while (iterator.hasNext()) {
            viewGroup.removeViewAt(((kotlin.collections.e)iterator).a());
        }
    }

    public void p() {
        int n2 = -1 + ((List)this.d).size();
        if (n2 >= 0) {
            int n3 = 0;
            do {
                int n4 = n3 + 1;
                Object object = this.b;
                this.j((ViewGroup)object, ((ViewGroup)object).getChildAt(n3), n3);
                if (n4 > n2) {
                    return;
                }
                n3 = n4;
            } while (true);
        }
    }

    public g q() {
        return new g(this, (c1.c)this.c);
    }

    public l r(l l2) {
        return ((c1.c)this.c).q(this, l2);
    }

    public l s(c c3) {
        int n2;
        l l2 = l.X;
        Iterator iterator = c3.l();
        while (iterator.hasNext() && !((l2 = ((c1.c)this.c).q(this, c3.i(n2 = ((Integer)iterator.next()).intValue()))) instanceof d)) {
        }
        return l2;
    }

    public l t(String string) {
        if (((Map)this.d).containsKey((Object)string)) {
            return (l)((Map)this.d).get((Object)string);
        }
        g g2 = (g)this.b;
        if (g2 != null) {
            return g2.t(string);
        }
        throw new IllegalArgumentException(String.format((String)"%s is not defined", (Object[])new Object[]{string}));
    }

    public void u(String string, l l2) {
        if (((Map)this.e).containsKey((Object)string)) {
            return;
        }
        if (l2 == null) {
            ((Map)this.d).remove((Object)string);
            return;
        }
        ((Map)this.d).put((Object)string, (Object)l2);
    }

    public void v(String string, l l2) {
        g g2;
        if (!((Map)this.d).containsKey((Object)string) && (g2 = (g)this.b) != null && g2.w(string)) {
            ((g)this.b).v(string, l2);
            return;
        }
        if (((Map)this.e).containsKey((Object)string)) {
            return;
        }
        if (l2 == null) {
            ((Map)this.d).remove((Object)string);
            return;
        }
        ((Map)this.d).put((Object)string, (Object)l2);
    }

    public boolean w(String string) {
        if (((Map)this.d).containsKey((Object)string)) {
            return true;
        }
        g g2 = (g)this.b;
        if (g2 != null) {
            return g2.w(string);
        }
        return false;
    }

    public void zza() {
        o9.a a2 = (o9.a)this.b;
        o9.k k2 = (o9.k)this.c;
        o9.b b2 = (o9.b)this.d;
        o9.j j3 = (o9.j)this.e;
        k2.b = false;
        a2.e(b2);
        if (j3 != null) {
            j3.zza();
        }
    }
}

