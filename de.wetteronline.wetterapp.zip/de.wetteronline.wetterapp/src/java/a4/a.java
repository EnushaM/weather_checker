/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a4.c
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  f4.a
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  t3.k
 */
package a4;

import a4.c;
import a4.d;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import t3.k;

public class a
extends c<Boolean> {
    public static final String i = k.e((String)"BatteryChrgTracker");

    public a(Context context, f4.a a2) {
        super(context, a2);
    }

    public Object a() {
        boolean bl;
        block5 : {
            block4 : {
                IntentFilter intentFilter = new IntentFilter("android.intent.action.BATTERY_CHANGED");
                Intent intent = ((d)this).b.registerReceiver(null, intentFilter);
                if (intent == null) {
                    k.c().b(i, "getInitialState - null intent received", new Throwable[0]);
                    return null;
                }
                int n2 = intent.getIntExtra("status", -1);
                if (n2 == 2) break block4;
                bl = false;
                if (n2 != 5) break block5;
            }
            bl = true;
        }
        return bl;
    }

    public IntentFilter f() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.os.action.CHARGING");
        intentFilter.addAction("android.os.action.DISCHARGING");
        return intentFilter;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void g(Context var1_1, Intent var2_2) {
        block14 : {
            block15 : {
                var3_3 = var2_2.getAction();
                if (var3_3 == null) {
                    return;
                }
                var4_4 = k.c();
                var5_5 = a.i;
                var6_6 = 1;
                var7_7 = new Object[var6_6];
                var7_7[0] = var3_3;
                var4_4.a(var5_5, String.format((String)"Received %s", (Object[])var7_7), new Throwable[0]);
                switch (var3_3.hashCode()) {
                    case 1019184907: {
                        if (!var3_3.equals((Object)"android.intent.action.ACTION_POWER_CONNECTED")) break;
                        var6_6 = 3;
                        ** break;
                    }
                    case 948344062: {
                        if (!var3_3.equals((Object)"android.os.action.CHARGING")) break;
                        var6_6 = 2;
                        ** break;
                    }
                    case -54942926: {
                        if (!var3_3.equals((Object)"android.os.action.DISCHARGING")) {
                            break;
                        }
                        break block14;
                    }
                    case -1886648615: {
                        if (var3_3.equals((Object)"android.intent.action.ACTION_POWER_DISCONNECTED")) break block15;
                    }
                }
                var6_6 = -1;
                ** break;
            }
            var6_6 = 0;
        }
        switch (var6_6) {
            default: {
                return;
            }
            case 3: {
                this.c(Boolean.TRUE);
                return;
            }
            case 2: {
                this.c(Boolean.TRUE);
                return;
            }
            case 1: {
                this.c(Boolean.FALSE);
                return;
            }
            case 0: 
        }
        this.c(Boolean.FALSE);
    }
}

