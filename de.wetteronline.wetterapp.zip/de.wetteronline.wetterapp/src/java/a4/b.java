/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a4.c
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  f4.a
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Objects
 *  t3.k
 */
package a4;

import a4.c;
import a4.d;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import f4.a;
import java.util.Objects;
import t3.k;

public class b
extends c<Boolean> {
    public static final String i = k.e((String)"BatteryNotLowTracker");

    public b(Context context, a a2) {
        super(context, a2);
    }

    public Object a() {
        boolean bl;
        block5 : {
            block4 : {
                IntentFilter intentFilter = new IntentFilter("android.intent.action.BATTERY_CHANGED");
                Intent intent = ((d)this).b.registerReceiver(null, intentFilter);
                if (intent == null) {
                    k.c().b(i, "getInitialState - null intent received", new Throwable[0]);
                    return null;
                }
                int n2 = intent.getIntExtra("status", -1);
                int n3 = intent.getIntExtra("level", -1);
                int n4 = intent.getIntExtra("scale", -1);
                float f2 = (float)n3 / (float)n4;
                if (n2 == 1) break block4;
                float f3 = f2 FCMPL 0.15f;
                bl = false;
                if (f3 <= 0) break block5;
            }
            bl = true;
        }
        return bl;
    }

    public IntentFilter f() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.BATTERY_OKAY");
        intentFilter.addAction("android.intent.action.BATTERY_LOW");
        return intentFilter;
    }

    public void g(Context context, Intent intent) {
        if (intent.getAction() == null) {
            return;
        }
        k k2 = k.c();
        String string = i;
        Object[] arrobject = new Object[]{intent.getAction()};
        k2.a(string, String.format((String)"Received %s", (Object[])arrobject), new Throwable[0]);
        String string2 = intent.getAction();
        Objects.requireNonNull((Object)string2);
        if (!string2.equals((Object)"android.intent.action.BATTERY_OKAY")) {
            if (!string2.equals((Object)"android.intent.action.BATTERY_LOW")) {
                return;
            }
            ((d)((Object)this)).c(Boolean.FALSE);
            return;
        }
        ((d)((Object)this)).c(Boolean.TRUE);
    }
}

