/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a8;

import a8.f;
import a8.k;

public interface c {
    public k create(f var1);
}

