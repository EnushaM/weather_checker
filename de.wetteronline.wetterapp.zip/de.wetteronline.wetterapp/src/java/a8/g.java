/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  h8.a
 *  java.lang.Object
 */
package a8;

import android.content.Context;
import h8.a;

public class g {
    public final Context a;
    public final a b;
    public final a c;

    public g(Context context, a a3, a a4) {
        this.a = context;
        this.b = a3;
        this.c = a4;
    }
}

