/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package a8;

import a8.b;
import a8.c;
import a8.d;
import a8.f;
import a8.g;
import a8.k;
import android.content.Context;
import java.util.HashMap;
import java.util.Map;

public class i
implements d {
    public final a a;
    public final g b;
    public final Map<String, k> c;

    public i(Context context, g g2) {
        Object object = new Object(context){
            public final Context a;
            public Map<String, String> b = null;
            {
                this.a = context;
            }

            /*
             * Exception decompiling
             */
            public c a(String var1) {
                // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl29.1 : ACONST_NULL : trying to set 1 previously set to 0
                // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
                // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
                // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
                // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
                // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
                // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
                // org.benf.cfr.reader.entities.g.p(Method.java:396)
                // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
                // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
                // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
                // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
                // org.benf.cfr.reader.b.a(Driver.java:128)
                // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
                // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
                // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
                // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
                // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
                // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
                // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
                // java.lang.Thread.run(Thread.java:923)
                throw new IllegalStateException("Decompilation failed");
            }
        };
        this.c = new HashMap();
        this.a = object;
        this.b = g2;
    }

    @Override
    public k a(String string) {
        i i2 = this;
        synchronized (i2) {
            c c3;
            block6 : {
                block5 : {
                    if (!this.c.containsKey((Object)string)) break block5;
                    k k2 = (k)this.c.get((Object)string);
                    return k2;
                }
                c3 = this.a.a(string);
                if (c3 != null) break block6;
                return null;
            }
            g g2 = this.b;
            k k3 = c3.create(new b(g2.a, g2.b, g2.c, string));
            this.c.put((Object)string, (Object)k3);
            return k3;
        }
    }

}

