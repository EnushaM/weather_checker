/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Iterable
 *  java.lang.Object
 *  z7.f
 */
package a8;

import z7.f;

public abstract class e {
    public abstract Iterable<f> a();

    public abstract byte[] b();
}

