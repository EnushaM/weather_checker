/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.support.v4.media.b
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Objects
 */
package a8;

import a8.f;
import android.content.Context;
import h8.a;
import java.util.Objects;

public final class b
extends f {
    public final Context a;
    public final a b;
    public final a c;
    public final String d;

    public b(Context context, a a2, a a3, String string) {
        Objects.requireNonNull((Object)context, (String)"Null applicationContext");
        this.a = context;
        Objects.requireNonNull((Object)a2, (String)"Null wallClock");
        this.b = a2;
        Objects.requireNonNull((Object)a3, (String)"Null monotonicClock");
        this.c = a3;
        Objects.requireNonNull((Object)string, (String)"Null backendName");
        this.d = string;
    }

    @Override
    public Context a() {
        return this.a;
    }

    @Override
    public String b() {
        return this.d;
    }

    @Override
    public a c() {
        return this.c;
    }

    @Override
    public a d() {
        return this.b;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof f) {
            f f2 = (f)object;
            return this.a.equals((Object)f2.a()) && this.b.equals((Object)f2.d()) && this.c.equals((Object)f2.c()) && this.d.equals((Object)f2.b());
        }
        return false;
    }

    public int hashCode() {
        return 1000003 * (1000003 * (1000003 * (1000003 ^ this.a.hashCode()) ^ this.b.hashCode()) ^ this.c.hashCode()) ^ this.d.hashCode();
    }

    public String toString() {
        StringBuilder stringBuilder = android.support.v4.media.b.a((String)"CreationContext{applicationContext=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", wallClock=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", monotonicClock=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", backendName=");
        return b2.a.a(stringBuilder, this.d, "}");
    }
}

