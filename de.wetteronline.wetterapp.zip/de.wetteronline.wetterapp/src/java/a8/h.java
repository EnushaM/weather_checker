/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.g;
import android.content.Context;
import f8.o;
import h8.a;

public final class h
implements fr.a {
    public final /* synthetic */ int a;
    public final fr.a<Context> b;
    public final fr.a<a> c;
    public final fr.a<a> d;

    public h(fr.a a2, fr.a a3, fr.a a4, int n2) {
        this.a = n2;
        if (n2 != 1) {
            this.b = a2;
            this.c = a3;
            this.d = a4;
            return;
        }
        super();
        this.b = a2;
        this.c = a3;
        this.d = a4;
    }

    public Object get() {
        switch (this.a) {
            default: {
                break;
            }
            case 0: {
                return new g(this.b.get(), this.c.get(), this.d.get());
            }
        }
        return new o(this.b.get(), (String)((Object)this.c.get()), (Integer)this.d.get());
    }
}

