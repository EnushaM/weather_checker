/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.datatransport.runtime.backends.b
 *  java.lang.Object
 *  z7.f
 */
package a8;

import a8.e;
import com.google.android.datatransport.runtime.backends.b;
import z7.f;

public interface k {
    public b a(e var1);

    public f b(f var1);
}

