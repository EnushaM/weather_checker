/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  z7.f
 */
package a8;

import a8.a;
import a8.e;
import android.support.v4.media.b;
import java.util.Arrays;
import z7.f;

public final class a
extends e {
    public final Iterable<f> a;
    public final byte[] b;

    public a(Iterable iterable, byte[] arrby, a a2) {
        this.a = iterable;
        this.b = arrby;
    }

    @Override
    public Iterable<f> a() {
        return this.a;
    }

    @Override
    public byte[] b() {
        return this.b;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof e) {
            byte[] arrby;
            byte[] arrby2;
            e e2 = (e)object;
            return this.a.equals(e2.a()) && Arrays.equals((byte[])(arrby2 = this.b), (byte[])(arrby = e2 instanceof a ? ((a)e2).b : e2.b()));
        }
        return false;
    }

    public int hashCode() {
        return 1000003 * (1000003 ^ this.a.hashCode()) ^ Arrays.hashCode((byte[])this.b);
    }

    public String toString() {
        StringBuilder stringBuilder = b.a((String)"BackendRequest{events=");
        stringBuilder.append(this.a);
        stringBuilder.append(", extras=");
        stringBuilder.append(Arrays.toString((byte[])this.b));
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

