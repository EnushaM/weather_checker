/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 */
package a8;

import a8.g;
import a8.i;
import android.content.Context;
import fr.a;

public final class j
implements a {
    public final a<Context> a;
    public final a<g> b;

    public j(a<Context> a2, a<g> a3) {
        this.a = a2;
        this.b = a3;
    }

    public Object get() {
        return new i(this.a.get(), this.b.get());
    }
}

