/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  sr.g
 *  t0.q
 */
package a0;

import android.support.v4.media.b;
import sr.g;
import t0.q;

public final class h {
    public final long a;
    public final long b;

    public h(long l3, long l4, g g3) {
        this.a = l3;
        this.b = l4;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof h)) {
            return false;
        }
        long l3 = this.a;
        h h2 = (h)object;
        if (!q.b((long)l3, (long)h2.a)) {
            return false;
        }
        return q.b((long)this.b, (long)h2.b);
    }

    public int hashCode() {
        return 31 * q.h((long)this.a) + q.h((long)this.b);
    }

    public String toString() {
        StringBuilder stringBuilder = b.a((String)"SelectionColors(selectionHandleColor=");
        stringBuilder.append((Object)q.i((long)this.a));
        stringBuilder.append(", selectionBackgroundColor=");
        stringBuilder.append((Object)q.i((long)this.b));
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}

