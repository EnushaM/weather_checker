/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e1.h
 *  java.lang.Long
 *  java.lang.Object
 *  java.util.Map
 */
package a0;

import a0.c;
import a0.d;
import a0.e;
import e1.h;
import java.util.Map;

public interface f {
    public void a(c var1);

    public void b(long var1);

    public c c(c var1);

    public long d();

    public void e(h var1, long var2, e var4);

    public void f(h var1, long var2, long var4, e var6);

    public void g(long var1);

    public void h();

    public Map<Long, d> i();

    public void j(long var1);
}

