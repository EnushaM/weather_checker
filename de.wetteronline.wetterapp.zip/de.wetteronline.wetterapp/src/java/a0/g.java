/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a0.g$a
 *  e0.w
 *  e0.x0
 *  java.lang.Long
 *  java.lang.Object
 *  java.util.Map
 *  rr.a
 */
package a0;

import a0.d;
import a0.f;
import a0.g;
import e0.w;
import e0.x0;
import java.util.Map;

public final class g {
    public static final x0<f> a = w.c(null, (rr.a)a.c, (int)1);

    public static final boolean a(f f2, long l3) {
        if (f2 == null) {
            return false;
        }
        return f2.i().containsKey((Object)l3);
    }
}

