/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a0.i$a
 *  e.n
 *  e0.w
 *  e0.x0
 *  java.lang.Object
 *  rr.a
 *  sr.g
 *  t0.q
 */
package a0;

import a0.h;
import a0.i;
import e.n;
import e0.w;
import e0.x0;
import sr.g;
import t0.q;

public final class i {
    public static final x0<h> a;
    public static final h b;

    public static {
        h h2;
        a = w.c(null, (rr.a)a.c, (int)1);
        long l3 = n.c((long)4282550004L);
        b = h2 = new h(l3, q.a((long)l3, (float)0.4f, (float)0.0f, (float)0.0f, (float)0.0f, (int)14), null);
    }
}

