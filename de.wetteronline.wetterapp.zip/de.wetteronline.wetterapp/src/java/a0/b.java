/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a0;

import a0.c;
import e1.h;
import l1.s;
import rr.a;

public final class b
implements c {
    public final a<h> a;
    public final a<s> b;

    public b(long l2, a<? extends h> a2, a<s> a3) {
        this.a = a2;
        this.b = a3;
    }
}

