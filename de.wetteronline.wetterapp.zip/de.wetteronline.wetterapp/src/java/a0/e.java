/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package a0;

public final class e
extends Enum<e> {
    public static final /* enum */ e b;
    public static final /* enum */ e c;
    public static final /* enum */ e d;
    public static final /* enum */ e e;
    public static final /* synthetic */ e[] f;

    public static {
        e e2;
        e e3;
        e e4;
        e e5;
        b = e4 = new e();
        c = e3 = new e();
        d = e2 = new e();
        e = e5 = new e();
        f = new e[]{e4, e3, e2, e5};
    }

    public static e valueOf(String string) {
        return (e)Enum.valueOf(e.class, (String)string);
    }

    public static e[] values() {
        return (e[])f.clone();
    }
}

