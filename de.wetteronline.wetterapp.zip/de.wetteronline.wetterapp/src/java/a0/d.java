/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  ma.e
 */
package a0;

import java.util.Objects;
import ma.e;

public final class d {
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof d)) {
            return false;
        }
        Objects.requireNonNull((Object)((d)object));
        if (!e.a(null, null)) {
            return false;
        }
        return e.a(null, null);
    }

    public int hashCode() {
        throw null;
    }

    public String toString() {
        return "Selection(start=null, end=null, handlesCrossed=false)";
    }
}

