/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  bb.a
 *  bb.c
 *  j
 *  j$.util.concurrent.ConcurrentHashMap
 *  java.lang.Boolean
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 *  java.util.Objects
 *  java.util.Set
 *  java.util.concurrent.ExecutorService
 *  r9.a
 */
package ab;

import ab.a;
import android.os.Bundle;
import bb.c;
import bb.e;
import bb.g;
import i9.d;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import l9.k0;
import l9.y0;

public class b
implements ab.a {
    public static volatile ab.a c;
    public final r9.a a;
    public final Map<String, bb.a> b;

    public b(r9.a a2) {
        Objects.requireNonNull((Object)a2, (String)"null reference");
        this.a = a2;
        this.b = new j.ConcurrentHashMap();
    }

    /*
     * Exception decompiling
     */
    @Override
    public void a(a.c var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl69.1 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public Map<String, Object> b(boolean bl) {
        return this.a.a.m(null, null, bl);
    }

    @Override
    public void c(String string, String string2, Bundle bundle) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        Bundle bundle2 = bundle;
        if (!c.c((String)string)) {
            return;
        }
        if (!c.b((String)string2, (Bundle)bundle2)) {
            return;
        }
        if (!c.a((String)string, (String)string2, (Bundle)bundle2)) {
            return;
        }
        if ("clx".equals((Object)string) && "_ae".equals((Object)string2)) {
            bundle2.putLong("_r", 1L);
        }
        this.a.a.c(string, string2, bundle2, true, true, null);
    }

    @Override
    public void clearConditionalUserProperty(String string, String string2, Bundle bundle) {
        y0 y02 = this.a.a;
        Objects.requireNonNull((Object)y02);
        k0 k02 = new k0(y02, string, null, null);
        y02.a.execute((Runnable)k02);
    }

    @Override
    public int d(String string) {
        return this.a.a.d(string);
    }

    @Override
    public a.a e(final String string, a.b b2) {
        Objects.requireNonNull((Object)b2, (String)"null reference");
        if (!c.c((String)string)) {
            return null;
        }
        if (this.h(string)) {
            return null;
        }
        r9.a a2 = this.a;
        Object object = "fiam".equals((Object)string) ? new e(a2, b2) : (!"crash".equals((Object)string) && !"clx".equals((Object)string) ? null : new g(a2, b2));
        if (object != null) {
            this.b.put((Object)string, object);
            return new a.a(){

                @Override
                public void a(Set<String> set) {
                    if (b.this.h(string) && string.equals((Object)"fiam") && set != null) {
                        if (set.isEmpty()) {
                            return;
                        }
                        ((bb.a)b.this.b.get((Object)string)).a(set);
                    }
                }
            };
        }
        return null;
    }

    @Override
    public List<a.c> f(String string, String string2) {
        ArrayList arrayList = new ArrayList();
        for (Bundle bundle : this.a.a.l(string, string2)) {
            Objects.requireNonNull((Object)bundle, (String)"null reference");
            a.c c3 = new a.c();
            String string3 = d.p(bundle, "origin", String.class, null);
            Objects.requireNonNull((Object)string3, (String)"null reference");
            c3.a = string3;
            String string4 = d.p(bundle, "name", String.class, null);
            Objects.requireNonNull((Object)string4, (String)"null reference");
            c3.b = string4;
            c3.c = d.p(bundle, "value", Object.class, null);
            c3.d = d.p(bundle, "trigger_event_name", String.class, null);
            Long l2 = 0L;
            c3.e = d.p(bundle, "trigger_timeout", Long.class, l2);
            c3.f = d.p(bundle, "timed_out_event_name", String.class, null);
            c3.g = d.p(bundle, "timed_out_event_params", Bundle.class, null);
            c3.h = d.p(bundle, "triggered_event_name", String.class, null);
            c3.i = d.p(bundle, "triggered_event_params", Bundle.class, null);
            c3.j = d.p(bundle, "time_to_live", Long.class, l2);
            c3.k = d.p(bundle, "expired_event_name", String.class, null);
            c3.l = d.p(bundle, "expired_event_params", Bundle.class, null);
            c3.n = d.p(bundle, "active", Boolean.class, Boolean.FALSE);
            c3.m = d.p(bundle, "creation_timestamp", Long.class, l2);
            c3.o = d.p(bundle, "triggered_timestamp", Long.class, l2);
            arrayList.add((Object)c3);
        }
        return arrayList;
    }

    @Override
    public void g(String string, String string2, Object object) {
        if (!c.c((String)string)) {
            return;
        }
        if (!c.d((String)string, (String)string2)) {
            return;
        }
        this.a.a.a(string, string2, object, true);
    }

    public final boolean h(String string) {
        return !string.isEmpty() && this.b.containsKey((Object)string) && this.b.get((Object)string) != null;
    }

}

