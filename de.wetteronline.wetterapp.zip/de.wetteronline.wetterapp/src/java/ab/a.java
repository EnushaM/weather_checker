/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 */
package ab;

import android.os.Bundle;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface a {
    public void a(c var1);

    public Map<String, Object> b(boolean var1);

    public void c(String var1, String var2, Bundle var3);

    public void clearConditionalUserProperty(String var1, String var2, Bundle var3);

    public int d(String var1);

    public a e(String var1, b var2);

    public List<c> f(String var1, String var2);

    public void g(String var1, String var2, Object var3);

    public static interface a {
        public void a(Set<String> var1);
    }

    public static interface b {
        public void a(int var1, Bundle var2);
    }

    public static class c {
        public String a;
        public String b;
        public Object c;
        public String d;
        public long e;
        public String f;
        public Bundle g;
        public String h;
        public Bundle i;
        public long j;
        public String k;
        public Bundle l;
        public long m;
        public boolean n;
        public long o;
    }

}

