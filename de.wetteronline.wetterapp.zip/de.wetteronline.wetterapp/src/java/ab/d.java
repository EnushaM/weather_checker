/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.Executor
 */
package ab;

import java.util.concurrent.Executor;

public final class d
implements Executor {
    public static final /* synthetic */ d b;

    public static /* synthetic */ {
        b = new d();
    }

    public final void execute(Runnable runnable) {
        runnable.run();
    }
}

