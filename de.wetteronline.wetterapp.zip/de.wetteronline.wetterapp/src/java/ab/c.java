/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Objects
 *  xb.a
 */
package ab;

import java.util.Objects;
import xb.a;
import xb.b;

public final class c
implements b {
    public static final /* synthetic */ c a;

    public static /* synthetic */ {
        a = new c();
    }

    public final void a(a a2) {
        Objects.requireNonNull((Object)a2);
        Objects.requireNonNull(null);
        throw null;
    }
}

