/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

public final class o1
extends Enum<o1> {
    public static final /* enum */ o1 b;
    public static final /* enum */ o1 c;
    public static final /* enum */ o1 d;
    public static final /* enum */ o1 e;
    public static final /* enum */ o1 f;
    public static final /* synthetic */ o1[] g;

    public static {
        o1 o12;
        o1 o13;
        o1 o14;
        o1 o15;
        o1 o16;
        b = o16 = new o1();
        c = o14 = new o1();
        d = o15 = new o1();
        e = o13 = new o1();
        f = o12 = new o1();
        g = new o1[]{o16, o14, o15, o13, o12};
    }

    public static o1 valueOf(String string) {
        return (o1)Enum.valueOf(o1.class, (String)string);
    }

    public static o1[] values() {
        return (o1[])g.clone();
    }
}

