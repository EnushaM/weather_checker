/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.ui.text.intl.a
 *  b0.u2$a
 *  b0.u2$b
 *  b0.u2$c
 *  b0.u2$d
 *  b0.u2$e
 *  b0.u2$f
 *  e0.g
 *  e0.l1
 *  e0.s1
 *  e0.v
 *  e0.w
 *  e0.x0
 *  e0.y0
 *  e0.z1
 *  gr.v
 *  hr.u
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 *  l1.a
 *  l1.s
 *  l1.u
 *  ma.e
 *  o0.g
 *  o0.g$a
 *  p1.d
 *  p1.e
 *  p1.f
 *  p1.g
 *  rr.a
 *  rr.l
 *  rr.p
 *  t0.h0
 *  t0.q
 *  u1.a
 *  u1.b
 *  u1.c
 *  u1.d
 *  u1.e
 *  u1.f
 *  x1.i
 *  z.a
 *  z.d
 */
package b0;

import b0.p;
import b0.q;
import b0.u2;
import e0.l1;
import e0.s1;
import e0.w;
import e0.x0;
import e0.y0;
import e0.z1;
import gr.v;
import hr.u;
import java.util.List;
import java.util.Map;
import l1.s;
import o0.g;
import p1.g;
import rr.l;
import t0.h0;
import x1.i;

public final class u2 {
    public static final x0<l1.u> a = w.b((s1)z1.a, (rr.a)a.c);

    public static final void a(l1.u u3, rr.p<? super e0.g, ? super Integer, v> p2, e0.g g3, int n2) {
        int n3;
        ma.e.f((Object)u3, (String)"value");
        ma.e.f(p2, (String)"content");
        e0.g g4 = g3.o(1919620117);
        if ((n2 & 14) == 0) {
            int n4 = g4.M((Object)u3) ? 4 : 2;
            n3 = n4 | n2;
        } else {
            n3 = n2;
        }
        if ((n2 & 112) == 0) {
            int n5 = g4.M(p2) ? 32 : 16;
            n3 |= n5;
        }
        if ((18 ^ n3 & 91) == 0 && g4.r()) {
            g4.x();
        } else {
            x0<l1.u> x02 = a;
            l1.u u4 = ((l1.u)g4.K(x02)).a(u3);
            y0[] arry0 = new y0[]{x02.b((Object)u4)};
            w.a((y0[])arry0, p2, (e0.g)g4, (int)(8 | n3 & 112));
        }
        l1 l12 = g4.u();
        if (l12 == null) {
            return;
        }
        l12.a((rr.p)new b(u3, p2, n2));
    }

    public static final void b(l1.a a3, o0.g g3, long l3, long l4, p1.e e2, g g4, p1.d d3, long l5, u1.c c3, u1.b b3, long l6, int n2, boolean bl, int n3, Map<String, z.d> map, l<? super s, v> l7, l1.u u3, e0.g g5, int n4, int n5, int n6) {
        long l8;
        boolean bl2;
        p1.e e3;
        g g6;
        l<? super s, v> l9;
        int n7;
        l1.u u4;
        u1.c c4;
        Map<String, z.d> map2;
        long l10;
        long l11;
        int n8;
        long l12;
        int n9;
        int n10;
        long l13;
        p1.d d4;
        int n11;
        u1.b b4;
        o0.g g7;
        int n12;
        ma.e.f((Object)a3, (String)"text");
        e0.g g8 = g5.o(1557616910);
        if ((n6 & 1) != 0) {
            n12 = n4 | 6;
        } else if ((n4 & 14) == 0) {
            int n13 = g8.M((Object)a3) ? 4 : 2;
            n12 = n13 | n4;
        } else {
            n12 = n4;
        }
        int n14 = n6 & 2;
        if (n14 != 0) {
            n12 |= 48;
        } else if ((n4 & 112) == 0) {
            int n15 = g8.M((Object)g3) ? 32 : 16;
            n12 |= n15;
        }
        if ((n4 & 896) == 0) {
            int n16 = n6 & 4;
            l8 = l3;
            int n17 = n16 == 0 && g8.i(l8) ? 256 : 128;
            n12 |= n17;
        } else {
            l8 = l3;
        }
        if ((n4 & 7168) == 0) {
            int n18 = (n6 & 8) == 0 && g8.i(l4) ? 2048 : 1024;
            n12 |= n18;
        }
        if ((n8 = n6 & 16) != 0) {
            n12 |= 8192;
        }
        int n19 = n6 & 32;
        int n20 = 131072;
        if (n19 != 0) {
            n12 |= 196608;
        } else if ((n4 & 458752) == 0) {
            int n21 = g8.M((Object)g4) ? n20 : 65536;
            n12 |= n21;
        }
        int n22 = n6 & 64;
        if (n22 != 0) {
            n12 |= 1572864;
        } else if ((n4 & 3670016) == 0) {
            int n23 = g8.M((Object)d3) ? 1048576 : 524288;
            n12 |= n23;
        }
        if ((n4 & 29360128) == 0) {
            int n24 = (n6 & 128) == 0 && g8.i(l5) ? 8388608 : 4194304;
            n12 |= n24;
        }
        if ((n11 = n6 & 256) != 0) {
            n12 |= 100663296;
        } else if ((n4 & 234881024) == 0) {
            int n25 = g8.M((Object)c3) ? 67108864 : 33554432;
            n12 |= n25;
        }
        int n26 = n6 & 512;
        if (n26 != 0) {
            n12 |= 268435456;
        }
        if ((n5 & 14) == 0) {
            int n27 = (n6 & 1024) == 0 && g8.i(l6) ? 4 : 2;
            n7 = n5 | n27;
        } else {
            n7 = n5;
        }
        int n28 = n6 & 2048;
        if (n28 != 0) {
            n7 |= 16;
        }
        int n29 = n7;
        int n30 = n6 & 4096;
        if (n30 != 0) {
            n29 |= 384;
        } else if ((n5 & 896) == 0) {
            int n31 = g8.c(bl) ? 256 : 128;
            n29 |= n31;
        }
        int n32 = n6 & 8192;
        if (n32 != 0) {
            n29 |= 3072;
        } else if ((n5 & 7168) == 0) {
            int n33 = g8.h(n3) ? 2048 : 1024;
            n29 |= n33;
        }
        int n34 = n6 & 16384;
        if (n34 != 0) {
            n29 |= 8192;
        }
        if ((n5 & 458752) == 0) {
            if ((n6 & 32768) != 0 || !g8.M(l7)) {
                n20 = 65536;
            }
            n29 |= n20;
        }
        if ((n5 & 3670016) == 0) {
            int n35 = (n6 & 65536) == 0 && g8.M((Object)u3) ? 1048576 : 524288;
            n29 |= n35;
        }
        if ((18960 & n6) == 0 && (306783378 ^ 1533916891 & n12) == 0 && (599186 ^ 2995931 & n29) == 0 && g8.r()) {
            g8.x();
            g7 = g3;
            l11 = l4;
            e3 = e2;
            g6 = g4;
            d4 = d3;
            c4 = c3;
            b4 = b3;
            l13 = l6;
            n10 = n2;
            bl2 = bl;
            n9 = n3;
            map2 = map;
            l9 = l7;
            u4 = u3;
            l12 = l8;
            l10 = l5;
        } else {
            Map<String, z.d> map3;
            u1.c c5;
            l1.u u5;
            p1.e e4;
            long l14;
            long l15;
            long l16;
            p1.d d5;
            long l17;
            int n36;
            l<? super s, v> l18;
            Object object;
            g g9;
            u1.b b5;
            int n37;
            int n38;
            int n39 = n4 & 1;
            boolean bl3 = true;
            if (n39 != 0 && !g8.B()) {
                g8.m();
                if ((n6 & 4) != 0) {
                    n12 &= -897;
                }
                if ((n6 & 8) != 0) {
                    n12 &= -7169;
                }
                if ((n6 & 128) != 0) {
                    n12 &= -29360129;
                }
                if ((n6 & 1024) != 0) {
                    n29 &= -15;
                }
                if (n28 != 0) {
                    n29 &= -113;
                }
                if (n34 != 0) {
                    n29 &= -57345;
                }
                if ((n6 & 32768) != 0) {
                    n29 &= -458753;
                }
                if ((n6 & 65536) != 0) {
                    n29 &= -3670017;
                }
                object = g3;
                e4 = e2;
                g9 = g4;
                d5 = d3;
                c5 = c3;
                b5 = b3;
                l14 = l6;
                n38 = n2;
                bl2 = bl;
                n9 = n3;
                map3 = map;
                l18 = l7;
                u5 = u3;
                n36 = n12;
                n37 = n29;
                l16 = l4;
                l15 = l5;
            } else {
                Map<String, z.d> map4;
                long l19;
                l<? super s, v> l20;
                l1.u u6;
                long l21;
                long l22;
                long l23;
                boolean bl4;
                g8.n();
                object = n14 != 0 ? g.a.b : g3;
                if ((n6 & 4) != 0) {
                    l21 = t0.q.h;
                    n12 &= -897;
                } else {
                    l21 = l8;
                }
                if ((n6 & 8) != 0) {
                    l23 = i.d;
                    n12 &= -7169;
                } else {
                    l23 = l4;
                }
                e4 = n8 != 0 ? null : e2;
                g9 = n19 != 0 ? null : g4;
                d5 = n22 != 0 ? null : d3;
                if ((n6 & 128) != 0) {
                    l22 = i.d;
                    n12 &= -29360129;
                } else {
                    l22 = l5;
                }
                u1.c c6 = n11 != 0 ? null : c3;
                u1.b b6 = n26 != 0 ? null : b3;
                if ((n6 & 1024) != 0) {
                    l19 = i.d;
                    n29 &= -15;
                } else {
                    l19 = l6;
                }
                if (n28 != 0) {
                    n29 &= -113;
                    bl4 = bl3;
                } else {
                    bl4 = n2;
                }
                boolean bl5 = n30 != 0 ? bl3 : (boolean)(bl ? 1 : 0);
                int n40 = n32 != 0 ? Integer.MAX_VALUE : n3;
                if (n34 != 0) {
                    map4 = u.b;
                    n29 &= -57345;
                } else {
                    map4 = map;
                }
                if ((n6 & 32768) != 0) {
                    l20 = e.c;
                    n29 &= -458753;
                } else {
                    l20 = l7;
                }
                int n41 = n6 & 65536;
                u1.b b7 = b6;
                if (n41 != 0) {
                    u6 = (l1.u)g8.K(a);
                    n29 &= -3670017;
                } else {
                    u6 = u3;
                }
                g8.L();
                u5 = u6;
                n36 = n12;
                n37 = n29;
                bl2 = bl5;
                n9 = n40;
                map3 = map4;
                c5 = c6;
                l18 = l20;
                l16 = l23;
                b5 = b7;
                n38 = bl4;
                l8 = l21;
                l15 = l22;
                l14 = l19;
            }
            g8.d(1557617653);
            long l24 = t0.q.h;
            boolean bl6 = l8 != l24 ? bl3 : false;
            long l25 = l8;
            if (bl6) {
                l17 = l25;
            } else {
                long l26 = u5.a;
                if (l26 == l24) {
                    bl3 = false;
                }
                if (!bl3) {
                    l26 = t0.q.a((long)((t0.q)g8.K(q.a)).a, (float)((Number)g8.K(p.a)).floatValue(), (float)0.0f, (float)0.0f, (float)0.0f, (int)14);
                }
                l17 = l26;
            }
            g8.I();
            l1.u u7 = new l1.u(l17, l16, g9, e4, null, d5, null, l15, null, null, null, 0L, c5, null, b5, null, l14, null, 175952);
            l1.u u8 = u5.a(u7);
            int n42 = 16809984 | n36 & 14 | n36 & 112 | 7168 & n37 >> 6;
            int n43 = n37 << 9;
            int n44 = n42 | n43 & 458752 | n43 & 3670016;
            z.a.a((l1.a)a3, (o0.g)object, (l1.u)u8, l18, (int)n38, (boolean)bl2, (int)n9, map3, (e0.g)g8, (int)n44, (int)0);
            l10 = l15;
            l9 = l18;
            l12 = l25;
            long l27 = l16;
            g7 = object;
            int n45 = n38;
            c4 = c5;
            l11 = l27;
            l1.u u9 = u5;
            b4 = b5;
            e3 = e4;
            l13 = l14;
            g6 = g9;
            d4 = d5;
            map2 = map3;
            n10 = n45;
            u4 = u9;
        }
        l1 l14 = g8.u();
        if (l14 == null) {
            return;
        }
        f f2 = new f(a3, g7, l12, l11, e3, g6, d4, l10, c4, b4, l13, n10, bl2, n9, map2, l9, u4, n4, n5, n6);
        l14.a((rr.p)f2);
    }

    public static final void c(String string, o0.g g3, long l3, long l4, p1.e e2, g g4, p1.d d3, long l5, u1.c c3, u1.b b3, long l6, int n2, boolean bl, int n3, l<? super s, v> l7, l1.u u3, e0.g g5, int n4, int n5, int n6) {
        l1.u u4;
        u1.b b4;
        o0.g g6;
        int n7;
        boolean bl2;
        int n8;
        p1.d d4;
        long l8;
        p1.e e3;
        int n9;
        long l9;
        int n10;
        l<? super s, v> l10;
        int n11;
        long l11;
        int n12;
        long l12;
        u1.c c4;
        int n13;
        g g7;
        long l13;
        e0.g g8;
        ma.e.f((Object)string, (String)"text");
        e0.g g9 = g5.o(1557612414);
        if ((n6 & 1) != 0) {
            n8 = n4 | 6;
        } else if ((n4 & 14) == 0) {
            int n14 = g9.M((Object)string) ? 4 : 2;
            n8 = n14 | n4;
        } else {
            n8 = n4;
        }
        int n15 = n6 & 2;
        if (n15 != 0) {
            n8 |= 48;
        } else if ((n4 & 112) == 0) {
            int n16 = g9.M((Object)g3) ? 32 : 16;
            n8 |= n16;
        }
        if ((n4 & 896) == 0) {
            int n17 = n6 & 4;
            l13 = l3;
            int n18 = n17 == 0 && g9.i(l13) ? 256 : 128;
            n8 |= n18;
        } else {
            l13 = l3;
        }
        if ((n4 & 7168) == 0) {
            int n19 = (n6 & 8) == 0 && g9.i(l4) ? 2048 : 1024;
            n8 |= n19;
        }
        if ((n13 = n6 & 16) != 0) {
            n8 |= 8192;
        }
        int n20 = n6 & 32;
        int n21 = 65536;
        if (n20 != 0) {
            n8 |= 196608;
        } else if ((n4 & 458752) == 0) {
            int n22 = g9.M((Object)g4) ? 131072 : n21;
            n8 |= n22;
        }
        int n23 = n6 & 64;
        if (n23 != 0) {
            n8 |= 1572864;
        } else if ((n4 & 3670016) == 0) {
            int n24 = g9.M((Object)d3) ? 1048576 : 524288;
            n8 |= n24;
        }
        if ((n4 & 29360128) == 0) {
            int n25 = (n6 & 128) == 0 && g9.i(l5) ? 8388608 : 4194304;
            n8 |= n25;
        }
        if ((n11 = n6 & 256) != 0) {
            n8 |= 100663296;
        } else if ((n4 & 234881024) == 0) {
            int n26 = g9.M((Object)c3) ? 67108864 : 33554432;
            n8 |= n26;
        }
        int n27 = n6 & 512;
        if (n27 != 0) {
            n8 |= 268435456;
        }
        if ((n5 & 14) == 0) {
            int n28 = (n6 & 1024) == 0 && g9.i(l6) ? 4 : 2;
            n10 = n5 | n28;
        } else {
            n10 = n5;
        }
        int n29 = n6 & 2048;
        if (n29 != 0) {
            n10 |= 16;
        }
        if ((n9 = n6 & 4096) != 0) {
            n10 |= 384;
        } else if ((n5 & 896) == 0) {
            int n30 = g9.c(bl) ? 256 : 128;
            n10 |= n30;
        }
        int n31 = n6 & 8192;
        if (n31 != 0) {
            n10 |= 3072;
        } else if ((n5 & 7168) == 0) {
            int n32 = g9.h(n3) ? 2048 : 1024;
            n10 |= n32;
        }
        if ((n5 & 57344) == 0) {
            int n33 = (n6 & 16384) == 0 && g9.M(l7) ? 16384 : 8192;
            n10 |= n33;
        }
        if ((n5 & 458752) == 0) {
            if ((n6 & 32768) == 0 && g9.M((Object)u3)) {
                n21 = 131072;
            }
            n10 |= n21;
        }
        if ((2576 & n6) == 0 && (306783378 ^ 1533916891 & n8) == 0 && (74898 ^ 374491 & n10) == 0 && g9.r()) {
            g9.x();
            g6 = g3;
            l9 = l4;
            e3 = e2;
            g7 = g4;
            d4 = d3;
            c4 = c3;
            b4 = b3;
            l8 = l6;
            n12 = n2;
            bl2 = bl;
            n7 = n3;
            l10 = l7;
            u4 = u3;
            g8 = g9;
            l12 = l13;
            l11 = l5;
        } else {
            p1.d d5;
            u1.c c5;
            Object object;
            int n34;
            l<? super s, v> l14;
            int n35;
            boolean bl3;
            long l15;
            u1.b b5;
            l1.u u5;
            long l16;
            g g10;
            int n36;
            int n37;
            long l17;
            p1.e e4;
            long l18;
            if ((n4 & 1) != 0 && !g9.B()) {
                g9.m();
                if ((n6 & 4) != 0) {
                    n8 &= -897;
                }
                if ((n6 & 8) != 0) {
                    n8 &= -7169;
                }
                if ((n6 & 128) != 0) {
                    n8 &= -29360129;
                }
                if ((n6 & 1024) != 0) {
                    n10 &= -15;
                }
                if (n29 != 0) {
                    n10 &= -113;
                }
                if ((n6 & 16384) != 0) {
                    n10 &= -57345;
                }
                if ((n6 & 32768) != 0) {
                    n10 &= -458753;
                }
                object = g3;
                l17 = l4;
                e4 = e2;
                g10 = g4;
                l16 = l5;
                c5 = c3;
                b5 = b3;
                l18 = l6;
                n36 = n2;
                bl3 = bl;
                n35 = n3;
                l14 = l7;
                u5 = u3;
                n34 = n8;
                n37 = n10;
                l15 = l3;
                d5 = d3;
            } else {
                long l19;
                l1.u u6;
                long l20;
                long l21;
                l<? super s, v> l22;
                int n38;
                boolean bl4;
                long l23;
                g9.n();
                object = n15 != 0 ? g.a.b : g3;
                if ((n6 & 4) != 0) {
                    l20 = t0.q.h;
                    n8 &= -897;
                } else {
                    l20 = l3;
                }
                if ((n6 & 8) != 0) {
                    l21 = i.d;
                    n8 &= -7169;
                } else {
                    l21 = l4;
                }
                e4 = n13 != 0 ? null : e2;
                g10 = n20 != 0 ? null : g4;
                p1.d d6 = n23 != 0 ? null : d3;
                if ((n6 & 128) != 0) {
                    l23 = i.d;
                    n8 &= -29360129;
                } else {
                    l23 = l5;
                }
                c5 = n11 != 0 ? null : c3;
                u1.b b6 = n27 != 0 ? null : b3;
                if ((n6 & 1024) != 0) {
                    l19 = i.d;
                    n10 &= -15;
                } else {
                    l19 = l6;
                }
                boolean bl5 = true;
                if (n29 != 0) {
                    n38 = n10 & -113;
                    bl4 = bl5;
                } else {
                    n38 = n10;
                    bl4 = n2;
                }
                if (n9 == 0) {
                    bl5 = (boolean)(bl ? 1 : 0);
                }
                int n39 = n31 != 0 ? Integer.MAX_VALUE : n3;
                if ((n6 & 16384) != 0) {
                    l22 = c.c;
                    n38 &= -57345;
                } else {
                    l22 = l7;
                }
                int n40 = n6 & 32768;
                int n41 = n8;
                if (n40 != 0) {
                    u6 = (l1.u)g9.K(a);
                    n38 &= -458753;
                } else {
                    u6 = u3;
                }
                g9.L();
                n34 = n41;
                u5 = u6;
                n37 = n38;
                n35 = n39;
                l14 = l22;
                bl3 = bl5;
                l16 = l23;
                l17 = l21;
                l18 = l19;
                b5 = b6;
                n36 = bl4;
                d5 = d6;
                l15 = l20;
            }
            g8 = g9;
            int n42 = n36;
            l1.a a3 = new l1.a(string, null, null, 6);
            u u7 = u.b;
            int n43 = 1073774592 | n34 & 112 | n34 & 896 | n34 & 7168 | n34 & 458752 | n34 & 3670016 | 29360128 & n34 | 234881024 & n34;
            int n44 = 32832 | n37 & 14 | n37 & 896 | n37 & 7168;
            int n45 = n37 << 3;
            int n46 = n44 | n45 & 458752 | n45 & 3670016;
            u2.b(a3, object, l15, l17, e4, g10, d5, l16, c5, b5, l18, n42, bl3, n35, (Map<String, z.d>)u7, l14, u5, g8, n43, n46, 0);
            n12 = n42;
            b4 = b5;
            c4 = c5;
            g7 = g10;
            l11 = l16;
            l8 = l18;
            bl2 = bl3;
            n7 = n35;
            l10 = l14;
            u4 = u5;
            p1.e e5 = e4;
            d4 = d5;
            l12 = l15;
            g6 = object;
            l9 = l17;
            e3 = e5;
        }
        l1 l14 = g8.u();
        if (l14 == null) {
            return;
        }
        long l24 = l8;
        d d7 = new d(string, g6, l12, l9, e3, g7, d4, l11, c4, b4, l24, n12, bl2, n7, l10, u4, n4, n5, n6);
        l14.a((rr.p)d7);
    }
}

