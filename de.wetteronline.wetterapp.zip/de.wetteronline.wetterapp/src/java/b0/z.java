/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  co.a
 *  e0.r0
 *  java.lang.Float
 *  java.lang.Number
 *  java.lang.Object
 *  rr.a
 *  sr.m
 */
package b0;

import b0.n0;
import b0.o0;
import b0.r2;
import co.a;
import e0.r0;
import sr.m;

public final class z
extends m
implements rr.a<Float> {
    public final /* synthetic */ float c;
    public final /* synthetic */ n0 d;

    public z(float f3, float f4, n0 n02) {
        this.c = f3;
        this.d = n02;
        super(0);
    }

    public Object s() {
        float f3 = this.c;
        float f4 = ((Number)this.d.a.e.getValue()).floatValue();
        return Float.valueOf((float)a.k((float)((f4 - f3) / (0.0f - f3)), (float)0.0f, (float)1.0f));
    }
}

