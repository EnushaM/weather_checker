/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b0;

public final class s0 {
    public final int a;
    public final int b;

    public s0(boolean bl, int n2, int n3, int n4) {
        this.a = n2;
        this.b = n4;
    }
}

