/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.ui.text.intl.a
 *  b0.x2$a
 *  e0.w
 *  e0.x0
 *  java.lang.Object
 *  java.lang.String
 *  l1.u
 *  p1.d
 *  p1.e
 *  p1.f
 *  p1.g
 *  rr.a
 *  sr.g
 *  t0.h0
 *  u1.a
 *  u1.b
 *  u1.c
 *  u1.d
 *  u1.e
 *  u1.f
 */
package b0;

import b0.w2;
import b0.x2;
import e0.w;
import e0.x0;
import l1.u;
import p1.e;
import sr.g;
import t0.h0;
import u1.b;
import u1.c;
import u1.d;
import u1.f;

public final class x2 {
    public static final x0<w2> a = w.d((rr.a)a.c);

    public static final u a(u u3, p1.d d3) {
        if (u3.f != null) {
            return u3;
        }
        long l3 = u3.a;
        long l4 = u3.b;
        p1.g g3 = u3.c;
        e e2 = u3.d;
        p1.f f2 = u3.e;
        String string = u3.g;
        long l5 = u3.h;
        u1.a a3 = u3.i;
        u1.e e3 = u3.j;
        androidx.compose.ui.text.intl.a a4 = u3.k;
        long l6 = u3.l;
        c c3 = u3.m;
        h0 h02 = u3.n;
        b b3 = u3.o;
        d d4 = u3.p;
        long l7 = u3.q;
        f f3 = u3.r;
        u u4 = new u(l3, l4, g3, e2, f2, d3, string, l5, a3, e3, a4, l6, c3, h02, b3, d4, l7, f3, null);
        return u4;
    }
}

