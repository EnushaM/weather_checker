/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.g1$a
 *  b0.g1$b
 *  b0.g1$c
 *  b0.g1$d
 *  b0.m1
 *  b0.n1
 *  e.n
 *  e0.g
 *  e0.g$a
 *  e0.l1
 *  e0.v
 *  e0.w
 *  e0.x0
 *  e1.b0
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  k0.a
 *  k0.b
 *  ma.e
 *  o0.g
 *  o0.g$a
 *  rr.a
 *  rr.p
 *  rr.q
 *  t0.i0
 *  x.w
 *  y.a
 */
package b0;

import b0.a2;
import b0.f0;
import b0.g1;
import b0.k;
import b0.l;
import b0.m1;
import b0.n;
import b0.n0;
import b0.n1;
import b0.o0;
import b0.p1;
import b0.q1;
import b0.r1;
import b0.s0;
import b0.t0;
import b0.v;
import e0.g;
import e0.l1;
import e0.x0;
import e1.b0;
import ma.e;
import o0.g;
import rr.p;
import rr.q;
import t0.i0;
import x.w;

public final class g1 {
    public static final x0<s0> a = e0.w.d((rr.a)a.c);
    public static final float b = 16;

    public static final void a(g g3, p1 p12, p<? super e0.g, ? super Integer, gr.v> p2, p<? super e0.g, ? super Integer, gr.v> p3, q<? super a2, ? super e0.g, ? super Integer, gr.v> q3, p<? super e0.g, ? super Integer, gr.v> p4, int n2, boolean bl, q<Object, ? super e0.g, ? super Integer, gr.v> q4, boolean bl2, i0 i02, float f2, long l3, long l4, long l5, long l6, long l7, q<? super w, ? super e0.g, ? super Integer, gr.v> q5, e0.g g4, int n3, int n4, int n5) {
        p<? super e0.g, ? super Integer, gr.v> p5;
        q<? super a2, ? super e0.g, ? super Integer, gr.v> q6;
        long l8;
        p<? super e0.g, ? super Integer, gr.v> p6;
        int n6;
        i0 i03;
        p1 p13;
        e0.g g5;
        int n7;
        boolean bl3;
        long l9;
        int n8;
        int n9;
        q<? super a2, ? super e0.g, ? super Integer, gr.v> q7;
        p<? super e0.g, ? super Integer, gr.v> p7;
        g g6;
        long l10;
        boolean bl4;
        long l11;
        q<Object, ? super e0.g, ? super Integer, gr.v> q8;
        int n10;
        long l12;
        int n11;
        int n12;
        boolean bl5;
        int n13;
        p<? super e0.g, ? super Integer, gr.v> p8;
        long l13;
        float f3;
        block87 : {
            int n14;
            block86 : {
                block85 : {
                    block84 : {
                        block80 : {
                            int n15;
                            block83 : {
                                block82 : {
                                    block81 : {
                                        e.f(q5, (String)"content");
                                        g5 = g4.o(-1013849884);
                                        n7 = n5 & 1;
                                        if (n7 != 0) {
                                            n8 = n3 | 6;
                                        } else if ((n3 & 14) == 0) {
                                            int n16 = g5.M((Object)g3) ? 4 : 2;
                                            n8 = n16 | n3;
                                        } else {
                                            n8 = n3;
                                        }
                                        if ((n3 & 112) == 0) {
                                            int n17 = (n5 & 2) == 0 && g5.M((Object)p12) ? 32 : 16;
                                            n8 |= n17;
                                        }
                                        if ((n3 & 896) == 0) {
                                            int n18 = (n5 & 4) == 0 && g5.M(p2) ? 256 : 128;
                                            n8 |= n18;
                                        }
                                        if ((n3 & 7168) == 0) {
                                            int n19 = (n5 & 8) == 0 && g5.M(p3) ? 2048 : 1024;
                                            n8 |= n19;
                                        }
                                        if ((n3 & 57344) != 0) break block80;
                                        if ((n5 & 16) != 0) break block81;
                                        q6 = q3;
                                        if (!g5.M(q6)) break block82;
                                        n15 = 16384;
                                        break block83;
                                    }
                                    q6 = q3;
                                }
                                n15 = 8192;
                            }
                            n8 |= n15;
                            break block84;
                        }
                        q6 = q3;
                    }
                    if ((n3 & 458752) == 0) {
                        int n20 = n5 & 32;
                        p6 = p4;
                        int n21 = n20 == 0 && g5.M(p6) ? 131072 : 65536;
                        n8 |= n21;
                    } else {
                        p6 = p4;
                    }
                    if ((n3 & 3670016) == 0) {
                        int n22 = n5 & 64;
                        n11 = n2;
                        int n23 = n22 == 0 && g5.h(n11) ? 1048576 : 524288;
                        n8 |= n23;
                    } else {
                        n11 = n2;
                    }
                    n13 = n5 & 128;
                    if (n13 != 0) {
                        n8 |= 12582912;
                        bl4 = bl;
                    } else {
                        int n24 = n3 & 29360128;
                        bl4 = bl;
                        if (n24 == 0) {
                            int n25 = g5.c(bl4) ? 8388608 : 4194304;
                            n8 |= n25;
                        }
                    }
                    n6 = n5 & 256;
                    if (n6 != 0) {
                        n8 |= 100663296;
                    } else if ((n3 & 234881024) == 0) {
                        int n26 = g5.M(q4) ? 67108864 : 33554432;
                        n8 |= n26;
                    }
                    n12 = n5 & 512;
                    if (n12 != 0) {
                        n8 |= 805306368;
                    } else if ((n3 & 1879048192) == 0) {
                        int n27 = g5.c(bl2) ? 536870912 : 268435456;
                        n8 |= n27;
                    }
                    if ((n4 & 14) == 0) {
                        int n28 = (n5 & 1024) == 0 && g5.M((Object)i02) ? 4 : 2;
                        n9 = n4 | n28;
                    } else {
                        n9 = n4;
                    }
                    if ((n4 & 112) == 0) {
                        int n29 = (n5 & 2048) == 0 && g5.f(f2) ? 32 : 16;
                        n9 |= n29;
                    }
                    if ((n4 & 896) == 0) {
                        int n30 = (n5 & 4096) == 0 && g5.i(l3) ? 256 : 128;
                        n9 |= n30;
                    }
                    if ((n4 & 7168) == 0) {
                        int n31 = (n5 & 8192) == 0 && g5.i(l4) ? 2048 : 1024;
                        n9 |= n31;
                    }
                    if ((n4 & 57344) == 0) {
                        int n32 = (n5 & 16384) == 0 && g5.i(l5) ? 16384 : 8192;
                        n9 |= n32;
                    }
                    if ((n4 & 458752) == 0) {
                        int n33 = (n5 & 32768) == 0 && g5.i(l6) ? 131072 : 65536;
                        n9 |= n33;
                    }
                    if ((n4 & 3670016) == 0) {
                        int n34 = n5 & 65536;
                        l12 = l7;
                        int n35 = n34 == 0 && g5.i(l12) ? 1048576 : 524288;
                        n9 |= n35;
                    } else {
                        l12 = l7;
                    }
                    if ((n5 & 131072) == 0) break block85;
                    n14 = 12582912;
                    break block86;
                }
                if ((n4 & 29360128) != 0) break block87;
                n14 = g5.M(q5) ? 8388608 : 4194304;
            }
            n9 |= n14;
        }
        if ((306783378 ^ n8 & 1533916891) == 0 && (4793490 ^ n9 & 23967451) == 0 && g5.r()) {
            g5.x();
            g6 = g3;
            p13 = p12;
            p7 = p2;
            p8 = p3;
            i03 = i02;
            f3 = f2;
            l13 = l3;
            l10 = l4;
            l8 = l5;
            l9 = l6;
            l11 = l12;
            p5 = p6;
            n10 = n11;
            bl3 = bl4;
            q7 = q6;
            q8 = q4;
            bl5 = bl2;
        } else {
            boolean bl6;
            p<? super e0.g, ? super Integer, gr.v> p9;
            int n36;
            p1 p14;
            q<? super a2, ? super e0.g, ? super Integer, gr.v> q9;
            float f4;
            p1 p15;
            p<? super e0.g, ? super Integer, gr.v> p10;
            p<? super e0.g, ? super Integer, gr.v> p11;
            int n37;
            long l14;
            q<Object, ? super e0.g, ? super Integer, gr.v> q10;
            if ((n3 & 1) != 0 && !g5.B()) {
                g5.m();
                if ((n5 & 2) != 0) {
                    n8 &= -113;
                }
                if ((n5 & 4) != 0) {
                    n8 &= -897;
                }
                if ((n5 & 8) != 0) {
                    n8 &= -7169;
                }
                if ((n5 & 16) != 0) {
                    n8 &= -57345;
                }
                if ((n5 & 32) != 0) {
                    n8 &= -458753;
                }
                if ((n5 & 64) != 0) {
                    n8 &= -3670017;
                }
                if ((n5 & 1024) != 0) {
                    n9 &= -15;
                }
                if ((n5 & 2048) != 0) {
                    n9 &= -113;
                }
                int n38 = n9;
                if ((n5 & 4096) != 0) {
                    n38 &= -897;
                }
                if ((n5 & 8192) != 0) {
                    n38 &= -7169;
                }
                if ((n5 & 16384) != 0) {
                    n38 &= -57345;
                }
                if ((32768 & n5) != 0) {
                    n38 &= -458753;
                }
                if ((n5 & 65536) != 0) {
                    n38 &= -3670017;
                }
                p14 = p12;
                bl6 = bl2;
                i03 = i02;
                f4 = f2;
                l13 = l3;
                l10 = l4;
                l14 = l5;
                l9 = l6;
                n37 = n38;
                n36 = n8;
                l11 = l12;
                g6 = g3;
                p11 = p2;
                p9 = p3;
                q10 = q4;
                q<? super a2, ? super e0.g, ? super Integer, gr.v> q11 = q6;
                p10 = p6;
                q9 = q11;
            } else {
                int n39;
                float f5;
                g.a a3;
                int n40;
                long l15;
                p1 p16;
                long l16;
                int n41;
                long l17;
                g5.n();
                Object object = n7 != 0 ? g.a.b : g3;
                if ((n5 & 2) != 0) {
                    a3 = object;
                    g5.d(-1962071859);
                    n0 n02 = f0.c((o0)o0.b, null, (e0.g)g5, (int)2);
                    g5.d(-3687241);
                    Object object2 = g5.e();
                    Object object3 = g.a.b;
                    if (object2 == object3) {
                        object2 = new a2();
                        g5.E(object2);
                    }
                    g5.I();
                    a2 a22 = (a2)object2;
                    g5.d(-3687241);
                    Object object4 = g5.e();
                    if (object4 == object3) {
                        object4 = new p1(n02, a22);
                        g5.E(object4);
                    }
                    g5.I();
                    p16 = (p1)object4;
                    g5.I();
                    n8 &= -113;
                } else {
                    a3 = object;
                    p16 = p12;
                }
                if ((n5 & 4) != 0) {
                    p11 = n.b;
                    n8 &= -897;
                } else {
                    p11 = p2;
                }
                if ((n5 & 8) != 0) {
                    p9 = n.c;
                    n8 &= -7169;
                } else {
                    p9 = p3;
                }
                if ((n5 & 16) != 0) {
                    q9 = n.d;
                    n8 &= -57345;
                } else {
                    q9 = q6;
                }
                if ((n5 & 32) != 0) {
                    p10 = n.e;
                    n8 &= -458753;
                } else {
                    p10 = p4;
                }
                if ((n5 & 64) != 0) {
                    n8 &= -3670017;
                    n11 = 1;
                }
                if (n13 != 0) {
                    bl4 = false;
                }
                q<Object, ? super e0.g, ? super Integer, gr.v> q12 = n6 != 0 ? null : q4;
                boolean bl7 = n12 != 0 ? true : bl2;
                if ((n5 & 1024) != 0) {
                    i03 = ((q1)g5.K(r1.a)).c;
                    n9 &= -15;
                } else {
                    i03 = i02;
                }
                p1 p17 = p16;
                if ((n5 & 2048) != 0) {
                    float f6 = v.b;
                    n9 &= -113;
                    f5 = f6;
                } else {
                    f5 = f2;
                }
                int n42 = n9;
                q<Object, ? super e0.g, ? super Integer, gr.v> q13 = q12;
                if ((n5 & 4096) != 0) {
                    long l18 = ((k)g5.K(l.a)).h();
                    int n43 = n42 & -897;
                    n41 = n8;
                    n40 = n43;
                    l16 = l18;
                } else {
                    n41 = n8;
                    n40 = n42;
                    l16 = l3;
                }
                boolean bl8 = bl7;
                if ((n5 & 8192) != 0) {
                    l10 = l.a(l16, g5);
                    n40 &= -7169;
                } else {
                    l10 = l4;
                }
                if ((n5 & 16384) != 0) {
                    l14 = v.a(g5);
                    n40 &= -57345;
                } else {
                    l14 = l5;
                }
                if ((32768 & n5) != 0) {
                    long l19 = ((k)g5.K(l.a)).a();
                    n39 = n40 & -458753;
                    l17 = l19;
                } else {
                    n39 = n40;
                    l17 = l6;
                }
                if ((n5 & 65536) != 0) {
                    l15 = l.a(l17, g5);
                    n39 &= -3670017;
                } else {
                    l15 = l7;
                }
                g5.L();
                n36 = n41;
                l13 = l16;
                n37 = n39;
                l11 = l15;
                g6 = a3;
                p14 = p17;
                f4 = f5;
                l9 = l17;
                q10 = q13;
                bl6 = bl8;
            }
            d d2 = new d(l9, l11, n37, bl4, n11, p11, q5, p10, p9, n36, q9, p14);
            p<? super e0.g, ? super Integer, gr.v> p16 = p11;
            p<? super e0.g, ? super Integer, gr.v> p17 = p9;
            k0.a a4 = e.n.h((e0.g)g5, (int)-819889681, (boolean)true, (Object)d2);
            if (q10 != null) {
                g5.d(-1013848226);
                n0 n03 = p14.a;
                b b3 = new b((q)a4);
                p15 = p14;
                k0.a a5 = e.n.h((e0.g)g5, (int)-819903232, (boolean)true, (Object)b3);
                int n44 = 805306368 | 14 & n36 >> 24 | 112 & n36 << 3 | 7168 & n36 >> 18;
                int n45 = n37 << 12;
                int n46 = n44 | n45 & 57344 | n45 & 458752 | n45 & 3670016 | n45 & 29360128 | n45 & 234881024;
                f0.a(q10, g6, n03, bl6, i03, f4, l13, l10, l14, (p<? super e0.g, ? super Integer, gr.v>)a5, g5, n46, 0);
                g5.I();
            } else {
                p15 = p14;
                g5.d(-1013847717);
                Integer n47 = 48 | n36 & 14;
                ((k0.b)a4).r((Object)g6, (Object)g5, (Object)n47);
                g5.I();
            }
            p13 = p15;
            q7 = q9;
            n10 = n11;
            bl3 = bl4;
            p5 = p10;
            f3 = f4;
            l8 = l14;
            q8 = q10;
            bl5 = bl6;
            p7 = p16;
            p8 = p17;
        }
        l1 l14 = g5.u();
        if (l14 == null) {
            return;
        }
        c c2 = new c(g6, p13, p7, p8, q7, p5, n10, bl3, q8, bl5, i03, f3, l13, l10, l8, l9, l11, q5, n3, n4, n5);
        l14.a((p)c2);
    }

    public static final void b(boolean bl, int n2, p p2, q q3, p p3, p p4, p p5, e0.g g3, int n3) {
        int n4;
        e0.g g4;
        int n5;
        e0.g g5 = g3.o(-2103106784);
        if ((n3 & 14) == 0) {
            int n6 = g5.c(bl) ? 4 : 2;
            n5 = n6 | n3;
        } else {
            n5 = n3;
        }
        if ((n3 & 112) == 0) {
            int n7 = g5.h(n2) ? 32 : 16;
            n5 |= n7;
        }
        if ((n3 & 896) == 0) {
            int n8 = g5.M((Object)p2) ? 256 : 128;
            n5 |= n8;
        }
        if ((n3 & 7168) == 0) {
            int n9 = g5.M((Object)q3) ? 2048 : 1024;
            n5 |= n9;
        }
        if ((57344 & n3) == 0) {
            int n10 = g5.M((Object)p3) ? 16384 : 8192;
            n5 |= n10;
        }
        if ((458752 & n3) == 0) {
            int n11 = g5.M((Object)p4) ? 131072 : 65536;
            n5 |= n11;
        }
        if ((3670016 & n3) == 0) {
            int n12 = g5.M((Object)p5) ? 1048576 : 524288;
            n5 |= n12;
        }
        if ((599186 ^ (n4 = n5) & 2995931) == 0 && g5.r()) {
            g5.x();
            g4 = g5;
        } else {
            Object[] arrobject = new Object[]{p2, p3, p4, new t0(n2), bl, p5, q3};
            g5.d(-3685570);
            int n13 = 0;
            boolean bl2 = false;
            while (n13 < 7) {
                Object object = arrobject[n13];
                ++n13;
                bl2 |= g5.M(object);
            }
            Object object = g5.e();
            if (!bl2 && object != g.a.b) {
                g4 = g5;
            } else {
                g4 = g5;
                m1 m12 = new m1(p2, p3, p4, n2, bl, p5, n4, q3);
                g4.E((Object)m12);
                object = m12;
            }
            g4.I();
            b0.b(null, (p)((p)object), (e0.g)g4, (int)0, (int)1);
        }
        l1 l12 = g4.u();
        if (l12 == null) {
            return;
        }
        n1 n12 = new n1(bl, n2, p2, q3, p3, p4, p5, n3);
        l12.a((p)n12);
    }
}

