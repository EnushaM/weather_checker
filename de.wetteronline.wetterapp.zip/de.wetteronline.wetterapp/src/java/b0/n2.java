/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  co.a
 *  ds.g0
 *  e0.r0
 *  gr.v
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  java.util.Objects
 *  jr.d
 *  kr.a
 *  lr.e
 *  lr.i
 *  ma.e
 *  rr.p
 *  x1.b
 */
package b0;

import b0.f1;
import b0.n2;
import b0.r2;
import b0.v2;
import ds.g0;
import e0.r0;
import gr.v;
import java.util.Map;
import java.util.Objects;
import jr.d;
import lr.e;
import lr.i;
import rr.p;
import x1.b;

@e(c="androidx.compose.material.SwipeableKt$swipeable$3$3", f="Swipeable.kt", l={607}, m="invokeSuspend")
public final class n2
extends i
implements p<g0, d<? super v>, Object> {
    public int f;
    public final /* synthetic */ r2<Object> g;
    public final /* synthetic */ Map<Float, Object> h;
    public final /* synthetic */ f1 i;
    public final /* synthetic */ b j;
    public final /* synthetic */ p<Object, Object, v2> k;
    public final /* synthetic */ float l;

    public n2(r2<Object> r22, Map<Float, Object> map, f1 f12, b b3, p<Object, Object, ? extends v2> p2, float f2, d<? super n2> d3) {
        this.g = r22;
        this.h = map;
        this.i = f12;
        this.j = b3;
        this.k = p2;
        this.l = f2;
        super(2, d3);
    }

    public final d<v> e(Object object, d<?> d3) {
        n2 n22 = new n2(this.g, this.h, this.i, this.j, this.k, this.l, d3);
        return n22;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final Object h(Object object) {
        kr.a a3 = kr.a.b;
        int n3 = this.f;
        if (n3 != 0) {
            if (n3 != 1) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            co.a.L((Object)object);
            return v.a;
        } else {
            co.a.L((Object)object);
            Map<Float, Object> map = this.g.c();
            r2<Object> r22 = this.g;
            Map<Float, Object> map2 = this.h;
            Objects.requireNonNull(r22);
            ma.e.f(map2, (String)"<set-?>");
            r22.i.setValue(map2);
            r2<Object> r23 = this.g;
            f1 f12 = this.i;
            r23.o.setValue((Object)f12);
            r2<Object> r24 = this.g;
            p<Float, Float, Float> p2 = new p<Float, Float, Float>(this.h, this.k, this.j){
                public final /* synthetic */ Map<Float, Object> c;
                public final /* synthetic */ p<Object, Object, v2> d;
                public final /* synthetic */ b e;
                {
                    this.c = map;
                    this.d = p2;
                    this.e = b3;
                    super(2);
                }

                public Object t0(Object object, Object object2) {
                    float f2 = ((java.lang.Number)object).floatValue();
                    float f3 = ((java.lang.Number)object2).floatValue();
                    Object object3 = hr.z.I(this.c, (Object)Float.valueOf((float)f2));
                    Object object4 = hr.z.I(this.c, (Object)Float.valueOf((float)f3));
                    Object object5 = this.d.t0(object3, object4);
                    b b3 = this.e;
                    return Float.valueOf((float)((v2)object5).a(b3, f2, f3));
                }
            };
            Objects.requireNonNull(r24);
            ma.e.f((Object)p2, (String)"<set-?>");
            r24.m.setValue((Object)p2);
            b b3 = this.j;
            r2<Object> r25 = this.g;
            float f2 = b3.J(this.l);
            r25.n.setValue((Object)Float.valueOf((float)f2));
            r2<Object> r26 = this.g;
            Map<Float, Object> map3 = this.h;
            this.f = 1;
            if (r26.e(map, map3, (d<v>)this) != a3) return v.a;
            return a3;
        }
    }

    public Object t0(Object object, Object object2) {
        return ((n2)this.e((Object)((g0)object), (d)object2)).h((Object)v.a);
    }
}

