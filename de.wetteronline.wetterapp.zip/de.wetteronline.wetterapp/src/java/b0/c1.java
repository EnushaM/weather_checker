/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.BlendModeColorFilter
 *  android.graphics.ColorFilter
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.PorterDuffColorFilter
 *  android.os.Build
 *  android.os.Build$VERSION
 *  b0.c1$a
 *  b0.c1$b
 *  b0.c1$c
 *  e.c
 *  e.n
 *  e0.g
 *  e0.g$a
 *  e0.l1
 *  e0.v
 *  e0.x0
 *  e1.d
 *  e1.d$a
 *  j1.o
 *  java.lang.Float
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  o0.g
 *  o0.g$a
 *  rr.l
 *  rr.p
 *  s0.f
 *  t0.j
 *  t0.q
 *  t0.r
 *  w0.b
 *  x.f
 *  x.h0
 *  x0.d
 *  x0.s
 *  x0.u
 */
package b0;

import android.graphics.BlendModeColorFilter;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.os.Build;
import b0.c1;
import b0.p;
import b0.q;
import e.n;
import e0.g;
import e0.l1;
import e0.v;
import e0.x0;
import e1.d;
import j1.o;
import ma.e;
import o0.g;
import rr.l;
import s0.f;
import t0.j;
import t0.r;
import x.h0;
import x0.s;
import x0.u;

public final class c1 {
    public static final g a = h0.i((g)g.a.b, (float)24);

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void a(w0.b var0, String var1_1, g var2_2, long var3_3, e0.g var5_4, int var6_5, int var7_6) {
        e.f((Object)var0, (String)"painter");
        var8_7 = var5_4.o(1547384967);
        if ((var7_6 & 4) != 0) {
            var10_8 = g.a.b;
        } else {
            var10_9 = var2_2;
        }
        var11_11 = (var7_6 & 8) != 0 ? t0.q.a((long)((t0.q)var8_7.K(q.a)).a, (float)((Number)var8_7.K(p.a)).floatValue(), (float)0.0f, (float)0.0f, (float)0.0f, (int)14) : var3_3;
        if (t0.q.b((long)var11_11, (long)t0.q.h)) {
            var14_12 = null;
        } else {
            if (Build.VERSION.SDK_INT >= 29) {
                var35_13 = j.a.a(var11_11, 5);
            } else {
                var35_14 = new PorterDuffColorFilter(n.A((long)var11_11), n.B((int)5));
            }
            var14_12 = new r((ColorFilter)var35_15);
        }
        var15_16 = 1;
        if (var1_1 != null) {
            var8_7.d(1547385352);
            var31_17 = g.a.b;
            var8_7.d(-3686930);
            var32_18 = var8_7.M((Object)var1_1);
            var33_19 = var8_7.e();
            if (var32_18 || var33_19 == g.a.b) {
                var33_19 = new c(var1_1);
                var8_7.E(var33_19);
            }
            var8_7.I();
            var17_20 = o.b((g)var31_17, (boolean)false, (l)((l)var33_19), (int)var15_16);
            var8_7.I();
        } else {
            var8_7.d(1547385496);
            var8_7.I();
            var17_20 = g.a.b;
        }
        var18_21 = var17_20;
        e.f((Object)var10_10, (String)"<this>");
        var20_22 = var0.c();
        if (f.b((long)var20_22, (long)f.d)) ** GOTO lbl-1000
        var28_23 = var0.c();
        if (!Float.isInfinite((float)f.e((long)var28_23)) || !Float.isInfinite((float)f.c((long)var28_23))) {
            var15_16 = 0;
        }
        if (var15_16 == 0) {
            var23_24 = g.a.b;
        } else lbl-1000: // 2 sources:
        {
            var23_24 = c1.a;
        }
        var24_25 = var10_10.r(var23_24);
        x.f.a((g)e.c.o((g)var24_25, (w0.b)var0, (boolean)false, null, (d)d.a.b, (float)0.0f, (r)var14_12, (int)22).r((g)var18_21), (e0.g)var8_7, (int)0);
        var26_26 = var8_7.u();
        if (var26_26 == null) {
            return;
        }
        var27_27 = new b(var0, var1_1, (g)var10_10, var11_11, var6_5, var7_6);
        var26_26.a((rr.p)var27_27);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void b(x0.d var0, String var1_1, g var2_2, long var3_3, e0.g var5_4, int var6_5, int var7_6) {
        block23 : {
            block19 : {
                block22 : {
                    block21 : {
                        block20 : {
                            block18 : {
                                e.f((Object)var0, (String)"imageVector");
                                var8_7 = var5_4.o(1547382739);
                                if ((var7_6 & 1) != 0) {
                                    var10_8 = var6_5 | 6;
                                } else if ((var6_5 & 14) == 0) {
                                    var26_9 = var8_7.M((Object)var0) != false ? 4 : 2;
                                    var10_8 = var26_9 | var6_5;
                                } else {
                                    var10_8 = var6_5;
                                }
                                if ((var7_6 & 2) != 0) {
                                    var10_8 |= 48;
                                } else if ((var6_5 & 112) == 0) {
                                    var25_10 = var8_7.M((Object)var1_1) != false ? 32 : 16;
                                    var10_8 |= var25_10;
                                }
                                var11_11 = var7_6 & 4;
                                if (var11_11 == 0) break block18;
                                var10_8 |= 384;
                                ** GOTO lbl-1000
                            }
                            if ((var6_5 & 896) == 0) {
                                var12_12 = var2_2;
                                var24_13 = var8_7.M((Object)var12_12) != false ? 256 : 128;
                                var10_8 |= var24_13;
                            } else lbl-1000: // 2 sources:
                            {
                                var12_12 = var2_2;
                            }
                            if ((var6_5 & 7168) != 0) break block19;
                            if ((var7_6 & 8) != 0) break block20;
                            var13_14 = var3_3;
                            if (!var8_7.i(var13_14)) break block21;
                            var23_15 = 2048;
                            break block22;
                        }
                        var13_14 = var3_3;
                    }
                    var23_15 = 1024;
                }
                var10_8 |= var23_15;
                break block23;
            }
            var13_14 = var3_3;
        }
        if ((1170 ^ var10_8 & 5851) == 0 && var8_7.r()) {
            var8_7.x();
            var16_16 = var13_14;
        } else {
            if ((var6_5 & 1) != 0 && !var8_7.B()) {
                var8_7.m();
                if ((var7_6 & 8) != 0) {
                    var10_8 &= -7169;
                }
            } else {
                var8_7.n();
                if (var11_11 != 0) {
                    var15_17 = g.a.b;
                } else {
                    var15_18 = var12_12;
                }
                if ((var7_6 & 8) != 0) {
                    var13_14 = t0.q.a((long)((t0.q)var8_7.K(q.a)).a, (float)((Number)var8_7.K(p.a)).floatValue(), (float)0.0f, (float)0.0f, (float)0.0f, (int)14);
                    var10_8 &= -7169;
                }
                var8_7.L();
                var12_12 = var15_19;
            }
            var16_16 = var13_14;
            var18_20 = u.b((x0.d)var0, (e0.g)var8_7);
            var19_21 = 8 | var10_8 & 112 | var10_8 & 896 | var10_8 & 7168;
            c1.a((w0.b)var18_20, var1_1, var12_12, var16_16, var8_7, var19_21, 0);
        }
        var20_22 = var8_7.u();
        if (var20_22 == null) {
            return;
        }
        var21_23 = new a(var0, var1_1, var12_12, var16_16, var6_5, var7_6);
        var20_22.a((rr.p)var21_23);
    }
}

