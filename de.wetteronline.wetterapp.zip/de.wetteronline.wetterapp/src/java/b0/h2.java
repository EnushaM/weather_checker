/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Object
 *  rr.a
 *  sr.m
 */
package b0;

import b0.s1;
import gr.v;
import rr.a;
import sr.m;

public final class h2
extends m
implements a<v> {
    public final /* synthetic */ s1 c;

    public h2(s1 s12) {
        this.c = s12;
        super(0);
    }

    public Object s() {
        this.c.b();
        return v.a;
    }
}

