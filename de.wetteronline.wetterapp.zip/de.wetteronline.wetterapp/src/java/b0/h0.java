/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  rr.a
 *  rr.p
 *  sr.m
 */
package b0;

import b0.f0;
import e0.g;
import gr.v;
import rr.a;
import rr.p;
import sr.m;

public final class h0
extends m
implements p<g, Integer, v> {
    public final /* synthetic */ boolean c;
    public final /* synthetic */ a<v> d;
    public final /* synthetic */ a<Float> e;
    public final /* synthetic */ long f;
    public final /* synthetic */ int g;

    public h0(boolean bl, a<v> a3, a<Float> a4, long l2, int n3) {
        this.c = bl;
        this.d = a3;
        this.e = a4;
        this.f = l2;
        this.g = n3;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        ((Number)object2).intValue();
        f0.b(this.c, this.d, this.e, this.f, g3, 1 | this.g);
        return v.a;
    }
}

