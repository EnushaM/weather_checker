/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b0;

public final class d1 {
    public static final d1 a;
    public static final float b;

    public static {
        b = 4;
    }
}

