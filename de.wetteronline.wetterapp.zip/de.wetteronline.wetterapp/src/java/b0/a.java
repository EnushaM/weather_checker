/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e.d
 *  java.lang.Object
 *  x.w
 */
package b0;

import b0.b;
import e.d;
import x.w;

public final class a {
    public static final a a = new a();
    public static final float b = 4;
    public static final w c;

    public static {
        float f2 = b.b;
        c = d.b((float)f2, (float)0.0f, (float)f2, (float)0.0f, (int)10);
    }
}

