/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.b$a
 *  b0.b$b
 *  b0.b$c
 *  b0.b$d
 *  e.n
 *  e0.g
 *  e0.l1
 *  e0.v
 *  e0.x0
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  k0.a
 *  ma.e
 *  o0.g
 *  o0.g$a
 *  rr.p
 *  rr.q
 *  t0.e0
 *  t0.i0
 *  x.c0
 *  x.h0
 *  x.w
 */
package b0;

import b0.b;
import b0.k;
import b0.l;
import b0.m;
import b0.m2;
import e.n;
import e0.l1;
import e0.x0;
import gr.v;
import ma.e;
import o0.g;
import rr.p;
import rr.q;
import t0.e0;
import t0.i0;
import x.c0;
import x.h0;
import x.w;

public final class b {
    public static final float a;
    public static final float b;
    public static final g c;
    public static final g d;

    public static {
        float f2;
        a = 56;
        b = f2 = (float)4;
        g.a a3 = g.a.b;
        c = h0.k((g)a3, (float)((float)16 - f2));
        d = h0.k((g)h0.e((g)a3, (float)0.0f, (int)1), (float)((float)72 - f2));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void a(long var0, long var2_1, float var4_2, w var5_3, i0 var6_4, g var7_5, q<? super c0, ? super e0.g, ? super Integer, v> var8_6, e0.g var9_7, int var10_8, int var11_9) {
        block26 : {
            var12_10 = var9_7.o(-1459317484);
            if ((var11_9 & 1) != 0) {
                var14_11 = var10_8 | 6;
            } else if ((var10_8 & 14) == 0) {
                var31_12 = var12_10.i(var0) != false ? 4 : 2;
                var14_11 = var31_12 | var10_8;
            } else {
                var14_11 = var10_8;
            }
            if ((var11_9 & 2) != 0) {
                var14_11 |= 48;
            } else if ((var10_8 & 112) == 0) {
                var30_13 = var12_10.i(var2_1) != false ? 32 : 16;
                var14_11 |= var30_13;
            }
            if ((var11_9 & 4) != 0) {
                var14_11 |= 384;
            } else if ((var10_8 & 896) == 0) {
                var29_14 = var12_10.f(var4_2) != false ? 256 : 128;
                var14_11 |= var29_14;
            }
            if ((var11_9 & 8) != 0) {
                var14_11 |= 3072;
            } else if ((var10_8 & 7168) == 0) {
                var28_15 = var12_10.M((Object)var5_3) != false ? 2048 : 1024;
                var14_11 |= var28_15;
            }
            if ((var11_9 & 16) != 0) {
                var14_11 |= 24576;
            } else if ((57344 & var10_8) == 0) {
                var27_16 = var12_10.M((Object)var6_4) != false ? 16384 : 8192;
                var14_11 |= var27_16;
            }
            var15_17 = var11_9 & 32;
            if (var15_17 == 0) break block26;
            var14_11 |= 196608;
            ** GOTO lbl-1000
        }
        if ((var10_8 & 458752) == 0) {
            var16_18 = var7_5;
            var26_19 = var12_10.M((Object)var16_18) != false ? 131072 : 65536;
            var14_11 |= var26_19;
        } else lbl-1000: // 2 sources:
        {
            var16_18 = var7_5;
        }
        if ((var11_9 & 64) != 0) {
            var14_11 |= 1572864;
        } else if ((3670016 & var10_8) == 0) {
            var25_20 = var12_10.M(var8_6) != false ? 1048576 : 524288;
            var14_11 |= var25_20;
        }
        if ((599186 ^ 2995931 & var14_11) == 0 && var12_10.r()) {
            var12_10.x();
            var17_21 = var16_18;
        } else {
            if (var15_17 != 0) {
                var17_22 = g.a.b;
            } else {
                var17_23 = var16_18;
            }
            var18_26 = n.h((e0.g)var12_10, (int)-819907654, (boolean)true, (Object)new a(var5_3, var8_6, var14_11));
            var19_27 = 1572864 | 14 & var14_11 >> 15 | 112 & var14_11 >> 9;
            var20_28 = var14_11 << 6;
            var21_29 = var19_27 | var20_28 & 896 | var20_28 & 7168 | 458752 & var14_11 << 9;
            m2.c((g)var17_24, (i0)var6_4, (long)var0, (long)var2_1, (float)var4_2, (p)var18_26, (e0.g)var12_10, (int)var21_29, (int)16);
        }
        var22_30 = var12_10.u();
        if (var22_30 == null) {
            return;
        }
        var23_31 = new b(var0, var2_1, var4_2, var5_3, var6_4, (g)var17_25, var8_6, var10_8, var11_9);
        var22_30.a((p)var23_31);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void b(p<? super e0.g, ? super Integer, v> var0, g var1_1, p<? super e0.g, ? super Integer, v> var2_2, q<? super c0, ? super e0.g, ? super Integer, v> var3_3, long var4_4, long var6_5, float var8_6, e0.g var9_7, int var10_8, int var11_9) {
        block44 : {
            block40 : {
                block43 : {
                    block42 : {
                        block41 : {
                            block39 : {
                                block35 : {
                                    block38 : {
                                        block37 : {
                                            block36 : {
                                                block34 : {
                                                    block30 : {
                                                        block33 : {
                                                            block32 : {
                                                                block31 : {
                                                                    block29 : {
                                                                        block25 : {
                                                                            block28 : {
                                                                                block27 : {
                                                                                    block26 : {
                                                                                        block24 : {
                                                                                            block23 : {
                                                                                                e.f(var0, (String)"title");
                                                                                                var12_10 = var9_7.o(404499380);
                                                                                                if ((var11_9 & 1) != 0) {
                                                                                                    var14_11 = var10_8 | 6;
                                                                                                } else if ((var10_8 & 14) == 0) {
                                                                                                    var59_12 = var12_10.M(var0) != false ? 4 : 2;
                                                                                                    var14_11 = var59_12 | var10_8;
                                                                                                } else {
                                                                                                    var14_11 = var10_8;
                                                                                                }
                                                                                                var15_13 = var11_9 & 2;
                                                                                                if (var15_13 == 0) break block23;
                                                                                                var14_11 |= 48;
                                                                                                ** GOTO lbl-1000
                                                                                            }
                                                                                            if ((var10_8 & 112) == 0) {
                                                                                                var16_14 = var1_1;
                                                                                                var58_15 = var12_10.M((Object)var16_14) != false ? 32 : 16;
                                                                                                var14_11 |= var58_15;
                                                                                            } else lbl-1000: // 2 sources:
                                                                                            {
                                                                                                var16_14 = var1_1;
                                                                                            }
                                                                                            var17_16 = var11_9 & 4;
                                                                                            if (var17_16 == 0) break block24;
                                                                                            var14_11 |= 384;
                                                                                            ** GOTO lbl-1000
                                                                                        }
                                                                                        if ((var10_8 & 896) == 0) {
                                                                                            var18_17 = var2_2;
                                                                                            var57_18 = var12_10.M(var18_17) != false ? 256 : 128;
                                                                                            var14_11 |= var57_18;
                                                                                        } else lbl-1000: // 2 sources:
                                                                                        {
                                                                                            var18_17 = var2_2;
                                                                                        }
                                                                                        if ((var10_8 & 7168) != 0) break block25;
                                                                                        if ((var11_9 & 8) != 0) break block26;
                                                                                        var19_19 = var3_3;
                                                                                        if (!var12_10.M(var19_19)) break block27;
                                                                                        var56_20 = 2048;
                                                                                        break block28;
                                                                                    }
                                                                                    var19_19 = var3_3;
                                                                                }
                                                                                var56_20 = 1024;
                                                                            }
                                                                            var14_11 |= var56_20;
                                                                            break block29;
                                                                        }
                                                                        var19_19 = var3_3;
                                                                    }
                                                                    if ((57344 & var10_8) != 0) break block30;
                                                                    if ((var11_9 & 16) != 0) break block31;
                                                                    var20_21 = var4_4;
                                                                    if (!var12_10.i(var20_21)) break block32;
                                                                    var55_22 = 16384;
                                                                    break block33;
                                                                }
                                                                var20_21 = var4_4;
                                                            }
                                                            var55_22 = 8192;
                                                        }
                                                        var14_11 |= var55_22;
                                                        break block34;
                                                    }
                                                    var20_21 = var4_4;
                                                }
                                                if ((var10_8 & 458752) != 0) break block35;
                                                if ((var11_9 & 32) != 0) break block36;
                                                var22_23 = var6_5;
                                                if (!var12_10.i(var22_23)) break block37;
                                                var54_24 = 131072;
                                                break block38;
                                            }
                                            var22_23 = var6_5;
                                        }
                                        var54_24 = 65536;
                                    }
                                    var14_11 |= var54_24;
                                    break block39;
                                }
                                var22_23 = var6_5;
                            }
                            if ((3670016 & var10_8) != 0) break block40;
                            if ((var11_9 & 64) != 0) break block41;
                            var24_25 = var8_6;
                            if (!var12_10.f(var24_25)) break block42;
                            var53_26 = 1048576;
                            break block43;
                        }
                        var24_25 = var8_6;
                    }
                    var53_26 = 524288;
                }
                var14_11 |= var53_26;
                break block44;
            }
            var24_25 = var8_6;
        }
        if ((599186 ^ 2995931 & var14_11) == 0 && var12_10.r()) {
            var12_10.x();
            var35_27 = var16_14;
            var36_28 = var18_17;
            var37_29 = var19_19;
            var43_30 = var20_21;
            var41_31 = var22_23;
            var40_32 = var24_25;
        } else {
            if ((var10_8 & 1) != 0 && !var12_10.B()) {
                var12_10.m();
                if ((var11_9 & 8) != 0) {
                    var14_11 &= -7169;
                }
                if ((var11_9 & 16) != 0) {
                    var14_11 &= -57345;
                }
                if ((var11_9 & 32) != 0) {
                    var14_11 &= -458753;
                }
                if ((var11_9 & 64) != 0) {
                    var14_11 &= -3670017;
                }
            } else {
                var12_10.n();
                if (var15_13 != 0) {
                    var16_14 = g.a.b;
                }
                if (var17_16 != 0) {
                    var18_17 = null;
                }
                if ((var11_9 & 8) != 0) {
                    var52_36 = m.b;
                    var14_11 &= -7169;
                    var19_19 = var52_36;
                }
                if ((var11_9 & 16) != 0) {
                    var50_37 = (k)var12_10.K(l.a);
                    e.f((Object)var50_37, (String)"<this>");
                    var20_21 = var50_37.i() != false ? var50_37.e() : var50_37.h();
                    var14_11 &= -57345;
                }
                if ((var11_9 & 32) != 0) {
                    var22_23 = l.a(var20_21, var12_10);
                    var14_11 &= -458753;
                }
                if ((var11_9 & 64) != 0) {
                    var48_38 = b0.a.b;
                    var14_11 &= -3670017;
                    var24_25 = var48_38;
                }
                var12_10.L();
            }
            var25_33 = var24_25;
            var26_34 = var22_23;
            var28_35 = var14_11;
            var30_39 = b0.a.c;
            var31_40 = e0.a;
            var32_41 = n.h((e0.g)var12_10, (int)-819890463, (boolean)true, (Object)new c(var18_17, var28_35, var0, var19_19));
            var33_42 = var28_35 >> 12;
            var34_43 = 1597440 | var33_42 & 14 | var33_42 & 112 | var33_42 & 896 | 458752 & var28_35 << 12;
            b.a(var20_21, var26_34, var25_33, var30_39, var31_40, var16_14, (q<? super c0, ? super e0.g, ? super Integer, v>)var32_41, var12_10, var34_43, 0);
            var35_27 = var16_14;
            var36_28 = var18_17;
            var37_29 = var19_19;
            var38_44 = var20_21;
            var40_32 = var25_33;
            var41_31 = var26_34;
            var43_30 = var38_44;
        }
        var45_45 = var12_10.u();
        if (var45_45 == null) {
            return;
        }
        var46_46 = new d(var0, var35_27, var36_28, var37_29, var43_30, var41_31, var40_32, var10_8, var11_9);
        var45_45.a((p)var46_46);
    }
}

