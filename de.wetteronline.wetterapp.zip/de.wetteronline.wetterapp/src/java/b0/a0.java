/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.r0
 *  java.lang.Float
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.l
 *  sr.m
 *  ur.b
 *  x1.b
 *  x1.f
 */
package b0;

import b0.n0;
import b0.o0;
import b0.r2;
import e.c;
import e0.r0;
import ma.e;
import rr.l;
import sr.m;
import ur.b;
import x1.f;

public final class a0
extends m
implements l<x1.b, f> {
    public final /* synthetic */ n0 c;

    public a0(n0 n02) {
        this.c = n02;
        super(1);
    }

    public Object y(Object object) {
        e.f((Object)((x1.b)object), (String)"$this$offset");
        return new f(c.c(b.b((float)((Number)this.c.a.e.getValue()).floatValue()), 0));
    }
}

