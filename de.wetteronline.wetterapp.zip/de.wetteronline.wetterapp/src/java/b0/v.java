/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.g
 *  e0.v
 *  e0.x0
 *  java.lang.Object
 *  t0.q
 */
package b0;

import b0.k;
import b0.l;
import e0.g;
import e0.x0;
import t0.q;

public final class v {
    public static final v a;
    public static final float b;

    public static {
        b = 16;
    }

    public static final long a(g g3) {
        g3.d(925913318);
        long l3 = q.a((long)((k)g3.K(l.a)).d(), (float)0.32f, (float)0.0f, (float)0.0f, (float)0.0f, (int)14);
        g3.I();
        return l3;
    }
}

