/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.a1
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.p
 *  sr.m
 */
package b0;

import b0.a1;
import b0.o0;
import b0.v2;
import ma.e;
import rr.p;
import sr.m;

public final class w
extends m
implements p<o0, o0, v2> {
    public static final w c = new w();

    public w() {
        super(2);
    }

    public Object t0(Object object, Object object2) {
        o0 o02 = (o0)((Object)object);
        o0 o03 = (o0)((Object)object2);
        e.f((Object)((Object)o02), (String)"$noName_0");
        e.f((Object)((Object)o03), (String)"$noName_1");
        return new a1(0.5f);
    }
}

