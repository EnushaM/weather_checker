/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e1.e
 *  e1.m
 *  e1.v
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.NoSuchElementException
 */
package b0;

import b0.c2;
import b0.g2;
import e1.b;
import e1.e;
import e1.m;
import e1.n;
import e1.o;
import e1.p;
import e1.v;
import gr.v;
import java.util.List;
import java.util.NoSuchElementException;
import rr.l;

public final class c2
implements n {
    public c2(String string, String string2) {
    }

    @Override
    public final o a(p p2, List<? extends m> list, long l2) {
        ma.e.f(p2, "$this$Layout");
        ma.e.f(list, "measurables");
        for (m m2 : list) {
            int n2;
            if (!ma.e.a(e.n.q(m2), "action")) continue;
            e1.v v3 = m2.v(l2);
            int n3 = x1.a.g(l2) - v3.b;
            int n4 = n3 - p2.Q(g2.f);
            int n6 = n4 < (n2 = x1.a.i(l2)) ? n2 : n4;
            for (m m3 : list) {
                if (!ma.e.a(e.n.q(m3), "text")) continue;
                e1.v v4 = m3.v(x1.a.a(l2, 0, n6, 0, 0, 9));
                e e2 = b.a;
                int n7 = v4.P((e1.a)e2);
                boolean bl = true;
                boolean bl2 = n7 != Integer.MIN_VALUE ? bl : false;
                if (bl2) {
                    int n8 = v4.P((e1.a)b.b);
                    boolean bl3 = n8 != Integer.MIN_VALUE ? bl : false;
                    if (bl3) {
                        int n9;
                        int n10;
                        int n11;
                        if (n7 != n8) {
                            bl = false;
                        }
                        int n12 = x1.a.g(l2) - v3.b;
                        if (bl) {
                            int n13 = Math.max((int)p2.Q(g2.h), (int)v3.c);
                            int n14 = (n13 - v4.c) / 2;
                            int n15 = v3.P((e1.a)e2);
                            int n16 = 0;
                            if (n15 != Integer.MIN_VALUE) {
                                n16 = n7 + n14 - n15;
                            }
                            n10 = n13;
                            n11 = n16;
                            n9 = n14;
                        } else {
                            int n17 = p2.Q(g2.a) - n7 - p2.Q(g2.e);
                            int n18 = Math.max((int)p2.Q(g2.i), (int)(n17 + v4.c));
                            int n19 = (n18 - v3.c) / 2;
                            n9 = n17;
                            n10 = n18;
                            n11 = n19;
                        }
                        int n20 = x1.a.g(l2);
                        l<v.a, v> l3 = new l<v.a, v>(v4, n9, v3, n12, n11){
                            public final /* synthetic */ e1.v c;
                            public final /* synthetic */ int d;
                            public final /* synthetic */ e1.v e;
                            public final /* synthetic */ int f;
                            public final /* synthetic */ int g;
                            {
                                this.c = v3;
                                this.d = n2;
                                this.e = v4;
                                this.f = n3;
                                this.g = n4;
                                super(1);
                            }

                            public Object y(Object object) {
                                v.a a2 = (v.a)object;
                                ma.e.f(a2, "$this$layout");
                                v.a.f(a2, this.c, 0, this.d, 0.0f, 4, null);
                                v.a.f(a2, this.e, this.f, this.g, 0.0f, 4, null);
                                return v.a;
                            }
                        };
                        return p.a.b(p2, n20, n10, null, l3, 4, null);
                    }
                    throw new IllegalArgumentException("No baselines for text".toString());
                }
                throw new IllegalArgumentException("No baselines for text".toString());
            }
            throw new NoSuchElementException("Collection contains no element matching the predicate.");
        }
        throw new NoSuchElementException("Collection contains no element matching the predicate.");
    }
}

