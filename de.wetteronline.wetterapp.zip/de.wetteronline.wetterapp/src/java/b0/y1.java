/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  co.a
 *  ds.g0
 *  gr.v
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  jr.d
 *  kr.a
 *  lr.e
 *  lr.i
 *  rr.a
 *  rr.p
 *  t.b
 *  t.g
 */
package b0;

import ds.g0;
import gr.v;
import jr.d;
import lr.e;
import rr.a;
import rr.p;
import t.b;
import t.g;
import t.i;

@e(c="androidx.compose.material.SnackbarHostKt$animatedOpacity$2", f="SnackbarHost.kt", l={350}, m="invokeSuspend")
public final class y1
extends lr.i
implements p<g0, d<? super v>, Object> {
    public int f;
    public final /* synthetic */ b<Float, i> g;
    public final /* synthetic */ boolean h;
    public final /* synthetic */ g<Float> i;
    public final /* synthetic */ a<v> j;

    public y1(b<Float, i> b3, boolean bl, g<Float> g2, a<v> a3, d<? super y1> d3) {
        this.g = b3;
        this.h = bl;
        this.i = g2;
        this.j = a3;
        super(2, d3);
    }

    public final d<v> e(Object object, d<?> d3) {
        y1 y12 = new y1(this.g, this.h, this.i, this.j, d3);
        return y12;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final Object h(Object object) {
        kr.a a3 = kr.a.b;
        int n3 = this.f;
        if (n3 != 0) {
            if (n3 != 1) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            co.a.L((Object)object);
        } else {
            co.a.L((Object)object);
            b<Float, i> b3 = this.g;
            float f2 = this.h ? 1.0f : 0.0f;
            Float f3 = new Float(f2);
            g<Float> g2 = this.i;
            this.f = 1;
            if (b.c(b3, (Object)f3, g2, null, null, (d)this, (int)12) == a3) {
                return a3;
            }
        }
        this.j.s();
        return v.a;
    }

    public Object t0(Object object, Object object2) {
        (g0)object;
        d d3 = (d)object2;
        y1 y12 = new y1(this.g, this.h, this.i, this.j, (d<? super y1>)d3);
        return y12.h((Object)v.a);
    }
}

