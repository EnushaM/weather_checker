/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.u
 *  b0.x0$a
 *  b0.x0$b
 *  b0.x0$c
 *  b0.x0$d
 *  d0.o
 *  e.n
 *  e0.g
 *  e0.g$a
 *  e0.l1
 *  e0.v
 *  e0.w1
 *  e0.x0
 *  gr.v
 *  j1.h
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  k0.a
 *  ma.e
 *  o0.g
 *  o0.g$a
 *  rr.a
 *  rr.p
 *  sr.g
 *  t0.i0
 *  u.w
 *  w.g
 *  w.h
 *  w.i
 *  x.h0
 *  x1.d
 *  y.a
 *  y.b
 *  y.c
 */
package b0;

import b0.k;
import b0.l;
import b0.m2;
import b0.q1;
import b0.r1;
import b0.u;
import b0.w0;
import b0.x0;
import d0.o;
import e.n;
import e0.g;
import e0.l1;
import e0.w1;
import gr.v;
import j1.h;
import java.util.Objects;
import ma.e;
import o0.g;
import rr.p;
import sr.g;
import t0.i0;
import u.w;
import w.i;
import x.h0;

public final class x0 {
    public static final float a = 56;
    public static final float b = 48;
    public static final float c = 12;
    public static final float d = 20;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void a(p<? super e0.g, ? super Integer, v> var0, rr.a<v> var1_1, o0.g var2_2, p<? super e0.g, ? super Integer, v> var3_3, w.h var4_4, i0 var5_5, long var6_6, long var8_7, w0 var10_8, e0.g var11_9, int var12_10, int var13_11) {
        block48 : {
            block44 : {
                block47 : {
                    block46 : {
                        block45 : {
                            block43 : {
                                block42 : {
                                    e.f(var0, (String)"text");
                                    e.f(var1_1, (String)"onClick");
                                    var14_12 = var11_9.o(223642380);
                                    if ((var13_11 & 1) != 0) {
                                        var16_13 = var12_10 | 6;
                                    } else if ((var12_10 & 14) == 0) {
                                        var94_14 = var14_12.M(var0) != false ? 4 : 2;
                                        var16_13 = var94_14 | var12_10;
                                    } else {
                                        var16_13 = var12_10;
                                    }
                                    if ((var13_11 & 2) != 0) {
                                        var16_13 |= 48;
                                    } else if ((var12_10 & 112) == 0) {
                                        var93_15 = var14_12.M(var1_1) != false ? 32 : 16;
                                        var16_13 |= var93_15;
                                    }
                                    var17_16 = var13_11 & 4;
                                    if (var17_16 == 0) break block42;
                                    var16_13 |= 384;
                                    ** GOTO lbl-1000
                                }
                                if ((var12_10 & 896) == 0) {
                                    var18_17 = var2_2;
                                    var92_18 = var14_12.M((Object)var18_17) != false ? 256 : 128;
                                    var16_13 |= var92_18;
                                } else lbl-1000: // 2 sources:
                                {
                                    var18_17 = var2_2;
                                }
                                var19_19 = var13_11 & 8;
                                if (var19_19 == 0) break block43;
                                var16_13 |= 3072;
                                ** GOTO lbl-1000
                            }
                            if ((var12_10 & 7168) == 0) {
                                var20_20 = var3_3;
                                var91_21 = var14_12.M(var20_20) != false ? 2048 : 1024;
                                var16_13 |= var91_21;
                            } else lbl-1000: // 2 sources:
                            {
                                var20_20 = var3_3;
                            }
                            var21_22 = var13_11 & 16;
                            if (var21_22 != 0) {
                                var16_13 |= 24576;
                            } else if ((var12_10 & 57344) == 0) {
                                var90_23 = var14_12.M((Object)var4_4) != false ? 16384 : 8192;
                                var16_13 |= var90_23;
                            }
                            if ((var12_10 & 458752) == 0) {
                                var89_24 = (var13_11 & 32) == 0 && var14_12.M((Object)var5_5) != false ? 131072 : 65536;
                                var16_13 |= var89_24;
                            }
                            if ((var12_10 & 3670016) == 0) {
                                var87_25 = var13_11 & 64;
                                var22_26 = var6_6;
                                var88_27 = var87_25 == 0 && var14_12.i(var22_26) != false ? 1048576 : 524288;
                                var16_13 |= var88_27;
                            } else {
                                var22_26 = var6_6;
                            }
                            if ((var12_10 & 29360128) == 0) {
                                var85_28 = var13_11 & 128;
                                var24_29 = var8_7;
                                var86_30 = var85_28 == 0 && var14_12.i(var24_29) != false ? 8388608 : 4194304;
                                var16_13 |= var86_30;
                            } else {
                                var24_29 = var8_7;
                            }
                            if ((var12_10 & 234881024) != 0) break block44;
                            if ((var13_11 & 256) != 0) break block45;
                            var26_31 = var10_8;
                            if (!var14_12.M((Object)var26_31)) break block46;
                            var84_32 = 67108864;
                            break block47;
                        }
                        var26_31 = var10_8;
                    }
                    var84_32 = 33554432;
                }
                var16_13 |= var84_32;
                break block48;
            }
            var26_31 = var10_8;
        }
        if ((38347922 ^ var16_13 & 191739611) == 0 && var14_12.r()) {
            var14_12.x();
            var59_33 = var4_4;
            var57_34 = var18_17;
            var58_35 = var20_20;
            var56_36 = var14_12;
            var60_37 = var5_5;
            var82_38 = var22_26;
            var65_39 = var26_31;
            var63_40 = var24_29;
            var61_41 = var82_38;
        } else {
            if ((var12_10 & 1) != 0 && !var14_12.B()) {
                var14_12.m();
                if ((var13_11 & 32) != 0) {
                    var16_13 &= -458753;
                }
                if ((var13_11 & 64) != 0) {
                    var16_13 &= -3670017;
                }
                if ((var13_11 & 128) != 0) {
                    var16_13 &= -29360129;
                }
                if ((var13_11 & 256) != 0) {
                    var16_13 &= -234881025;
                }
                var34_42 = var4_4;
                var41_43 = var5_5;
                var40_44 = var18_17;
                var35_45 = var24_29;
                var37_46 = var22_26;
                var39_47 = var26_31;
            } else {
                var14_12.n();
                if (var17_16 != 0) {
                    var27_49 = g.a.b;
                } else {
                    var27_50 = var18_17;
                }
                if (var19_19 != 0) {
                    var20_20 = null;
                }
                if (var21_22 != 0) {
                    var14_12.d(-3687241);
                    var79_52 = var14_12.e();
                    if (var79_52 == g.a.b) {
                        var79_52 = new i();
                        var14_12.E(var79_52);
                    }
                    var14_12.I();
                    var28_53 = (w.h)var79_52;
                } else {
                    var28_53 = var4_4;
                }
                if ((var13_11 & 32) != 0) {
                    var76_54 = ((q1)var14_12.K(r1.a)).a;
                    var77_55 = y.c.a((int)50);
                    Objects.requireNonNull((Object)var76_54);
                    var29_56 = var76_54.b(var77_55, var77_55, var77_55, var77_55);
                    var16_13 &= -458753;
                } else {
                    var29_56 = var5_5;
                }
                if ((var13_11 & 64) != 0) {
                    var22_26 = ((k)var14_12.K(l.a)).g();
                    var16_13 &= -3670017;
                }
                if ((var13_11 & 128) != 0) {
                    var30_57 = l.a(var22_26, var14_12);
                    var16_13 &= -29360129;
                } else {
                    var30_57 = var24_29;
                }
                if ((var13_11 & 256) != 0) {
                    var14_12.d(795786825);
                    var68_58 = 6;
                    var69_59 = 12;
                    var70_60 = new x1.d(var68_58);
                    var32_61 = var27_51;
                    var71_62 = new x1.d(var69_59);
                    var33_63 = var29_56;
                    var14_12.d(-3686552);
                    var72_64 = var14_12.M((Object)var70_60) | var14_12.M((Object)var71_62);
                    var73_65 = var14_12.e();
                    if (var72_64 || var73_65 == g.a.b) {
                        var73_65 = new u(var68_58, var69_59, null);
                        var14_12.E(var73_65);
                    }
                    var14_12.I();
                    var74_66 = (u)var73_65;
                    var14_12.I();
                    var16_13 &= -234881025;
                    var26_31 = var74_66;
                } else {
                    var32_61 = var27_51;
                    var33_63 = var29_56;
                }
                var14_12.L();
                var34_42 = var28_53;
                var35_45 = var30_57;
                var37_46 = var22_26;
                var39_47 = var26_31;
                var40_44 = var32_61;
                var41_43 = var33_63;
            }
            var42_48 = var20_20;
            var43_67 = x0.b;
            var44_68 = h0.j((o0.g)var40_44, (float)var43_67, (float)var43_67, (float)Float.NaN, (float)Float.NaN);
            var45_69 = n.h((e0.g)var14_12, (int)-819890049, (boolean)true, (Object)new a(var42_48, var0, var16_13));
            var46_70 = 12582912 | 14 & var16_13 >> 3;
            var47_71 = var16_13 >> 6;
            var48_72 = var46_70 | var47_71 & 896 | var47_71 & 7168 | 57344 & var47_71 | 458752 & var47_71 | var47_71 & 3670016;
            var49_73 = var34_42;
            var50_74 = var41_43;
            var51_75 = var37_46;
            var53_76 = var35_45;
            var55_77 = var39_47;
            var56_36 = var14_12;
            x0.b(var1_1, var44_68, var49_73, var50_74, var51_75, var53_76, var55_77, (p<? super e0.g, ? super Integer, v>)var45_69, var14_12, var48_72, 0);
            var57_34 = var40_44;
            var58_35 = var42_48;
            var59_33 = var34_42;
            var60_37 = var41_43;
            var61_41 = var37_46;
            var63_40 = var35_45;
            var65_39 = var39_47;
        }
        var66_78 = var56_36.u();
        if (var66_78 == null) {
            return;
        }
        var67_79 = new b(var0, var1_1, var57_34, var58_35, var59_33, var60_37, var61_41, var63_40, var65_39, var12_10, var13_11);
        var66_78.a((p)var67_79);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void b(rr.a<v> var0, o0.g var1_1, w.h var2_2, i0 var3_3, long var4_4, long var6_5, w0 var8_6, p<? super e0.g, ? super Integer, v> var9_7, e0.g var10_8, int var11_9, int var12_10) {
        block52 : {
            block51 : {
                block50 : {
                    block49 : {
                        block45 : {
                            block48 : {
                                block47 : {
                                    block46 : {
                                        block44 : {
                                            block40 : {
                                                block43 : {
                                                    block42 : {
                                                        block41 : {
                                                            block39 : {
                                                                block35 : {
                                                                    block38 : {
                                                                        block37 : {
                                                                            block36 : {
                                                                                block34 : {
                                                                                    e.f(var0, (String)"onClick");
                                                                                    e.f(var9_7, (String)"content");
                                                                                    var13_11 = var10_8.o(-2057936914);
                                                                                    if ((var12_10 & 1) != 0) {
                                                                                        var15_12 = var11_9 | 6;
                                                                                    } else if ((var11_9 & 14) == 0) {
                                                                                        var76_13 = var13_11.M(var0) != false ? 4 : 2;
                                                                                        var15_12 = var76_13 | var11_9;
                                                                                    } else {
                                                                                        var15_12 = var11_9;
                                                                                    }
                                                                                    var16_14 = var12_10 & 2;
                                                                                    if (var16_14 != 0) {
                                                                                        var15_12 |= 48;
                                                                                    } else if ((var11_9 & 112) == 0) {
                                                                                        var75_15 = var13_11.M((Object)var1_1) != false ? 32 : 16;
                                                                                        var15_12 |= var75_15;
                                                                                    }
                                                                                    var18_16 = var12_10 & 4;
                                                                                    if (var18_16 == 0) break block34;
                                                                                    var15_12 |= 384;
                                                                                    ** GOTO lbl-1000
                                                                                }
                                                                                if ((var11_9 & 896) == 0) {
                                                                                    var19_17 = var2_2;
                                                                                    var74_18 = var13_11.M((Object)var19_17) != false ? 256 : 128;
                                                                                    var15_12 |= var74_18;
                                                                                } else lbl-1000: // 2 sources:
                                                                                {
                                                                                    var19_17 = var2_2;
                                                                                }
                                                                                if ((var11_9 & 7168) != 0) break block35;
                                                                                if ((var12_10 & 8) != 0) break block36;
                                                                                var20_19 = var3_3;
                                                                                if (!var13_11.M((Object)var20_19)) break block37;
                                                                                var73_20 = 2048;
                                                                                break block38;
                                                                            }
                                                                            var20_19 = var3_3;
                                                                        }
                                                                        var73_20 = 1024;
                                                                    }
                                                                    var15_12 |= var73_20;
                                                                    break block39;
                                                                }
                                                                var20_19 = var3_3;
                                                            }
                                                            if ((var11_9 & 57344) != 0) break block40;
                                                            if ((var12_10 & 16) != 0) break block41;
                                                            var21_21 = var4_4;
                                                            if (!var13_11.i(var21_21)) break block42;
                                                            var72_22 = 16384;
                                                            break block43;
                                                        }
                                                        var21_21 = var4_4;
                                                    }
                                                    var72_22 = 8192;
                                                }
                                                var15_12 |= var72_22;
                                                break block44;
                                            }
                                            var21_21 = var4_4;
                                        }
                                        if ((458752 & var11_9) != 0) break block45;
                                        if ((var12_10 & 32) != 0) break block46;
                                        var23_23 = var6_5;
                                        if (!var13_11.i(var23_23)) break block47;
                                        var71_24 = 131072;
                                        break block48;
                                    }
                                    var23_23 = var6_5;
                                }
                                var71_24 = 65536;
                            }
                            var15_12 |= var71_24;
                            break block49;
                        }
                        var23_23 = var6_5;
                    }
                    if ((var11_9 & 3670016) == 0) {
                        var69_25 = var12_10 & 64;
                        var25_26 = var8_6;
                        var70_27 = var69_25 == 0 && var13_11.M((Object)var25_26) != false ? 1048576 : 524288;
                        var15_12 |= var70_27;
                    } else {
                        var25_26 = var8_6;
                    }
                    if ((var12_10 & 128) == 0) break block50;
                    var68_28 = 12582912;
                    break block51;
                }
                if ((var11_9 & 29360128) != 0) break block52;
                var68_28 = var13_11.M(var9_7) != false ? 8388608 : 4194304;
            }
            var15_12 |= var68_28;
        }
        if ((4793490 ^ 23967451 & var15_12) == 0 && var13_11.r()) {
            var13_11.x();
            var43_29 = var1_1;
            var42_30 = var13_11;
            var50_31 = var19_17;
            var44_32 = var20_19;
            var45_33 = var21_21;
            var47_34 = var23_23;
            var49_35 = var25_26;
        } else {
            if ((var11_9 & 1) != 0 && !var13_11.B()) {
                var13_11.m();
                if ((var12_10 & 8) != 0) {
                    var15_12 &= -7169;
                }
                if ((var12_10 & 16) != 0) {
                    var15_12 &= -57345;
                }
                if ((var12_10 & 32) != 0) {
                    var15_12 &= -458753;
                }
                if ((var12_10 & 64) != 0) {
                    var15_12 &= -3670017;
                }
            } else {
                var13_11.n();
                if (var16_14 != 0) {
                    var26_42 = g.a.b;
                } else {
                    var26_43 = var1_1;
                }
                if (var18_16 != 0) {
                    var13_11.d(-3687241);
                    var65_45 = var13_11.e();
                    if (var65_45 == g.a.b) {
                        var65_45 = new i();
                        var13_11.E(var65_45);
                    }
                    var13_11.I();
                    var19_17 = (w.h)var65_45;
                }
                if ((var12_10 & 8) != 0) {
                    var61_46 = ((q1)var13_11.K(r1.a)).a;
                    var62_47 = y.c.a((int)50);
                    Objects.requireNonNull((Object)var61_46);
                    var64_48 = var61_46.b(var62_47, var62_47, var62_47, var62_47);
                    var15_12 &= -7169;
                    var20_19 = var64_48;
                }
                if ((var12_10 & 16) != 0) {
                    var21_21 = ((k)var13_11.K(l.a)).g();
                    var15_12 &= -57345;
                }
                if ((var12_10 & 32) != 0) {
                    var23_23 = l.a(var21_21, var13_11);
                    var15_12 &= -458753;
                }
                if ((var12_10 & 64) != 0) {
                    var13_11.d(795786825);
                    var53_49 = 6;
                    var54_50 = 12;
                    var55_51 = new x1.d(var53_49);
                    var1_1 = var26_44;
                    var56_52 = new x1.d(var54_50);
                    var13_11.d(-3686552);
                    var57_53 = var13_11.M((Object)var55_51) | var13_11.M((Object)var56_52);
                    var58_54 = var13_11.e();
                    if (var57_53 || var58_54 == g.a.b) {
                        var58_54 = new u(var53_49, var54_50, null);
                        var13_11.E(var58_54);
                    }
                    var13_11.I();
                    var59_55 = (u)var58_54;
                    var13_11.I();
                    var15_12 &= -3670017;
                    var25_26 = var59_55;
                } else {
                    var1_1 = var26_44;
                }
                var13_11.L();
            }
            var27_36 = var1_1;
            var28_37 = var19_17;
            var29_38 = var20_19;
            var30_39 = var21_21;
            var32_40 = var23_23;
            var34_41 = var25_26;
            var35_56 = ((x1.d)var34_41.a((w.g)var28_37, (e0.g)var13_11, (int)(14 & var15_12 >> 6 | 112 & var15_12 >> 15)).getValue()).b;
            var36_57 = o.a((boolean)false, (float)0.0f, (long)0L, (e0.g)var13_11, (int)0, (int)7);
            var37_58 = new h(0);
            var38_59 = n.h((e0.g)var13_11, (int)-819890344, (boolean)true, (Object)new c(var32_40, var9_7, var15_12));
            var39_60 = var15_12 & 14 | var15_12 & 112;
            var40_61 = var15_12 >> 3;
            var41_62 = var39_60 | var40_61 & 896 | var40_61 & 7168 | 57344 & var40_61 | 29360128 & var15_12 << 15;
            var42_30 = var13_11;
            m2.a(var0, (o0.g)var27_36, (i0)var29_38, (long)var30_39, (long)var32_40, (float)var35_56, (w.h)var28_37, (w)var36_57, (boolean)false, null, (h)var37_58, (p)var38_59, (e0.g)var42_30, (int)var41_62, (int)384, (int)1568);
            var43_29 = var27_36;
            var44_32 = var29_38;
            var45_33 = var30_39;
            var47_34 = var32_40;
            var49_35 = var34_41;
            var50_31 = var28_37;
        }
        var51_63 = var42_30.u();
        if (var51_63 == null) {
            return;
        }
        var52_64 = new d(var0, var43_29, var50_31, var44_32, var45_33, var47_34, var49_35, var9_7, var11_9, var12_10);
        var51_63.a((p)var52_64);
    }
}

