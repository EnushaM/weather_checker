/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.z0
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.List
 */
package b0;

import b0.u0;
import e0.z0;
import java.util.ArrayList;
import java.util.List;

public final class v0<T> {
    public Object a = new Object();
    public List<u0<T>> b = new ArrayList();
    public z0 c;
}

