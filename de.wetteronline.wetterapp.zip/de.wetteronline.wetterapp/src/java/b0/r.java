/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  sr.e0
 *  sr.g
 *  t0.q
 */
package b0;

import b0.e;
import e0.u1;
import e0.w1;
import sr.e0;
import sr.g;
import t0.q;

public final class r
implements e {
    public final long a;
    public final long b;
    public final long c;
    public final long d;

    public r(long l2, long l3, long l4, long l5, g g3) {
        this.a = l2;
        this.b = l3;
        this.c = l4;
        this.d = l5;
    }

    @Override
    public w1<q> a(boolean bl, e0.g g3, int n2) {
        g3.d(1290125638);
        long l2 = bl ? this.a : this.c;
        w1 w12 = u1.d((Object)new q(l2), (e0.g)g3);
        g3.I();
        return w12;
    }

    @Override
    public w1<q> b(boolean bl, e0.g g3, int n2) {
        g3.d(1464782856);
        long l2 = bl ? this.b : this.d;
        w1 w12 = u1.d((Object)new q(l2), (e0.g)g3);
        g3.I();
        return w12;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null) {
            if (!ma.e.a(e0.a(r.class), e0.a((Class)object.getClass()))) {
                return false;
            }
            r r3 = (r)object;
            if (!q.b((long)this.a, (long)r3.a)) {
                return false;
            }
            if (!q.b((long)this.b, (long)r3.b)) {
                return false;
            }
            if (!q.b((long)this.c, (long)r3.c)) {
                return false;
            }
            return q.b((long)this.d, (long)r3.d);
        }
        return false;
    }

    public int hashCode() {
        return 31 * (31 * (31 * q.h((long)this.a) + q.h((long)this.b)) + q.h((long)this.c)) + q.h((long)this.d);
    }
}

