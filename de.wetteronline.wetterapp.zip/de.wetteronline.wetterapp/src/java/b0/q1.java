/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  ma.e
 *  y.a
 *  y.f
 *  y.g
 */
package b0;

import android.support.v4.media.b;
import ma.e;
import y.a;
import y.f;
import y.g;

public final class q1 {
    public final a a;
    public final a b;
    public final a c;

    public q1() {
        this(null, null, null, 7);
    }

    public q1(a a3, a a4, a a5, int n2) {
        f f2 = (n2 & 1) != 0 ? g.a((float)4) : null;
        f f3 = (n2 & 2) != 0 ? g.a((float)4) : null;
        int n3 = 4 & n2;
        f f4 = null;
        if (n3 != 0) {
            f4 = g.a((float)((float)false));
        }
        e.f((Object)f2, (String)"small");
        e.f((Object)f3, (String)"medium");
        e.f((Object)f4, (String)"large");
        this.a = f2;
        this.b = f3;
        this.c = f4;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof q1)) {
            return false;
        }
        a a3 = this.a;
        q1 q12 = (q1)object;
        if (!e.a((Object)a3, (Object)q12.a)) {
            return false;
        }
        if (!e.a((Object)this.b, (Object)q12.b)) {
            return false;
        }
        return e.a((Object)this.c, (Object)q12.c);
    }

    public int hashCode() {
        return 31 * (31 * this.a.hashCode() + this.b.hashCode()) + this.c.hashCode();
    }

    public String toString() {
        StringBuilder stringBuilder = b.a((String)"Shapes(small=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", medium=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", large=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}

