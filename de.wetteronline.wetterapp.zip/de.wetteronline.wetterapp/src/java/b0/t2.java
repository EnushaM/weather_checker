/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.r0
 *  java.lang.Boolean
 *  java.lang.Float
 *  java.lang.Iterable
 *  java.lang.Number
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  t.g
 *  tn.a
 */
package b0;

import b0.q2;
import b0.r2;
import b0.s2;
import e0.r0;
import gr.v;
import gs.c;
import hr.s;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import jr.d;
import kr.a;
import ma.e;
import rr.l;
import rr.p;
import t.g;

public final class t2
implements gs.d<Map<Float, Object>> {
    public final /* synthetic */ r2 b;
    public final /* synthetic */ float c;

    public t2(r2 r22, float f2) {
        this.b = r22;
        this.c = f2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public Object a(Map<Float, Object> var1_1, d<? super v> var2_2) {
        block14 : {
            block10 : {
                block13 : {
                    block11 : {
                        block12 : {
                            block9 : {
                                block8 : {
                                    var3_3 = a.b;
                                    var4_4 = var1_1;
                                    var5_5 = q2.a(var4_4, this.b.d());
                                    e.d((Object)var5_5);
                                    var6_6 = var5_5.floatValue();
                                    var7_7 = ((Number)this.b.e.getValue()).floatValue();
                                    var8_8 = var4_4.keySet();
                                    var9_9 = (p)this.b.m.getValue();
                                    var10_10 = this.c;
                                    var11_11 = ((Number)this.b.n.getValue()).floatValue();
                                    var12_12 = new ArrayList();
                                    for (Object var42_14 : var8_8) {
                                        var43_15 = ((Number)var42_14).floatValue();
                                        var44_16 = var3_3;
                                        var45_17 = var43_15;
                                        var47_18 = var9_9;
                                        var48_19 = var10_10;
                                        var49_20 = var45_17 <= 0.001 + (double)var7_7;
                                        if (var49_20) {
                                            var12_12.add(var42_14);
                                        }
                                        var9_9 = var47_18;
                                        var3_3 = var44_16;
                                        var10_10 = var48_19;
                                    }
                                    var14_21 = var3_3;
                                    var15_22 = var9_9;
                                    var16_23 = var10_10;
                                    var17_24 = s.e0((Iterable<Float>)var12_12);
                                    var18_25 = new ArrayList();
                                    for (Object var36_27 : var8_8) {
                                        var37_28 = ((Number)var36_27).floatValue();
                                        var39_29 = var11_11;
                                        var40_30 = var37_28 >= (double)var7_7 - 0.001;
                                        if (var40_30) {
                                            var18_25.add(var36_27);
                                        }
                                        var11_11 = var39_29;
                                    }
                                    var20_31 = var11_11;
                                    var21_32 = s.g0((Iterable<Float>)var18_25);
                                    if (var17_24 != null) break block8;
                                    var35_33 = tn.a.v((Object)var21_32);
                                    ** GOTO lbl51
                                }
                                if (var21_32 != null) break block9;
                                var35_33 = tn.a.t((Object)var17_24);
                                ** GOTO lbl51
                            }
                            var22_34 = var17_24.floatValue() == var21_32.floatValue();
                            if (var22_34) {
                                var35_33 = tn.a.t((Object)Float.valueOf((float)var7_7));
lbl51: // 3 sources:
                                var25_35 = var35_33;
                                var24_36 = 1;
                            } else {
                                var23_37 = new Float[2];
                                var23_37[0] = var17_24;
                                var24_36 = 1;
                                var23_37[var24_36] = var21_32;
                                var25_35 = tn.a.u((Object[])var23_37);
                            }
                            var26_38 = var25_35.size();
                            if (var26_38 == 0) break block10;
                            if (var26_38 == var24_36) break block11;
                            var27_39 = ((Number)var25_35.get(0)).floatValue();
                            var34_40 = ((Number)var25_35.get(var24_36)).floatValue();
                            if (!(var6_6 <= var7_7)) break block12;
                            if (var16_23 >= var20_31 || !(var7_7 < ((Number)var15_22.t0(Float.valueOf((float)var27_39), Float.valueOf((float)var34_40))).floatValue())) break block13;
                            break block14;
                        }
                        if (var16_23 <= -var20_31 || !(var7_7 > ((Number)var15_22.t0(Float.valueOf((float)var34_40), Float.valueOf((float)var27_39))).floatValue())) break block14;
                        break block13;
                    }
                    var34_40 = ((Number)var25_35.get(0)).floatValue();
                }
                var27_39 = var34_40;
                break block14;
            }
            var27_39 = var6_6;
        }
        var28_41 = var4_4.get((Object)new Float(var27_39));
        if (var28_41 != null && this.b.b.y(var28_41).booleanValue()) {
            var31_42 = this.b;
            var32_43 = var31_42.a;
            var33_44 = var31_42.j.f(new s2(var28_41, var31_42, var32_43), var2_2);
            if (var33_44 != var14_21) {
                var33_44 = v.a;
            }
            if (var33_44 != var14_21) return v.a;
            return var33_44;
        }
        var29_45 = this.b;
        var30_46 = var29_45.b(var6_6, var29_45.a, var2_2);
        if (var30_46 != var14_21) return v.a;
        return var30_46;
    }
}

