/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e1.e
 *  e1.m
 *  e1.v
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package b0;

import b0.g2;
import b0.j2;
import e1.b;
import e1.e;
import e1.m;
import e1.n;
import e1.o;
import e1.p;
import e1.v;
import gr.v;
import hr.s;
import java.util.List;
import rr.l;

public final class j2
implements n {
    public static final j2 a = new j2();

    @Override
    public final o a(p p2, List<? extends m> list, long l2) {
        ma.e.f(p2, "$this$Layout");
        ma.e.f(list, "measurables");
        boolean bl = list.size() == 1;
        if (bl) {
            e1.v v3 = s.W(list).v(l2);
            int n2 = v3.P((e1.a)b.a);
            int n3 = v3.P((e1.a)b.b);
            boolean bl2 = n2 != Integer.MIN_VALUE;
            if (bl2) {
                boolean bl3 = false;
                if (n3 != Integer.MIN_VALUE) {
                    bl3 = true;
                }
                if (bl3) {
                    float f2 = n2 == n3 ? g2.h : g2.i;
                    int n4 = Math.max((int)p2.Q(f2), (int)v3.c);
                    return p.a.b(p2, x1.a.g(l2), n4, null, new l<v.a, v>(n4, v3){
                        public final /* synthetic */ int c;
                        public final /* synthetic */ e1.v d;
                        {
                            this.c = n2;
                            this.d = v3;
                            super(1);
                        }

                        public Object y(Object object) {
                            v.a a2 = (v.a)object;
                            ma.e.f(a2, "$this$layout");
                            int n2 = this.c;
                            e1.v v3 = this.d;
                            v.a.f(a2, v3, 0, (n2 - v3.c) / 2, 0.0f, 4, null);
                            return v.a;
                        }
                    }, 4, null);
                }
                throw new IllegalArgumentException("No baselines for text".toString());
            }
            throw new IllegalArgumentException("No baselines for text".toString());
        }
        throw new IllegalArgumentException("text for Snackbar expected to have exactly only one child".toString());
    }
}

