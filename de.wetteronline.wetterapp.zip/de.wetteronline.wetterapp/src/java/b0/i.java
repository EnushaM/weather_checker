/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.x0
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  l1.u
 *  rr.p
 *  rr.q
 *  sr.m
 *  x.c0
 *  x.w
 */
package b0;

import b0.h;
import b0.u2;
import b0.w2;
import b0.x2;
import e.n;
import e0.g;
import e0.x0;
import gr.v;
import l1.u;
import rr.p;
import rr.q;
import sr.m;
import x.c0;
import x.w;

public final class i
extends m
implements p<g, Integer, v> {
    public final /* synthetic */ w c;
    public final /* synthetic */ q<c0, g, Integer, v> d;
    public final /* synthetic */ int e;

    public i(w w3, q<? super c0, ? super g, ? super Integer, v> q2, int n3) {
        this.c = w3;
        this.d = q2;
        this.e = n3;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        int n3 = ((Number)object2).intValue();
        if ((2 ^ n3 & 11) == 0 && g3.r()) {
            g3.x();
        } else {
            u2.a(g3.K(x2.a).k, n.h(g3, -819891209, true, (Object)new h(this.c, this.d, this.e)), g3, 48);
        }
        return v.a;
    }
}

