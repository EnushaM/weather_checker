/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  co.a
 *  e0.r0
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  t.g
 */
package b0;

import b0.q2;
import b0.r2;
import b0.s2;
import e0.r0;
import gr.v;
import hr.s;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import jr.d;
import lr.c;
import t.g;

public final class s2
implements gs.d<Map<Float, Object>> {
    public final /* synthetic */ Object b;
    public final /* synthetic */ r2 c;
    public final /* synthetic */ g d;

    public s2(Object object, r2 r22, g g3) {
        this.b = object;
        this.c = r22;
        this.d = g3;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public Object a(Map<Float, Object> var1_1, d<? super v> var2_2) {
        block17 : {
            block16 : {
                block14 : {
                    block15 : {
                        block13 : {
                            if (!(var2_2 instanceof a)) ** GOTO lbl-1000
                            var3_3 = var2_2;
                            var29_4 = var3_3.f;
                            if ((var29_4 & Integer.MIN_VALUE) != 0) {
                                var3_3.f = var29_4 + Integer.MIN_VALUE;
                            } else lbl-1000: // 2 sources:
                            {
                                var3_3 = new c(this, var2_2){
                                    public /* synthetic */ Object e;
                                    public int f;
                                    public final /* synthetic */ s2 g;
                                    public Object h;
                                    public Object i;
                                    {
                                        this.g = s22;
                                        super(d2);
                                    }

                                    public final Object h(Object object) {
                                        this.e = object;
                                        this.f = Integer.MIN_VALUE | this.f;
                                        return this.g.a(null, (d)this);
                                    }
                                };
                            }
                            var4_5 = var3_3.e;
                            var5_6 = kr.a.b;
                            var6_7 = var3_3.f;
                            if (var6_7 != 0) {
                                if (var6_7 != 1) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                var7_8 = (Map)var3_3.i;
                                var9_9 = (s2)var3_3.h;
                                try {
                                    co.a.L((Object)var4_5);
                                    break block13;
                                }
                                catch (Throwable var8_10) {
                                    break block14;
                                }
                            }
                            co.a.L((Object)var4_5);
                            var7_8 = var1_1;
                            var17_13 = q2.a(var7_8, this.b);
                            if (var17_13 == null) break block15;
                            var18_14 = this.c;
                            var19_15 = var17_13.floatValue();
                            var20_16 = this.d;
                            var3_3.h = this;
                            var3_3.i = var7_8;
                            var3_3.f = 1;
                            var21_17 = var18_14.b(var19_15, (g<Float>)var20_16, var3_3);
                            if (var21_17 == var5_6) {
                                return var5_6;
                            }
                            var9_9 = this;
                        }
                        var22_18 = ((Number)var9_9.c.g.getValue()).floatValue();
                        var23_19 = new LinkedHashMap();
                        var24_20 = var7_8.entrySet().iterator();
                        break block16;
                    }
                    try {
                        throw new IllegalArgumentException("The target value must have an associated anchor.".toString());
                    }
                    catch (Throwable var8_11) {
                        var9_9 = this;
                    }
                }
                var10_24 = ((Number)var9_9.c.g.getValue()).floatValue();
                var11_25 = new LinkedHashMap();
                var12_26 = var7_8.entrySet().iterator();
                break block17;
            }
            while (var24_20.hasNext()) {
                var26_21 = (Map.Entry)var24_20.next();
                var27_22 = Math.abs((float)(((Number)var26_21.getKey()).floatValue() - var22_18)) < 0.5f;
                if (!var27_22) continue;
                var23_19.put(var26_21.getKey(), var26_21.getValue());
            }
            var25_23 = s.X(var23_19.values());
            if (var25_23 == null) {
                var25_23 = var9_9.c.d();
            }
            var9_9.c.c.setValue(var25_23);
            return v.a;
        }
        while (var12_26.hasNext()) {
            var14_27 = (Map.Entry)var12_26.next();
            var15_28 = Math.abs((float)(((Number)var14_27.getKey()).floatValue() - var10_24)) < 0.5f;
            if (!var15_28) continue;
            var11_25.put(var14_27.getKey(), var14_27.getValue());
        }
        var13_29 = s.X(var11_25.values());
        if (var13_29 == null) {
            var13_29 = var9_9.c.d();
        }
        var9_9.c.c.setValue(var13_29);
        throw var8_12;
    }
}

