/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

public final class t0 {
    public final int a;

    public /* synthetic */ t0(int n2) {
        this.a = n2;
    }

    public boolean equals(Object object) {
        int n2 = this.a;
        if (!(object instanceof t0)) {
            return false;
        }
        return n2 == ((t0)object).a;
    }

    public int hashCode() {
        return this.a;
    }

    public String toString() {
        boolean bl = this.a == 0;
        if (bl) {
            return "FabPosition.Center";
        }
        return "FabPosition.End";
    }
}

