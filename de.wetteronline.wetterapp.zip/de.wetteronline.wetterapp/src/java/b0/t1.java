/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

public final class t1
extends Enum<t1> {
    public static final /* enum */ t1 b = new t1();
    public static final /* enum */ t1 c = new t1();
    public static final /* enum */ t1 d = new t1();
    public static final /* synthetic */ t1[] e;

    public static {
        e = arrt1 = new t1[]{t1.b, t1.c, t1.d};
    }

    public static t1 valueOf(String string) {
        return (t1)Enum.valueOf(t1.class, (String)string);
    }

    public static t1[] values() {
        return (t1[])e.clone();
    }
}

