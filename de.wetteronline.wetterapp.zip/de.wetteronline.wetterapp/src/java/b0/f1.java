/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s.b
 *  s.d
 */
package b0;

import s.b;
import s.d;

public final class f1 {
    public final float a;
    public final float b;
    public final float c;

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof f1)) {
            return false;
        }
        float f2 = this.a;
        f1 f12 = (f1)object;
        boolean bl = f2 == f12.a;
        if (!bl) {
            return false;
        }
        boolean bl2 = this.b == f12.b;
        if (!bl2) {
            return false;
        }
        boolean bl3 = this.c == f12.c;
        return bl3;
    }

    public int hashCode() {
        int n2 = 31 * Float.floatToIntBits((float)this.a);
        return d.a((float)this.b, (int)n2, (int)31) + Float.floatToIntBits((float)this.c);
    }

    public String toString() {
        StringBuilder stringBuilder = android.support.v4.media.b.a((String)"ResistanceConfig(basis=");
        stringBuilder.append(this.a);
        stringBuilder.append(", factorAtMin=");
        stringBuilder.append(this.b);
        stringBuilder.append(", factorAtMax=");
        return b.a((StringBuilder)stringBuilder, (float)this.c, (char)')');
    }
}

