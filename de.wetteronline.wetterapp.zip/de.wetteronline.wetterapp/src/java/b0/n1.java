/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  rr.p
 *  rr.q
 *  sr.m
 *  x.w
 */
package b0;

import b0.g1;
import e0.g;
import gr.v;
import rr.p;
import rr.q;
import sr.m;
import x.w;

public final class n1
extends m
implements p<g, Integer, v> {
    public final /* synthetic */ boolean c;
    public final /* synthetic */ int d;
    public final /* synthetic */ p<g, Integer, v> e;
    public final /* synthetic */ q<w, g, Integer, v> f;
    public final /* synthetic */ p<g, Integer, v> g;
    public final /* synthetic */ p<g, Integer, v> h;
    public final /* synthetic */ p<g, Integer, v> i;
    public final /* synthetic */ int j;

    public n1(boolean bl, int n3, p<? super g, ? super Integer, v> p4, q<? super w, ? super g, ? super Integer, v> q2, p<? super g, ? super Integer, v> p5, p<? super g, ? super Integer, v> p6, p<? super g, ? super Integer, v> p7, int n4) {
        this.c = bl;
        this.d = n3;
        this.e = p4;
        this.f = q2;
        this.g = p5;
        this.h = p6;
        this.i = p7;
        this.j = n4;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        ((Number)object2).intValue();
        g1.b(this.c, this.d, this.e, this.f, this.g, this.h, this.i, g3, 1 | this.j);
        return v.a;
    }
}

