/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.t2
 *  co.a
 *  ds.g0
 *  gr.v
 *  gs.c
 *  gs.d
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  jr.d
 *  kotlinx.coroutines.a
 *  kr.a
 *  lr.e
 *  lr.i
 *  rr.p
 *  rr.q
 */
package b0;

import b0.r2;
import b0.t2;
import ds.g0;
import gr.v;
import gs.c;
import java.util.Map;
import jr.d;
import lr.e;
import lr.i;
import rr.p;
import rr.q;

@e(c="androidx.compose.material.SwipeableKt$swipeable$3$4", f="Swipeable.kt", l={}, m="invokeSuspend")
public final class o2
extends i
implements q<g0, Float, d<? super v>, Object> {
    public /* synthetic */ Object f;
    public /* synthetic */ float g;
    public final /* synthetic */ r2<Object> h;

    public o2(r2<Object> r22, d<? super o2> d3) {
        this.h = r22;
        super(3, d3);
    }

    public final Object h(Object object) {
        co.a.L((Object)object);
        g0 g02 = (g0)this.f;
        float f2 = this.g;
        kotlinx.coroutines.a.d((g0)g02, null, (int)0, (p)new p<g0, d<? super v>, Object>(this.h, f2, null){
            public int f;
            public final /* synthetic */ r2<Object> g;
            public final /* synthetic */ float h;
            {
                this.g = r22;
                this.h = f2;
                super(2, d3);
            }

            public final d<v> e(Object object, d<?> d3) {
                return new /* invalid duplicate definition of identical inner class */;
            }

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final Object h(Object object) {
                kr.a a3 = kr.a.b;
                int n3 = this.f;
                if (n3 != 0) {
                    if (n3 != 1) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    co.a.L((Object)object);
                    return v.a;
                } else {
                    co.a.L((Object)object);
                    r2<Object> r22 = this.g;
                    float f2 = this.h;
                    this.f = 1;
                    Object object2 = r22.j.f((gs.d)new t2(r22, f2), (d)this);
                    if (object2 != a3) {
                        object2 = v.a;
                    }
                    if (object2 != a3) return v.a;
                    return a3;
                }
            }

            public Object t0(Object object, Object object2) {
                (g0)object;
                d d3 = (d)object2;
                return new /* invalid duplicate definition of identical inner class */.h((Object)v.a);
            }
        }, (int)3, null);
        return v.a;
    }

    public Object r(Object object, Object object2, Object object3) {
        g0 g02 = (g0)object;
        float f2 = ((Number)object2).floatValue();
        d d3 = (d)object3;
        o2 o22 = new o2(this.h, (d<? super o2>)d3);
        o22.f = g02;
        o22.g = f2;
        v v3 = v.a;
        o22.h((Object)v3);
        return v3;
    }

}

