/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  sr.g
 *  t.b
 *  t.r0
 *  t.t0
 *  w.f
 *  w.g
 */
package b0;

import b0.g;
import b0.s;
import ds.g0;
import e0.f0;
import e0.g;
import e0.w1;
import gr.v;
import jr.d;
import m0.u;
import ma.e;
import rr.p;
import t.h;
import t.i;
import t.r0;
import t.t0;
import w.f;
import w.k;

public final class s
implements g {
    public final float a;
    public final float b;
    public final float c;

    public s(float f2, float f3, float f4, sr.g g3) {
        this.a = f2;
        this.b = f3;
        this.c = f4;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public w1<x1.d> a(boolean bl, w.g g3, e0.g g4, int n2) {
        e.f((Object)g3, "interactionSource");
        g4.d(-1598810717);
        g4.d(-3687241);
        u u3 = g4.e();
        Object object = g.a.b;
        if (u3 == object) {
            u3 = new u();
            g4.E(u3);
        }
        g4.I();
        u u4 = u3;
        f0.c((Object)g3, (p)new p<g0, d<? super v>, Object>(g3, (u<f>)u4, null){
            public int f;
            public final /* synthetic */ w.g g;
            public final /* synthetic */ u<f> h;
            {
                this.g = g3;
                this.h = u3;
                super(2, d2);
            }

            public final d<v> e(Object object, d<?> d2) {
                return new /* invalid duplicate definition of identical inner class */;
            }

            /*
             * Enabled force condition propagation
             * Lifted jumps to return sites
             */
            public final Object h(Object object) {
                kr.a a2 = kr.a.b;
                int n2 = this.f;
                if (n2 != 0) {
                    if (n2 != 1) throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    co.a.L((Object)object);
                    return v.a;
                } else {
                    co.a.L((Object)object);
                    gs.c c3 = this.g.a();
                    gs.d<f> d2 = new gs.d<f>(this.h){
                        public final /* synthetic */ u b;
                        {
                            this.b = u3;
                        }

                        public Object a(f f2, d<? super v> d2) {
                            f f3 = f2;
                            if (f3 instanceof k) {
                                this.b.add(f3);
                            } else if (f3 instanceof w.l) {
                                this.b.remove(((w.l)f3).a);
                            } else if (f3 instanceof w.j) {
                                this.b.remove(((w.j)f3).a);
                            }
                            return v.a;
                        }
                    };
                    this.f = 1;
                    if (c3.f(d2, this) != a2) return v.a;
                    return a2;
                }
            }

            public Object t0(Object object, Object object2) {
                (g0)object;
                d d2 = (d)object2;
                return new /* invalid duplicate definition of identical inner class */.h((Object)v.a);
            }
        }, (e0.g)g4);
        f f2 = (f)hr.s.d0(u4);
        float f3 = !bl ? this.c : (f2 instanceof k ? this.b : this.a);
        float f4 = f3;
        g4.d(-3687241);
        Object object2 = g4.e();
        if (object2 == object) {
            x1.d d2 = new x1.d(f4);
            object2 = new t.b((Object)d2, t0.c, null);
            g4.E(object2);
        }
        g4.I();
        t.b b3 = (t.b)object2;
        if (!bl) {
            g4.d(-1598809568);
            f0.c((Object)new x1.d(f4), (p)new p<g0, d<? super v>, Object>((t.b<x1.d, i>)b3, f4, null){
                public int f;
                public final /* synthetic */ t.b<x1.d, i> g;
                public final /* synthetic */ float h;
                {
                    this.g = b3;
                    this.h = f2;
                    super(2, d2);
                }

                public final d<v> e(Object object, d<?> d2) {
                    return new /* invalid duplicate definition of identical inner class */;
                }

                /*
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                public final Object h(Object object) {
                    kr.a a2 = kr.a.b;
                    int n2 = this.f;
                    if (n2 != 0) {
                        if (n2 != 1) throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        co.a.L((Object)object);
                        return v.a;
                    } else {
                        co.a.L((Object)object);
                        t.b<x1.d, i> b3 = this.g;
                        x1.d d2 = new x1.d(this.h);
                        this.f = 1;
                        if (b3.f((Object)d2, (d)this) != a2) return v.a;
                        return a2;
                    }
                }

                public Object t0(Object object, Object object2) {
                    (g0)object;
                    d d2 = (d)object2;
                    return new /* invalid duplicate definition of identical inner class */.h((Object)v.a);
                }
            }, (e0.g)g4);
            g4.I();
        } else {
            g4.d(-1598809397);
            x1.d d3 = new x1.d(f4);
            p<g0, d<? super v>, Object> p2 = new p<g0, d<? super v>, Object>((t.b<x1.d, i>)b3, this, f4, f2, null){
                public int f;
                public final /* synthetic */ t.b<x1.d, i> g;
                public final /* synthetic */ s h;
                public final /* synthetic */ float i;
                public final /* synthetic */ f j;
                {
                    this.g = b3;
                    this.h = s3;
                    this.i = f2;
                    this.j = f3;
                    super(2, d2);
                }

                public final d<v> e(Object object, d<?> d2) {
                    p<g0, d<? super v>, Object> p2 = new /* invalid duplicate definition of identical inner class */;
                    return p2;
                }

                /*
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                public final Object h(Object object) {
                    kr.a a2 = kr.a.b;
                    int n2 = this.f;
                    if (n2 != 0) {
                        if (n2 != 1) throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        co.a.L((Object)object);
                        return v.a;
                    } else {
                        co.a.L((Object)object);
                        boolean bl = x1.d.a(((x1.d)this.g.e.getValue()).b, this.h.b);
                        k k2 = null;
                        if (bl) {
                            k2 = new k(s0.c.c, null);
                        }
                        t.b<x1.d, i> b3 = this.g;
                        float f2 = this.i;
                        f f3 = this.j;
                        this.f = 1;
                        if (b0.p0.a(b3, f2, k2, f3, this) != a2) return v.a;
                        return a2;
                    }
                }

                public Object t0(Object object, Object object2) {
                    (g0)object;
                    d d2 = (d)object2;
                    p<g0, d<? super v>, Object> p2 = new /* invalid duplicate definition of identical inner class */;
                    return p2.h((Object)v.a);
                }
            };
            f0.c((Object)d3, (p)p2, (e0.g)g4);
            g4.I();
        }
        h h2 = b3.c;
        g4.I();
        return h2;
    }
}

