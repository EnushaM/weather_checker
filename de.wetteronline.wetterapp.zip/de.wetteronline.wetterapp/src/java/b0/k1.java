/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.x0
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  rr.p
 *  sr.m
 */
package b0;

import b0.g1;
import b0.s0;
import e0.g;
import e0.w;
import e0.x0;
import e0.y0;
import gr.v;
import rr.p;
import sr.m;

public final class k1
extends m
implements p<g, Integer, v> {
    public final /* synthetic */ s0 c;
    public final /* synthetic */ p<g, Integer, v> d;
    public final /* synthetic */ int e;

    public k1(s0 s02, p<? super g, ? super Integer, v> p4, int n3) {
        this.c = s02;
        this.d = p4;
        this.e = n3;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        int n3 = ((Number)object2).intValue();
        if ((2 ^ n3 & 11) == 0 && g3.r()) {
            g3.x();
        } else {
            y0[] arry0 = new y0[]{g1.a.b((Object)this.c)};
            w.a((y0[])arry0, this.d, (g)g3, (int)(8 | 112 & this.e >> 15));
        }
        return v.a;
    }
}

