/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.s2
 *  gr.v
 *  gs.c
 *  gs.d
 *  java.lang.Boolean
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  jr.d
 *  kr.a
 *  ma.e
 *  rr.l
 *  t.g
 *  t.q0
 */
package b0;

import b0.f0;
import b0.o0;
import b0.r2;
import b0.s2;
import gr.v;
import gs.c;
import java.util.Map;
import jr.d;
import kr.a;
import ma.e;
import rr.l;
import t.g;
import t.q0;

public final class n0 {
    public final r2<o0> a;

    public n0(o0 o02, l<? super o0, Boolean> l3) {
        e.f((Object)((Object)o02), (String)"initialValue");
        e.f(l3, (String)"confirmStateChange");
        this.a = new r2<o0>(o02, (g<Float>)f0.c, l3);
    }

    public final Object a(d<? super v> d3) {
        a a3;
        o0 o02 = o0.b;
        r2<o0> r22 = this.a;
        q0<Float> q02 = f0.c;
        Object object = r22.j.f((gs.d)new s2((Object)o02, r22, q02), d3);
        if (object != (a3 = a.b)) {
            object = v.a;
        }
        if (object != a3) {
            object = v.a;
        }
        if (object == a3) {
            return object;
        }
        return v.a;
    }
}

