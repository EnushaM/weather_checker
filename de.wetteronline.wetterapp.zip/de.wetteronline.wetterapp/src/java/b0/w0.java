/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.g
 *  e0.w1
 *  java.lang.Object
 *  w.g
 *  x1.d
 */
package b0;

import e0.g;
import e0.w1;
import x1.d;

public interface w0 {
    public w1<d> a(w.g var1, g var2, int var3);
}

