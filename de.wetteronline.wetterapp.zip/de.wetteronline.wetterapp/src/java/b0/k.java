/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  e0.r0
 *  e0.s1
 *  e0.u1
 *  e0.z1
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  sr.g
 *  t0.q
 */
package b0;

import android.support.v4.media.b;
import e0.r0;
import e0.s1;
import e0.u1;
import e0.z1;
import sr.g;
import t0.q;

public final class k {
    public final r0 a;
    public final r0 b;
    public final r0 c;
    public final r0 d;
    public final r0 e;
    public final r0 f;
    public final r0 g;
    public final r0 h;
    public final r0 i;
    public final r0 j;
    public final r0 k;
    public final r0 l;
    public final r0 m;

    public k(long l3, long l4, long l5, long l6, long l7, long l8, long l9, long l10, long l11, long l12, long l13, long l14, boolean bl, g g3) {
        q q3 = new q(l3);
        z1 z12 = z1.a;
        this.a = u1.a((Object)q3, (s1)z12);
        this.b = u1.a((Object)new q(l4), (s1)z12);
        this.c = u1.a((Object)new q(l5), (s1)z12);
        this.d = u1.a((Object)new q(l6), (s1)z12);
        this.e = u1.a((Object)new q(l7), (s1)z12);
        this.f = u1.a((Object)new q(l8), (s1)z12);
        this.g = u1.a((Object)new q(l9), (s1)z12);
        this.h = u1.a((Object)new q(l10), (s1)z12);
        this.i = u1.a((Object)new q(l11), (s1)z12);
        this.j = u1.a((Object)new q(l12), (s1)z12);
        this.k = u1.a((Object)new q(l13), (s1)z12);
        this.l = u1.a((Object)new q(l14), (s1)z12);
        this.m = u1.a((Object)bl, (s1)z12);
    }

    public final long a() {
        return ((q)this.e.getValue()).a;
    }

    public final long b() {
        return ((q)this.h.getValue()).a;
    }

    public final long c() {
        return ((q)this.i.getValue()).a;
    }

    public final long d() {
        return ((q)this.k.getValue()).a;
    }

    public final long e() {
        return ((q)this.a.getValue()).a;
    }

    public final long f() {
        return ((q)this.b.getValue()).a;
    }

    public final long g() {
        return ((q)this.c.getValue()).a;
    }

    public final long h() {
        return ((q)this.f.getValue()).a;
    }

    public final boolean i() {
        return (Boolean)this.m.getValue();
    }

    public String toString() {
        StringBuilder stringBuilder = b.a((String)"Colors(primary=");
        stringBuilder.append((Object)q.i((long)this.e()));
        stringBuilder.append(", primaryVariant=");
        stringBuilder.append((Object)q.i((long)this.f()));
        stringBuilder.append(", secondary=");
        stringBuilder.append((Object)q.i((long)this.g()));
        stringBuilder.append(", secondaryVariant=");
        stringBuilder.append((Object)q.i((long)((q)this.d.getValue()).a));
        stringBuilder.append(", background=");
        stringBuilder.append((Object)q.i((long)this.a()));
        stringBuilder.append(", surface=");
        stringBuilder.append((Object)q.i((long)this.h()));
        stringBuilder.append(", error=");
        stringBuilder.append((Object)q.i((long)((q)this.g.getValue()).a));
        stringBuilder.append(", onPrimary=");
        stringBuilder.append((Object)q.i((long)this.b()));
        stringBuilder.append(", onSecondary=");
        stringBuilder.append((Object)q.i((long)this.c()));
        stringBuilder.append(", onBackground=");
        stringBuilder.append((Object)q.i((long)((q)this.j.getValue()).a));
        stringBuilder.append(", onSurface=");
        stringBuilder.append((Object)q.i((long)this.d()));
        stringBuilder.append(", onError=");
        stringBuilder.append((Object)q.i((long)((q)this.l.getValue()).a));
        stringBuilder.append(", isLight=");
        stringBuilder.append(this.i());
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}

