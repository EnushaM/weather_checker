/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Float
 *  java.lang.Object
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  ma.e
 */
package b0;

import java.util.Map;
import java.util.Set;
import ma.e;

public final class q2 {
    public static final Float a(Map map, Object object) {
        Object object22;
        block2 : {
            for (Object object22 : map.entrySet()) {
                if (!e.a((Object)((Map.Entry)object22).getValue(), (Object)object)) continue;
                break block2;
            }
            object22 = null;
        }
        Map.Entry entry = (Map.Entry)object22;
        if (entry == null) {
            return null;
        }
        return (Float)entry.getKey();
    }
}

