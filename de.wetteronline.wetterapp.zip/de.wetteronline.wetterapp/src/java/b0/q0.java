/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.g
 *  java.lang.Object
 */
package b0;

import e0.g;

public interface q0 {
    public long a(long var1, float var3, g var4, int var5);
}

