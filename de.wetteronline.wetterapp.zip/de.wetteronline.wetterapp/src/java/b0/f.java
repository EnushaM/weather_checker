/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.r
 *  e.d
 *  e.n
 *  e0.g
 *  e0.v
 *  e0.x0
 *  java.lang.Object
 *  sr.g
 *  t0.q
 *  x.w
 *  x.x
 */
package b0;

import b0.e;
import b0.k;
import b0.l;
import b0.q;
import b0.r;
import e.d;
import e.n;
import e0.v;
import e0.x0;
import sr.g;
import x.w;
import x.x;

public final class f {
    public static final f a;
    public static final w b;
    public static final float c;
    public static final float d;
    public static final w e;

    public static {
        w w3;
        a = new f();
        float f2 = 16;
        float f3 = 8;
        b = w3 = d.a((float)f2, (float)f3, (float)f2, (float)f3);
        c = 64;
        d = 36;
        x x3 = (x)w3;
        e = d.a((float)f3, (float)x3.b, (float)f3, (float)x3.d);
    }

    public final e a(long l3, long l4, long l5, long l6, e0.g g3, int n2, int n3) {
        long l7;
        long l8;
        g3.d(2063544006);
        long l9 = (n3 & 1) != 0 ? ((k)g3.K(l.a)).e() : l3;
        long l10 = (n3 & 2) != 0 ? l.a(l9, g3) : l4;
        if ((n3 & 4) != 0) {
            x0<k> x02 = l.a;
            l8 = n.j((long)t0.q.a((long)((k)g3.K(x02)).d(), (float)0.12f, (float)0.0f, (float)0.0f, (float)0.0f, (int)14), (long)((k)g3.K(x02)).h());
        } else {
            l8 = l5;
        }
        if ((n3 & 8) != 0) {
            x0<k> x03 = l.a;
            long l11 = ((k)g3.K(x03)).d();
            g3.d(-651892877);
            g3.d(-1499253717);
            long l12 = ((t0.q)g3.K(q.a)).a;
            if (((k)g3.K(x03)).i()) {
                n.u((long)l12);
            } else {
                n.u((long)l12);
            }
            g3.I();
            g3.I();
            l7 = t0.q.a((long)l11, (float)0.38f, (float)0.0f, (float)0.0f, (float)0.0f, (int)14);
        } else {
            l7 = l6;
        }
        r r3 = new r(l9, l10, l8, l7, null);
        g3.I();
        return r3;
    }

    public final e b(long l3, long l4, long l5, e0.g g3, int n2) {
        long l6;
        g3.d(1409303640);
        long l7 = (n2 & 1) != 0 ? t0.q.g : l3;
        long l8 = (n2 & 2) != 0 ? ((k)g3.K(l.a)).e() : l4;
        if ((n2 & 4) != 0) {
            x0<k> x02 = l.a;
            long l9 = ((k)g3.K(x02)).d();
            g3.d(-651892877);
            g3.d(-1499253717);
            long l10 = ((t0.q)g3.K(q.a)).a;
            if (((k)g3.K(x02)).i()) {
                n.u((long)l10);
            } else {
                n.u((long)l10);
            }
            g3.I();
            g3.I();
            l6 = t0.q.a((long)l9, (float)0.38f, (float)0.0f, (float)0.0f, (float)0.0f, (int)14);
        } else {
            l6 = l5;
        }
        r r3 = new r(l7, l8, l7, l6, null);
        g3.I();
        return r3;
    }
}

