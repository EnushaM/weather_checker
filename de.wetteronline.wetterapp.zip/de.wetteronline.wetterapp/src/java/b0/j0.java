/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Boolean
 *  java.lang.Object
 *  rr.a
 *  sr.m
 */
package b0;

import gr.v;
import rr.a;
import sr.m;

public final class j0
extends m
implements a<Boolean> {
    public final /* synthetic */ a<v> c;

    public j0(a<v> a3) {
        this.c = a3;
        super(0);
    }

    public Object s() {
        this.c.s();
        return Boolean.TRUE;
    }
}

