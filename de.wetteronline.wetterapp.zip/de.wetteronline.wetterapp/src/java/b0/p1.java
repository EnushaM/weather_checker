/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 */
package b0;

import b0.a2;
import b0.n0;
import ma.e;

public final class p1 {
    public final n0 a;
    public final a2 b;

    public p1(n0 n02, a2 a22) {
        e.f((Object)n02, (String)"drawerState");
        e.f((Object)a22, (String)"snackbarHostState");
        this.a = n02;
        this.b = a22;
    }
}

