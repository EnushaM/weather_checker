/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  x1.b
 */
package b0;

import x1.b;

public interface v2 {
    public float a(b var1, float var2, float var3);
}

