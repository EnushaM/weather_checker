/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  l0.i
 *  ma.e
 *  rr.p
 *  sr.m
 */
package b0;

import b0.n0;
import b0.o0;
import b0.r2;
import l0.i;
import ma.e;
import rr.p;
import sr.m;

public final class l0
extends m
implements p<i, n0, o0> {
    public static final l0 c = new l0();

    public l0() {
        super(2);
    }

    public Object t0(Object object, Object object2) {
        i i3 = (i)object;
        n0 n02 = (n0)object2;
        e.f((Object)i3, (String)"$this$Saver");
        e.f((Object)n02, (String)"it");
        return n02.a.d();
    }
}

