/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.ui.platform.f0
 *  androidx.compose.ui.platform.r0
 *  b0.e1$a
 *  b0.e1$b
 *  e.n
 *  e0.g
 *  e0.g$a
 *  e0.l1
 *  e0.v
 *  e0.w1
 *  e0.x0
 *  j1.o
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  o0.f
 *  o0.g
 *  o0.g$a
 *  rr.l
 *  rr.p
 *  rr.q
 *  t.b0
 *  t.c0
 *  t.d0
 *  t.f0
 *  t.f0$a
 *  t.f0$b
 *  t.o
 *  t.r0
 *  t.s
 *  t.t
 *  t.t0
 *  t.u
 *  t.u$a
 *  t0.g
 *  u.b
 *  u.e0
 *  u.u
 *  v0.k
 *  w.h
 *  x.h0
 *  x1.b
 */
package b0;

import androidx.compose.ui.platform.f0;
import b0.d1;
import b0.e1;
import b0.k;
import b0.l;
import e.n;
import e0.g;
import e0.l1;
import e0.v;
import e0.w1;
import e0.x0;
import ma.e;
import o0.f;
import o0.g;
import rr.p;
import rr.q;
import t.b0;
import t.c0;
import t.d0;
import t.f0;
import t.o;
import t.r0;
import t.s;
import t.t;
import t.t0;
import t.u;
import u.e0;
import u.u;
import w.h;
import x.h0;

public final class e1 {
    public static final float a = 40;
    public static final o b = new o(0.4f, 0.0f, 0.2f, 1.0f);

    public static final void a(g g3, long l3, float f2, e0.g g4, int n2, int n3) {
        g g5;
        int n4;
        long l4;
        long l5;
        float f3;
        int n5;
        g g6;
        e0.g g7;
        float f4;
        block19 : {
            block15 : {
                int n6;
                block18 : {
                    block17 : {
                        block16 : {
                            block14 : {
                                block10 : {
                                    int n7;
                                    block13 : {
                                        block12 : {
                                            block11 : {
                                                g7 = g4.o(1769711483);
                                                n5 = n3 & 1;
                                                if (n5 != 0) {
                                                    n4 = n2 | 6;
                                                    g5 = g3;
                                                } else if ((n2 & 14) == 0) {
                                                    g5 = g3;
                                                    int n8 = g7.M((Object)g5) ? 4 : 2;
                                                    n4 = n8 | n2;
                                                } else {
                                                    g5 = g3;
                                                    n4 = n2;
                                                }
                                                if ((n2 & 112) != 0) break block10;
                                                if ((n3 & 2) != 0) break block11;
                                                l4 = l3;
                                                if (!g7.i(l4)) break block12;
                                                n7 = 32;
                                                break block13;
                                            }
                                            l4 = l3;
                                        }
                                        n7 = 16;
                                    }
                                    n4 |= n7;
                                    break block14;
                                }
                                l4 = l3;
                            }
                            if ((n2 & 896) != 0) break block15;
                            if ((n3 & 4) != 0) break block16;
                            f3 = f2;
                            if (!g7.f(f3)) break block17;
                            n6 = 256;
                            break block18;
                        }
                        f3 = f2;
                    }
                    n6 = 128;
                }
                n4 |= n6;
                break block19;
            }
            f3 = f2;
        }
        if ((146 ^ n4 & 731) == 0 && g7.r()) {
            g7.x();
            g6 = g5;
            l5 = l4;
            f4 = f3;
        } else {
            float f5;
            Object object;
            long l6;
            if ((n2 & 1) != 0 && !g7.B()) {
                g7.m();
                object = g5;
                l6 = l4;
                f5 = f3;
            } else {
                g7.n();
                object = n5 != 0 ? g.a.b : g5;
                l6 = (n3 & 2) != 0 ? ((k)g7.K(l.a)).e() : l4;
                float f6 = (n3 & 4) != 0 ? d1.b : f3;
                g7.L();
                f5 = f6;
            }
            x1.b b3 = (x1.b)g7.K((v)f0.e);
            v0.k k2 = new v0.k(b3.J(f5), 0.0f, 2, 0, null, 26);
            g7.d(353815743);
            g7.d(-3687241);
            Object object2 = g7.e();
            if (object2 == g.a.b) {
                object2 = new c0();
                g7.E(object2);
            }
            g7.I();
            c0 c02 = (c0)object2;
            c02.a(g7, 8);
            g7.I();
            Integer n9 = 0;
            Integer n10 = 5;
            r0 r02 = t0.b;
            u.a a3 = u.a.a;
            w1 w12 = d0.b((c0)c02, (Object)n9, (Object)n10, (r0)r02, (b0)n.s((s)n.D((int)6660, (int)0, (t)a3, (int)2), null, (int)2), (e0.g)g7);
            w1 w13 = d0.a((c0)c02, (float)0.0f, (float)286.0f, (b0)n.s((s)n.D((int)1332, (int)0, (t)a3, (int)2), null, (int)2), (e0.g)g7, (int)4536);
            f0.b b4 = new f0.b();
            b4.a = 1332;
            f0.a a4 = b4.a((Object)Float.valueOf((float)0.0f), 0);
            o o2 = b;
            e.f((Object)o2, (String)"easing");
            a4.b = o2;
            b4.a((Object)Float.valueOf((float)290.0f), 666);
            w1 w14 = d0.a((c0)c02, (float)0.0f, (float)290.0f, (b0)n.s((s)new t.f0(b4), null, (int)2), (e0.g)g7, (int)4536);
            f0.b b5 = new f0.b();
            b5.a = 1332;
            f0.a a5 = b5.a((Object)Float.valueOf((float)0.0f), 666);
            e.f((Object)o2, (String)"easing");
            a5.b = o2;
            b5.a((Object)Float.valueOf((float)290.0f), b5.a);
            w1 w15 = d0.a((c0)c02, (float)0.0f, (float)290.0f, (b0)n.s((s)new t.f0(b5), null, (int)2), (e0.g)g7, (int)4536);
            e.f((Object)object, (String)"<this>");
            g g8 = h0.i((g)j1.o.b((g)object, (boolean)false, (rr.l)e0.c, (int)1), (float)a);
            e.f((Object)g8, (String)"<this>");
            g g9 = f.a((g)g8, (rr.l)androidx.compose.ui.platform.r0.c, (q)new u(null, true));
            float f7 = f5;
            long l7 = l6;
            g.a a6 = object;
            a a7 = new a(f7, l7, k2, w12, w14, w15, w13);
            u.b.a((g)g9, (rr.l)a7, (e0.g)g7, (int)0);
            l5 = l6;
            f4 = f5;
            g6 = a6;
        }
        l1 l12 = g7.u();
        if (l12 == null) {
            return;
        }
        b b6 = new b(g6, l5, f4, n2, n3);
        l12.a((p)b6);
    }
}

