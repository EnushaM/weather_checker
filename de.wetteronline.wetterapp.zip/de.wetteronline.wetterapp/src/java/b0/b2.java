/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  rr.p
 *  sr.m
 */
package b0;

import b0.g2;
import e0.g;
import gr.v;
import rr.p;
import sr.m;

public final class b2
extends m
implements p<g, Integer, v> {
    public final /* synthetic */ p<g, Integer, v> c;
    public final /* synthetic */ p<g, Integer, v> d;
    public final /* synthetic */ int e;

    public b2(p<? super g, ? super Integer, v> p4, p<? super g, ? super Integer, v> p5, int n3) {
        this.c = p4;
        this.d = p5;
        this.e = n3;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        ((Number)object2).intValue();
        g2.c(this.c, this.d, g3, 1 | this.e);
        return v.a;
    }
}

