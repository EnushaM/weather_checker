/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  rr.p
 *  sr.m
 */
package b0;

import b0.g2;
import e0.g;
import gr.v;
import rr.p;
import sr.m;

public final class e2
extends m
implements p<g, Integer, v> {
    public final /* synthetic */ p<g, Integer, v> c;
    public final /* synthetic */ p<g, Integer, v> d;
    public final /* synthetic */ int e;
    public final /* synthetic */ boolean f;

    public e2(p<? super g, ? super Integer, v> p4, p<? super g, ? super Integer, v> p5, int n3, boolean bl) {
        this.c = p4;
        this.d = p5;
        this.e = n3;
        this.f = bl;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        int n3 = ((Number)object2).intValue();
        if ((2 ^ n3 & 11) == 0 && g3.r()) {
            g3.x();
        } else if (this.c == null) {
            g3.d(59708346);
            g2.e(this.d, g3, 14 & this.e >> 21);
            g3.I();
        } else if (this.f) {
            g3.d(59708411);
            p<g, Integer, v> p4 = this.d;
            p<g, Integer, v> p5 = this.c;
            int n4 = this.e;
            g2.c(p4, p5, g3, 14 & n4 >> 21 | n4 & 112);
            g3.I();
        } else {
            g3.d(59708478);
            p<g, Integer, v> p6 = this.d;
            p<g, Integer, v> p7 = this.c;
            int n6 = this.e;
            g2.d(p6, p7, g3, 14 & n6 >> 21 | n6 & 112);
            g3.I();
        }
        return v.a;
    }
}

