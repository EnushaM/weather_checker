/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  rr.p
 *  rr.q
 *  sr.m
 *  x.w
 */
package b0;

import e.d;
import e0.g;
import e1.j0;
import gr.v;
import rr.p;
import rr.q;
import sr.m;
import x.w;

public final class j1
extends m
implements p<g, Integer, v> {
    public final /* synthetic */ j0 c;
    public final /* synthetic */ int d;
    public final /* synthetic */ q<w, g, Integer, v> e;
    public final /* synthetic */ int f;

    public j1(j0 j02, int n3, q<? super w, ? super g, ? super Integer, v> q2, int n4) {
        this.c = j02;
        this.d = n3;
        this.e = q2;
        this.f = n4;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        int n3 = ((Number)object2).intValue();
        if ((2 ^ n3 & 11) == 0 && g3.r()) {
            g3.x();
        } else {
            w w3 = d.b(0.0f, 0.0f, 0.0f, this.c.D(this.d), 7);
            this.e.r((Object)w3, (Object)g3, (Object)(112 & this.f >> 6));
        }
        return v.a;
    }
}

