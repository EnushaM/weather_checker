/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.c
 *  gr.v
 *  j1.a
 *  j1.j
 *  j1.u
 *  j1.w
 *  j1.x
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.a
 *  rr.l
 *  sr.m
 */
package b0;

import b0.j0;
import gr.c;
import gr.v;
import j1.j;
import j1.u;
import j1.w;
import j1.x;
import ma.e;
import rr.a;
import rr.l;
import sr.m;

public final class k0
extends m
implements l<x, v> {
    public final /* synthetic */ String c;
    public final /* synthetic */ a<v> d;

    public k0(String string, a<v> a3) {
        this.c = string;
        this.d = a3;
        super(1);
    }

    public Object y(Object object) {
        x x3 = (x)object;
        e.f((Object)x3, (String)"$this$semantics");
        u.c((x)x3, (String)this.c);
        j0 j02 = new j0(this.d);
        e.f((Object)x3, (String)"<this>");
        x3.a(j.c, (Object)new j1.a(null, (c)j02));
        return v.a;
    }
}

