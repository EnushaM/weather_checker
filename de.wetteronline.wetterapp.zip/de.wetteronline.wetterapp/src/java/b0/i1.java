/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  rr.p
 *  rr.q
 *  sr.m
 *  x.w
 */
package b0;

import b0.a2;
import b0.g1;
import b0.h1;
import b0.p1;
import e.n;
import e0.g;
import gr.v;
import k0.a;
import rr.p;
import rr.q;
import sr.m;
import x.w;

public final class i1
extends m
implements p<g, Integer, v> {
    public final /* synthetic */ boolean c;
    public final /* synthetic */ int d;
    public final /* synthetic */ p<g, Integer, v> e;
    public final /* synthetic */ q<w, g, Integer, v> f;
    public final /* synthetic */ p<g, Integer, v> g;
    public final /* synthetic */ p<g, Integer, v> h;
    public final /* synthetic */ int i;
    public final /* synthetic */ int j;
    public final /* synthetic */ q<a2, g, Integer, v> k;
    public final /* synthetic */ p1 l;

    public i1(boolean bl, int n3, p<? super g, ? super Integer, v> p4, q<? super w, ? super g, ? super Integer, v> q2, p<? super g, ? super Integer, v> p5, p<? super g, ? super Integer, v> p6, int n4, int n6, q<? super a2, ? super g, ? super Integer, v> q3, p1 p12) {
        this.c = bl;
        this.d = n3;
        this.e = p4;
        this.f = q2;
        this.g = p5;
        this.h = p6;
        this.i = n4;
        this.j = n6;
        this.k = q3;
        this.l = p12;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        int n3 = ((Number)object2).intValue();
        if ((2 ^ n3 & 11) == 0 && g3.r()) {
            g3.x();
        } else {
            boolean bl = this.c;
            int n4 = this.d;
            p<g, Integer, v> p4 = this.e;
            q<w, g, Integer, v> q2 = this.f;
            a a3 = n.h(g3, -819902883, true, (Object)new h1(this.k, this.l, this.i));
            p<g, Integer, v> p5 = this.g;
            p<g, Integer, v> p6 = this.h;
            int n6 = this.i;
            g1.b(bl, n4, p4, q2, a3, p5, p6, g3, 24576 | 14 & n6 >> 21 | 112 & n6 >> 15 | n6 & 896 | 7168 & this.j >> 12 | 458752 & n6 | 3670016 & n6 << 9);
        }
        return v.a;
    }
}

