/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.ui.platform.f0
 *  androidx.compose.ui.platform.h
 *  b0.x1$a
 *  b0.x1$b
 *  b0.x1$c
 *  b0.x1$d
 *  b0.x1$e
 *  e.h
 *  e.n
 *  e0.b2
 *  e0.d
 *  e0.f0
 *  e0.g
 *  e0.g$a
 *  e0.l1
 *  e0.n1
 *  e0.r0
 *  e0.v
 *  e0.x0
 *  e0.z0
 *  e1.k
 *  e1.n
 *  f1.a
 *  f1.a$a
 *  gr.v
 *  hr.n
 *  hr.s
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Objects
 *  jr.d
 *  k0.b
 *  ma.e
 *  o0.a
 *  o0.a$a
 *  o0.g
 *  o0.g$a
 *  rr.a
 *  rr.p
 *  rr.q
 *  x.f
 *  x1.b
 *  x1.h
 */
package b0;

import androidx.compose.ui.platform.f0;
import b0.a2;
import b0.o;
import b0.s1;
import b0.u0;
import b0.v0;
import b0.x1;
import e0.b2;
import e0.g;
import e0.l1;
import e0.n1;
import e0.r0;
import e0.x0;
import e0.z0;
import e1.k;
import f1.a;
import gr.v;
import hr.n;
import hr.s;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import o0.a;
import o0.g;
import rr.p;
import rr.q;
import x.f;
import x1.h;

public final class x1 {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void a(s1 var0, g var1_1, q<? super s1, ? super e0.g, ? super Integer, v> var2_2, e0.g var3_3, int var4_4, int var5_5) {
        block28 : {
            var6_6 = var3_3.o(-1656515806);
            if ((var5_5 & 1) != 0) {
                var8_7 = var4_4 | 6;
            } else if ((var4_4 & 14) == 0) {
                var58_8 = var6_6.M((Object)var0) != false ? 4 : 2;
                var8_7 = var58_8 | var4_4;
            } else {
                var8_7 = var4_4;
            }
            var9_9 = var5_5 & 2;
            if (var9_9 == 0) break block28;
            var8_7 |= 48;
            ** GOTO lbl-1000
        }
        if ((var4_4 & 112) == 0) {
            var10_10 = var1_1;
            var57_11 = var6_6.M((Object)var10_10) != false ? 32 : 16;
            var8_7 |= var57_11;
        } else lbl-1000: // 2 sources:
        {
            var10_10 = var1_1;
        }
        if ((var5_5 & 4) != 0) {
            var8_7 |= 384;
        } else if ((var4_4 & 896) == 0) {
            var56_12 = var6_6.M(var2_2) != false ? 256 : 128;
            var8_7 |= var56_12;
        }
        if ((146 ^ var8_7 & 731) == 0 && var6_6.r()) {
            var6_6.x();
            var34_13 = var10_10;
        } else {
            if (var9_9 != 0) {
                var11_14 = g.a.b;
            } else {
                var11_15 = var10_10;
            }
            var6_6.d(-3687241);
            var12_17 = var6_6.e();
            if (var12_17 == g.a.b) {
                var12_17 = new v0();
                var6_6.E(var12_17);
            }
            var6_6.I();
            var13_18 = (v0)var12_17;
            if (!ma.e.a((Object)var0, (Object)var13_18.a)) {
                var13_18.a = var0;
                var44_19 = var13_18.b;
                var45_20 = new ArrayList(n.L(var44_19, (int)10));
                var46_21 = var44_19.iterator();
                while (var46_21.hasNext()) {
                    var45_20.add((Object)((s1)((u0)var46_21.next()).a));
                }
                var47_22 = s.t0((Collection)var45_20);
                var48_23 = (ArrayList)var47_22;
                if (!var48_23.contains((Object)var0)) {
                    var48_23.add((Object)var0);
                }
                var13_18.b.clear();
                var49_24 = s.U((Iterable)var47_22);
                var50_25 = var13_18.b;
                for (s1 var52_27 : (ArrayList)var49_24) {
                    var50_25.add(new u0<s1>(var52_27, (q<? super p<? super e0.g, ? super Integer, v>, ? super e0.g, ? super Integer, v>)e.n.i((int)-985541570, (boolean)true, (Object)new a(var52_27, var0, var47_22, var13_18))));
                }
            }
            var14_28 = 14 & var8_7 >> 3;
            var6_6.d(-1990474327);
            var16_29 = a.a.b;
            var17_30 = var14_28 >> 3;
            var18_31 = f.d((o0.a)var16_29, (boolean)false, (e0.g)var6_6, (int)(var17_30 & 14 | var17_30 & 112));
            var19_32 = 112 & var14_28 << 3;
            var6_6.d(1376089335);
            var20_33 = (x1.b)var6_6.K((e0.v)f0.e);
            var21_34 = (h)var6_6.K((e0.v)f0.i);
            Objects.requireNonNull((Object)f1.a.R);
            var23_35 = a.a.b;
            var24_36 = k.a((g)var11_16);
            var25_37 = 7168 & var19_32 << 9;
            if (!(var6_6.t() instanceof e0.d)) {
                e.h.p();
                throw null;
            }
            var6_6.q();
            if (var6_6.l()) {
                var6_6.v(var23_35);
            } else {
                var6_6.C();
            }
            var6_6.s();
            b2.a((e0.g)var6_6, (Object)var18_31, (p)a.a.e);
            b2.a((e0.g)var6_6, (Object)var20_33, (p)a.a.d);
            b2.a((e0.g)var6_6, (Object)var21_34, (p)a.a.f);
            var6_6.g();
            var26_38 = new n1(var6_6);
            var27_39 = 112 & var25_37 >> 3;
            ((k0.b)var24_36).r((Object)var26_38, (Object)var6_6, (Object)var27_39);
            var6_6.d(2058660585);
            var29_40 = 14 & var25_37 >> 9;
            var6_6.d(-1253629305);
            if ((2 ^ var29_40 & 11) == 0 && var6_6.r()) {
                var6_6.x();
            } else {
                var30_41 = 6 | 112 & var14_28 >> 6;
                var6_6.d(-1050268607);
                if ((16 ^ var30_41 & 81) == 0 && var6_6.r()) {
                    var6_6.x();
                } else {
                    var31_42 = var6_6.b();
                    if (var31_42 == null) throw new IllegalStateException("no recompose scope found".toString());
                    var6_6.N(var31_42);
                    var13_18.c = var31_42;
                    var32_43 = var13_18.b;
                    var33_44 = -1 + var32_43.size();
                    if (var33_44 >= 0) {
                        var37_45 = 0;
                        do {
                            var38_46 = var37_45 + 1;
                            var39_47 = (u0)var32_43.get(var37_45);
                            var40_48 = (s1)var39_47.a;
                            var41_49 = var39_47.b;
                            var6_6.p(-208579897, (Object)var40_48);
                            var41_49.r((Object)e.n.h((e0.g)var6_6, (int)-819901460, (boolean)true, (Object)new b(var2_2, var40_48, var8_7)), (Object)var6_6, (Object)6);
                            var6_6.H();
                            if (var38_46 > var33_44) break;
                            var37_45 = var38_46;
                        } while (true);
                    }
                }
                var6_6.I();
            }
            var6_6.I();
            var6_6.I();
            var6_6.J();
            var6_6.I();
            var6_6.I();
            var34_13 = var11_16;
        }
        var35_50 = var6_6.u();
        if (var35_50 == null) {
            return;
        }
        var36_51 = new c(var0, var34_13, var2_2, var4_4, var5_5);
        var35_50.a((p)var36_51);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void b(a2 var0, g var1_1, q<? super s1, ? super e0.g, ? super Integer, v> var2_2, e0.g var3_3, int var4_4, int var5_5) {
        block21 : {
            block17 : {
                block20 : {
                    block19 : {
                        block18 : {
                            block16 : {
                                ma.e.f((Object)var0, (String)"hostState");
                                var6_6 = var3_3.o(1627730774);
                                if ((var5_5 & 1) != 0) {
                                    var8_7 = var4_4 | 6;
                                } else if ((var4_4 & 14) == 0) {
                                    var28_8 = var6_6.M((Object)var0) != false ? 4 : 2;
                                    var8_7 = var28_8 | var4_4;
                                } else {
                                    var8_7 = var4_4;
                                }
                                var9_9 = var5_5 & 2;
                                if (var9_9 == 0) break block16;
                                var8_7 |= 48;
                                ** GOTO lbl-1000
                            }
                            if ((var4_4 & 112) == 0) {
                                var10_10 = var1_1;
                                var27_11 = var6_6.M((Object)var1_1) != false ? 32 : 16;
                                var8_7 |= var27_11;
                            } else lbl-1000: // 2 sources:
                            {
                                var10_10 = var1_1;
                            }
                            if ((var4_4 & 896) != 0) break block17;
                            if ((var5_5 & 4) != 0) break block18;
                            var11_12 = var2_2;
                            if (!var6_6.M(var2_2)) break block19;
                            var26_13 = 256;
                            break block20;
                        }
                        var11_12 = var2_2;
                    }
                    var26_13 = 128;
                }
                var8_7 |= var26_13;
                break block21;
            }
            var11_12 = var2_2;
        }
        if ((146 ^ var8_7 & 731) == 0 && var6_6.r()) {
            var6_6.x();
            var22_14 = var10_10;
            var21_15 = var11_12;
        } else {
            if ((var4_4 & 1) != 0 && !var6_6.B()) {
                var6_6.m();
                if ((var5_5 & 4) != 0) {
                    var8_7 &= -897;
                }
                var12_16 = var10_10;
                var15_21 = var8_7;
                var16_22 = var11_12;
            } else {
                var6_6.n();
                if (var9_9 != 0) {
                    var12_17 = g.a.b;
                } else {
                    var12_18 = var10_10;
                }
                if ((var5_5 & 4) != 0) {
                    var13_23 = o.b;
                    var8_7 &= -897;
                } else {
                    var13_23 = var11_12;
                }
                var6_6.L();
                var14_24 = var13_23;
                var15_21 = var8_7;
                var16_22 = var14_24;
            }
            var17_25 = (s1)var0.b.getValue();
            e0.f0.c((Object)var17_25, (p)new d(var17_25, (androidx.compose.ui.platform.h)var6_6.K((e0.v)f0.a), null), (e0.g)var6_6);
            var18_26 = (s1)var0.b.getValue();
            var19_27 = var15_21 & 112 | var15_21 & 896;
            x1.a(var18_26, (g)var12_20, var16_22, var6_6, var19_27, 0);
            var20_28 = var12_20;
            var21_15 = var16_22;
            var22_14 = var20_28;
        }
        var23_29 = var6_6.u();
        if (var23_29 == null) {
            return;
        }
        var24_30 = new e(var0, var22_14, var21_15, var4_4, var5_5);
        var23_29.a((p)var24_30);
    }
}

