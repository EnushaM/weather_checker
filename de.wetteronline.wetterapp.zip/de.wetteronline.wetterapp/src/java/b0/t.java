/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.x0
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  t0.q
 */
package b0;

import b0.k;
import b0.l;
import b0.q0;
import e.n;
import e0.g;
import e0.v;
import e0.x0;
import t0.q;

public final class t
implements q0 {
    public static final t a = new t();

    @Override
    public long a(long l2, float f2, g g3, int n2) {
        k k2 = g3.K(l.a);
        if (Float.compare((float)f2, (float)((float)false)) > 0 && !k2.i()) {
            g3.d(-1272525241);
            float f3 = (2.0f + 4.5f * (float)Math.log((double)(f2 + (float)true))) / 100.0f;
            long l3 = n.j(q.a((long)l.a(l2, g3), (float)f3, (float)0.0f, (float)0.0f, (float)0.0f, (int)14), l2);
            g3.I();
            return l3;
        }
        g3.d(-1272525098);
        g3.I();
        return l2;
    }
}

