/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  rr.a
 *  sr.m
 */
package b0;

import b0.s1;
import rr.a;
import sr.m;

public final class u1
extends m
implements a<Boolean> {
    public final /* synthetic */ s1 c;

    public u1(s1 s12) {
        this.c = s12;
        super(0);
    }

    public Object s() {
        this.c.dismiss();
        return Boolean.TRUE;
    }
}

