/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.q$a
 *  e0.w
 *  e0.x0
 *  java.lang.Object
 *  rr.a
 *  t0.q
 */
package b0;

import b0.q;
import e0.w;
import e0.x0;

public final class q {
    public static final x0<t0.q> a = w.c(null, (rr.a)a.c, (int)1);
}

