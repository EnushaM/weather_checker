/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.l
 *  sr.m
 */
package b0;

import b0.n0;
import b0.o0;
import ma.e;
import rr.l;
import sr.m;

public final class m0
extends m
implements l<o0, n0> {
    public final /* synthetic */ l<o0, Boolean> c;

    public m0(l<? super o0, Boolean> l2) {
        this.c = l2;
        super(1);
    }

    public Object y(Object object) {
        o0 o02 = (o0)((Object)object);
        e.f((Object)((Object)o02), (String)"it");
        return new n0(o02, this.c);
    }
}

