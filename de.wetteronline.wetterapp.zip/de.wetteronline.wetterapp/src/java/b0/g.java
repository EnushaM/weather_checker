/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.g
 *  e0.w1
 *  java.lang.Object
 *  w.g
 *  x1.d
 */
package b0;

import e0.w1;
import x1.d;

public interface g {
    public w1<d> a(boolean var1, w.g var2, e0.g var3, int var4);
}

