/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.ui.platform.f0
 *  e0.x0
 *  f1.a
 *  f1.a$a
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  k0.b
 *  ma.e
 *  o0.a
 *  o0.a$a
 *  o0.g
 *  rr.a
 *  rr.p
 *  rr.q
 *  sr.m
 *  x.f
 *  x.h0
 *  x1.b
 *  x1.h
 */
package b0;

import androidx.compose.ui.platform.f0;
import b0.x0;
import e0.b2;
import e0.d;
import e0.n1;
import e1.k;
import e1.n;
import f1.a;
import gr.v;
import java.util.Objects;
import k0.b;
import ma.e;
import o0.a;
import o0.g;
import rr.p;
import rr.q;
import sr.m;
import x.f;
import x.h0;
import x1.h;

public final class y0
extends m
implements p<e0.g, Integer, v> {
    public final /* synthetic */ p<e0.g, Integer, v> c;
    public final /* synthetic */ int d;

    public y0(p<? super e0.g, ? super Integer, v> p4, int n3) {
        this.c = p4;
        this.d = n3;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        block7 : {
            block6 : {
                e0.g g3;
                block5 : {
                    g3 = (e0.g)object;
                    int n3 = ((Number)object2).intValue();
                    if ((2 ^ n3 & 11) != 0 || !g3.r()) break block5;
                    g3.x();
                    break block6;
                }
                g.a a3 = g.a.b;
                float f3 = x0.a;
                g g5 = h0.d((g)a3, (float)f3, (float)f3);
                a a4 = a.a.c;
                p<e0.g, Integer, v> p4 = this.c;
                int n4 = this.d;
                g3.d(-1990474327);
                n n6 = f.d((a)a4, (boolean)false, (e0.g)g3, (int)0);
                g3.d(1376089335);
                x1.b b3 = (x1.b)g3.K(f0.e);
                h h3 = (h)g3.K(f0.i);
                Objects.requireNonNull((Object)f1.a.R);
                rr.a a6 = a.a.b;
                q<n1<f1.a>, e0.g, Integer, v> q3 = k.a(g5);
                if (!(g3.t() instanceof d)) break block7;
                g3.q();
                if (g3.l()) {
                    g3.v(a6);
                } else {
                    g3.C();
                }
                g3.s();
                e.f((Object)g3, (String)"composer");
                b2.a(g3, n6, a.a.e);
                b2.a(g3, b3, a.a.d);
                b2.a(g3, h3, a.a.f);
                g3.g();
                e.f((Object)g3, (String)"composer");
                n1 n12 = new n1(g3);
                Integer n7 = 0;
                ((b)q3).r(n12, (Object)g3, (Object)n7);
                g3.d(2058660585);
                g3.d(-1253629305);
                g3.d(638020661);
                p4.t0((Object)g3, (Object)(14 & n4 >> 21));
                g3.I();
                g3.I();
                g3.I();
                g3.J();
                g3.I();
                g3.I();
            }
            return v.a;
        }
        e.h.p();
        throw null;
    }
}

