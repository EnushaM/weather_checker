/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.ui.platform.f0
 *  e0.x0
 *  f1.a
 *  f1.a$a
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  k0.b
 *  ma.e
 *  o0.a
 *  o0.a$a
 *  o0.a$b
 *  o0.g
 *  rr.a
 *  rr.p
 *  rr.q
 *  sr.m
 *  x.d
 *  x.d$j
 *  x.h0
 *  x.l
 *  x.m
 *  x1.b
 *  x1.h
 */
package b0;

import androidx.compose.ui.platform.f0;
import e0.b2;
import e0.n1;
import e0.x0;
import e1.k;
import e1.n;
import f1.a;
import gr.v;
import java.util.Objects;
import k0.b;
import ma.e;
import o0.a;
import o0.g;
import rr.p;
import rr.q;
import sr.m;
import x.d;
import x.h0;
import x.l;
import x1.h;

public final class e0
extends m
implements p<e0.g, Integer, v> {
    public final /* synthetic */ q<Object, e0.g, Integer, v> c;
    public final /* synthetic */ int d;

    public e0(q<Object, ? super e0.g, ? super Integer, v> q2, int n3) {
        this.c = q2;
        this.d = n3;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        block9 : {
            block8 : {
                e0.g g3;
                block7 : {
                    g3 = (e0.g)object;
                    int n3 = ((Number)object2).intValue();
                    if ((2 ^ n3 & 11) != 0 || !g3.r()) break block7;
                    g3.x();
                    break block8;
                }
                g g5 = h0.f((g)g.a.b, (float)0.0f, (int)1);
                q<Object, e0.g, Integer, v> q2 = this.c;
                int n4 = 6 | 7168 & this.d << 9;
                g3.d(-1113031299);
                d.j j3 = d.d;
                a.b b3 = a.a.f;
                int n6 = n4 >> 3;
                n n7 = l.a((d.j)j3, (a.b)b3, (e0.g)g3, (int)(n6 & 14 | n6 & 112));
                int n8 = 112 & n4 << 3;
                g3.d(1376089335);
                x1.b b5 = (x1.b)g3.K(f0.e);
                h h3 = (h)g3.K(f0.i);
                Objects.requireNonNull((Object)f1.a.R);
                rr.a a3 = a.a.b;
                q<n1<f1.a>, e0.g, Integer, v> q3 = k.a(g5);
                int n9 = 7168 & n8 << 9;
                if (!(g3.t() instanceof e0.d)) break block9;
                g3.q();
                if (g3.l()) {
                    g3.v(a3);
                } else {
                    g3.C();
                }
                g3.s();
                e.f((Object)g3, (String)"composer");
                b2.a(g3, n7, a.a.e);
                b2.a(g3, b5, a.a.d);
                b2.a(g3, h3, a.a.f);
                g3.g();
                e.f((Object)g3, (String)"composer");
                n1 n12 = new n1(g3);
                Integer n10 = 112 & n9 >> 3;
                ((b)q3).r(n12, (Object)g3, (Object)n10);
                g3.d(2058660585);
                int n11 = 14 & n9 >> 9;
                g3.d(276693241);
                if ((2 ^ n11 & 11) == 0 && g3.r()) {
                    g3.x();
                } else {
                    q2.r((Object)x.m.a, (Object)g3, (Object)(6 | 112 & n4 >> 6));
                }
                g3.I();
                g3.I();
                g3.J();
                g3.I();
                g3.I();
            }
            return v.a;
        }
        e.h.p();
        throw null;
    }
}

