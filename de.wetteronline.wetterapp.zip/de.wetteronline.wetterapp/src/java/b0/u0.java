/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  e0.g
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  ma.e
 *  rr.p
 *  rr.q
 */
package b0;

import android.support.v4.media.b;
import e0.g;
import gr.v;
import ma.e;
import rr.p;
import rr.q;

public final class u0<T> {
    public final T a;
    public final q<p<? super g, ? super Integer, v>, g, Integer, v> b;

    public u0(T t2, q<? super p<? super g, ? super Integer, v>, ? super g, ? super Integer, v> q3) {
        this.a = t2;
        this.b = q3;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof u0)) {
            return false;
        }
        u0 u02 = (u0)object;
        if (!e.a(this.a, u02.a)) {
            return false;
        }
        return e.a(this.b, u02.b);
    }

    public int hashCode() {
        T t2 = this.a;
        int n2 = t2 == null ? 0 : t2.hashCode();
        return n2 * 31 + this.b.hashCode();
    }

    public String toString() {
        StringBuilder stringBuilder = b.a((String)"FadeInFadeOutAnimationItem(key=");
        stringBuilder.append(this.a);
        stringBuilder.append(", transition=");
        stringBuilder.append(this.b);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}

