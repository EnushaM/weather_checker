/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Object
 *  java.lang.String
 *  jr.d
 *  kr.a
 *  ma.e
 *  t.b
 *  t.o
 *  t.q0
 *  t.t
 *  t.u
 *  w.b
 *  w.f
 *  w.k
 *  x1.d
 */
package b0;

import gr.v;
import jr.d;
import kr.a;
import ma.e;
import t.b;
import t.o;
import t.q0;
import t.t;
import t.u;
import w.f;
import w.k;

public final class p0 {
    public static final q0<x1.d> a = new q0(120, 0, u.a, 2);
    public static final q0<x1.d> b = new q0(150, 0, (t)new o(0.4f, 0.0f, 0.6f, 1.0f), 2);

    public static {
        o o2 = new o(0.4f, 0.0f, 0.6f, 1.0f);
        if ((2 & 4) != 0) {
            o2 = u.a;
        }
        e.f((Object)o2, (String)"easing");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final Object a(b<x1.d, ?> var0, float var1_1, f var2_2, f var3_3, d<? super v> var4_4) {
        block7 : {
            block5 : {
                block6 : {
                    var5_5 = a.b;
                    if (var3_3 == null) break block5;
                    if (!(var3_3 instanceof k)) break block6;
                    var6_6 = p0.a;
                    break block7;
                }
                if (!(var3_3 instanceof w.b)) ** GOTO lbl-1000
                var6_6 = p0.a;
                break block7;
            }
            if (var2_2 == null) ** GOTO lbl-1000
            if (var2_2 instanceof k) {
                var6_6 = p0.b;
            } else if (var2_2 instanceof w.b) {
                var6_6 = p0.b;
            } else lbl-1000: // 3 sources:
            {
                var6_6 = null;
            }
        }
        var7_7 = var6_6;
        if (var7_7 != null) {
            var9_8 = b.c(var0, (Object)new x1.d(var1_1), var7_7, null, null, var4_4, (int)12);
            if (var9_8 != var5_5) return v.a;
            return var9_8;
        }
        var8_9 = var0.f((Object)new x1.d(var1_1), var4_4);
        if (var8_9 != var5_5) return v.a;
        return var8_9;
    }
}

