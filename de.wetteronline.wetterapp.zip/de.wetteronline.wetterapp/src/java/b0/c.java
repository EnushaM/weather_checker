/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.x0
 *  gr.v
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  rr.p
 *  sr.m
 *  t0.q
 */
package b0;

import b0.k;
import b0.l;
import b0.p;
import b0.q;
import e.n;
import e0.g;
import e0.w;
import e0.x0;
import e0.y0;
import gr.v;
import sr.m;

public final class c
extends m
implements rr.p<g, Integer, v> {
    public final /* synthetic */ rr.p<g, Integer, v> c;
    public final /* synthetic */ int d;

    public c(rr.p<? super g, ? super Integer, v> p4, int n3) {
        this.c = p4;
        this.d = n3;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        int n3 = ((Number)object2).intValue();
        if ((2 ^ n3 & 11) == 0 && g3.r()) {
            g3.x();
        } else {
            y0[] arry0 = new y0[1];
            x0<Float> x02 = p.a;
            g3.d(-1305244065);
            float f3 = 1.0f;
            g3.d(-1499253717);
            long l2 = g3.K(q.a).a;
            if (!(g3.K(l.a).i() ? (double)n.u(l2) > 0.5 : (double)n.u(l2) < 0.5)) {
                f3 = 0.87f;
            }
            g3.I();
            g3.I();
            arry0[0] = x02.b((Object)Float.valueOf((float)f3));
            w.a((y0[])arry0, this.c, (g)g3, (int)(8 | 112 & this.d << 3));
        }
        return v.a;
    }
}

