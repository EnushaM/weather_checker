/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.p$a
 *  e0.w
 *  e0.x0
 *  java.lang.Float
 *  java.lang.Object
 *  rr.a
 */
package b0;

import b0.p;
import e0.w;
import e0.x0;

public final class p {
    public static final x0<Float> a = w.c(null, (rr.a)a.c, (int)1);
}

