/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.p
 *  rr.q
 *  sr.m
 *  x.w
 *  x1.a
 */
package b0;

import b0.l1;
import e0.g;
import e1.j0;
import e1.o;
import e1.p;
import gr.v;
import ma.e;
import rr.q;
import sr.m;
import x.w;
import x1.a;

public final class m1
extends m
implements rr.p<j0, a, o> {
    public final /* synthetic */ rr.p<g, Integer, v> c;
    public final /* synthetic */ rr.p<g, Integer, v> d;
    public final /* synthetic */ rr.p<g, Integer, v> e;
    public final /* synthetic */ int f;
    public final /* synthetic */ boolean g;
    public final /* synthetic */ rr.p<g, Integer, v> h;
    public final /* synthetic */ int i;
    public final /* synthetic */ q<w, g, Integer, v> j;

    public m1(rr.p<? super g, ? super Integer, v> p4, rr.p<? super g, ? super Integer, v> p5, rr.p<? super g, ? super Integer, v> p6, int n3, boolean bl, rr.p<? super g, ? super Integer, v> p7, int n4, q<? super w, ? super g, ? super Integer, v> q2) {
        this.c = p4;
        this.d = p5;
        this.e = p6;
        this.f = n3;
        this.g = bl;
        this.h = p7;
        this.i = n4;
        this.j = q2;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        j0 j02 = (j0)object;
        long l2 = ((a)object2).a;
        e.f((Object)j02, (String)"$this$SubcomposeLayout");
        int n3 = a.g((long)l2);
        int n4 = a.f((long)l2);
        long l3 = a.a((long)l2, (int)0, (int)0, (int)0, (int)0, (int)10);
        l1 l12 = new l1(j02, this.c, this.d, this.e, this.f, n3, this.g, n4, l3, this.h, this.i, this.j);
        return p.a.b(j02, n3, n4, null, l12, 4, null);
    }
}

