/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.f0$a
 *  b0.f0$b
 *  b0.f0$c
 *  b0.f0$d
 *  b0.g0
 *  b0.h0
 *  b0.i0
 *  b0.k0
 *  b0.l0
 *  b0.m0
 *  c1.u
 *  ds.g0
 *  e.b
 *  e.n
 *  e0.f0
 *  e0.g
 *  e0.g$a
 *  e0.l1
 *  e0.v
 *  e0.x
 *  e0.x0
 *  gr.v
 *  j1.o
 *  java.lang.Boolean
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  jr.d
 *  jr.f
 *  jr.h
 *  l0.c
 *  l0.g
 *  l0.h
 *  l0.h$c
 *  ma.e
 *  o0.g
 *  o0.g$a
 *  rr.a
 *  rr.l
 *  rr.p
 *  rr.q
 *  t.q0
 *  t.t
 *  t0.i0
 *  t0.q
 *  u.b
 *  x.h0
 *  x.i
 *  y.a
 */
package b0;

import b0.f0;
import b0.g0;
import b0.h0;
import b0.i0;
import b0.k;
import b0.k0;
import b0.l;
import b0.l0;
import b0.m0;
import b0.n0;
import b0.o0;
import b0.q1;
import b0.r1;
import b0.v;
import c1.u;
import e.n;
import e0.g;
import e0.l1;
import e0.x;
import e0.x0;
import j1.o;
import jr.f;
import jr.h;
import l0.h;
import ma.e;
import o0.g;
import rr.p;
import rr.q;
import t.q0;
import t.t;
import x.i;

public final class f0 {
    public static final float a = 56;
    public static final float b = 400;
    public static final q0<Float> c = new q0(256, 0, null, 6);

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void a(q<Object, ? super e0.g, ? super Integer, gr.v> var0, g var1_1, n0 var2_2, boolean var3_3, t0.i0 var4_4, float var5_5, long var6_6, long var8_7, long var10_8, p<? super e0.g, ? super Integer, gr.v> var12_9, e0.g var13_10, int var14_11, int var15_12) {
        block60 : {
            block59 : {
                block58 : {
                    block57 : {
                        block53 : {
                            block56 : {
                                block55 : {
                                    block54 : {
                                        block52 : {
                                            block48 : {
                                                block51 : {
                                                    block50 : {
                                                        block49 : {
                                                            block47 : {
                                                                block43 : {
                                                                    block46 : {
                                                                        block45 : {
                                                                            block44 : {
                                                                                block42 : {
                                                                                    e.f(var0, (String)"drawerContent");
                                                                                    e.f(var12_9, (String)"content");
                                                                                    var16_13 = var13_10.o(-73332094);
                                                                                    if ((var15_12 & 1) != 0) {
                                                                                        var18_14 = var14_11 | 6;
                                                                                    } else if ((var14_11 & 14) == 0) {
                                                                                        var89_15 = var16_13.M(var0) != false ? 4 : 2;
                                                                                        var18_14 = var89_15 | var14_11;
                                                                                    } else {
                                                                                        var18_14 = var14_11;
                                                                                    }
                                                                                    var19_16 = var15_12 & 2;
                                                                                    if (var19_16 != 0) {
                                                                                        var18_14 |= 48;
                                                                                    } else if ((var14_11 & 112) == 0) {
                                                                                        var88_17 = var16_13.M((Object)var1_1) != false ? 32 : 16;
                                                                                        var18_14 |= var88_17;
                                                                                    }
                                                                                    if ((var14_11 & 896) == 0) {
                                                                                        var87_18 = (var15_12 & 4) == 0 && var16_13.M((Object)var2_2) != false ? 256 : 128;
                                                                                        var18_14 |= var87_18;
                                                                                    }
                                                                                    if ((var21_19 = var15_12 & 8) == 0) break block42;
                                                                                    var18_14 |= 3072;
                                                                                    ** GOTO lbl-1000
                                                                                }
                                                                                if ((var14_11 & 7168) == 0) {
                                                                                    var22_20 = var3_3;
                                                                                    var86_21 = var16_13.c(var22_20) != false ? 2048 : 1024;
                                                                                    var18_14 |= var86_21;
                                                                                } else lbl-1000: // 2 sources:
                                                                                {
                                                                                    var22_20 = var3_3;
                                                                                }
                                                                                if ((57344 & var14_11) != 0) break block43;
                                                                                if ((var15_12 & 16) != 0) break block44;
                                                                                var23_22 = var4_4;
                                                                                if (!var16_13.M((Object)var23_22)) break block45;
                                                                                var85_23 = 16384;
                                                                                break block46;
                                                                            }
                                                                            var23_22 = var4_4;
                                                                        }
                                                                        var85_23 = 8192;
                                                                    }
                                                                    var18_14 |= var85_23;
                                                                    break block47;
                                                                }
                                                                var23_22 = var4_4;
                                                            }
                                                            if ((458752 & var14_11) != 0) break block48;
                                                            if ((var15_12 & 32) != 0) break block49;
                                                            var24_24 = var5_5;
                                                            if (!var16_13.f(var24_24)) break block50;
                                                            var84_25 = 131072;
                                                            break block51;
                                                        }
                                                        var24_24 = var5_5;
                                                    }
                                                    var84_25 = 65536;
                                                }
                                                var18_14 |= var84_25;
                                                break block52;
                                            }
                                            var24_24 = var5_5;
                                        }
                                        if ((3670016 & var14_11) != 0) break block53;
                                        if ((var15_12 & 64) != 0) break block54;
                                        var25_26 = var6_6;
                                        if (!var16_13.i(var25_26)) break block55;
                                        var83_27 = 1048576;
                                        break block56;
                                    }
                                    var25_26 = var6_6;
                                }
                                var83_27 = 524288;
                            }
                            var18_14 |= var83_27;
                            break block57;
                        }
                        var25_26 = var6_6;
                    }
                    if ((29360128 & var14_11) == 0) {
                        var82_28 = (var15_12 & 128) == 0 && var16_13.i(var8_7) != false ? 8388608 : 4194304;
                        var18_14 |= var82_28;
                    }
                    if ((234881024 & var14_11) == 0) {
                        var80_29 = var15_12 & 256;
                        var27_30 = var10_8;
                        var81_31 = var80_29 == 0 && var16_13.i(var27_30) != false ? 67108864 : 33554432;
                        var18_14 |= var81_31;
                    } else {
                        var27_30 = var10_8;
                    }
                    if ((var15_12 & 512) == 0) break block58;
                    var79_32 = 805306368;
                    break block59;
                }
                if ((1879048192 & var14_11) != 0) break block60;
                var79_32 = var16_13.M(var12_9) != false ? 536870912 : 268435456;
            }
            var18_14 |= var79_32;
        }
        if ((306783378 ^ 1533916891 & var18_14) == 0 && var16_13.r()) {
            var16_13.x();
            var68_33 = var22_20;
            var69_34 = var23_22;
            var70_35 = var24_24;
            var61_36 = var25_26;
            var65_37 = var16_13;
            var63_38 = var8_7;
            var71_39 = var27_30;
            var73_40 = var1_1;
            var67_41 = var2_2;
        } else {
            if ((var14_11 & 1) != 0 && !var16_13.B()) {
                var16_13.m();
                if ((var15_12 & 4) != 0) {
                    var18_14 &= -897;
                }
                if ((var15_12 & 16) != 0) {
                    var18_14 &= -57345;
                }
                if ((var15_12 & 32) != 0) {
                    var18_14 &= -458753;
                }
                if ((var15_12 & 64) != 0) {
                    var18_14 &= -3670017;
                }
                if ((var15_12 & 128) != 0) {
                    var18_14 &= -29360129;
                }
                if ((var15_12 & 256) != 0) {
                    var18_14 &= -234881025;
                }
                var40_42 = var2_2;
                var46_43 = var8_7;
                var48_44 = var27_30;
                var41_45 = var22_20;
                var42_46 = var23_22;
                var43_47 = var24_24;
                var44_48 = var25_26;
            } else {
                var16_13.n();
                if (var19_16 != 0) {
                    var29_51 = g.a.b;
                } else {
                    var29_52 = var1_1;
                }
                if ((var15_12 & 4) != 0) {
                    var78_54 = o0.b;
                    var1_1 = var29_53;
                    var30_55 = f0.c((o0)var78_54, null, (e0.g)var16_13, (int)2);
                    var18_14 &= -897;
                } else {
                    var1_1 = var29_53;
                    var30_55 = var2_2;
                }
                var31_56 = var21_19 != 0 ? true : var22_20;
                if ((var15_12 & 16) != 0) {
                    var32_57 = ((q1)var16_13.K(r1.a)).c;
                    var18_14 &= -57345;
                } else {
                    var32_57 = var23_22;
                }
                if ((var15_12 & 32) != 0) {
                    var33_58 = v.b;
                    var18_14 &= -458753;
                } else {
                    var33_58 = var24_24;
                }
                if ((var15_12 & 64) != 0) {
                    var34_59 = ((k)var16_13.K(l.a)).h();
                    var18_14 &= -3670017;
                } else {
                    var34_59 = var25_26;
                }
                if ((var15_12 & 128) != 0) {
                    var36_60 = l.a(var34_59, var16_13);
                    var18_14 &= -29360129;
                } else {
                    var36_60 = var8_7;
                }
                if ((var15_12 & 256) != 0) {
                    var38_61 = v.a(var16_13);
                    var18_14 &= -234881025;
                } else {
                    var38_61 = var10_8;
                }
                var16_13.L();
                var40_42 = var30_55;
                var41_45 = var31_56;
                var42_46 = var32_57;
                var43_47 = var33_58;
                var44_48 = var34_59;
                var46_43 = var36_60;
                var48_44 = var38_61;
            }
            var50_49 = var1_1;
            var51_50 = var18_14;
            var16_13.d(-723524056);
            var16_13.d(-3687241);
            var52_62 = var16_13.e();
            if (var52_62 == g.a.b) {
                var53_63 = new x(e0.f0.d((f)h.b, (e0.g)var16_13));
                var16_13.E((Object)var53_63);
                var52_62 = var53_63;
            }
            var16_13.I();
            var54_64 = ((x)var52_62).a;
            var16_13.I();
            var55_65 = x.h0.f((g)var50_49, (float)0.0f, (int)1);
            var56_66 = var40_42;
            var57_67 = var41_45;
            var58_68 = var48_44;
            var60_69 = var42_46;
            var61_36 = var44_48;
            var63_38 = var46_43;
            var65_37 = var16_13;
            var66_70 = new a(var56_66, var57_67, var51_50, var58_68, var60_69, var61_36, var63_38, var43_47, var12_9, var54_64, var0);
            i.a((g)var55_65, null, (boolean)false, (q)n.h((e0.g)var65_37, (int)-819899687, (boolean)true, (Object)var66_70), (e0.g)var65_37, (int)3072, (int)6);
            var67_41 = var40_42;
            var68_33 = var41_45;
            var69_34 = var42_46;
            var70_35 = var43_47;
            var71_39 = var48_44;
            var73_40 = var50_49;
        }
        var74_71 = var65_37.u();
        if (var74_71 == null) {
            return;
        }
        var75_72 = new b(var0, var73_40, var67_41, var68_33, var69_34, var70_35, var61_36, var63_38, var71_39, var12_9, var14_11, var15_12);
        var74_71.a((p)var75_72);
    }

    public static final void b(boolean bl, rr.a a3, rr.a a4, long l3, e0.g g3, int n2) {
        int n3;
        e0.g g4 = g3.o(1010553887);
        if ((n2 & 14) == 0) {
            int n4 = g4.c(bl) ? 4 : 2;
            n3 = n4 | n2;
        } else {
            n3 = n2;
        }
        if ((n2 & 112) == 0) {
            int n5 = g4.M((Object)a3) ? 32 : 16;
            n3 |= n5;
        }
        if ((n2 & 896) == 0) {
            int n6 = g4.M((Object)a4) ? 256 : 128;
            n3 |= n6;
        }
        if ((n2 & 7168) == 0) {
            int n7 = g4.i(l3) ? 2048 : 1024;
            n3 |= n7;
        }
        if ((1170 ^ n3 & 5851) == 0 && g4.r()) {
            g4.x();
        } else {
            g.a a5;
            String string = e.b.d((int)1, (e0.g)g4);
            if (bl) {
                g4.d(1010554077);
                g.a a6 = g.a.b;
                g4.d(-3686930);
                boolean bl2 = g4.M((Object)a3);
                Object object = g4.e();
                if (bl2 || object == g.a.b) {
                    object = new i0(a3, null);
                    g4.E(object);
                }
                g4.I();
                g g5 = u.a((g)a6, (Object)a3, (p)((p)object));
                g4.d(-3686552);
                boolean bl3 = g4.M((Object)string) | g4.M((Object)a3);
                Object object2 = g4.e();
                if (bl3 || object2 == g.a.b) {
                    object2 = new k0(string, a3);
                    g4.E(object2);
                }
                g4.I();
                a5 = o.a((g)g5, (boolean)true, (rr.l)((rr.l)object2));
                g4.I();
            } else {
                g4.d(1010554335);
                g4.I();
                a5 = g.a.b;
            }
            g g6 = x.h0.f((g)g.a.b, (float)0.0f, (int)1).r((g)a5);
            t0.q q3 = new t0.q(l3);
            g4.d(-3686552);
            boolean bl4 = g4.M((Object)q3) | g4.M((Object)a4);
            Object object = g4.e();
            if (bl4 || object == g.a.b) {
                object = new g0(l3, a4);
                g4.E(object);
            }
            g4.I();
            u.b.a((g)g6, (rr.l)((rr.l)object), (e0.g)g4, (int)0);
        }
        l1 l12 = g4.u();
        if (l12 == null) {
            return;
        }
        h0 h02 = new h0(bl, a3, a4, l3, n2);
        l12.a((p)h02);
    }

    public static final n0 c(o0 o02, rr.l<? super o0, Boolean> l3, e0.g g3, int n2, int n3) {
        g3.d(-1540949526);
        Object object = (n2 & 2) != 0 ? c.c : null;
        Object[] arrobject = new Object[]{};
        e.f((Object)object, (String)"confirmStateChange");
        l0 l02 = l0.c;
        m0 m02 = new m0((rr.l)object);
        n0 n02 = (n0)l0.c.a((Object[])arrobject, (l0.g)new h.c((p)l02, (rr.l)m02), null, (rr.a)new d(o02, (rr.l)object), (e0.g)g3, (int)4);
        g3.I();
        return n02;
    }
}

