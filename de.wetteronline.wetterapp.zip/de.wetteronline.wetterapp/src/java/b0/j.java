/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.j$a
 *  b0.j$b
 *  b0.j$c
 *  b0.s
 *  d0.o
 *  e.c
 *  e.n
 *  e0.g
 *  e0.g$a
 *  e0.l1
 *  e0.v
 *  e0.w1
 *  e0.x0
 *  gr.v
 *  j1.h
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  k0.a
 *  ma.e
 *  o0.g
 *  o0.g$a
 *  rr.a
 *  rr.p
 *  rr.q
 *  sr.g
 *  t0.i0
 *  t0.q
 *  u.w
 *  w.g
 *  w.h
 *  w.i
 *  x.c0
 *  x.w
 *  x1.d
 *  y.a
 */
package b0;

import b0.e;
import b0.f;
import b0.g;
import b0.j;
import b0.m2;
import b0.q1;
import b0.r1;
import b0.s;
import d0.o;
import e.n;
import e0.g;
import e0.l1;
import e0.w1;
import e0.x0;
import gr.v;
import j1.h;
import o0.g;
import rr.p;
import rr.q;
import t0.i0;
import u.w;
import w.i;
import x.c0;
import x1.d;

public final class j {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void a(rr.a<v> var0, o0.g var1_1, boolean var2_2, w.h var3_3, g var4_4, i0 var5_5, e.c var6_6, e var7_7, x.w var8_8, q<? super c0, ? super e0.g, ? super Integer, v> var9_9, e0.g var10_10, int var11_11, int var12_12) {
        block64 : {
            block63 : {
                block62 : {
                    block61 : {
                        block57 : {
                            block60 : {
                                block59 : {
                                    block58 : {
                                        block56 : {
                                            block55 : {
                                                block54 : {
                                                    block53 : {
                                                        block49 : {
                                                            block52 : {
                                                                block51 : {
                                                                    block50 : {
                                                                        block48 : {
                                                                            block44 : {
                                                                                block47 : {
                                                                                    block46 : {
                                                                                        block45 : {
                                                                                            block43 : {
                                                                                                block42 : {
                                                                                                    block41 : {
                                                                                                        ma.e.f(var0, (String)"onClick");
                                                                                                        ma.e.f((Object)var8_8, (String)"content");
                                                                                                        var12_13 = var9_9.o(-423488210);
                                                                                                        if ((var11_11 & 1) != 0) {
                                                                                                            var14_14 /* !! */  = var10_10 | 6;
                                                                                                        } else if ((var10_10 & 14) == 0) {
                                                                                                            var97_15 = var12_13.M(var0) != false ? 4 : 2;
                                                                                                            var14_14 /* !! */  = var97_15 | var10_10;
                                                                                                        } else {
                                                                                                            var14_14 /* !! */  = (int)var10_10;
                                                                                                        }
                                                                                                        var15_16 = var11_11 & 2;
                                                                                                        if (var15_16 == 0) break block41;
                                                                                                        var14_14 /* !! */  |= 48;
                                                                                                        ** GOTO lbl-1000
                                                                                                    }
                                                                                                    if ((var10_10 & 112) == 0) {
                                                                                                        var16_17 = var1_1;
                                                                                                        var96_18 = var12_13.M((Object)var16_17) != false ? 32 : 16;
                                                                                                        var14_14 /* !! */  |= var96_18;
                                                                                                    } else lbl-1000: // 2 sources:
                                                                                                    {
                                                                                                        var16_17 = var1_1;
                                                                                                    }
                                                                                                    var17_19 = var11_11 & 4;
                                                                                                    if (var17_19 == 0) break block42;
                                                                                                    var14_14 /* !! */  |= 384;
                                                                                                    ** GOTO lbl-1000
                                                                                                }
                                                                                                if ((var10_10 & 896) == 0) {
                                                                                                    var18_20 = var2_2;
                                                                                                    var95_21 = var12_13.c(var18_20) != false ? 256 : 128;
                                                                                                    var14_14 /* !! */  |= var95_21;
                                                                                                } else lbl-1000: // 2 sources:
                                                                                                {
                                                                                                    var18_20 = var2_2;
                                                                                                }
                                                                                                var19_22 = var11_11 & 8;
                                                                                                if (var19_22 == 0) break block43;
                                                                                                var14_14 /* !! */  |= 3072;
                                                                                                ** GOTO lbl-1000
                                                                                            }
                                                                                            if ((var10_10 & 7168) == 0) {
                                                                                                var20_23 = var3_3;
                                                                                                var94_24 = var12_13.M((Object)var20_23) != false ? 2048 : 1024;
                                                                                                var14_14 /* !! */  |= var94_24;
                                                                                            } else lbl-1000: // 2 sources:
                                                                                            {
                                                                                                var20_23 = var3_3;
                                                                                            }
                                                                                            if ((57344 & var10_10) != 0) break block44;
                                                                                            if ((var11_11 & 16) != 0) break block45;
                                                                                            var21_25 = var4_4;
                                                                                            if (!var12_13.M((Object)var21_25)) break block46;
                                                                                            var93_26 = 16384;
                                                                                            break block47;
                                                                                        }
                                                                                        var21_25 = var4_4;
                                                                                    }
                                                                                    var93_26 = 8192;
                                                                                }
                                                                                var14_14 /* !! */  |= var93_26;
                                                                                break block48;
                                                                            }
                                                                            var21_25 = var4_4;
                                                                        }
                                                                        if ((var10_10 & 458752) != 0) break block49;
                                                                        if ((var11_11 & 32) != 0) break block50;
                                                                        var22_27 = var5_5;
                                                                        if (!var12_13.M((Object)var22_27)) break block51;
                                                                        var92_28 = 131072;
                                                                        break block52;
                                                                    }
                                                                    var22_27 = var5_5;
                                                                }
                                                                var92_28 = 65536;
                                                            }
                                                            var14_14 /* !! */  |= var92_28;
                                                            break block53;
                                                        }
                                                        var22_27 = var5_5;
                                                    }
                                                    if ((var11_11 & 64) == 0) break block54;
                                                    var91_29 = 1572864;
                                                    break block55;
                                                }
                                                if ((3670016 & var10_10) != 0) break block56;
                                                var91_29 = var12_13.M(null) != false ? 1048576 : 524288;
                                            }
                                            var14_14 /* !! */  |= var91_29;
                                        }
                                        if ((var10_10 & 29360128) != 0) break block57;
                                        if ((var11_11 & 128) != 0) break block58;
                                        var23_30 = var6_6;
                                        if (!var12_13.M((Object)var23_30)) break block59;
                                        var90_37 = 8388608;
                                        break block60;
                                    }
                                    var23_31 = var6_6;
                                }
                                var90_37 = 4194304;
                            }
                            var14_14 /* !! */  |= var90_37;
                            break block61;
                        }
                        var23_33 = var6_6;
                    }
                    if ((var10_10 & 234881024) == 0) {
                        var89_38 = (var11_11 & 256) == 0 && var12_13.M((Object)var7_7) != false ? 67108864 : 33554432;
                        var14_14 /* !! */  |= var89_38;
                    }
                    if ((var11_11 & 512) == 0) break block62;
                    var88_39 = 805306368;
                    break block63;
                }
                if ((var10_10 & 1879048192) != 0) break block64;
                var88_39 = var12_13.M((Object)var8_8) != false ? 536870912 : 268435456;
            }
            var14_14 /* !! */  |= var88_39;
        }
        if ((306783378 ^ 1533916891 & var14_14 /* !! */ ) == 0 && var12_13.r()) {
            var12_13.x();
            var65_40 = var7_7;
            var62_41 = var16_17;
            var60_42 = var12_13;
            var68_43 = var18_20;
            var67_44 = var20_23;
            var66_45 = var21_25;
            var63_46 = var22_27;
            var64_47 = var23_34;
        } else {
            if ((var10_10 & true) != 0 && !var12_13.B()) {
                var12_13.m();
                if ((var11_11 & 16) != 0) {
                    var14_14 /* !! */  &= -57345;
                }
                if ((var11_11 & 32) != 0) {
                    var14_14 /* !! */  &= -458753;
                }
                if ((var11_11 & 128) != 0) {
                    var14_14 /* !! */  &= -29360129;
                }
                if ((var11_11 & 256) != 0) {
                    var14_14 /* !! */  &= -234881025;
                }
                var29_48 = var16_17;
                var31_49 = var21_25;
                var32_50 = var22_27;
                var36_51 = var23_34;
                var30_52 = var3_3;
                var34_53 /* !! */  = var14_14 /* !! */ ;
                var35_54 = var7_7;
            } else {
                var12_13.n();
                if (var15_16 != 0) {
                    var24_55 = g.a.b;
                } else {
                    var24_56 = var16_17;
                }
                if (var17_19 != 0) {
                    var18_20 = true;
                }
                if (var19_22 != 0) {
                    var12_13.d(-3687241);
                    var85_58 = var12_13.e();
                    if (var85_58 == g.a.b) {
                        var85_58 = new i();
                        var12_13.E(var85_58);
                    }
                    var12_13.I();
                    var25_59 = (w.h)var85_58;
                } else {
                    var25_59 = var3_3;
                }
                if ((var11_11 & 16) != 0) {
                    var12_13.d(399129690);
                    var75_60 = 2;
                    var76_61 = 8;
                    var77_62 = (float)false;
                    var78_63 = new d(var75_60);
                    var79_64 = new d(var76_61);
                    var26_65 = var24_57;
                    var80_66 = new d(var77_62);
                    var27_67 = var25_59;
                    var12_13.d(-3686095);
                    var81_68 = var12_13.M((Object)var78_63) | var12_13.M((Object)var79_64) | var12_13.M((Object)var80_66);
                    var82_69 = var12_13.e();
                    if (var81_68 || var82_69 == g.a.b) {
                        var82_69 = new s(var75_60, var76_61, var77_62, null);
                        var12_13.E(var82_69);
                    }
                    var12_13.I();
                    var83_70 = (s)var82_69;
                    var12_13.I();
                    var14_14 /* !! */  &= -57345;
                    var21_25 = var83_70;
                } else {
                    var26_65 = var24_57;
                    var27_67 = var25_59;
                }
                if ((var11_11 & 32) != 0) {
                    var73_71 = ((q1)var12_13.K(r1.a)).a;
                    var14_14 /* !! */  &= -458753;
                    var22_27 = var73_71;
                }
                if ((var11_11 & 128) != 0) {
                    var72_72 = f.a.a(0L, 0L, 0L, 0L, var12_13, 0, 15);
                    var14_14 /* !! */  &= -29360129;
                    var23_35 = var72_72;
                }
                if ((var11_11 & 256) != 0) {
                    var28_73 = f.b;
                    var14_14 /* !! */  &= -234881025;
                } else {
                    var28_73 = var7_7;
                }
                var12_13.L();
                var29_48 = var26_65;
                var30_52 = var27_67;
                var31_49 = var21_25;
                var32_50 = var22_27;
                var33_74 = var23_36;
                var34_53 /* !! */  = var14_14 /* !! */ ;
                var35_54 = var28_73;
                var36_51 = var33_74;
            }
            var37_75 = var34_53 /* !! */  >> 6;
            var38_76 = var37_75 & 14;
            var39_77 = var38_76 | 112 & var34_53 /* !! */  >> 18;
            var40_78 = var36_51.b(var18_20, var12_13, var39_77);
            var41_79 = ((t0.q)var36_51.a((boolean)var18_20, (e0.g)var12_13, (int)var39_77).getValue()).a;
            var43_80 = (t0.q)var40_78.getValue();
            var44_81 = var36_51;
            var45_82 = t0.q.a((long)var43_80.a, (float)1.0f, (float)0.0f, (float)0.0f, (float)0.0f, (int)14);
            if (var31_49 == null) {
                var12_13.d(-243208069);
                var12_13.I();
                var47_83 = null;
            } else {
                var12_13.d(-423487418);
                var47_83 = var31_49.a(var18_20, (w.g)var30_52, var12_13, var38_76 | var37_75 & 112 | var37_75 & 896);
                var12_13.I();
            }
            var48_84 = var47_83 == null ? null : (d)var47_83.getValue();
            var49_85 = var48_84 == null ? (float)false : var48_84.b;
            var50_86 = var49_85;
            var51_87 = o.a((boolean)false, (float)0.0f, (long)0L, (e0.g)var12_13, (int)0, (int)7);
            var52_88 = new h(0);
            var53_89 = n.h((e0.g)var12_13, (int)-819891633, (boolean)true, (Object)new a(var40_78, (x.w)var35_54, (q)var8_8, var34_53 /* !! */ ));
            var54_90 = var34_53 /* !! */  & 14 | var34_53 /* !! */  & 112 | 896 & var34_53 /* !! */  >> 9 | 458752 & var34_53 /* !! */  >> 3 | 29360128 & var34_53 /* !! */  << 12 | 1879048192 & var34_53 /* !! */  << 21;
            var55_91 = var35_54;
            var56_92 = var29_48;
            var57_93 = var32_50;
            var58_94 = var30_52;
            var59_95 = var31_49;
            var60_42 = var12_13;
            var61_96 = var18_20;
            m2.a(var0, (o0.g)var56_92, (i0)var57_93, (long)var41_79, (long)var45_82, (float)var50_86, (w.h)var58_94, (w)var51_87, (boolean)var61_96, null, (h)var52_88, (p)var53_89, (e0.g)var60_42, (int)var54_90, (int)384, (int)1024);
            var62_41 = var29_48;
            var63_46 = var32_50;
            var64_47 = var44_81;
            var65_40 = var55_91;
            var66_45 = var59_95;
            var67_44 = var58_94;
            var68_43 = var61_96;
        }
        var69_97 = var60_42.u();
        if (var69_97 == null) {
            return;
        }
        var70_98 = new b(var0, var62_41, var68_43, var67_44, var66_45, var63_46, (e)var64_47, (x.w)var65_40, (q)var8_8, (int)var10_10, var11_11);
        var69_97.a((p)var70_98);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void b(rr.a<v> var0, o0.g var1_1, boolean var2_2, w.h var3_3, g var4_4, i0 var5_5, e.c var6_6, e var7_7, x.w var8_8, q<? super c0, ? super e0.g, ? super Integer, v> var9_9, e0.g var10_10, int var11_11, int var12_12) {
        block56 : {
            block55 : {
                block54 : {
                    block53 : {
                        block49 : {
                            block52 : {
                                block51 : {
                                    block50 : {
                                        block48 : {
                                            block47 : {
                                                block46 : {
                                                    block45 : {
                                                        block41 : {
                                                            block44 : {
                                                                block43 : {
                                                                    block42 : {
                                                                        block40 : {
                                                                            block39 : {
                                                                                block38 : {
                                                                                    ma.e.f(var0, (String)"onClick");
                                                                                    ma.e.f((Object)var8_8, (String)"content");
                                                                                    var12_13 = var9_9.o(1048282549);
                                                                                    if ((var11_11 & 1) != 0) {
                                                                                        var14_14 /* !! */  = var10_10 | 6;
                                                                                    } else if ((var10_10 & 14) == 0) {
                                                                                        var68_15 = var12_13.M(var0) != false ? 4 : 2;
                                                                                        var14_14 /* !! */  = var68_15 | var10_10;
                                                                                    } else {
                                                                                        var14_14 /* !! */  = (int)var10_10;
                                                                                    }
                                                                                    var15_16 = var11_11 & 2;
                                                                                    if (var15_16 != 0) {
                                                                                        var14_14 /* !! */  |= 48;
                                                                                    } else if ((var10_10 & 112) == 0) {
                                                                                        var67_17 = var12_13.M((Object)var1_1) != false ? 32 : 16;
                                                                                        var14_14 /* !! */  |= var67_17;
                                                                                    }
                                                                                    var16_18 = var11_11 & 4;
                                                                                    if (var16_18 == 0) break block38;
                                                                                    var14_14 /* !! */  |= 384;
                                                                                    ** GOTO lbl-1000
                                                                                }
                                                                                if ((var10_10 & 896) == 0) {
                                                                                    var17_19 = var2_2;
                                                                                    var66_20 = var12_13.c(var17_19) != false ? 256 : 128;
                                                                                    var14_14 /* !! */  |= var66_20;
                                                                                } else lbl-1000: // 2 sources:
                                                                                {
                                                                                    var17_19 = var2_2;
                                                                                }
                                                                                var18_21 = var11_11 & 8;
                                                                                if (var18_21 == 0) break block39;
                                                                                var14_14 /* !! */  |= 3072;
                                                                                ** GOTO lbl-1000
                                                                            }
                                                                            if ((var10_10 & 7168) == 0) {
                                                                                var19_22 = var3_3;
                                                                                var65_23 = var12_13.M((Object)var19_22) != false ? 2048 : 1024;
                                                                                var14_14 /* !! */  |= var65_23;
                                                                            } else lbl-1000: // 2 sources:
                                                                            {
                                                                                var19_22 = var3_3;
                                                                            }
                                                                            var20_24 = var11_11 & 16;
                                                                            if (var20_24 == 0) break block40;
                                                                            var14_14 /* !! */  |= 24576;
                                                                            ** GOTO lbl-1000
                                                                        }
                                                                        if ((var10_10 & 57344) == 0) {
                                                                            var21_25 = var4_4;
                                                                            var64_26 = var12_13.M((Object)var21_25) != false ? 16384 : 8192;
                                                                            var14_14 /* !! */  |= var64_26;
                                                                        } else lbl-1000: // 2 sources:
                                                                        {
                                                                            var21_25 = var4_4;
                                                                        }
                                                                        if ((var10_10 & 458752) != 0) break block41;
                                                                        if ((var11_11 & 32) != 0) break block42;
                                                                        var22_27 = var5_5;
                                                                        if (!var12_13.M((Object)var22_27)) break block43;
                                                                        var63_28 = 131072;
                                                                        break block44;
                                                                    }
                                                                    var22_27 = var5_5;
                                                                }
                                                                var63_28 = 65536;
                                                            }
                                                            var14_14 /* !! */  |= var63_28;
                                                            break block45;
                                                        }
                                                        var22_27 = var5_5;
                                                    }
                                                    if ((var11_11 & 64) == 0) break block46;
                                                    var62_29 = 1572864;
                                                    break block47;
                                                }
                                                if ((var10_10 & 3670016) != 0) break block48;
                                                var62_29 = var12_13.M(null) != false ? 1048576 : 524288;
                                            }
                                            var14_14 /* !! */  |= var62_29;
                                        }
                                        if ((var10_10 & 29360128) != 0) break block49;
                                        if ((var11_11 & 128) != 0) break block50;
                                        var23_30 = var6_6;
                                        if (!var12_13.M((Object)var23_30)) break block51;
                                        var61_37 = 8388608;
                                        break block52;
                                    }
                                    var23_31 = var6_6;
                                }
                                var61_37 = 4194304;
                            }
                            var14_14 /* !! */  |= var61_37;
                            break block53;
                        }
                        var23_33 = var6_6;
                    }
                    if ((var10_10 & 234881024) == 0) {
                        var60_38 = (var11_11 & 256) == 0 && var12_13.M((Object)var7_7) != false ? 67108864 : 33554432;
                        var14_14 /* !! */  |= var60_38;
                    }
                    if ((var11_11 & 512) == 0) break block54;
                    var59_39 = 805306368;
                    break block55;
                }
                if ((var10_10 & 1879048192) != 0) break block56;
                var59_39 = var12_13.M((Object)var8_8) != false ? 536870912 : 268435456;
            }
            var14_14 /* !! */  |= var59_39;
        }
        if ((306783378 ^ 1533916891 & var14_14 /* !! */ ) == 0 && var12_13.r()) {
            var12_13.x();
            var47_40 = var1_1;
            var48_41 = var17_19;
            var49_42 = var19_22;
            var43_43 = var21_25;
            var44_44 = var22_27;
            var45_45 = var23_34;
            var42_46 = var12_13;
            var46_47 = var7_7;
        } else {
            if ((var10_10 & true) != 0 && !var12_13.B()) {
                var12_13.m();
                if ((var11_11 & 32) != 0) {
                    var14_14 /* !! */  &= -458753;
                }
                if ((var11_11 & 128) != 0) {
                    var14_14 /* !! */  &= -29360129;
                }
                if ((var11_11 & 256) != 0) {
                    var14_14 /* !! */  &= -234881025;
                }
                var24_48 = var1_1;
                var33_53 = var7_7;
                var25_54 = var17_19;
                var26_55 = var19_22;
                var27_56 = var21_25;
                var31_57 = var22_27;
                var32_58 = var23_34;
            } else {
                var12_13.n();
                if (var15_16 != 0) {
                    var24_49 = g.a.b;
                } else {
                    var24_50 = var1_1;
                }
                var25_54 = var16_18 != 0 ? true : var17_19;
                if (var18_21 != 0) {
                    var12_13.d(-3687241);
                    var56_59 = var12_13.e();
                    if (var56_59 == g.a.b) {
                        var56_59 = new i();
                        var12_13.E(var56_59);
                    }
                    var12_13.I();
                    var26_55 = (w.h)var56_59;
                } else {
                    var26_55 = var19_22;
                }
                var27_56 = var20_24 != 0 ? null : var21_25;
                if ((var11_11 & 32) != 0) {
                    var55_60 = ((q1)var12_13.K(r1.a)).a;
                    var28_61 /* !! */  = var14_14 /* !! */  & -458753;
                    var29_62 = var55_60;
                } else {
                    var28_61 /* !! */  = var14_14 /* !! */ ;
                    var29_62 = var22_27;
                }
                if ((var11_11 & 128) != 0) {
                    var53_63 = f.a.b(0L, 0L, 0L, var12_13, 7);
                    var28_61 /* !! */  &= -29360129;
                    var23_35 = var53_63;
                }
                if ((var11_11 & 256) != 0) {
                    var30_64 = f.e;
                    var28_61 /* !! */  &= -234881025;
                } else {
                    var30_64 = var7_7;
                }
                var12_13.L();
                var31_57 = var29_62;
                var32_58 = var23_36;
                var14_14 /* !! */  = var28_61 /* !! */ ;
                var33_53 = var30_64;
            }
            var34_65 = var14_14 /* !! */  & 14 | var14_14 /* !! */  & 112 | var14_14 /* !! */  & 896 | var14_14 /* !! */  & 7168 | 57344 & var14_14 /* !! */  | var14_14 /* !! */  & 458752 | var14_14 /* !! */  & 3670016 | var14_14 /* !! */  & 29360128 | var14_14 /* !! */  & 234881024 | var14_14 /* !! */  & 1879048192;
            var35_66 = var24_52;
            var36_67 = var25_54;
            var37_68 = var26_55;
            var38_69 = var27_56;
            var39_70 = var31_57;
            var40_71 = var32_58;
            var41_72 = var33_53;
            var42_46 = var12_13;
            j.a(var0, (o0.g)var35_66, (boolean)var36_67, (w.h)var37_68, (g)var38_69, (i0)var39_70, (e)var40_71, (x.w)var41_72, (q)var8_8, (e0.g)var12_13, (int)var34_65, (int)0);
            var43_43 = var27_56;
            var44_44 = var31_57;
            var45_45 = var32_58;
            var46_47 = var33_53;
            var47_40 = var24_52;
            var48_41 = var25_54;
            var49_42 = var26_55;
        }
        var50_73 = var42_46.u();
        if (var50_73 == null) {
            return;
        }
        var51_74 = new c(var0, var47_40, var48_41, var49_42, var43_43, var44_44, (e)var45_45, (x.w)var46_47, (q)var8_8, (int)var10_10, var11_11);
        var50_73.a((p)var51_74);
    }
}

