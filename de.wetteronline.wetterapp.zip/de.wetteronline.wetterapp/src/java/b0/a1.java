/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s.b
 */
package b0;

import b0.v2;
import e.d;
import ma.e;
import s.b;

public final class a1
implements v2 {
    public final float a;

    public a1(float f2) {
        this.a = f2;
    }

    @Override
    public float a(x1.b b3, float f2, float f3) {
        e.f(b3, "<this>");
        return d.u(f2, f3, this.a);
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof a1)) {
            return false;
        }
        a1 a12 = (a1)object;
        return e.a((Object)Float.valueOf((float)this.a), (Object)Float.valueOf((float)a12.a));
    }

    public int hashCode() {
        return Float.floatToIntBits((float)this.a);
    }

    public String toString() {
        return b.a((StringBuilder)android.support.v4.media.b.a((String)"FractionalThreshold(fraction="), (float)this.a, (char)')');
    }
}

