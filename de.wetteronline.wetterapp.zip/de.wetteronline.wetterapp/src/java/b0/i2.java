/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.q
 *  sr.m
 *  x.c0
 */
package b0;

import b0.u2;
import e0.g;
import gr.v;
import ma.e;
import rr.q;
import sr.m;
import x.c0;

public final class i2
extends m
implements q<c0, g, Integer, v> {
    public final /* synthetic */ String c;

    public i2(String string) {
        this.c = string;
        super(3);
    }

    public Object r(Object object, Object object2, Object object3) {
        c0 c02 = (c0)object;
        g g3 = (g)object2;
        int n3 = ((Number)object3).intValue();
        e.f((Object)c02, (String)"$this$TextButton");
        if ((16 ^ n3 & 81) == 0 && g3.r()) {
            g3.x();
        } else {
            u2.c(this.c, null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, null, null, g3, 0, 64, 65534);
        }
        return v.a;
    }
}

