/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.ui.platform.f0
 *  e0.x0
 *  f1.a
 *  f1.a$a
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  k0.b
 *  ma.e
 *  o0.a
 *  o0.a$a
 *  o0.a$c
 *  o0.g
 *  rr.a
 *  rr.p
 *  rr.q
 *  sr.m
 *  x.b0
 *  x.c0
 *  x.d
 *  x.d$c
 *  x.h0
 *  x.w
 *  x1.b
 *  x1.h
 */
package b0;

import androidx.compose.ui.platform.f0;
import b0.f;
import e0.b2;
import e0.n1;
import e0.x0;
import e1.k;
import e1.n;
import f1.a;
import gr.v;
import java.util.Objects;
import k0.b;
import ma.e;
import o0.a;
import o0.g;
import rr.p;
import rr.q;
import sr.m;
import x.b0;
import x.c0;
import x.d;
import x.d0;
import x.h0;
import x.w;

public final class h
extends m
implements p<e0.g, Integer, v> {
    public final /* synthetic */ w c;
    public final /* synthetic */ q<c0, e0.g, Integer, v> d;
    public final /* synthetic */ int e;

    public h(w w3, q<? super c0, ? super e0.g, ? super Integer, v> q2, int n3) {
        this.c = w3;
        this.d = q2;
        this.e = n3;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        block9 : {
            block8 : {
                e0.g g3;
                block7 : {
                    g3 = (e0.g)object;
                    int n3 = ((Number)object2).intValue();
                    if ((2 ^ n3 & 11) != 0 || !g3.r()) break block7;
                    g3.x();
                    break block8;
                }
                g.a a3 = g.a.b;
                g g5 = e.d.z(h0.d((g)a3, (float)f.c, (float)f.d), this.c);
                d.d d3 = d.e;
                a.c c3 = a.a.e;
                q<c0, e0.g, Integer, v> q2 = this.d;
                int n4 = 7168 & this.e >> 18;
                g3.d(-1989997546);
                int n6 = n4 >> 3;
                n n7 = b0.a((d.c)d3, (a.c)c3, (e0.g)g3, (int)(n6 & 14 | n6 & 112));
                int n8 = 112 & n4 << 3;
                g3.d(1376089335);
                x1.b b3 = (x1.b)g3.K(f0.e);
                x1.h h3 = (x1.h)g3.K(f0.i);
                Objects.requireNonNull((Object)f1.a.R);
                rr.a a4 = a.a.b;
                q<n1<f1.a>, e0.g, Integer, v> q3 = k.a(g5);
                int n9 = 7168 & n8 << 9;
                if (!(g3.t() instanceof e0.d)) break block9;
                g3.q();
                if (g3.l()) {
                    g3.v(a4);
                } else {
                    g3.C();
                }
                g3.s();
                e.f((Object)g3, (String)"composer");
                b2.a(g3, n7, a.a.e);
                b2.a(g3, b3, a.a.d);
                b2.a(g3, h3, a.a.f);
                g3.g();
                e.f((Object)g3, (String)"composer");
                n1 n12 = new n1(g3);
                Integer n10 = 112 & n9 >> 3;
                ((b)q3).r(n12, (Object)g3, (Object)n10);
                g3.d(2058660585);
                int n11 = 14 & n9 >> 9;
                g3.d(-326682743);
                if ((2 ^ n11 & 11) == 0 && g3.r()) {
                    g3.x();
                } else {
                    q2.r((Object)d0.a, (Object)g3, (Object)(6 | 112 & n4 >> 6));
                }
                g3.I();
                g3.I();
                g3.J();
                g3.I();
                g3.I();
            }
            return v.a;
        }
        e.h.p();
        throw null;
    }
}

