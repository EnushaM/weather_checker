/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.r2$a
 *  b0.r2$b
 *  b0.r2$c
 *  b0.r2$e
 *  b0.r2$f
 *  b0.r2$g
 *  e0.r0
 *  e0.t1
 *  e0.u1
 *  gr.v
 *  gs.c
 *  gs.i
 *  gs.t
 *  hr.u
 *  java.lang.Boolean
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  jr.d
 *  kr.a
 *  ma.e
 *  rr.a
 *  rr.l
 *  rr.p
 *  t.g
 *  v.a
 *  v.w
 *  v.w$a
 */
package b0;

import b0.r2;
import e0.r0;
import e0.t1;
import e0.u1;
import gr.v;
import gs.i;
import gs.t;
import hr.u;
import java.util.Map;
import jr.d;
import rr.l;
import rr.p;
import v.w;

public class r2<T> {
    public final t.g<Float> a;
    public final l<T, Boolean> b;
    public final r0 c;
    public final r0 d;
    public final r0<Float> e;
    public final r0<Float> f;
    public final r0<Float> g;
    public final r0<Float> h;
    public final r0 i;
    public final gs.c<Map<Float, T>> j;
    public float k;
    public float l;
    public final r0 m;
    public final r0 n;
    public final r0 o;
    public final w p;

    public r2(T t2, t.g<Float> g3, l<? super T, Boolean> l3) {
        ma.e.f(g3, (String)"animationSpec");
        this.a = g3;
        this.b = l3;
        this.c = u1.b(t2, null, (int)2);
        this.d = u1.b((Object)Boolean.FALSE, null, (int)2);
        Float f2 = Float.valueOf((float)0.0f);
        this.e = u1.b((Object)f2, null, (int)2);
        this.f = u1.b((Object)f2, null, (int)2);
        this.g = u1.b((Object)f2, null, (int)2);
        this.h = u1.b(null, null, (int)2);
        this.i = u1.b((Object)u.b, null, (int)2);
        this.j = new i((gs.c)new f((gs.c)new t((p)new t1((rr.a)new c(this), null))), 1);
        this.k = Float.NEGATIVE_INFINITY;
        this.l = Float.POSITIVE_INFINITY;
        this.m = u1.b((Object)g.c, null, (int)2);
        this.n = u1.b((Object)f2, null, (int)2);
        this.o = u1.b(null, null, (int)2);
        this.p = new v.a((l)new b(this));
    }

    public static final void a(r2 r22, boolean bl) {
        r22.d.setValue((Object)bl);
    }

    public final Object b(float f2, t.g<Float> g3, d<? super v> d3) {
        Object object = w.a.a((w)this.p, null, (p)new a(this, f2, g3, null), d3, (int)1, null);
        if (object == kr.a.b) {
            return object;
        }
        return v.a;
    }

    public final Map<Float, T> c() {
        return (Map)this.i.getValue();
    }

    public final T d() {
        return (T)this.c.getValue();
    }

    /*
     * Exception decompiling
     */
    public final Object e(Map<Float, ? extends T> var1, Map<Float, ? extends T> var2, d<? super v> var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl375 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public final Object f(float f2, d<? super v> d3) {
        Object object = w.a.a((w)this.p, null, (p)new e(f2, this, null), d3, (int)1, null);
        if (object == kr.a.b) {
            return object;
        }
        return v.a;
    }
}

