/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  j1.e
 *  j1.u
 *  j1.w
 *  j1.x
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.a
 *  rr.l
 *  sr.m
 *  zr.j
 */
package b0;

import b0.s1;
import b0.u1;
import gr.v;
import j1.e;
import j1.u;
import j1.w;
import j1.x;
import rr.a;
import rr.l;
import sr.m;
import zr.j;

public final class v1
extends m
implements l<x, v> {
    public final /* synthetic */ s1 c;

    public v1(s1 s12) {
        this.c = s12;
        super(1);
    }

    public Object y(Object object) {
        x x3 = (x)object;
        ma.e.f((Object)x3, (String)"$this$semantics");
        ma.e.f((Object)x3, (String)"$this$liveRegion");
        u.d.a(x3, u.a[3], (Object)new e(0));
        u.b((x)x3, null, (a)new u1(this.c), (int)1);
        return v.a;
    }
}

