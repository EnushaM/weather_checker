/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.ui.platform.f0
 *  androidx.compose.ui.platform.r0
 *  b0.b2
 *  b0.c2
 *  b0.d2
 *  b0.g2$a
 *  b0.g2$b
 *  b0.g2$c
 *  b0.g2$d
 *  b0.g2$e
 *  b0.j2
 *  b0.k2
 *  e.d
 *  e.h
 *  e.n
 *  e0.b2
 *  e0.d
 *  e0.g
 *  e0.l1
 *  e0.n1
 *  e0.v
 *  e0.x0
 *  e1.a
 *  e1.b
 *  e1.e
 *  e1.k
 *  e1.n
 *  f1.a
 *  f1.a$a
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  k0.a
 *  k0.b
 *  ma.e
 *  o0.a
 *  o0.a$a
 *  o0.a$b
 *  o0.g
 *  o0.g$a
 *  rr.a
 *  rr.l
 *  rr.p
 *  rr.q
 *  t0.i0
 *  t0.q
 *  x.b
 *  x.d
 *  x.d$j
 *  x.f
 *  x.h0
 *  x.l
 *  x.q
 *  x1.b
 *  x1.d
 *  x1.h
 *  y.a
 */
package b0;

import androidx.compose.ui.platform.f0;
import androidx.compose.ui.platform.r0;
import b0.b2;
import b0.c2;
import b0.d2;
import b0.g2;
import b0.j2;
import b0.k;
import b0.k2;
import b0.l;
import b0.m2;
import b0.q1;
import b0.r1;
import b0.s1;
import e0.l1;
import e0.n1;
import e0.x0;
import e1.n;
import f1.a;
import gr.v;
import java.util.Objects;
import o0.a;
import o0.g;
import rr.p;
import t0.i0;
import x.d;
import x.f;
import x.h0;
import x.q;
import x1.h;

public final class g2 {
    public static final float a;
    public static final float b;
    public static final float c;
    public static final float d;
    public static final float e;
    public static final float f;
    public static final float g;
    public static final float h;
    public static final float i;

    public static {
        float f2;
        float f3;
        a = 30;
        b = 16;
        c = f3 = (float)8;
        d = f3;
        e = f2 = (float)6;
        f = f3;
        g = 18;
        float f4 = 48;
        float f5 = 2;
        h = f4 - f2 * f5;
        i = (float)68 - f2 * f5;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void a(g var0, p<? super e0.g, ? super Integer, v> var1_1, boolean var2_2, i0 var3_3, long var4_4, long var6_5, float var8_6, p<? super e0.g, ? super Integer, v> var9_7, e0.g var10_8, int var11_9, int var12_10) {
        block40 : {
            block36 : {
                block39 : {
                    block38 : {
                        block37 : {
                            block35 : {
                                block34 : {
                                    ma.e.f(var9_7, (String)"content");
                                    var13_11 = var10_8.o(895524162);
                                    var15_12 = var12_10 & 1;
                                    if (var15_12 != 0) {
                                        var16_13 = var11_9 | 6;
                                    } else if ((var11_9 & 14) == 0) {
                                        var70_14 = var13_11.M((Object)var0) != false ? 4 : 2;
                                        var16_13 = var70_14 | var11_9;
                                    } else {
                                        var16_13 = var11_9;
                                    }
                                    var17_15 = var12_10 & 2;
                                    if (var17_15 == 0) break block34;
                                    var16_13 |= 48;
                                    ** GOTO lbl-1000
                                }
                                if ((var11_9 & 112) == 0) {
                                    var18_16 = var1_1;
                                    var69_17 = var13_11.M(var18_16) != false ? 32 : 16;
                                    var16_13 |= var69_17;
                                } else lbl-1000: // 2 sources:
                                {
                                    var18_16 = var1_1;
                                }
                                var19_18 = var12_10 & 4;
                                if (var19_18 == 0) break block35;
                                var16_13 |= 384;
                                ** GOTO lbl-1000
                            }
                            if ((var11_9 & 896) == 0) {
                                var20_19 = var2_2;
                                var68_20 = var13_11.c(var20_19) != false ? 256 : 128;
                                var16_13 |= var68_20;
                            } else lbl-1000: // 2 sources:
                            {
                                var20_19 = var2_2;
                            }
                            if ((var11_9 & 7168) != 0) break block36;
                            if ((var12_10 & 8) != 0) break block37;
                            var21_21 = var3_3;
                            if (!var13_11.M((Object)var21_21)) break block38;
                            var67_22 = 2048;
                            break block39;
                        }
                        var21_21 = var3_3;
                    }
                    var67_22 = 1024;
                }
                var16_13 |= var67_22;
                break block40;
            }
            var21_21 = var3_3;
        }
        if ((57344 & var11_9) == 0) {
            var65_23 = var12_10 & 16;
            var22_24 = var4_4;
            var66_25 = var65_23 == 0 && var13_11.i(var22_24) != false ? 16384 : 8192;
            var16_13 |= var66_25;
        } else {
            var22_24 = var4_4;
        }
        if ((var11_9 & 458752) == 0) {
            var64_26 = (var12_10 & 32) == 0 && var13_11.i(var6_5) != false ? 131072 : 65536;
            var16_13 |= var64_26;
        }
        if ((var24_27 = var12_10 & 64) != 0) {
            var16_13 |= 1572864;
        } else if ((var11_9 & 3670016) == 0) {
            var63_28 = var13_11.f(var8_6) != false ? 1048576 : 524288;
            var16_13 |= var63_28;
        }
        if ((var12_10 & 128) != 0) {
            var16_13 |= 12582912;
        } else if ((29360128 & var11_9) == 0) {
            var62_29 = var13_11.M(var9_7) != false ? 8388608 : 4194304;
            var16_13 |= var62_29;
        }
        if ((4793490 ^ 23967451 & var16_13) == 0 && var13_11.r()) {
            var13_11.x();
            var25_30 = var0;
            var43_37 = var8_6;
            var50_38 = var18_16;
            var47_39 = var20_19;
            var44_40 = var21_21;
            var41_41 = var22_24;
            var48_42 = var6_5;
        } else {
            if ((var11_9 & 1) != 0 && !var13_11.B()) {
                var13_11.m();
                if ((var12_10 & 8) != 0) {
                    var16_13 &= -7169;
                }
                if ((var12_10 & 16) != 0) {
                    var16_13 &= -57345;
                }
                if ((var12_10 & 32) != 0) {
                    var16_13 &= -458753;
                }
                var25_31 = var0;
                var31_43 = var8_6;
                var32_44 = var16_13;
                var26_45 = var22_24;
                var33_46 = var6_5;
            } else {
                var13_11.n();
                if (var15_12 != 0) {
                    var25_32 = g.a.b;
                } else {
                    var25_33 = var0;
                }
                if (var17_15 != 0) {
                    var18_16 = null;
                }
                if (var19_18 != 0) {
                    var20_19 = false;
                }
                if ((var12_10 & 8) != 0) {
                    var60_47 = ((q1)var13_11.K(r1.a)).a;
                    var16_13 &= -7169;
                    var21_21 = var60_47;
                }
                if ((var12_10 & 16) != 0) {
                    var13_11.d(-465860777);
                    var56_48 = t0.q.a((long)((k)var13_11.K(l.a)).d(), (float)0.8f, (float)0.0f, (float)0.0f, (float)0.0f, (int)14);
                    var26_45 = e.n.j((long)var56_48, (long)((k)var13_11.K(l.a)).h());
                    var13_11.I();
                    var16_13 &= -57345;
                } else {
                    var26_45 = var22_24;
                }
                if ((var12_10 & 32) != 0) {
                    var28_49 = ((k)var13_11.K(l.a)).h();
                    var16_13 = -458753 & var16_13;
                } else {
                    var28_49 = var6_5;
                }
                var30_50 = var24_27 != 0 ? (float)6 : var8_6;
                var13_11.L();
                var31_43 = var30_50;
                var32_44 = var16_13;
                var33_46 = var28_49;
            }
            var35_51 = new a(var18_16, var9_7, var32_44, var20_19);
            var36_52 = var18_16;
            var37_53 = e.n.h((e0.g)var13_11, (int)-819890581, (boolean)true, (Object)var35_51);
            var38_54 = 1572864 | var32_44 & 14;
            var39_55 = var32_44 >> 6;
            var40_56 = var38_54 | var39_55 & 112 | var39_55 & 896 | var39_55 & 7168 | 458752 & var32_44 >> 3;
            m2.c((g)var25_35, (i0)var21_21, (long)var26_45, (long)var33_46, (float)var31_43, (p)var37_53, (e0.g)var13_11, (int)var40_56, (int)16);
            var41_41 = var26_45;
            var43_37 = var31_43;
            var44_40 = var21_21;
            var45_57 = var33_46;
            var47_39 = var20_19;
            var48_42 = var45_57;
            var50_38 = var36_52;
        }
        var51_58 = var13_11.u();
        if (var51_58 == null) {
            return;
        }
        var52_59 = new b((g)var25_36, var50_38, var47_39, var44_40, var41_41, var48_42, var43_37, var9_7, var11_9, var12_10);
        var51_58.a((p)var52_59);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void b(s1 var0, g var1_1, boolean var2_2, i0 var3_3, long var4_4, long var6_5, long var8_6, float var10_7, e0.g var11_8, int var12_9, int var13_10) {
        block47 : {
            block43 : {
                block46 : {
                    block45 : {
                        block44 : {
                            block42 : {
                                block38 : {
                                    block41 : {
                                        block40 : {
                                            block39 : {
                                                block37 : {
                                                    block36 : {
                                                        ma.e.f((Object)var0, (String)"snackbarData");
                                                        var14_11 = var11_8.o(895527353);
                                                        if ((var13_10 & 1) != 0) {
                                                            var16_12 = var12_9 | 6;
                                                        } else if ((var12_9 & 14) == 0) {
                                                            var90_13 = var14_11.M((Object)var0) != false ? 4 : 2;
                                                            var16_12 = var90_13 | var12_9;
                                                        } else {
                                                            var16_12 = var12_9;
                                                        }
                                                        var17_14 = var13_10 & 2;
                                                        if (var17_14 == 0) break block36;
                                                        var16_12 |= 48;
                                                        ** GOTO lbl-1000
                                                    }
                                                    if ((var12_9 & 112) == 0) {
                                                        var18_15 = var1_1;
                                                        var89_16 = var14_11.M((Object)var18_15) != false ? 32 : 16;
                                                        var16_12 |= var89_16;
                                                    } else lbl-1000: // 2 sources:
                                                    {
                                                        var18_15 = var1_1;
                                                    }
                                                    var19_17 = var13_10 & 4;
                                                    if (var19_17 == 0) break block37;
                                                    var16_12 |= 384;
                                                    ** GOTO lbl-1000
                                                }
                                                if ((var12_9 & 896) == 0) {
                                                    var20_18 = var2_2;
                                                    var88_19 = var14_11.c(var20_18) != false ? 256 : 128;
                                                    var16_12 |= var88_19;
                                                } else lbl-1000: // 2 sources:
                                                {
                                                    var20_18 = var2_2;
                                                }
                                                if ((var12_9 & 7168) != 0) break block38;
                                                if ((var13_10 & 8) != 0) break block39;
                                                var21_20 = var3_3;
                                                if (!var14_11.M((Object)var21_20)) break block40;
                                                var87_21 = 2048;
                                                break block41;
                                            }
                                            var21_20 = var3_3;
                                        }
                                        var87_21 = 1024;
                                    }
                                    var16_12 |= var87_21;
                                    break block42;
                                }
                                var21_20 = var3_3;
                            }
                            if ((var12_9 & 57344) == 0) {
                                var86_22 = (var13_10 & 16) == 0 && var14_11.i(var4_4) != false ? 16384 : 8192;
                                var16_12 |= var86_22;
                            }
                            if ((var12_9 & 458752) != 0) break block43;
                            if ((var13_10 & 32) != 0) break block44;
                            var22_23 = var6_5;
                            if (!var14_11.i(var22_23)) break block45;
                            var85_24 = 131072;
                            break block46;
                        }
                        var22_23 = var6_5;
                    }
                    var85_24 = 65536;
                }
                var16_12 |= var85_24;
                break block47;
            }
            var22_23 = var6_5;
        }
        if ((var12_9 & 3670016) == 0) {
            var83_25 = var13_10 & 64;
            var24_26 = var8_6;
            var84_27 = var83_25 == 0 && var14_11.i(var24_26) != false ? 1048576 : 524288;
            var16_12 |= var84_27;
        } else {
            var24_26 = var8_6;
        }
        var26_28 = var13_10 & 128;
        if (var26_28 != 0) {
            var16_12 |= 12582912;
            var28_29 = var10_7;
        } else {
            var27_30 = var12_9 & 29360128;
            var28_29 = var10_7;
            if (var27_30 == 0) {
                var82_31 = var14_11.f(var28_29) != false ? 8388608 : 4194304;
                var16_12 |= var82_31;
            }
        }
        if ((4793490 ^ var16_12 & 23967451) == 0 && var14_11.r()) {
            var14_11.x();
            var59_32 = var18_15;
            var60_33 = var20_18;
            var61_34 = var21_20;
            var64_35 = var24_26;
            var62_36 = var22_23;
            var66_37 = var4_4;
        } else {
            if ((var12_9 & 1) != 0 && !var14_11.B()) {
                var14_11.m();
                if ((var13_10 & 8) != 0) {
                    var16_12 &= -7169;
                }
                if ((var13_10 & 16) != 0) {
                    var16_12 &= -57345;
                }
                if ((var13_10 & 32) != 0) {
                    var16_12 &= -458753;
                }
                if ((var13_10 & 64) != 0) {
                    var16_12 &= -3670017;
                }
                var44_38 = var28_29;
                var45_39 = var24_26;
                var47_40 = var22_23;
                var39_41 = var16_12;
                var40_42 = var4_4;
            } else {
                var14_11.n();
                if (var17_14 != 0) {
                    var29_43 = g.a.b;
                } else {
                    var29_44 = var18_15;
                }
                var30_46 = var19_17 != 0 ? false : var20_18;
                if ((var13_10 & 8) != 0) {
                    var31_47 = ((q1)var14_11.K(r1.a)).a;
                    var16_12 &= -7169;
                } else {
                    var31_47 = var21_20;
                }
                if ((var13_10 & 16) != 0) {
                    var14_11.d(-465860777);
                    var76_48 = t0.q.a((long)((k)var14_11.K(l.a)).d(), (float)0.8f, (float)0.0f, (float)0.0f, (float)0.0f, (int)14);
                    var32_49 = var29_45;
                    var79_50 = (k)var14_11.K(l.a);
                    var33_51 = var30_46;
                    var34_52 = e.n.j((long)var76_48, (long)var79_50.h());
                    var14_11.I();
                    var16_12 &= -57345;
                } else {
                    var32_49 = var29_45;
                    var33_51 = var30_46;
                    var34_52 = var4_4;
                }
                if ((var13_10 & 32) != 0) {
                    var36_53 = ((k)var14_11.K(l.a)).h();
                    var16_12 &= -458753;
                } else {
                    var36_53 = var22_23;
                }
                if ((var13_10 & 64) != 0) {
                    var14_11.d(894573386);
                    var70_54 = (k)var14_11.K(l.a);
                    if (var70_54.i()) {
                        var71_55 = var70_54.e();
                        var24_26 = e.n.j((long)t0.q.a((long)var70_54.h(), (float)0.6f, (float)0.0f, (float)0.0f, (float)0.0f, (int)14), (long)var71_55);
                    } else {
                        var24_26 = var70_54.f();
                    }
                    var14_11.I();
                    var16_12 &= -3670017;
                }
                var38_56 = var26_28 != 0 ? (float)6 : var28_29;
                var14_11.L();
                var39_41 = var16_12;
                var40_42 = var34_52;
                var18_15 = var32_49;
                var42_57 = var36_53;
                var20_18 = var33_51;
                var21_20 = var31_47;
                var44_38 = var38_56;
                var45_39 = var24_26;
                var47_40 = var42_57;
            }
            var49_58 = var0.c();
            if (var49_58 != null) {
                var50_59 = new e(var45_39, var39_41, var0, var49_58);
                var51_60 = var45_39;
                var53_61 = e.n.h((e0.g)var14_11, (int)-819889186, (boolean)true, (Object)var50_59);
            } else {
                var51_60 = var45_39;
                var53_61 = null;
            }
            var54_62 = e.d.A((g)var18_15, (float)12);
            var55_63 = e.n.h((e0.g)var14_11, (int)-819890114, (boolean)true, (Object)new c(var0));
            var56_64 = 12582912 | var39_41 & 896 | var39_41 & 7168 | 57344 & var39_41 | 458752 & var39_41 | 3670016 & var39_41 >> 3;
            g2.a(var54_62, (p<? super e0.g, ? super Integer, v>)var53_61, var20_18, var21_20, var40_42, var47_40, var44_38, (p<? super e0.g, ? super Integer, v>)var55_63, var14_11, var56_64, 0);
            var28_29 = var44_38;
            var57_65 = var40_42;
            var59_32 = var18_15;
            var60_33 = var20_18;
            var61_34 = var21_20;
            var62_36 = var47_40;
            var64_35 = var51_60;
            var66_37 = var57_65;
        }
        var68_66 = var14_11.u();
        if (var68_66 == null) {
            return;
        }
        var69_67 = new d(var0, var59_32, var60_33, var61_34, var66_37, var62_36, var64_35, var28_29, var12_9, var13_10);
        var68_66.a((p)var69_67);
    }

    public static final void c(p p2, p p3, e0.g g3, int n2) {
        block17 : {
            block18 : {
                block19 : {
                    e0.g g4;
                    block16 : {
                        rr.a a3;
                        g.a a4;
                        rr.a a5;
                        int n3;
                        p p4;
                        block15 : {
                            g4 = g3.o(-829912256);
                            if ((n2 & 14) == 0) {
                                int n4 = g4.M((Object)p2) ? 4 : 2;
                                n3 = n4 | n2;
                            } else {
                                n3 = n2;
                            }
                            if ((n2 & 112) == 0) {
                                int n5 = g4.M((Object)p3) ? 32 : 16;
                                n3 |= n5;
                            }
                            if ((18 ^ n3 & 91) != 0 || !g4.r()) break block15;
                            g4.x();
                            break block16;
                        }
                        g.a a6 = g.a.b;
                        g g5 = h0.g((g)a6, (float)0.0f, (int)1);
                        float f2 = b;
                        float f3 = c;
                        g g6 = e.d.D((g)g5, (float)f2, (float)0.0f, (float)f3, (float)d, (int)2);
                        g4.d(-1113031299);
                        n n6 = x.l.a((d.j)x.d.d, (a.b)a.a.f, (e0.g)g4, (int)0);
                        g4.d(1376089335);
                        x0 x02 = f0.e;
                        x1.b b3 = (x1.b)g4.K((e0.v)x02);
                        x0 x03 = f0.i;
                        h h2 = (h)g4.K((e0.v)x03);
                        Objects.requireNonNull((Object)f1.a.R);
                        rr.a a7 = a.a.b;
                        rr.q q3 = e1.k.a((g)g6);
                        if (!(g4.t() instanceof e0.d)) break block17;
                        g4.q();
                        if (g4.l()) {
                            g4.v(a7);
                        } else {
                            g4.C();
                        }
                        g4.s();
                        ma.e.f((Object)g4, (String)"composer");
                        p p5 = a.a.e;
                        e0.b2.a((e0.g)g4, (Object)n6, (p)p5);
                        p p6 = a.a.d;
                        e0.b2.a((e0.g)g4, (Object)b3, (p)p6);
                        p p7 = a.a.f;
                        e0.b2.a((e0.g)g4, (Object)h2, (p)p7);
                        g4.g();
                        ma.e.f((Object)g4, (String)"composer");
                        n1 n12 = new n1(g4);
                        Integer n7 = 0;
                        ((k0.b)q3).r((Object)n12, (Object)g4, (Object)n7);
                        g4.d(2058660585);
                        g4.d(276693241);
                        g4.d(71171644);
                        float f4 = a;
                        float f5 = g;
                        ma.e.f((Object)a6, (String)"$this$paddingFromBaseline");
                        if (!x1.d.a((float)f5, (float)Float.NaN)) {
                            e1.e e2 = e1.b.b;
                            p4 = p7;
                            a5 = a7;
                            a4 = x.b.a((g)a6, (e1.a)e2, (float)0.0f, (float)f5, (int)2);
                        } else {
                            p4 = p7;
                            a5 = a7;
                            a4 = a6;
                        }
                        a6.r((g)a4);
                        Object object = !x1.d.a((float)f4, (float)Float.NaN) ? x.b.a((g)a6, (e1.a)e1.b.a, (float)f4, (float)0.0f, (int)4) : a6;
                        g g7 = a4.r((g)object);
                        p p8 = p4;
                        rr.a a8 = a5;
                        g g8 = e.d.D((g)g7, (float)0.0f, (float)0.0f, (float)f3, (float)0.0f, (int)11);
                        g4.d(-1990474327);
                        o0.a a9 = a.a.b;
                        n n8 = f.d((o0.a)a9, (boolean)false, (e0.g)g4, (int)0);
                        g4.d(1376089335);
                        x1.b b4 = (x1.b)g4.K((e0.v)x02);
                        h h3 = (h)g4.K((e0.v)x03);
                        rr.q q4 = e1.k.a((g)g8);
                        if (!(g4.t() instanceof e0.d)) break block18;
                        g4.q();
                        if (g4.l()) {
                            a3 = a8;
                            g4.v(a3);
                        } else {
                            a3 = a8;
                            g4.C();
                        }
                        g4.s();
                        ma.e.f((Object)g4, (String)"composer");
                        e0.b2.a((e0.g)g4, (Object)n8, (p)p5);
                        e0.b2.a((e0.g)g4, (Object)b4, (p)p6);
                        e0.b2.a((e0.g)g4, (Object)h3, (p)p8);
                        g4.g();
                        ma.e.f((Object)g4, (String)"composer");
                        n1 n13 = new n1(g4);
                        Integer n9 = 0;
                        ((k0.b)q4).r((Object)n13, (Object)g4, (Object)n9);
                        g4.d(2058660585);
                        g4.d(-1253629305);
                        g4.d(683214592);
                        p2.t0((Object)g4, (Object)(n3 & 14));
                        g4.I();
                        g4.I();
                        g4.I();
                        g4.J();
                        g4.I();
                        g4.I();
                        a.b b5 = a.a.h;
                        ma.e.f((Object)a6, (String)"<this>");
                        ma.e.f((Object)b5, (String)"alignment");
                        q q5 = new q(b5, (rr.l)r0.c);
                        a6.r((g)q5);
                        g4.d(-1990474327);
                        n n10 = f.d((o0.a)a9, (boolean)false, (e0.g)g4, (int)0);
                        g4.d(1376089335);
                        x1.b b6 = (x1.b)g4.K((e0.v)x02);
                        h h4 = (h)g4.K((e0.v)x03);
                        rr.q q6 = e1.k.a((g)q5);
                        if (!(g4.t() instanceof e0.d)) break block19;
                        g4.q();
                        if (g4.l()) {
                            g4.v(a3);
                        } else {
                            g4.C();
                        }
                        g4.s();
                        ma.e.f((Object)g4, (String)"composer");
                        e0.b2.a((e0.g)g4, (Object)n10, (p)p5);
                        e0.b2.a((e0.g)g4, (Object)b6, (p)p6);
                        e0.b2.a((e0.g)g4, (Object)h4, (p)p8);
                        g4.g();
                        ma.e.f((Object)g4, (String)"composer");
                        n1 n14 = new n1(g4);
                        Integer n11 = 0;
                        ((k0.b)q6).r((Object)n14, (Object)g4, (Object)n11);
                        g4.d(2058660585);
                        g4.d(-1253629305);
                        g4.d(683214646);
                        p3.t0((Object)g4, (Object)(14 & n3 >> 3));
                        g4.I();
                        g4.I();
                        g4.I();
                        g4.J();
                        g4.I();
                        g4.I();
                        g4.I();
                        g4.I();
                        g4.I();
                        g4.J();
                        g4.I();
                        g4.I();
                    }
                    l1 l12 = g4.u();
                    if (l12 == null) {
                        return;
                    }
                    l12.a((p)new b2(p2, p3, n2));
                    return;
                }
                e.h.p();
                throw null;
            }
            e.h.p();
            throw null;
        }
        e.h.p();
        throw null;
    }

    public static final void d(p p2, p p3, e0.g g3, int n2) {
        block15 : {
            block16 : {
                block17 : {
                    e0.g g4;
                    p p4;
                    block14 : {
                        int n3;
                        block13 : {
                            g4 = g3.o(-1143069246);
                            if ((n2 & 14) == 0) {
                                int n4 = g4.M((Object)p2) ? 4 : 2;
                                n3 = n4 | n2;
                            } else {
                                n3 = n2;
                            }
                            if ((n2 & 112) == 0) {
                                int n5 = g4.M((Object)p3) ? 32 : 16;
                                n3 |= n5;
                            }
                            if ((18 ^ n3 & 91) != 0 || !g4.r()) break block13;
                            g4.x();
                            p4 = p3;
                            break block14;
                        }
                        g.a a3 = g.a.b;
                        float f2 = b;
                        float f3 = c;
                        float f4 = e;
                        g g5 = e.d.C((g)a3, (float)f2, (float)f4, (float)f3, (float)f4);
                        c2 c22 = new c2("action", "text");
                        g4.d(1376089335);
                        x0 x02 = f0.e;
                        x1.b b3 = (x1.b)g4.K((e0.v)x02);
                        x0 x03 = f0.i;
                        h h2 = (h)g4.K((e0.v)x03);
                        Objects.requireNonNull((Object)f1.a.R);
                        rr.a a4 = a.a.b;
                        rr.q q3 = e1.k.a((g)g5);
                        if (!(g4.t() instanceof e0.d)) break block15;
                        g4.q();
                        if (g4.l()) {
                            g4.v(a4);
                        } else {
                            g4.C();
                        }
                        g4.s();
                        ma.e.f((Object)g4, (String)"composer");
                        p p5 = a.a.e;
                        e0.b2.a((e0.g)g4, (Object)c22, (p)p5);
                        p p6 = a.a.d;
                        e0.b2.a((e0.g)g4, (Object)b3, (p)p6);
                        p p7 = a.a.f;
                        e0.b2.a((e0.g)g4, (Object)h2, (p)p7);
                        g4.g();
                        ma.e.f((Object)g4, (String)"composer");
                        n1 n12 = new n1(g4);
                        Integer n6 = 0;
                        ((k0.b)q3).r((Object)n12, (Object)g4, (Object)n6);
                        g4.d(2058660585);
                        g4.d(-849178856);
                        g g6 = e.n.t((g)a3, (Object)"text");
                        g4.d(-1990474327);
                        o0.a a5 = a.a.b;
                        n n7 = f.d((o0.a)a5, (boolean)false, (e0.g)g4, (int)0);
                        g4.d(1376089335);
                        x1.b b4 = (x1.b)g4.K((e0.v)x02);
                        h h3 = (h)g4.K((e0.v)x03);
                        rr.q q4 = e1.k.a((g)g6);
                        if (!(g4.t() instanceof e0.d)) break block16;
                        g4.q();
                        if (g4.l()) {
                            g4.v(a4);
                        } else {
                            g4.C();
                        }
                        g4.s();
                        ma.e.f((Object)g4, (String)"composer");
                        e0.b2.a((e0.g)g4, (Object)n7, (p)p5);
                        e0.b2.a((e0.g)g4, (Object)b4, (p)p6);
                        e0.b2.a((e0.g)g4, (Object)h3, (p)p7);
                        g4.g();
                        ma.e.f((Object)g4, (String)"composer");
                        n1 n13 = new n1(g4);
                        Integer n8 = 0;
                        ((k0.b)q4).r((Object)n13, (Object)g4, (Object)n8);
                        g4.d(2058660585);
                        g4.d(-1253629305);
                        g4.d(-202240421);
                        p2.t0((Object)g4, (Object)(n3 & 14));
                        g4.I();
                        g4.I();
                        g4.I();
                        g4.J();
                        g4.I();
                        g4.I();
                        g g7 = e.n.t((g)a3, (Object)"action");
                        g4.d(-1990474327);
                        n n9 = f.d((o0.a)a5, (boolean)false, (e0.g)g4, (int)0);
                        g4.d(1376089335);
                        x1.b b5 = (x1.b)g4.K((e0.v)x02);
                        h h4 = (h)g4.K((e0.v)x03);
                        rr.q q5 = e1.k.a((g)g7);
                        if (!(g4.t() instanceof e0.d)) break block17;
                        g4.q();
                        if (g4.l()) {
                            g4.v(a4);
                        } else {
                            g4.C();
                        }
                        g4.s();
                        ma.e.f((Object)g4, (String)"composer");
                        e0.b2.a((e0.g)g4, (Object)n9, (p)p5);
                        e0.b2.a((e0.g)g4, (Object)b5, (p)p6);
                        e0.b2.a((e0.g)g4, (Object)h4, (p)p7);
                        g4.g();
                        ma.e.f((Object)g4, (String)"composer");
                        n1 n14 = new n1(g4);
                        Integer n10 = 0;
                        ((k0.b)q5).r((Object)n14, (Object)g4, (Object)n10);
                        g4.d(2058660585);
                        g4.d(-1253629305);
                        g4.d(-202240364);
                        Integer n11 = 14 & n3 >> 3;
                        p4 = p3;
                        p4.t0((Object)g4, (Object)n11);
                        g4.I();
                        g4.I();
                        g4.I();
                        g4.J();
                        g4.I();
                        g4.I();
                        g4.I();
                        g4.I();
                        g4.J();
                        g4.I();
                    }
                    l1 l12 = g4.u();
                    if (l12 == null) {
                        return;
                    }
                    l12.a((p)new d2(p2, p4, n2));
                    return;
                }
                e.h.p();
                throw null;
            }
            e.h.p();
            throw null;
        }
        e.h.p();
        throw null;
    }

    public static final void e(p p2, e0.g g3, int n2) {
        block10 : {
            e0.g g4;
            block9 : {
                int n3;
                block8 : {
                    g4 = g3.o(-868771705);
                    if ((n2 & 14) == 0) {
                        int n4 = g4.M((Object)p2) ? 4 : 2;
                        n3 = n4 | n2;
                    } else {
                        n3 = n2;
                    }
                    if ((2 ^ n3 & 11) != 0 || !g4.r()) break block8;
                    g4.x();
                    break block9;
                }
                g.a a3 = g.a.b;
                float f2 = b;
                float f3 = e;
                g g5 = e.d.C((g)a3, (float)f2, (float)f3, (float)f2, (float)f3);
                j2 j22 = j2.a;
                int n5 = n3 & 14;
                g4.d(1376089335);
                x1.b b3 = (x1.b)g4.K((e0.v)f0.e);
                h h2 = (h)g4.K((e0.v)f0.i);
                Objects.requireNonNull((Object)f1.a.R);
                rr.a a4 = a.a.b;
                rr.q q3 = e1.k.a((g)g5);
                int n6 = 7168 & n5 << 9;
                if (!(g4.t() instanceof e0.d)) break block10;
                g4.q();
                if (g4.l()) {
                    g4.v(a4);
                } else {
                    g4.C();
                }
                g4.s();
                ma.e.f((Object)g4, (String)"composer");
                e0.b2.a((e0.g)g4, (Object)j22, (p)a.a.e);
                e0.b2.a((e0.g)g4, (Object)b3, (p)a.a.d);
                e0.b2.a((e0.g)g4, (Object)h2, (p)a.a.f);
                g4.g();
                ma.e.f((Object)g4, (String)"composer");
                n1 n12 = new n1(g4);
                Integer n7 = 112 & n6 >> 3;
                ((k0.b)q3).r((Object)n12, (Object)g4, (Object)n7);
                g4.d(2058660585);
                p2.t0((Object)g4, (Object)(14 & n6 >> 9));
                g4.I();
                g4.J();
                g4.I();
            }
            l1 l12 = g4.u();
            if (l12 == null) {
                return;
            }
            l12.a((p)new k2(p2, n2));
            return;
        }
        e.h.p();
        throw null;
    }
}

