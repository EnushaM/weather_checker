/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  co.a
 *  ds.g0
 *  gr.v
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  jr.d
 *  kr.a
 *  lr.e
 *  lr.i
 *  rr.p
 */
package b0;

import b0.n0;
import ds.g0;
import gr.v;
import jr.d;
import kr.a;
import lr.e;
import lr.i;
import rr.p;

@e(c="androidx.compose.material.DrawerKt$ModalDrawer$1$2$2$1", f="Drawer.kt", l={421}, m="invokeSuspend")
public final class x
extends i
implements p<g0, d<? super v>, Object> {
    public int f;
    public final /* synthetic */ n0 g;

    public x(n0 n02, d<? super x> d3) {
        this.g = n02;
        super(2, d3);
    }

    public final d<v> e(Object object, d<?> d3) {
        return new x(this.g, d3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final Object h(Object object) {
        a a3 = a.b;
        int n3 = this.f;
        if (n3 != 0) {
            if (n3 != 1) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            co.a.L((Object)object);
            return v.a;
        } else {
            co.a.L((Object)object);
            n0 n02 = this.g;
            this.f = 1;
            if (n02.a((d<? super v>)this) != a3) return v.a;
            return a3;
        }
    }

    public Object t0(Object object, Object object2) {
        (g0)object;
        d d3 = (d)object2;
        return new x(this.g, (d<? super x>)d3).h((Object)v.a);
    }
}

