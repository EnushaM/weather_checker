/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

public final class o0
extends Enum<o0> {
    public static final /* enum */ o0 b;
    public static final /* enum */ o0 c;
    public static final /* synthetic */ o0[] d;

    public static {
        o0 o02;
        o0 o03;
        b = o02 = new o0();
        c = o03 = new o0();
        d = new o0[]{o02, o03};
    }

    public static o0 valueOf(String string) {
        return (o0)Enum.valueOf(o0.class, (String)string);
    }

    public static o0[] values() {
        return (o0[])d.clone();
    }
}

