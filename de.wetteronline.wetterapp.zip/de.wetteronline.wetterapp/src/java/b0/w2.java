/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  androidx.compose.ui.text.intl.a
 *  e.m
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  l1.u
 *  ma.e
 *  p1.d
 *  p1.e
 *  p1.f
 *  p1.g
 *  p1.k
 *  t0.h0
 *  u1.a
 *  u1.b
 *  u1.c
 *  u1.d
 *  u1.e
 *  u1.f
 */
package b0;

import androidx.compose.ui.text.intl.a;
import b0.x2;
import e.m;
import l1.u;
import p1.e;
import p1.g;
import p1.k;
import t0.h0;
import u1.b;
import u1.c;
import u1.d;
import u1.f;

public final class w2 {
    public final u a;
    public final u b;
    public final u c;
    public final u d;
    public final u e;
    public final u f;
    public final u g;
    public final u h;
    public final u i;
    public final u j;
    public final u k;
    public final u l;
    public final u m;

    public w2(p1.d d3, u u3, u u4, u u5, u u6, u u7, u u8, u u9, u u10, u u11, u u12, u u13, u u14, u u15, int n2) {
        u u16;
        u u17;
        u u18;
        u u19;
        u u20;
        u u21;
        u u22;
        u u23;
        u u24;
        u u25;
        u u26;
        u u27;
        u u28;
        k k3 = (n2 & 1) != 0 ? p1.d.c : null;
        if ((n2 & 2) != 0) {
            g g3 = g.g;
            long l3 = m.D((int)96);
            long l4 = m.C((double)-1.5);
            u19 = new u(0L, l3, g3, null, null, null, null, l4, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u19 = null;
        }
        if ((n2 & 4) != 0) {
            g g4 = g.g;
            long l5 = m.D((int)60);
            long l6 = m.C((double)-0.5);
            u27 = new u(0L, l5, g4, null, null, null, null, l6, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u27 = null;
        }
        if ((n2 & 8) != 0) {
            g g5 = g.h;
            long l7 = m.D((int)48);
            long l8 = m.D((int)0);
            u23 = new u(0L, l7, g5, null, null, null, null, l8, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u23 = null;
        }
        if ((n2 & 16) != 0) {
            g g6 = g.h;
            long l9 = m.D((int)34);
            long l10 = m.C((double)0.25);
            u21 = new u(0L, l9, g6, null, null, null, null, l10, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u21 = null;
        }
        if ((n2 & 32) != 0) {
            g g7 = g.h;
            long l11 = m.D((int)24);
            long l12 = m.D((int)0);
            u18 = new u(0L, l11, g7, null, null, null, null, l12, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u18 = null;
        }
        if ((n2 & 64) != 0) {
            g g8 = g.i;
            long l13 = m.D((int)20);
            long l14 = m.C((double)0.15);
            u17 = new u(0L, l13, g8, null, null, null, null, l14, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u17 = null;
        }
        if ((n2 & 128) != 0) {
            g g9 = g.h;
            long l15 = m.D((int)16);
            long l16 = m.C((double)0.15);
            u28 = new u(0L, l15, g9, null, null, null, null, l16, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u28 = null;
        }
        if ((n2 & 256) != 0) {
            g g10 = g.i;
            long l17 = m.D((int)14);
            long l18 = m.C((double)0.1);
            u25 = new u(0L, l17, g10, null, null, null, null, l18, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u25 = null;
        }
        if ((n2 & 512) != 0) {
            g g11 = g.h;
            long l19 = m.D((int)16);
            long l20 = m.C((double)0.5);
            u24 = new u(0L, l19, g11, null, null, null, null, l20, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u24 = null;
        }
        if ((n2 & 1024) != 0) {
            g g12 = g.h;
            long l21 = m.D((int)14);
            long l22 = m.C((double)0.25);
            u22 = new u(0L, l21, g12, null, null, null, null, l22, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u22 = null;
        }
        if ((n2 & 2048) != 0) {
            g g13 = g.i;
            long l23 = m.D((int)14);
            long l24 = m.C((double)1.25);
            u20 = new u(0L, l23, g13, null, null, null, null, l24, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u20 = null;
        }
        if ((n2 & 4096) != 0) {
            g g14 = g.h;
            long l25 = m.D((int)12);
            long l26 = m.C((double)0.4);
            u16 = new u(0L, l25, g14, null, null, null, null, l26, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u16 = null;
        }
        if ((n2 & 8192) != 0) {
            g g15 = g.h;
            long l27 = m.D((int)10);
            long l28 = m.C((double)1.5);
            u26 = new u(0L, l27, g15, null, null, null, null, l28, null, null, null, 0L, null, null, null, null, 0L, null, 262009);
        } else {
            u26 = null;
        }
        ma.e.f((Object)k3, (String)"defaultFontFamily");
        ma.e.f((Object)u19, (String)"h1");
        ma.e.f((Object)u27, (String)"h2");
        ma.e.f((Object)u23, (String)"h3");
        ma.e.f((Object)u21, (String)"h4");
        ma.e.f((Object)u18, (String)"h5");
        ma.e.f((Object)u17, (String)"h6");
        ma.e.f((Object)u28, (String)"subtitle1");
        ma.e.f((Object)u25, (String)"subtitle2");
        ma.e.f((Object)u24, (String)"body1");
        ma.e.f((Object)u22, (String)"body2");
        ma.e.f((Object)u20, (String)"button");
        ma.e.f((Object)u16, (String)"caption");
        ma.e.f((Object)u26, (String)"overline");
        u u29 = x2.a(u19, (p1.d)k3);
        u u30 = x2.a(u27, (p1.d)k3);
        u u31 = x2.a(u23, (p1.d)k3);
        u u32 = x2.a(u21, (p1.d)k3);
        u u33 = x2.a(u18, (p1.d)k3);
        u u34 = x2.a(u17, (p1.d)k3);
        u u35 = x2.a(u28, (p1.d)k3);
        u u36 = x2.a(u25, (p1.d)k3);
        u u37 = x2.a(u24, (p1.d)k3);
        u u38 = x2.a(u22, (p1.d)k3);
        u u39 = x2.a(u20, (p1.d)k3);
        u u40 = x2.a(u16, (p1.d)k3);
        u u41 = x2.a(u26, (p1.d)k3);
        this.a = u29;
        this.b = u30;
        this.c = u31;
        this.d = u32;
        this.e = u33;
        this.f = u34;
        this.g = u35;
        this.h = u36;
        this.i = u37;
        this.j = u38;
        this.k = u39;
        this.l = u40;
        this.m = u41;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof w2)) {
            return false;
        }
        u u3 = this.a;
        w2 w22 = (w2)object;
        if (!ma.e.a((Object)u3, (Object)w22.a)) {
            return false;
        }
        if (!ma.e.a((Object)this.b, (Object)w22.b)) {
            return false;
        }
        if (!ma.e.a((Object)this.c, (Object)w22.c)) {
            return false;
        }
        if (!ma.e.a((Object)this.d, (Object)w22.d)) {
            return false;
        }
        if (!ma.e.a((Object)this.e, (Object)w22.e)) {
            return false;
        }
        if (!ma.e.a((Object)this.f, (Object)w22.f)) {
            return false;
        }
        if (!ma.e.a((Object)this.g, (Object)w22.g)) {
            return false;
        }
        if (!ma.e.a((Object)this.h, (Object)w22.h)) {
            return false;
        }
        if (!ma.e.a((Object)this.i, (Object)w22.i)) {
            return false;
        }
        if (!ma.e.a((Object)this.j, (Object)w22.j)) {
            return false;
        }
        if (!ma.e.a((Object)this.k, (Object)w22.k)) {
            return false;
        }
        if (!ma.e.a((Object)this.l, (Object)w22.l)) {
            return false;
        }
        return ma.e.a((Object)this.m, (Object)w22.m);
    }

    public int hashCode() {
        return 31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * this.a.hashCode() + this.b.hashCode()) + this.c.hashCode()) + this.d.hashCode()) + this.e.hashCode()) + this.f.hashCode()) + this.g.hashCode()) + this.h.hashCode()) + this.i.hashCode()) + this.j.hashCode()) + this.k.hashCode()) + this.l.hashCode()) + this.m.hashCode();
    }

    public String toString() {
        StringBuilder stringBuilder = android.support.v4.media.b.a((String)"Typography(h1=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", h2=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", h3=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", h4=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", h5=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", h6=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", subtitle1=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(", subtitle2=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", body1=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(", body2=");
        stringBuilder.append((Object)this.j);
        stringBuilder.append(", button=");
        stringBuilder.append((Object)this.k);
        stringBuilder.append(", caption=");
        stringBuilder.append((Object)this.l);
        stringBuilder.append(", overline=");
        stringBuilder.append((Object)this.m);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}

