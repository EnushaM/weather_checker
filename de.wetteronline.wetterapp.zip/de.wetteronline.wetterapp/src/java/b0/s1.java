/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

import b0.t1;

public interface s1 {
    public String a();

    public void b();

    public String c();

    public void dismiss();

    public t1 getDuration();
}

