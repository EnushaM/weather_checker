/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c1.p
 *  co.a
 *  gr.v
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  jr.d
 *  kr.a
 *  lr.e
 *  lr.i
 *  rr.a
 *  rr.l
 *  rr.p
 *  rr.q
 *  s0.c
 *  tn.a
 *  v.p0
 *  v.v0
 */
package b0;

import b0.i0;
import c1.p;
import gr.v;
import jr.d;
import lr.e;
import lr.i;
import rr.l;
import rr.q;
import s0.c;
import v.p0;
import v.v0;

@e(c="androidx.compose.material.DrawerKt$Scrim$dismissDrawer$1$1", f="Drawer.kt", l={664}, m="invokeSuspend")
public final class i0
extends i
implements rr.p<p, d<? super v>, Object> {
    public int f;
    public /* synthetic */ Object g;
    public final /* synthetic */ rr.a<v> h;

    public i0(rr.a<v> a3, d<? super i0> d3) {
        this.h = a3;
        super(2, d3);
    }

    public final d<v> e(Object object, d<?> d3) {
        i0 i02 = new i0(this.h, d3);
        i02.g = object;
        return i02;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final Object h(Object object) {
        kr.a a3 = kr.a.b;
        int n3 = this.f;
        if (n3 != 0) {
            if (n3 != 1) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            co.a.L((Object)object);
            return v.a;
        } else {
            co.a.L((Object)object);
            p p2 = (p)this.g;
            l<c, v> l2 = new l<c, v>(this.h){
                public final /* synthetic */ rr.a<v> c;
                {
                    this.c = a3;
                    super(1);
                }

                public Object y(Object object) {
                    java.util.Objects.requireNonNull((Object)((c)object));
                    this.c.s();
                    return v.a;
                }
            };
            this.f = 1;
            q q2 = p0.a;
            v0 v02 = new v0(p2, q2, null, null, (l)l2, null);
            Object object2 = tn.a.k((rr.p)v02, (d)this);
            if (object2 != a3) {
                object2 = v.a;
            }
            if (object2 != a3) return v.a;
            return a3;
        }
    }

    public Object t0(Object object, Object object2) {
        p p2 = (p)object;
        d d3 = (d)object2;
        i0 i02 = new i0(this.h, (d<? super i0>)d3);
        i02.g = p2;
        return i02.h((Object)v.a);
    }
}

