/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.l$a
 *  e0.g
 *  e0.r0
 *  e0.v
 *  e0.w
 *  e0.x0
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.a
 *  t0.q
 */
package b0;

import b0.k;
import b0.l;
import b0.q;
import e0.g;
import e0.r0;
import e0.v;
import e0.w;
import e0.x0;
import ma.e;

public final class l {
    public static final x0<k> a = w.d((rr.a)a.c);

    public static final long a(long l3, g g3) {
        k k3 = (k)g3.K(a);
        e.f((Object)k3, (String)"$this$contentColorFor");
        long l4 = t0.q.b((long)l3, (long)k3.e()) ? k3.b() : (t0.q.b((long)l3, (long)k3.f()) ? k3.b() : (t0.q.b((long)l3, (long)k3.g()) ? k3.c() : (t0.q.b((long)l3, (long)((t0.q)k3.d.getValue()).a) ? k3.c() : (t0.q.b((long)l3, (long)k3.a()) ? ((t0.q)k3.j.getValue()).a : (t0.q.b((long)l3, (long)k3.h()) ? k3.d() : (t0.q.b((long)l3, (long)((t0.q)k3.g.getValue()).a) ? ((t0.q)k3.l.getValue()).a : t0.q.h))))));
        boolean bl = l4 != t0.q.h;
        if (bl) {
            return l4;
        }
        return ((t0.q)g3.K(q.a)).a;
    }
}

