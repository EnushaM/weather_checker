/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.g
 *  e0.w1
 *  java.lang.Object
 *  t0.q
 */
package b0;

import e0.g;
import e0.w1;
import t0.q;

public interface e {
    public w1<q> a(boolean var1, g var2, int var3);

    public w1<q> b(boolean var1, g var2, int var3);
}

