/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 *  java.util.RandomAccess
 *  ma.e
 *  rr.a
 *  sr.i0
 *  sr.m
 *  tn.a
 *  tr.a
 *  tr.b
 */
package b0;

import b0.s1;
import b0.u0;
import b0.v0;
import e0.z0;
import gr.v;
import java.util.Iterator;
import java.util.List;
import java.util.RandomAccess;
import ma.e;
import sr.i0;
import sr.m;
import tr.a;
import tr.b;

public final class w1
extends m
implements rr.a<v> {
    public final /* synthetic */ s1 c;
    public final /* synthetic */ v0<s1> d;

    public w1(s1 s12, v0<s1> v02) {
        this.c = s12;
        this.d = v02;
        super(0);
    }

    public Object s() {
        if (!e.a((Object)this.c, (Object)this.d.a)) {
            z0 z02;
            List list = this.d.b;
            s1 s12 = this.c;
            e.f(list, (String)"$this$removeAll");
            if (!(list instanceof RandomAccess)) {
                if (list instanceof a && !(list instanceof b)) {
                    i0.e(list, (String)"kotlin.collections.MutableIterable");
                    throw null;
                }
                Iterator iterator = list.iterator();
                while (iterator.hasNext()) {
                    u0 u02 = (u0)iterator.next();
                    e.f((Object)u02, (String)"it");
                    if (!Boolean.valueOf((boolean)e.a(u02.a, (Object)s12)).booleanValue()) continue;
                    iterator.remove();
                }
            } else {
                int n3;
                int n4 = tn.a.n(list);
                int n6 = 0;
                if (n4 >= 0) {
                    int n7 = 0;
                    do {
                        Object object = list.get(n6);
                        u0 u03 = (u0)object;
                        e.f((Object)u03, (String)"it");
                        if (!Boolean.valueOf((boolean)e.a(u03.a, (Object)s12)).booleanValue()) {
                            if (n7 != n6) {
                                list.set(n7, object);
                            }
                            ++n7;
                        }
                        if (n6 == n4) break;
                        ++n6;
                    } while (true);
                    n6 = n7;
                }
                if (n6 < list.size() && (n3 = tn.a.n(list)) >= n6) {
                    do {
                        list.remove(n3);
                        if (n3 == n6) break;
                        --n3;
                    } while (true);
                }
            }
            if ((z02 = this.d.c) != null) {
                z02.invalidate();
            }
        }
        return v.a;
    }
}

