/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.x0
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  l1.u
 *  rr.p
 *  sr.m
 */
package b0;

import b0.e2;
import b0.u2;
import b0.w2;
import b0.x2;
import e.n;
import e0.g;
import e0.x0;
import gr.v;
import l1.u;
import rr.p;
import sr.m;

public final class f2
extends m
implements p<g, Integer, v> {
    public final /* synthetic */ p<g, Integer, v> c;
    public final /* synthetic */ p<g, Integer, v> d;
    public final /* synthetic */ int e;
    public final /* synthetic */ boolean f;

    public f2(p<? super g, ? super Integer, v> p4, p<? super g, ? super Integer, v> p5, int n3, boolean bl) {
        this.c = p4;
        this.d = p5;
        this.e = n3;
        this.f = bl;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        int n3 = ((Number)object2).intValue();
        if ((2 ^ n3 & 11) == 0 && g3.r()) {
            g3.x();
        } else {
            u2.a(g3.K(x2.a).j, n.h(g3, -819890387, true, (Object)new e2(this.c, this.d, this.e, this.f)), g3, 48);
        }
        return v.a;
    }
}

