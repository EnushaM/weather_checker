/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.ui.platform.f0
 *  b0.b1$a
 *  d0.o
 *  e.h
 *  e.n
 *  e0.b2
 *  e0.d
 *  e0.g
 *  e0.g$a
 *  e0.l1
 *  e0.n1
 *  e0.v
 *  e0.w
 *  e0.x0
 *  e0.y0
 *  e1.k
 *  e1.n
 *  f1.a
 *  f1.a$a
 *  gr.v
 *  j1.h
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  k0.b
 *  ma.e
 *  o0.a
 *  o0.a$a
 *  o0.g
 *  o0.g$a
 *  rr.a
 *  rr.p
 *  rr.q
 *  t0.q
 *  u.d
 *  u.w
 *  w.h
 *  w.i
 *  x.f
 *  x.h0
 *  x1.b
 *  x1.h
 */
package b0;

import androidx.compose.ui.platform.f0;
import b0.b1;
import b0.k;
import b0.l;
import b0.p;
import b0.q;
import d0.o;
import e0.b2;
import e0.g;
import e0.l1;
import e0.n1;
import e0.x0;
import e0.y0;
import e1.n;
import f1.a;
import gr.v;
import java.util.Objects;
import ma.e;
import o0.a;
import o0.g;
import u.d;
import u.w;
import w.i;
import x.f;
import x.h0;
import x1.b;
import x1.h;

public final class b1 {
    public static final float a = 24;
    public static final g b = h0.i((g)g.a.b, (float)48);

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void a(rr.a<v> var0, g var1_1, boolean var2_2, w.h var3_3, rr.p<? super e0.g, ? super Integer, v> var4_4, e0.g var5_5, int var6_6, int var7_7) {
        block30 : {
            block29 : {
                block28 : {
                    e.f(var0, (String)"onClick");
                    e.f(var4_4, (String)"content");
                    var8_8 = var5_5.o(1248191244);
                    if ((var7_7 & 1) != 0) {
                        var10_9 = var6_6 | 6;
                    } else if ((var6_6 & 14) == 0) {
                        var60_10 = var8_8.M(var0) != false ? 4 : 2;
                        var10_9 = var60_10 | var6_6;
                    } else {
                        var10_9 = var6_6;
                    }
                    var11_11 = var7_7 & 2;
                    if (var11_11 == 0) break block28;
                    var10_9 |= 48;
                    ** GOTO lbl-1000
                }
                if ((var6_6 & 112) == 0) {
                    var12_12 = var1_1;
                    var59_13 = var8_8.M((Object)var12_12) != false ? 32 : 16;
                    var10_9 |= var59_13;
                } else lbl-1000: // 2 sources:
                {
                    var12_12 = var1_1;
                }
                var13_14 = var7_7 & 4;
                if (var13_14 == 0) break block29;
                var10_9 |= 384;
                ** GOTO lbl-1000
            }
            if ((var6_6 & 896) == 0) {
                var14_15 = var2_2;
                var58_16 = var8_8.c(var14_15) != false ? 256 : 128;
                var10_9 |= var58_16;
            } else lbl-1000: // 2 sources:
            {
                var14_15 = var2_2;
            }
            var15_17 = var7_7 & 8;
            if (var15_17 == 0) break block30;
            var10_9 |= 3072;
            ** GOTO lbl-1000
        }
        if ((var6_6 & 7168) == 0) {
            var16_18 = var3_3;
            var57_19 = var8_8.M((Object)var16_18) != false ? 2048 : 1024;
            var10_9 |= var57_19;
        } else lbl-1000: // 2 sources:
        {
            var16_18 = var3_3;
        }
        if ((var7_7 & 16) != 0) {
            var10_9 |= 24576;
        } else if ((57344 & var6_6) == 0) {
            var56_20 = var8_8.M(var4_4) != false ? 16384 : 8192;
            var10_9 |= var56_20;
        }
        var17_21 = var10_9;
        if ((9362 ^ var17_21 & 46811) == 0 && var8_8.r()) {
            var8_8.x();
            var50_22 = var14_15;
            var26_23 = var8_8;
            var51_24 = var16_18;
        } else {
            if (var11_11 != 0) {
                var18_25 = g.a.b;
            } else {
                var18_26 = var12_12;
            }
            var19_28 = var13_14 != 0 ? true : var14_15;
            if (var15_17 != 0) {
                var8_8.d(-3687241);
                var55_29 = var8_8.e();
                if (var55_29 == g.a.b) {
                    var55_29 = new i();
                    var8_8.E(var55_29);
                }
                var8_8.I();
                var20_30 = (w.h)var55_29;
            } else {
                var20_30 = var16_18;
            }
            var21_31 = o.a((boolean)false, (float)b1.a, (long)0L, (e0.g)var8_8, (int)54, (int)4);
            var22_32 = new j1.h(0);
            var23_33 = var18_27;
            var24_34 = var20_30;
            var25_35 = var19_28;
            var26_23 = var8_8;
            var27_36 = d.b((g)var23_33, (w.h)var24_34, (w)var21_31, (boolean)var25_35, null, (j1.h)var22_32, var0).r(b1.b);
            var28_37 = a.a.c;
            var26_23.d(-1990474327);
            var29_38 = f.d((o0.a)var28_37, (boolean)false, (e0.g)var26_23, (int)0);
            var26_23.d(1376089335);
            var30_39 = (b)var26_23.K((e0.v)f0.e);
            var31_40 = (h)var26_23.K((e0.v)f0.i);
            var32_41 = f1.a.R;
            Objects.requireNonNull((Object)var32_41);
            var34_42 = a.a.b;
            var35_43 = e1.k.a((g)var27_36);
            if (!(var26_23.t() instanceof e0.d)) {
                e.h.p();
                throw null;
            }
            var26_23.q();
            if (var26_23.l()) {
                var26_23.v(var34_42);
            } else {
                var26_23.C();
            }
            var26_23.s();
            e.f((Object)var26_23, (String)"composer");
            Objects.requireNonNull((Object)var32_41);
            b2.a((e0.g)var26_23, (Object)var29_38, (rr.p)a.a.e);
            Objects.requireNonNull((Object)var32_41);
            b2.a((e0.g)var26_23, (Object)var30_39, (rr.p)a.a.d);
            Objects.requireNonNull((Object)var32_41);
            b2.a((e0.g)var26_23, (Object)var31_40, (rr.p)a.a.f);
            var26_23.g();
            e.f((Object)var26_23, (String)"composer");
            var39_44 = new n1(var26_23);
            var40_45 = 0;
            ((k0.b)var35_43).r((Object)var39_44, (Object)var26_23, (Object)var40_45);
            var26_23.d(2058660585);
            var26_23.d(-1253629305);
            var26_23.d(753555776);
            if (var19_28) {
                var26_23.d(753555826);
                var43_46 = ((Number)var26_23.K(p.a)).floatValue();
            } else {
                var26_23.d(753555852);
                var26_23.d(-651892877);
                var43_46 = 0.38f;
                var26_23.d(-1499253717);
                var45_47 = ((t0.q)var26_23.K(q.a)).a;
                if (((k)var26_23.K(l.a)).i()) {
                    e.n.u((long)var45_47);
                } else {
                    e.n.u((long)var45_47);
                }
                var26_23.I();
                var26_23.I();
            }
            var26_23.I();
            var49_48 = new y0[]{p.a.b((Object)Float.valueOf((float)var43_46))};
            e0.w.a((y0[])var49_48, var4_4, (e0.g)var26_23, (int)(8 | 112 & var17_21 >> 9));
            var26_23.I();
            var26_23.I();
            var26_23.I();
            var26_23.J();
            var26_23.I();
            var26_23.I();
            var12_12 = var18_27;
            var50_22 = var19_28;
            var51_24 = var20_30;
        }
        var52_49 = var26_23.u();
        if (var52_49 == null) {
            return;
        }
        var53_50 = new a(var0, var12_12, var50_22, var51_24, var4_4, var6_6, var7_7);
        var52_49.a((rr.p)var53_50);
    }
}

