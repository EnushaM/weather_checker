/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b0.m2$a
 *  b0.m2$b
 *  b0.m2$c
 *  b0.m2$d
 *  b0.m2$e
 *  b0.m2$f
 *  c1.u
 *  e.c
 *  e.n
 *  e0.g
 *  e0.g$a
 *  e0.l1
 *  e0.v
 *  e0.w
 *  e0.x0
 *  e0.y0
 *  gr.v
 *  j1.h
 *  j1.o
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  jr.d
 *  ma.e
 *  o0.g
 *  o0.g$a
 *  rr.a
 *  rr.l
 *  rr.p
 *  t0.e0
 *  t0.i0
 *  t0.q
 *  u.d
 *  u.w
 *  u.y
 *  w.h
 *  w.i
 *  x1.d
 */
package b0;

import b0.k;
import b0.l;
import b0.m2;
import b0.q;
import b0.q0;
import b0.r0;
import c1.u;
import e.n;
import e0.g;
import e0.l1;
import e0.x0;
import e0.y0;
import gr.v;
import j1.h;
import j1.o;
import o0.g;
import rr.p;
import t0.e0;
import t0.i0;
import u.w;
import u.y;
import w.i;

public final class m2 {
    /*
     * Enabled aggressive block sorting
     */
    public static final void a(rr.a<v> a3, g g3, i0 i02, long l3, long l4, e.c c3, float f2, w.h h2, w w3, boolean bl, String string, h h3, p<? super e0.g, ? super Integer, v> p2, e0.g g4, int n2, int n3, int n4) {
        long l5;
        long l6;
        void var47_52;
        int n5;
        w w4;
        e0.g g5;
        float f3;
        int n6;
        e.c c4;
        int n7;
        Object object;
        int n8;
        int n9;
        w.h h4;
        g g6;
        long l7;
        i0 i03;
        void var44_59;
        block58 : {
            int n10;
            block57 : {
                block56 : {
                    ma.e.f(a3, (String)"onClick");
                    ma.e.f((Object)h3, (String)"content");
                    g5 = p2.o(-750962995);
                    if ((n3 & 1) != 0) {
                        object = g4 | 6;
                    } else if ((g4 & 14) == 0) {
                        int n11 = g5.M(a3) ? 4 : 2;
                        object = n11 | g4;
                    } else {
                        object = (Object)g4;
                    }
                    n5 = n3 & 2;
                    if (n5 != 0) {
                        object |= 48;
                    } else if ((g4 & 112) == 0) {
                        int n12 = g5.M((Object)g3) ? 32 : 16;
                        object |= n12;
                    }
                    n8 = n3 & 4;
                    if (n8 != 0) {
                        object |= 384;
                    } else if ((g4 & 896) == 0) {
                        int n13 = g5.M((Object)i02) ? 256 : 128;
                        object |= n13;
                    }
                    if ((g4 & 7168) == 0) {
                        int n14 = (n3 & 8) == 0 && g5.i(l3) ? 2048 : 1024;
                        object |= n14;
                    }
                    if ((g4 & 57344) == 0) {
                        int n15 = n3 & 16;
                        l6 = l4;
                        int n16 = n15 == 0 && g5.i(l6) ? 16384 : 8192;
                        object |= n16;
                    } else {
                        l6 = l4;
                    }
                    if ((n3 & 32) == 0) break block56;
                    n10 = 196608;
                    break block57;
                }
                if ((g4 & 458752) != 0) break block58;
                n10 = g5.M(null) ? 131072 : 65536;
            }
            object |= n10;
        }
        if ((n7 = n3 & 64) != 0) {
            object |= 1572864;
        } else if ((g4 & 3670016) == 0) {
            int n17 = g5.f((float)c3) ? 1048576 : 524288;
            object |= n17;
        }
        int n18 = n3 & 128;
        if (n18 != 0) {
            object |= 12582912;
        } else if ((g4 & 29360128) == 0) {
            int n19 = g5.M((Object)f2) ? 8388608 : 4194304;
            object |= n19;
        }
        if ((g4 & 234881024) == 0) {
            int n20 = (n3 & 256) == 0 && g5.M((Object)h2) ? 67108864 : 33554432;
            object |= n20;
        }
        if ((n9 = n3 & 512) != 0) {
            object |= 805306368;
        } else if ((g4 & 1879048192) == 0) {
            int n21 = g5.c((boolean)w3) ? 536870912 : 268435456;
            object |= n21;
        }
        int n22 = n3 & 1024;
        if (n22 != 0) {
            n6 = n2 | 6;
        } else if ((n2 & 14) == 0) {
            int n23 = g5.M((Object)bl) ? 4 : 2;
            n6 = n2 | n23;
        } else {
            n6 = n2;
        }
        int n24 = n3 & 2048;
        if (n24 != 0) {
            n6 |= 48;
        } else if ((n2 & 112) == 0) {
            int n25 = g5.M((Object)string) ? 32 : 16;
            n6 |= n25;
        }
        int n26 = n6;
        if ((n3 & 4096) != 0) {
            n26 |= 384;
        } else if ((n2 & 896) == 0) {
            int n27 = g5.M((Object)h3) ? 256 : 128;
            n26 |= n27;
        }
        if ((306783378 ^ 1533916891 & object) == 0 && (146 ^ n26 & 731) == 0 && g5.r()) {
            g5.x();
            g6 = g3;
            i03 = i02;
            l7 = l3;
            c4 = c3;
            f3 = f2;
            boolean bl2 = bl;
            String string2 = string;
            l5 = l6;
            h4 = h2;
            w4 = w3;
        } else {
            void var50_68;
            void var47_51;
            Object object2;
            g g7;
            long l8;
            e.c c5;
            Object object3;
            void var44_58;
            i0 i04;
            w.h h5;
            if ((g4 & true) != 0 && !g5.B()) {
                g5.m();
                if ((n3 & 8) != 0) {
                    object &= -7169;
                }
                if ((n3 & 16) != 0) {
                    object &= -57345;
                }
                if ((n3 & 256) != 0) {
                    object &= -234881025;
                }
                g7 = g3;
                l8 = l3;
                c5 = c3;
                float f4 = f2;
                h5 = h2;
                object3 = w3;
                boolean bl3 = bl;
                String string3 = string;
                object2 = object;
                i04 = i02;
            } else {
                i0 i05;
                void var32_75;
                Object object4;
                void var40_85;
                g5.n();
                if (n5 != 0) {
                    g.a a4 = g.a.b;
                } else {
                    g g8 = g3;
                }
                i0 i06 = n8 != 0 ? e0.a : i02;
                if ((n3 & 8) != 0) {
                    long l9 = ((k)g5.K(l.a)).h();
                    object &= -7169;
                    i05 = i06;
                    l8 = l9;
                } else {
                    i05 = i06;
                    l8 = l3;
                }
                if ((n3 & 16) != 0) {
                    l6 = l.a(l8, g5);
                    object &= -57345;
                }
                void var37_79 = var32_75;
                Object object5 = n7 != 0 ? (Object)((float)false) : c3;
                if (n18 != 0) {
                    g5.d(-3687241);
                    Object object6 = g5.e();
                    object4 = object5;
                    if (object6 == g.a.b) {
                        object6 = new i();
                        g5.E(object6);
                    }
                    g5.I();
                    w.h h6 = (w.h)object6;
                } else {
                    object4 = object5;
                    float f5 = f2;
                }
                if ((n3 & 256) != 0) {
                    h5 = (w)g5.K((e0.v)y.a);
                    object &= -234881025;
                } else {
                    h5 = h2;
                }
                Object object7 = n9 != 0 ? true : w3;
                Object object8 = n22 != 0 ? null : (Object)bl;
                if (n24 != 0) {
                    Object var44_55 = null;
                } else {
                    String string4 = string;
                }
                g5.L();
                object2 = object;
                object3 = object7;
                Object object9 = object8;
                i04 = i05;
                c5 = object4;
                void var50_67 = var40_85;
                g7 = var37_79;
            }
            g g9 = u.d.b((g)g.a.b, (w.h)var50_68, (w)h5, (boolean)object3, (String)var47_51, (h)var44_58, a3);
            void var54_89 = var50_68;
            int n28 = object2 >> 3;
            int n29 = n28 & 14 | n28 & 112;
            w.h h7 = h5;
            int n30 = n29 | n28 & 896;
            Object object10 = object3;
            int n31 = n30 | n28 & 7168 | n28 & 57344 | n28 & 458752 | 29360128 & n26 << 15;
            m2.b((g)g7, (i0)i04, (long)l8, (long)l6, (float)c5, (g)g9, (p)h3, (e0.g)g5, (int)n31);
            l7 = l8;
            l5 = l6;
            w4 = object10;
            f3 = var54_89;
            h4 = h7;
            c4 = c5;
            i03 = i04;
            g6 = g7;
        }
        l1 l12 = g5.u();
        if (l12 == null) {
            return;
        }
        l12.a((p)new d(a3, g6, i03, l7, l5, (float)c4, (w.h)f3, (w)h4, (boolean)w4, (String)var47_52, (h)var44_59, (p)h3, (int)g4, n2, n3));
    }

    public static final void b(g g3, i0 i02, long l3, long l4, e.c c3, float f2, g g4, p<? super e0.g, ? super Integer, v> p2, e0.g g5, int n2) {
        Object object;
        e0.g g6;
        Object object2;
        e0.g g7 = p2.o(-750961937);
        if ((g5 & 14) == 0) {
            int n3 = g7.M((Object)g3) ? 4 : 2;
            object = n3 | g5;
        } else {
            object = g5;
        }
        if ((g5 & 112) == 0) {
            int n4 = g7.M((Object)i02) ? 32 : 16;
            object = object | n4;
        }
        if ((g5 & 896) == 0) {
            int n5 = g7.i(l3) ? 256 : 128;
            object = object | n5;
        }
        if ((g5 & 7168) == 0) {
            int n6 = g7.i(l4) ? 2048 : 1024;
            object = object | n6;
        }
        if ((57344 & g5) == 0) {
            int n7 = g7.M(null) ? 16384 : 8192;
            object = object | n7;
        }
        if ((458752 & g5) == 0) {
            int n8 = g7.f((float)c3) ? 131072 : 65536;
            object = object | n8;
        }
        if ((3670016 & g5) == 0) {
            int n9 = g7.M((Object)f2) ? 1048576 : 524288;
            object = object | n9;
        }
        if ((29360128 & g5) == 0) {
            int n10 = g7.M((Object)g4) ? 8388608 : 4194304;
            object = object | n10;
        }
        if ((4793490 ^ (object2 = object) & 23967451) == 0 && g7.r()) {
            g7.x();
            g6 = g7;
        } else {
            long l5;
            x0<x1.d> x02;
            reference var18_26;
            q0 q02 = (q0)g7.K(r0.a);
            x0<x1.d> x03 = r0.b;
            reference var17_24 = c3 + ((x1.d)g7.K(x03)).b;
            if (t0.q.b((long)l3, (long)((k)g7.K(l.a)).h()) && q02 != null) {
                g7.d(-750961487);
                int n11 = 14 & object2 >> 6;
                var18_26 = var17_24;
                x02 = x03;
                l5 = q02.a(l3, (float)var18_26, g7, n11);
                g7.I();
            } else {
                var18_26 = var17_24;
                x02 = x03;
                g7.d(-750961417);
                g7.I();
                l5 = l3;
            }
            y0[] arry0 = new y0[]{q.a.b((Object)new t0.q(l4)), x02.b((Object)new x1.d((float)var18_26))};
            g6 = g7;
            e e2 = new e(g3, (float)c3, i02, l5, (g)f2, (p)g4, (int)object2);
            e0.w.a((y0[])arry0, (p)n.h((e0.g)g6, (int)-819902387, (boolean)true, (Object)e2), (e0.g)g6, (int)56);
        }
        l1 l12 = g6.u();
        if (l12 == null) {
            return;
        }
        f f3 = new f(g3, i02, l3, l4, (float)c3, (g)f2, (p)g4, (int)g5);
        l12.a((p)f3);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static final void c(g var0, i0 var1_1, long var2_2, long var4_3, e.c var6_4, float var7_5, p<? super e0.g, ? super Integer, v> var8_6, e0.g var9_7, int var10_8, int var11_9) {
        block40 : {
            block39 : {
                block38 : {
                    block37 : {
                        block33 : {
                            block36 : {
                                block35 : {
                                    block34 : {
                                        block32 : {
                                            block28 : {
                                                block31 : {
                                                    block30 : {
                                                        block29 : {
                                                            block27 : {
                                                                ma.e.f((Object)var7_5, (String)"content");
                                                                var11_10 = var8_6.o(-750968235);
                                                                var13_11 = var10_8 & 1;
                                                                if (var13_11 != 0) {
                                                                    var15_12 /* !! */  = var9_7 | 6;
                                                                    var14_13 = var0;
                                                                } else if ((var9_7 & 14) == 0) {
                                                                    var14_13 = var0;
                                                                    var56_14 = var11_10.M((Object)var14_13) != false ? 4 : 2;
                                                                    var15_12 /* !! */  = var56_14 | var9_7;
                                                                } else {
                                                                    var14_13 = var0;
                                                                    var15_12 /* !! */  = (int)var9_7;
                                                                }
                                                                var16_15 = var10_8 & 2;
                                                                if (var16_15 == 0) break block27;
                                                                var15_12 /* !! */  |= 48;
                                                                ** GOTO lbl-1000
                                                            }
                                                            if ((var9_7 & 112) == 0) {
                                                                var17_16 = var1_1;
                                                                var55_17 = var11_10.M((Object)var17_16) != false ? 32 : 16;
                                                                var15_12 /* !! */  |= var55_17;
                                                            } else lbl-1000: // 2 sources:
                                                            {
                                                                var17_16 = var1_1;
                                                            }
                                                            if ((var9_7 & 896) != 0) break block28;
                                                            if ((var10_8 & 4) != 0) break block29;
                                                            var18_18 = var2_2;
                                                            if (!var11_10.i(var18_18)) break block30;
                                                            var54_19 = 256;
                                                            break block31;
                                                        }
                                                        var18_18 = var2_2;
                                                    }
                                                    var54_19 = 128;
                                                }
                                                var15_12 /* !! */  |= var54_19;
                                                break block32;
                                            }
                                            var18_18 = var2_2;
                                        }
                                        if ((var9_7 & 7168) != 0) break block33;
                                        if ((var10_8 & 8) != 0) break block34;
                                        var20_20 = var4_3;
                                        if (!var11_10.i(var20_20)) break block35;
                                        var53_21 = 2048;
                                        break block36;
                                    }
                                    var20_20 = var4_3;
                                }
                                var53_21 = 1024;
                            }
                            var15_12 /* !! */  |= var53_21;
                            break block37;
                        }
                        var20_20 = var4_3;
                    }
                    if ((var10_8 & 16) != 0) {
                        var15_12 /* !! */  |= 24576;
                    } else if ((var9_7 & 57344) == 0) {
                        var52_22 = var11_10.M(null) != false ? 16384 : 8192;
                        var15_12 /* !! */  |= var52_22;
                    }
                    var22_23 = var10_8 & 32;
                    if (var22_23 != 0) {
                        var15_12 /* !! */  |= 196608;
                        var24_24 /* !! */  = var6_4;
                    } else {
                        var23_25 = var9_7 & 458752;
                        var24_24 /* !! */  = var6_4;
                        if (var23_25 == 0) {
                            var51_26 = var11_10.f((float)var24_24 /* !! */ ) != false ? 131072 : 65536;
                            var15_12 /* !! */  |= var51_26;
                        }
                    }
                    if ((var10_8 & 64) == 0) break block38;
                    var50_27 = 1572864;
                    break block39;
                }
                if ((var9_7 & 3670016) != 0) break block40;
                var50_27 = var11_10.M((Object)var7_5) != false ? 1048576 : 524288;
            }
            var15_12 /* !! */  |= var50_27;
        }
        if ((599186 ^ var15_12 /* !! */  & 2995931) == 0 && var11_10.r()) {
            var11_10.x();
            var37_28 = var17_16;
            var38_29 = var18_18;
            var40_30 = var20_20;
            var42_31 = var24_24 /* !! */ ;
        } else {
            if ((var9_7 & true) != 0 && !var11_10.B()) {
                var11_10.m();
                if ((var10_8 & 4) != 0) {
                    var15_12 /* !! */  &= -897;
                }
                if ((var10_8 & 8) != 0) {
                    var15_12 /* !! */  &= -7169;
                }
                var27_32 = var17_16;
                var28_33 = var18_18;
                var30_34 = var20_20;
                var32_35 = var24_24 /* !! */ ;
                var33_36 = var14_13;
            } else {
                var11_10.n();
                if (var13_11 != 0) {
                    var25_37 = g.a.b;
                } else {
                    var25_38 = var14_13;
                }
                var26_40 = var16_15 != 0 ? e0.a : var17_16;
                if ((var10_8 & 4) != 0) {
                    var47_41 = ((k)var11_10.K(l.a)).h();
                    var15_12 /* !! */  &= -897;
                    var18_18 = var47_41;
                }
                if ((var10_8 & 8) != 0) {
                    var45_42 = l.a(var18_18, var11_10);
                    var15_12 /* !! */  &= -7169;
                    var20_20 = var45_42;
                }
                if (var22_23 != 0) {
                    var24_24 /* !! */  = (e.c)((float)false);
                }
                var11_10.L();
                var27_32 = var26_40;
                var28_33 = var18_18;
                var30_34 = var20_20;
                var32_35 = var24_24 /* !! */ ;
                var33_36 = var25_39;
            }
            var35_43 = u.a((g)o.a((g)g.a.b, (boolean)false, (rr.l)a.c), (Object)v.a, (p)new b(null));
            var36_44 = var15_12 /* !! */  & 14 | var15_12 /* !! */  & 112 | var15_12 /* !! */  & 896 | var15_12 /* !! */  & 7168 | 57344 & var15_12 /* !! */  | 458752 & var15_12 /* !! */  | 29360128 & var15_12 /* !! */  << 3;
            m2.b((g)var33_36, (i0)var27_32, (long)var28_33, (long)var30_34, (float)var32_35, (g)var35_43, (p)var7_5, (e0.g)var11_10, (int)var36_44);
            var14_13 = var33_36;
            var37_28 = var27_32;
            var38_29 = var28_33;
            var40_30 = var30_34;
            var42_31 = var32_35;
        }
        var43_45 = var11_10.u();
        if (var43_45 == null) {
            return;
        }
        var44_46 = new c(var14_13, var37_28, var38_29, var40_30, (float)var42_31, (p)var7_5, (int)var9_7, var10_8);
        var43_45.a((p)var44_46);
    }
}

