/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e0.r0
 *  e0.u1
 *  java.lang.Object
 *  ks.b
 *  ks.e
 */
package b0;

import e0.r0;
import e0.u1;
import ks.b;
import ks.e;

public final class a2 {
    public final b a = e.a((boolean)false, (int)1);
    public final r0 b = u1.b(null, null, (int)2);
}

