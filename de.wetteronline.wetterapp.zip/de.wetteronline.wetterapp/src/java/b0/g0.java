/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Float
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.a
 *  rr.l
 *  sr.m
 *  v0.f$a
 */
package b0;

import gr.v;
import ma.e;
import rr.a;
import rr.l;
import sr.m;
import v0.f;

public final class g0
extends m
implements l<f, v> {
    public final /* synthetic */ long c;
    public final /* synthetic */ a<Float> d;

    public g0(long l2, a<Float> a3) {
        this.c = l2;
        this.d = a3;
        super(1);
    }

    public Object y(Object object) {
        f f3 = (f)object;
        e.f((Object)f3, (String)"$this$Canvas");
        f.a.e((f)f3, (long)this.c, (long)0L, (long)0L, (float)((Number)this.d.s()).floatValue(), null, null, (int)0, (int)118, null);
        return v.a;
    }
}

