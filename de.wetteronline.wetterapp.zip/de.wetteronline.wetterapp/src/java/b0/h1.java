/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  rr.p
 *  rr.q
 *  sr.m
 */
package b0;

import b0.a2;
import b0.p1;
import e0.g;
import gr.v;
import rr.p;
import rr.q;
import sr.m;

public final class h1
extends m
implements p<g, Integer, v> {
    public final /* synthetic */ q<a2, g, Integer, v> c;
    public final /* synthetic */ p1 d;
    public final /* synthetic */ int e;

    public h1(q<? super a2, ? super g, ? super Integer, v> q2, p1 p12, int n3) {
        this.c = q2;
        this.d = p12;
        this.e = n3;
        super(2);
    }

    public Object t0(Object object, Object object2) {
        g g3 = (g)object;
        int n3 = ((Number)object2).intValue();
        if ((2 ^ n3 & 11) == 0 && g3.r()) {
            g3.x();
        } else {
            this.c.r((Object)this.d.b, (Object)g3, (Object)(112 & this.e >> 9));
        }
        return v.a;
    }
}

