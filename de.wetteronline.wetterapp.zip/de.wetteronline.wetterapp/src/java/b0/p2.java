/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.compose.ui.platform.f0
 *  b0.n2
 *  b0.o2
 *  e0.r0
 *  e0.x0
 *  hr.s
 *  java.lang.Boolean
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Map
 *  java.util.Objects
 *  jr.d
 *  ma.e
 *  o0.g
 *  rr.a
 *  rr.l
 *  rr.p
 *  rr.q
 *  sr.m
 *  v.a0
 *  v.n
 *  v.o
 *  v.p
 *  v.v
 *  v.w
 *  x1.b
 */
package b0;

import androidx.compose.ui.platform.f0;
import b0.f1;
import b0.n2;
import b0.o2;
import b0.q2;
import b0.r2;
import b0.v2;
import e0.r0;
import e0.x0;
import hr.s;
import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import jr.d;
import ma.e;
import o0.g;
import rr.a;
import rr.l;
import rr.p;
import rr.q;
import sr.m;
import v.a0;
import v.n;
import v.o;
import v.v;
import v.w;
import w.h;
import x1.b;

public final class p2
extends m
implements q<g, e0.g, Integer, g> {
    public final /* synthetic */ Map<Float, Object> c;
    public final /* synthetic */ r2<Object> d;
    public final /* synthetic */ a0 e;
    public final /* synthetic */ boolean f;
    public final /* synthetic */ h g;
    public final /* synthetic */ boolean h;
    public final /* synthetic */ f1 i;
    public final /* synthetic */ p<Object, Object, v2> j;
    public final /* synthetic */ float k;

    public p2(Map<Float, Object> map, r2<Object> r22, a0 a02, boolean bl, h h3, boolean bl2, f1 f12, p<Object, Object, ? extends v2> p4, float f3) {
        this.c = map;
        this.d = r22;
        this.e = a02;
        this.f = bl;
        this.g = h3;
        this.h = bl2;
        this.i = f12;
        this.j = p4;
        this.k = f3;
        super(3);
    }

    public Object r(Object object, Object object2, Object object3) {
        g g3 = (g)object;
        e0.g g5 = (e0.g)object2;
        ((Number)object3).intValue();
        e.f((Object)g3, (String)"$this$composed");
        g5.d(1735465469);
        boolean bl = this.c.isEmpty();
        boolean bl2 = true;
        if (bl ^ bl2) {
            if (s.S((Iterable)this.c.values()).size() != this.c.size()) {
                bl2 = false;
            }
            if (bl2) {
                b b3 = (b)g5.K(f0.e);
                r2<Object> r22 = this.d;
                Map<Float, Object> map = this.c;
                Objects.requireNonNull(r22);
                e.f(map, (String)"newAnchors");
                if (r22.c().isEmpty()) {
                    Float f3 = q2.a(map, r22.d());
                    if (f3 != null) {
                        r22.e.setValue((Object)f3);
                        r22.g.setValue((Object)f3);
                    } else {
                        throw new IllegalArgumentException("The initial value must have an associated anchor.".toString());
                    }
                }
                Map<Float, Object> map2 = this.c;
                n2 n22 = new n2(this.d, map2, this.i, b3, this.j, this.k, null);
                e0.f0.c(map2, (p)n22, (e0.g)g5);
                g.a a3 = g.a.b;
                boolean bl3 = (Boolean)this.d.d.getValue();
                r2<Object> r23 = this.d;
                w w3 = r23.p;
                a0 a02 = this.e;
                boolean bl4 = this.f;
                h h3 = this.g;
                o2 o22 = new o2(r23, null);
                boolean bl5 = this.h;
                n n3 = new n(null);
                e.f((Object)a3, (String)"<this>");
                e.f((Object)w3, (String)"state");
                e.f((Object)a02, (String)"orientation");
                e.f((Object)n3, (String)"onDragStarted");
                e.f((Object)o22, (String)"onDragStopped");
                g g6 = v.c((g)a3, (w)w3, (l)o.c, (a0)a02, (boolean)bl4, (h)h3, (a)new v.p(bl3), (q)n3, (q)o22, (boolean)bl5);
                g5.I();
                return g6;
            }
            throw new IllegalArgumentException("You cannot have two anchors mapped to the same state.".toString());
        }
        throw new IllegalArgumentException("You must have at least one anchor.".toString());
    }
}

