/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  e1.m
 *  e1.v
 *  gr.v
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  ma.e
 *  rr.l
 *  rr.p
 *  rr.q
 *  sr.m
 *  tn.a
 *  x.w
 *  x1.a
 *  x1.h
 */
package b0;

import b0.g1;
import b0.j1;
import b0.k1;
import b0.o1;
import b0.s0;
import e.n;
import e0.g;
import e1.j0;
import e1.v;
import gr.v;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import ma.e;
import rr.l;
import rr.p;
import rr.q;
import sr.m;
import tn.a;
import x.w;
import x1.h;

public final class l1
extends m
implements l<v.a, v> {
    public final /* synthetic */ j0 c;
    public final /* synthetic */ p<g, Integer, v> d;
    public final /* synthetic */ p<g, Integer, v> e;
    public final /* synthetic */ p<g, Integer, v> f;
    public final /* synthetic */ int g;
    public final /* synthetic */ int h;
    public final /* synthetic */ boolean i;
    public final /* synthetic */ int j;
    public final /* synthetic */ long k;
    public final /* synthetic */ p<g, Integer, v> l;
    public final /* synthetic */ int m;
    public final /* synthetic */ q<w, g, Integer, v> n;

    public l1(j0 j02, p<? super g, ? super Integer, v> p4, p<? super g, ? super Integer, v> p5, p<? super g, ? super Integer, v> p6, int n3, int n4, boolean bl, int n6, long l2, p<? super g, ? super Integer, v> p7, int n7, q<? super w, ? super g, ? super Integer, v> q2) {
        this.c = j02;
        this.d = p4;
        this.e = p5;
        this.f = p6;
        this.g = n3;
        this.h = n4;
        this.i = bl;
        this.j = n6;
        this.k = l2;
        this.l = p7;
        this.m = n7;
        this.n = q2;
        super(1);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public Object y(Object var1_1) {
        block53 : {
            block54 : {
                block52 : {
                    block51 : {
                        block49 : {
                            block50 : {
                                block47 : {
                                    block48 : {
                                        var2_2 = (v.a)var1_1;
                                        e.f((Object)var2_2, (String)"$this$layout");
                                        var3_3 = this.c.B((Object)o1.b, this.d);
                                        var4_4 = this.k;
                                        var6_5 = new ArrayList(var3_3.size());
                                        var7_6 = -1 + var3_3.size();
                                        if (var7_6 >= 0) {
                                            var128_7 = 0;
                                            do {
                                                var129_8 = var128_7 + 1;
                                                var6_5.add((Object)((e1.m)var3_3.get(var128_7)).v(var4_4));
                                                if (var129_8 > var7_6) break;
                                                var128_7 = var129_8;
                                            } while (true);
                                        }
                                        if (var6_5.isEmpty()) {
                                            var8_9 = null;
                                        } else {
                                            var8_9 = var6_5.get(0);
                                            var122_10 = ((e1.v)var8_9).c;
                                            var123_11 = a.n((List)var6_5);
                                            if (1 <= var123_11) {
                                                var124_12 = 1;
                                                do {
                                                    var125_13 = var124_12 + 1;
                                                    var126_14 = var6_5.get(var124_12);
                                                    var127_15 = ((e1.v)var126_14).c;
                                                    if (var122_10 < var127_15) {
                                                        var8_9 = var126_14;
                                                        var122_10 = var127_15;
                                                    }
                                                    if (var124_12 == var123_11) break;
                                                    var124_12 = var125_13;
                                                } while (true);
                                            }
                                        }
                                        var9_16 = (e1.v)var8_9;
                                        var10_17 = var9_16 == null ? 0 : var9_16.c;
                                        var11_18 = this.c.B((Object)o1.d, this.e);
                                        var12_19 = this.k;
                                        var14_20 = new ArrayList(var11_18.size());
                                        var15_21 = -1 + var11_18.size();
                                        if (var15_21 >= 0) {
                                            var119_22 = 0;
                                            do {
                                                var120_23 = var119_22 + 1;
                                                var14_20.add((Object)((e1.m)var11_18.get(var119_22)).v(var12_19));
                                                if (var120_23 > var15_21) break;
                                                var119_22 = var120_23;
                                            } while (true);
                                        }
                                        if (var14_20.isEmpty()) {
                                            var16_24 = null;
                                        } else {
                                            var16_24 = var14_20.get(0);
                                            var113_25 = ((e1.v)var16_24).c;
                                            var114_26 = a.n((List)var14_20);
                                            if (1 <= var114_26) {
                                                var115_27 = 1;
                                                do {
                                                    var116_28 = var115_27 + 1;
                                                    var117_29 = var14_20.get(var115_27);
                                                    var118_30 = ((e1.v)var117_29).c;
                                                    if (var113_25 < var118_30) {
                                                        var16_24 = var117_29;
                                                        var113_25 = var118_30;
                                                    }
                                                    if (var115_27 == var114_26) break;
                                                    var115_27 = var116_28;
                                                } while (true);
                                            }
                                        }
                                        var17_31 = (e1.v)var16_24;
                                        var18_32 = var17_31 == null ? 0 : var17_31.c;
                                        var19_33 = this.c.B((Object)o1.e, this.f);
                                        var20_34 = this.k;
                                        var22_35 = new ArrayList();
                                        var23_36 = var19_33.iterator();
                                        while (var23_36.hasNext()) {
                                            var110_37 = ((e1.m)var23_36.next()).v(var20_34);
                                            var111_38 = var110_37.c != 0 && var110_37.b != 0;
                                            if (!var111_38) {
                                                var110_37 = null;
                                            }
                                            if (var110_37 == null) continue;
                                            var22_35.add((Object)var110_37);
                                        }
                                        if (!(true ^ var22_35.isEmpty())) break block47;
                                        if (!var22_35.isEmpty()) break block48;
                                        var92_39 = null;
                                        break block49;
                                    }
                                    var92_39 = var22_35.get(0);
                                    var104_40 = ((e1.v)var92_39).b;
                                    var105_41 = a.n((List)var22_35);
                                    if (1 > var105_41) break block49;
                                    break block50;
                                }
                                var24_57 = null;
                                break block51;
                            }
                            var106_42 = 1;
                            do {
                                var107_43 = var106_42 + 1;
                                var108_44 = var22_35.get(var106_42);
                                var109_45 = ((e1.v)var108_44).b;
                                if (var104_40 < var109_45) {
                                    var104_40 = var109_45;
                                    var92_39 = var108_44;
                                }
                                if (var106_42 == var105_41) break;
                                var106_42 = var107_43;
                            } while (true);
                        }
                        e.d((Object)var92_39);
                        var93_46 = ((e1.v)var92_39).b;
                        if (var22_35.isEmpty()) {
                            var94_47 = null;
                        } else {
                            var94_47 = var22_35.get(0);
                            var98_48 = ((e1.v)var94_47).c;
                            var99_49 = a.n((List)var22_35);
                            if (1 <= var99_49) {
                                var100_50 = 1;
                                do {
                                    var101_51 = var100_50 + 1;
                                    var102_52 = var22_35.get(var100_50);
                                    var103_53 = ((e1.v)var102_52).c;
                                    if (var98_48 < var103_53) {
                                        var98_48 = var103_53;
                                        var94_47 = var102_52;
                                    }
                                    if (var100_50 == var99_49) break;
                                    var100_50 = var101_51;
                                } while (true);
                            }
                        }
                        e.d((Object)var94_47);
                        var95_54 = ((e1.v)var94_47).c;
                        var96_55 = this.g == 1;
                        var97_56 = var96_55 ? (this.c.getLayoutDirection() == h.b ? this.h - this.c.Q(g1.b) - var93_46 : this.c.Q(g1.b)) : (this.h - var93_46) / 2;
                        var24_57 = new s0(this.i, var97_56, var93_46, var95_54);
                    }
                    var25_58 = this.c.B((Object)o1.f, n.i(-985538854, true, (Object)new k1(var24_57, this.l, this.m)));
                    var26_59 = this.k;
                    var28_60 = new ArrayList(var25_58.size());
                    var29_61 = -1 + var25_58.size();
                    if (var29_61 >= 0) {
                        var89_62 = 0;
                        do {
                            var90_63 = var89_62 + 1;
                            var28_60.add((Object)((e1.m)var25_58.get(var89_62)).v(var26_59));
                            if (var90_63 > var29_61) break;
                            var89_62 = var90_63;
                        } while (true);
                    }
                    if (var28_60.isEmpty()) {
                        var30_64 = null;
                    } else {
                        var30_64 = var28_60.get(0);
                        var83_65 = ((e1.v)var30_64).c;
                        var84_66 = a.n((List)var28_60);
                        if (1 <= var84_66) {
                            var85_67 = 1;
                            do {
                                var86_68 = var85_67 + 1;
                                var87_69 = var28_60.get(var85_67);
                                var88_70 = ((e1.v)var87_69).c;
                                if (var83_65 < var88_70) {
                                    var83_65 = var88_70;
                                    var30_64 = var87_69;
                                }
                                if (var85_67 == var84_66) break;
                                var85_67 = var86_68;
                            } while (true);
                        }
                    }
                    var31_71 = (e1.v)var30_64;
                    var32_72 = var31_71 == null ? 0 : var31_71.c;
                    if (var24_57 != null) break block52;
                    var33_73 = null;
                    break block53;
                }
                var78_74 = this.c;
                var79_75 = this.i;
                if (var32_72 != 0) break block54;
                var80_76 = var24_57.b;
                var81_77 = var78_74.Q(g1.b);
                ** GOTO lbl179
            }
            if (var79_75) {
                var82_78 = var32_72 + var24_57.b / 2;
            } else {
                var80_76 = var32_72 + var24_57.b;
                var81_77 = var78_74.Q(g1.b);
lbl179: // 2 sources:
                var82_78 = var81_77 + var80_76;
            }
            var33_73 = var82_78;
        }
        if (var18_32 != 0) {
            var77_79 = var33_73 == null ? var32_72 : var33_73;
            var34_80 = var18_32 + var77_79;
        } else {
            var34_80 = 0;
        }
        var35_81 = this.j - var10_17;
        var36_82 = this.c;
        var37_83 = o1.c;
        var38_84 = this.n;
        var39_85 = var22_35;
        var40_86 = var36_82.B((Object)var37_83, n.i(-985545322, true, (Object)new j1(var36_82, var32_72, var38_84, this.m)));
        var41_87 = this.k;
        var43_88 = new ArrayList(var40_86.size());
        var44_89 = -1 + var40_86.size();
        if (var44_89 >= 0) {
            var70_90 = 0;
            do {
                var71_91 = var70_90 + 1;
                var72_92 = (e1.m)var40_86.get(var70_90);
                var73_93 = var35_81;
                var74_94 = var35_81;
                var75_95 = var40_86;
                var43_88.add((Object)var72_92.v(x1.a.a((long)var41_87, (int)0, (int)0, (int)0, (int)var73_93, (int)7)));
                if (var71_91 > var44_89) break;
                var70_90 = var71_91;
                var35_81 = var74_94;
                var40_86 = var75_95;
            } while (true);
        }
        if ((var45_96 = -1 + var43_88.size()) >= 0) {
            var64_97 = 0;
            do {
                var65_98 = var64_97 + 1;
                var66_99 = (e1.v)var43_88.get(var64_97);
                var67_100 = var10_17;
                var68_101 = var10_17;
                var69_102 = var45_96;
                v.a.c(var2_2, var66_99, 0, var67_100, 0.0f, 4, null);
                var64_97 = var65_98;
                if (var64_97 > var69_102) break;
                var45_96 = var69_102;
                var10_17 = var68_101;
            } while (true);
        }
        if ((var46_103 = -1 + var6_5.size()) >= 0) {
            var62_104 = 0;
            do {
                var63_105 = var62_104 + 1;
                v.a.c(var2_2, (e1.v)var6_5.get(var62_104), 0, 0, 0.0f, 4, null);
                if (var63_105 > var46_103) break;
                var62_104 = var63_105;
            } while (true);
        }
        var47_106 = this.j;
        var48_107 = -1 + var14_20.size();
        if (var48_107 >= 0) {
            var60_108 = 0;
            do {
                var61_109 = var60_108 + 1;
                v.a.c(var2_2, (e1.v)var14_20.get(var60_108), 0, var47_106 - var34_80, 0.0f, 4, null);
                if (var61_109 > var48_107) break;
                var60_108 = var61_109;
            } while (true);
        }
        var49_110 = this.j;
        var50_111 = -1 + var28_60.size();
        if (var50_111 >= 0) {
            var58_112 = 0;
            do {
                var59_113 = var58_112 + 1;
                v.a.c(var2_2, (e1.v)var28_60.get(var58_112), 0, var49_110 - var32_72, 0.0f, 4, null);
                if (var59_113 > var50_111) break;
                var58_112 = var59_113;
            } while (true);
        }
        if (var24_57 == null) {
            return v.a;
        }
        var51_114 = this.j;
        var52_115 = -1 + var39_85.size();
        if (var52_115 < 0) return v.a;
        var53_116 = 0;
        do {
            var54_117 = var53_116 + 1;
            var55_118 = var39_85;
            var56_119 = (e1.v)var55_118.get(var53_116);
            var57_120 = var24_57.a;
            e.d((Object)var33_73);
            v.a.c(var2_2, var56_119, var57_120, var51_114 - var33_73, 0.0f, 4, null);
            if (var54_117 > var52_115) {
                return v.a;
            }
            var53_116 = var54_117;
            var39_85 = var55_118;
        } while (true);
    }
}

