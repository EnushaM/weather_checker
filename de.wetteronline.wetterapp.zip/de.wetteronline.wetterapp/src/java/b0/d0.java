/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ds.g0
 *  gr.v
 *  j1.u
 *  j1.w
 *  j1.x
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.a
 *  rr.l
 *  sr.m
 *  zr.j
 */
package b0;

import b0.c0;
import b0.n0;
import b0.o0;
import b0.r2;
import ds.g0;
import gr.v;
import j1.u;
import j1.w;
import j1.x;
import ma.e;
import rr.a;
import rr.l;
import sr.m;
import zr.j;

public final class d0
extends m
implements l<x, v> {
    public final /* synthetic */ String c;
    public final /* synthetic */ n0 d;
    public final /* synthetic */ g0 e;

    public d0(String string, n0 n02, g0 g02) {
        this.c = string;
        this.d = n02;
        this.e = g02;
        super(1);
    }

    public Object y(Object object) {
        x x3 = (x)object;
        e.f((Object)x3, (String)"$this$semantics");
        String string = this.c;
        e.f((Object)x3, (String)"<this>");
        e.f((Object)string, (String)"<set-?>");
        u.c.a(x3, u.a[2], (Object)string);
        boolean bl = this.d.a.d() == o0.c;
        if (bl) {
            u.b((x)x3, null, (a)new c0(this.d, this.e), (int)1);
        }
        return v.a;
    }
}

