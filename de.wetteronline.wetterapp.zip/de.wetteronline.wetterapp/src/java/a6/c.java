/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a6;

import a6.b;

public interface c {
    public c a();

    public boolean b(b var1);

    public boolean c();

    public boolean d(b var1);

    public boolean e(b var1);

    public void f(b var1);

    public void g(b var1);
}

