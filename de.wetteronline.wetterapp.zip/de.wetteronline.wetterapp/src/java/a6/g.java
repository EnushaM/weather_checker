/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.graphics.drawable.Drawable
 *  android.os.SystemClock
 *  android.util.Log
 *  c6.b
 *  c6.c
 *  com.bumptech.glide.d
 *  com.bumptech.glide.e
 *  com.bumptech.glide.load.a
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Objects
 *  java.util.concurrent.Executor
 *  o5.k
 *  t5.a
 */
package a6;

import a6.a;
import a6.b;
import a6.c;
import a6.d;
import a6.f;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.util.Log;
import e6.j;
import f6.d;
import h5.e;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executor;
import k5.l;
import k5.m;
import k5.q;
import k5.v;
import o5.k;

public final class g<R>
implements b,
b6.b,
f {
    public static final boolean C = Log.isLoggable((String)"Request", (int)2);
    public boolean A;
    public RuntimeException B;
    public final f6.d a;
    public final Object b;
    public final d<R> c;
    public final c d;
    public final Context e;
    public final com.bumptech.glide.d f;
    public final Object g;
    public final Class<R> h;
    public final a<?> i;
    public final int j;
    public final int k;
    public final com.bumptech.glide.e l;
    public final b6.c<R> m;
    public final List<d<R>> n;
    public final c6.c<? super R> o;
    public final Executor p;
    public v<R> q;
    public l.d r;
    public long s;
    public volatile l t;
    public int u;
    public Drawable v;
    public Drawable w;
    public Drawable x;
    public int y;
    public int z;

    public g(Context context, com.bumptech.glide.d d2, Object object, Object object2, Class<R> class_, a<?> a2, int n2, int n3, com.bumptech.glide.e e2, b6.c<R> c3, d<R> d3, List<d<R>> list, c c4, l l2, c6.c<? super R> c5, Executor executor) {
        if (C) {
            String.valueOf((int)this.hashCode());
        }
        this.a = new f6.d(){
            public volatile boolean a;

            public void a() {
                if (!this.a) {
                    return;
                }
                throw new IllegalStateException("Already released");
            }
        };
        this.b = object;
        this.e = context;
        this.f = d2;
        this.g = object2;
        this.h = class_;
        this.i = a2;
        this.j = n2;
        this.k = n3;
        this.l = e2;
        this.m = c3;
        this.c = d3;
        this.n = list;
        this.d = c4;
        this.t = l2;
        this.o = c5;
        this.p = executor;
        this.u = 1;
        if (this.B == null && d2.g) {
            this.B = new RuntimeException("Glide request origin trace");
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void a() {
        Object object;
        Object object2 = object = this.b;
        synchronized (object2) {
            if (this.isRunning()) {
                this.clear();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean b() {
        Object object;
        Object object2 = object = this.b;
        synchronized (object2) {
            if (this.u != 6) return false;
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void c() {
        Object object;
        Object object2 = object = this.b;
        synchronized (object2) {
            this.e();
            this.a.a();
            this.s = SystemClock.elapsedRealtimeNanos();
            Object object3 = this.g;
            int n2 = 3;
            if (object3 == null) {
                if (j.h(this.j, this.k)) {
                    this.y = this.j;
                    this.z = this.k;
                }
                if (this.g() == null) {
                    n2 = 5;
                }
                this.l(new q("Received null model"), n2);
                return;
            }
            int n3 = this.u;
            if (n3 == 2) {
                throw new IllegalArgumentException("Cannot restart a running request");
            }
            if (n3 == 4) {
                this.m(this.q, com.bumptech.glide.load.a.f);
                return;
            }
            this.u = n2;
            if (j.h(this.j, this.k)) {
                this.o(this.j, this.k);
            } else {
                this.m.c(this);
            }
            int n4 = this.u;
            if (n4 == 2 || n4 == n2) {
                c c3 = this.d;
                boolean bl = c3 == null || c3.e(this);
                if (bl) {
                    this.m.g(this.h());
                }
            }
            if (C) {
                e6.f.a(this.s);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void clear() {
        Object object;
        c c3;
        Object object2 = object = this.b;
        // MONITORENTER : object2
        this.e();
        this.a.a();
        if (this.u == 6) {
            // MONITOREXIT : object2
            return;
        }
        this.f();
        v<R> v2 = this.q;
        if (v2 != null) {
            this.q = null;
        } else {
            v2 = null;
        }
        boolean bl = (c3 = this.d) == null || c3.b(this);
        if (bl) {
            this.m.h(this.h());
        }
        this.u = 6;
        // MONITOREXIT : object2
        if (v2 == null) return;
        this.t.e(v2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean d() {
        Object object;
        Object object2 = object = this.b;
        synchronized (object2) {
            if (this.u != 4) return false;
            return true;
        }
    }

    public final void e() {
        if (!this.A) {
            return;
        }
        throw new IllegalStateException("You can't start or clear loads in RequestListener or Target callbacks. If you're trying to start a fallback request when a load fails, use RequestBuilder#error(RequestBuilder). Otherwise consider posting your into() or clear() calls to the main thread using a Handler instead.");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void f() {
        this.e();
        this.a.a();
        this.m.f(this);
        l.d d2 = this.r;
        if (d2 != null) {
            l l2;
            l l3 = l2 = d2.c;
            synchronized (l3) {
                d2.a.h(d2.b);
            }
            this.r = null;
            return;
        }
    }

    public final Drawable g() {
        if (this.x == null) {
            int n2;
            Drawable drawable;
            a<?> a2 = this.i;
            this.x = drawable = a2.p;
            if (drawable == null && (n2 = a2.q) > 0) {
                this.x = this.k(n2);
            }
        }
        return this.x;
    }

    public final Drawable h() {
        if (this.w == null) {
            int n2;
            Drawable drawable;
            a<?> a2 = this.i;
            this.w = drawable = a2.h;
            if (drawable == null && (n2 = a2.i) > 0) {
                this.w = this.k(n2);
            }
        }
        return this.w;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean i(b b2) {
        boolean bl;
        int n2;
        com.bumptech.glide.e e2;
        int n3;
        Object object;
        Object object2;
        int n4;
        com.bumptech.glide.e e3;
        Object object3;
        Class<R> class_;
        a<?> a2;
        a<?> a3;
        Class<R> class_2;
        Object object4;
        int n6;
        int n7;
        int n8;
        if (!(b2 instanceof g)) {
            return false;
        }
        Object object5 = object4 = this.b;
        synchronized (object5) {
            n6 = this.j;
            n4 = this.k;
            object2 = this.g;
            class_ = this.h;
            a2 = this.i;
            e2 = this.l;
            List<d<R>> list = this.n;
            n8 = list != null ? list.size() : 0;
        }
        g g2 = (g)b2;
        Object object6 = object = g2.b;
        synchronized (object6) {
            n3 = g2.j;
            n7 = g2.k;
            object3 = g2.g;
            class_2 = g2.h;
            a3 = g2.i;
            e3 = g2.l;
            List<d<R>> list = g2.n;
            n2 = list != null ? list.size() : 0;
        }
        if (n6 != n3) return false;
        if (n4 != n7) return false;
        if (object2 == null) {
            if (object3 != null) return false;
            bl = true;
        } else {
            bl = object2 instanceof k ? ((k)object2).a(object3) : object2.equals(object3);
        }
        if (!bl) return false;
        if (!class_.equals(class_2)) return false;
        if (!a2.equals(a3)) return false;
        if (e2 != e3) return false;
        if (n8 != n2) return false;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean isRunning() {
        Object object;
        Object object2 = object = this.b;
        synchronized (object2) {
            int n2 = this.u;
            if (n2 == 2) return true;
            if (n2 != 3) return false;
            return true;
        }
    }

    public final boolean j() {
        c c3 = this.d;
        return c3 == null || !c3.a().c();
        {
        }
    }

    public final Drawable k(int n2) {
        Resources.Theme theme = this.i.v;
        if (theme == null) {
            theme = this.e.getTheme();
        }
        com.bumptech.glide.d d2 = this.f;
        return t5.a.a((Context)d2, (Context)d2, (int)n2, (Resources.Theme)theme);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void l(q q3, int n2) {
        Object object;
        this.a.a();
        Object object2 = object = this.b;
        synchronized (object2) {
            d<R> d2;
            boolean bl;
            boolean bl2;
            block13 : {
                block12 : {
                    Objects.requireNonNull((Object)((Object)q3));
                    int n3 = this.f.h;
                    if (n3 <= n2) {
                        Objects.toString((Object)this.g);
                        if (n3 <= 4) {
                            ArrayList arrayList = new ArrayList();
                            q3.a((Throwable)q3, (List<Throwable>)arrayList);
                            int n4 = arrayList.size();
                            int n6 = 0;
                            while (n6 < n4) {
                                int n7 = n6 + 1;
                                (Throwable)arrayList.get(n6);
                                n6 = n7;
                            }
                        }
                    }
                    this.r = null;
                    this.u = 5;
                    this.A = bl = true;
                    try {
                        List<d<R>> list = this.n;
                        if (list == null) break block12;
                        Iterator iterator = list.iterator();
                        bl2 = false;
                        while (iterator.hasNext()) {
                            bl2 |= ((d)iterator.next()).a(q3, this.g, this.m, this.j());
                        }
                        break block13;
                    }
                    catch (Throwable throwable) {
                        this.A = false;
                        throw throwable;
                    }
                }
                bl2 = false;
            }
            if ((d2 = this.c) == null || !d2.a(q3, this.g, this.m, this.j())) {
                bl = false;
            }
            if (!(bl2 | bl)) {
                this.p();
            }
            this.A = false;
            c c3 = this.d;
            if (c3 != null) {
                c3.f(this);
            }
            return;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void m(v<?> v2, com.bumptech.glide.load.a a2) {
        g g2;
        v<?> v3;
        void var4_24;
        block17 : {
            void var10_15;
            block18 : {
                block16 : {
                    Object obj;
                    block14 : {
                        block15 : {
                            boolean bl;
                            Object object;
                            this.a.a();
                            v3 = null;
                            Object object2 = object = this.b;
                            // MONITORENTER : object2
                            this.r = null;
                            if (v2 == null) {
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Expected to receive a Resource<R> with an object of ");
                                stringBuilder.append(this.h);
                                stringBuilder.append(" inside, but instead got null.");
                                this.l(new q(stringBuilder.toString()), 5);
                                // MONITOREXIT : object2
                                return;
                            }
                            obj = v2.get();
                            if (obj == null || !this.h.isAssignableFrom(obj.getClass())) break block14;
                            c c3 = this.d;
                            boolean bl2 = c3 == null || (bl = c3.d(this));
                            if (bl2) break block15;
                            this.q = null;
                            this.u = 4;
                            // MONITOREXIT : object2
                            break block16;
                        }
                        this.n(v2, obj, a2);
                        // MONITOREXIT : object2
                        return;
                    }
                    try {
                        this.q = null;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Expected to receive an object of ");
                        stringBuilder.append(this.h);
                        stringBuilder.append(" but instead got ");
                        String string = obj != null ? obj.getClass() : "";
                        stringBuilder.append((Object)string);
                        stringBuilder.append("{");
                        stringBuilder.append(obj);
                        stringBuilder.append("} inside Resource{");
                        stringBuilder.append(v2);
                        stringBuilder.append("}.");
                        String string2 = obj != null ? "" : " To indicate failure return a null Resource object, rather than a Resource object containing null data.";
                        stringBuilder.append(string2);
                        this.l(new q(stringBuilder.toString()), 5);
                        // MONITOREXIT : object2
                    }
                    catch (Throwable throwable) {
                        v3 = v2;
                        g2 = this;
                    }
                }
                this.t.e(v2);
                return;
                break block18;
                catch (Throwable throwable) {
                    g g3;
                    Throwable throwable2;
                    g g4 = g3 = this;
                    var10_15 = throwable2;
                    g2 = g4;
                }
            }
            try {
                throw var10_15;
            }
            catch (Throwable throwable) {
                break block17;
            }
            catch (Throwable throwable) {
                g2 = this;
            }
        }
        if (v3 == null) throw var4_24;
        g2.t.e(v3);
        throw var4_24;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void n(v<R> v2, R r3, com.bumptech.glide.load.a a2) {
        d<R> d2;
        boolean bl;
        boolean bl2;
        boolean bl3;
        block8 : {
            block7 : {
                bl3 = this.j();
                this.u = 4;
                this.q = v2;
                if (this.f.h <= 3) {
                    Objects.toString((Object)a2);
                    Objects.toString((Object)this.g);
                    e6.f.a(this.s);
                }
                this.A = bl = true;
                try {
                    List<d<R>> list = this.n;
                    if (list == null) break block7;
                    Iterator iterator = list.iterator();
                    bl2 = false;
                    while (iterator.hasNext()) {
                        bl2 |= ((d)iterator.next()).b(r3, this.g, this.m, a2, bl3);
                    }
                    break block8;
                }
                catch (Throwable throwable) {
                    this.A = false;
                    throw throwable;
                }
            }
            bl2 = false;
        }
        if ((d2 = this.c) == null || !d2.b(r3, this.g, this.m, a2, bl3)) {
            bl = false;
        }
        if (!(bl | bl2)) {
            Objects.requireNonNull(this.o);
            c6.a<?> a3 = c6.a.a;
            this.m.e(r3, a3);
        }
        this.A = false;
        c c3 = this.d;
        if (c3 != null) {
            c3.g(this);
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void o(int n2, int n3) {
        void var5_35;
        Object object3;
        block17 : {
            l.d d2;
            Object object;
            int n4 = n2;
            this.a.a();
            Object object2 = object = this.b;
            // MONITORENTER : object2
            boolean bl = C;
            if (bl) {
                e6.f.a(this.s);
            }
            if (this.u != 3) {
                // MONITOREXIT : object2
                return;
            }
            this.u = 2;
            float f2 = this.i.c;
            if (n4 != Integer.MIN_VALUE) {
                n4 = Math.round((float)(f2 * (float)n4));
            }
            this.y = n4;
            int n6 = n3 == Integer.MIN_VALUE ? n3 : Math.round((float)(f2 * (float)n3));
            this.z = n6;
            if (bl) {
                e6.f.a(this.s);
            }
            l l2 = this.t;
            com.bumptech.glide.d d3 = this.f;
            Object object4 = this.g;
            a<?> a2 = this.i;
            h5.c c3 = a2.m;
            int n7 = this.y;
            int n8 = this.z;
            Class<?> class_ = a2.t;
            Class<R> class_2 = this.h;
            com.bumptech.glide.e e2 = this.l;
            k5.k k2 = a2.d;
            Map<Class<?>, h5.g<?>> map = a2.s;
            boolean bl2 = a2.n;
            boolean bl3 = a2.z;
            e e3 = a2.r;
            boolean bl4 = a2.j;
            boolean bl5 = a2.x;
            boolean bl6 = a2.A;
            boolean bl7 = a2.y;
            Executor executor = this.p;
            object3 = object;
            try {
                d2 = l2.b(d3, object4, c3, n7, n8, class_, class_2, e2, k2, map, bl2, bl3, e3, bl4, bl5, bl6, bl7, this, executor);
            }
            catch (Throwable throwable) {
                break block17;
            }
            try {
                this.r = d2;
                if (this.u != 2) {
                    this.r = null;
                }
                if (bl) {
                    e6.f.a(this.s);
                }
                // MONITOREXIT : object3
                return;
            }
            catch (Throwable throwable) {}
            break block17;
            catch (Throwable throwable) {
                object3 = object;
            }
            break block17;
            catch (Throwable throwable) {
                object3 = object;
            }
        }
        Object object5 = object3;
        throw var5_35;
    }

    public final void p() {
        c c3 = this.d;
        boolean bl = c3 == null || c3.e(this);
        if (!bl) {
            return;
        }
        Object object = this.g;
        Drawable drawable = null;
        if (object == null) {
            drawable = this.g();
        }
        if (drawable == null) {
            if (this.v == null) {
                Drawable drawable2;
                int n2;
                a<?> a2 = this.i;
                this.v = drawable2 = a2.f;
                if (drawable2 == null && (n2 = a2.g) > 0) {
                    this.v = this.k(n2);
                }
            }
            drawable = this.v;
        }
        if (drawable == null) {
            drawable = this.h();
        }
        this.m.d(drawable);
    }
}

