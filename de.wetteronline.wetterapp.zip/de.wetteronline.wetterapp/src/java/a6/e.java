/*
 * Decompiled with CFR 0.0.
 */
package a6;

import a6.a;

public class e
extends a<e> {
}

