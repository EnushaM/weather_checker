/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b6.c
 *  com.bumptech.glide.load.a
 *  java.lang.Object
 *  k5.q
 */
package a6;

import b6.c;
import com.bumptech.glide.load.a;
import k5.q;

public interface d<R> {
    public boolean a(q var1, Object var2, c<R> var3, boolean var4);

    public boolean b(R var1, Object var2, c<R> var3, a var4, boolean var5);
}

