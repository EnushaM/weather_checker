/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.graphics.Bitmap
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  androidx.collection.a
 *  com.bumptech.glide.e
 *  d6.a
 *  e6.b
 *  e6.j
 *  h5.c
 *  h5.d
 *  h5.e
 *  h5.g
 *  java.lang.Class
 *  java.lang.CloneNotSupportedException
 *  java.lang.Cloneable
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Map
 *  java.util.Objects
 *  k5.k
 *  r5.k
 *  v5.c
 *  v5.e
 */
package a6;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import e6.b;
import e6.j;
import h5.c;
import h5.d;
import h5.e;
import h5.g;
import java.util.Map;
import java.util.Objects;
import r5.k;

public abstract class a<T extends a<T>>
implements Cloneable {
    public boolean A;
    public int b;
    public float c = 1.0f;
    public k5.k d = k5.k.c;
    public com.bumptech.glide.e e = com.bumptech.glide.e.d;
    public Drawable f;
    public int g;
    public Drawable h;
    public int i;
    public boolean j = true;
    public int k = -1;
    public int l = -1;
    public c m = d6.a.b;
    public boolean n;
    public boolean o = true;
    public Drawable p;
    public int q;
    public e r = new e();
    public Map<Class<?>, g<?>> s = new b();
    public Class<?> t = Object.class;
    public boolean u;
    public Resources.Theme v;
    public boolean w;
    public boolean x;
    public boolean y;
    public boolean z = true;

    public static boolean f(int n2, int n3) {
        return (n2 & n3) != 0;
    }

    public T a(a<?> a3) {
        if (this.w) {
            return ((a)this.c()).a(a3);
        }
        if (a.f(a3.b, 2)) {
            this.c = a3.c;
        }
        if (a.f(a3.b, 262144)) {
            this.x = a3.x;
        }
        if (a.f(a3.b, 1048576)) {
            this.A = a3.A;
        }
        if (a.f(a3.b, 4)) {
            this.d = a3.d;
        }
        if (a.f(a3.b, 8)) {
            this.e = a3.e;
        }
        if (a.f(a3.b, 16)) {
            this.f = a3.f;
            this.g = 0;
            this.b = -33 & this.b;
        }
        if (a.f(a3.b, 32)) {
            this.g = a3.g;
            this.f = null;
            this.b = -17 & this.b;
        }
        if (a.f(a3.b, 64)) {
            this.h = a3.h;
            this.i = 0;
            this.b = -129 & this.b;
        }
        if (a.f(a3.b, 128)) {
            this.i = a3.i;
            this.h = null;
            this.b = -65 & this.b;
        }
        if (a.f(a3.b, 256)) {
            this.j = a3.j;
        }
        if (a.f(a3.b, 512)) {
            this.l = a3.l;
            this.k = a3.k;
        }
        if (a.f(a3.b, 1024)) {
            this.m = a3.m;
        }
        if (a.f(a3.b, 4096)) {
            this.t = a3.t;
        }
        if (a.f(a3.b, 8192)) {
            this.p = a3.p;
            this.q = 0;
            this.b = -16385 & this.b;
        }
        if (a.f(a3.b, 16384)) {
            this.q = a3.q;
            this.p = null;
            this.b = -8193 & this.b;
        }
        if (a.f(a3.b, 32768)) {
            this.v = a3.v;
        }
        if (a.f(a3.b, 65536)) {
            this.o = a3.o;
        }
        if (a.f(a3.b, 131072)) {
            this.n = a3.n;
        }
        if (a.f(a3.b, 2048)) {
            this.s.putAll(a3.s);
            this.z = a3.z;
        }
        if (a.f(a3.b, 524288)) {
            this.y = a3.y;
        }
        if (!this.o) {
            int n2;
            this.s.clear();
            this.b = n2 = -2049 & this.b;
            this.n = false;
            this.b = n2 & -131073;
            this.z = true;
        }
        this.b |= a3.b;
        this.r.d(a3.r);
        this.j();
        return (T)this;
    }

    public T c() {
        a a3;
        try {
            b b2;
            e e2;
            a3 = (a)super.clone();
            a3.r = e2 = new e();
            e2.d(this.r);
            a3.s = b2 = new b();
            b2.putAll(this.s);
            a3.u = false;
            a3.w = false;
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            throw new RuntimeException((Throwable)cloneNotSupportedException);
        }
        return (T)a3;
    }

    public T d(Class<?> class_) {
        if (this.w) {
            return ((a)this.c()).d(class_);
        }
        Objects.requireNonNull(class_, (String)"Argument must not be null");
        this.t = class_;
        this.b = 4096 | this.b;
        this.j();
        return (T)this;
    }

    public T e(k5.k k2) {
        if (this.w) {
            return ((a)this.c()).e(k2);
        }
        Objects.requireNonNull((Object)k2, (String)"Argument must not be null");
        this.d = k2;
        this.b = 4 | this.b;
        this.j();
        return (T)this;
    }

    public boolean equals(Object object) {
        boolean bl = object instanceof a;
        boolean bl2 = false;
        if (bl) {
            a a3 = (a)object;
            int n2 = Float.compare((float)a3.c, (float)this.c);
            bl2 = false;
            if (n2 == 0) {
                int n3 = this.g;
                int n4 = a3.g;
                bl2 = false;
                if (n3 == n4) {
                    boolean bl3 = j.a((Object)this.f, (Object)a3.f);
                    bl2 = false;
                    if (bl3) {
                        int n5 = this.i;
                        int n6 = a3.i;
                        bl2 = false;
                        if (n5 == n6) {
                            boolean bl4 = j.a((Object)this.h, (Object)a3.h);
                            bl2 = false;
                            if (bl4) {
                                int n7 = this.q;
                                int n8 = a3.q;
                                bl2 = false;
                                if (n7 == n8) {
                                    boolean bl5 = j.a((Object)this.p, (Object)a3.p);
                                    bl2 = false;
                                    if (bl5) {
                                        boolean bl6 = this.j;
                                        boolean bl7 = a3.j;
                                        bl2 = false;
                                        if (bl6 == bl7) {
                                            int n9 = this.k;
                                            int n10 = a3.k;
                                            bl2 = false;
                                            if (n9 == n10) {
                                                int n11 = this.l;
                                                int n12 = a3.l;
                                                bl2 = false;
                                                if (n11 == n12) {
                                                    boolean bl8 = this.n;
                                                    boolean bl9 = a3.n;
                                                    bl2 = false;
                                                    if (bl8 == bl9) {
                                                        boolean bl10 = this.o;
                                                        boolean bl11 = a3.o;
                                                        bl2 = false;
                                                        if (bl10 == bl11) {
                                                            boolean bl12 = this.x;
                                                            boolean bl13 = a3.x;
                                                            bl2 = false;
                                                            if (bl12 == bl13) {
                                                                boolean bl14 = this.y;
                                                                boolean bl15 = a3.y;
                                                                bl2 = false;
                                                                if (bl14 == bl15) {
                                                                    boolean bl16 = this.d.equals((Object)a3.d);
                                                                    bl2 = false;
                                                                    if (bl16) {
                                                                        com.bumptech.glide.e e2 = this.e;
                                                                        com.bumptech.glide.e e3 = a3.e;
                                                                        bl2 = false;
                                                                        if (e2 == e3) {
                                                                            boolean bl17 = this.r.equals((Object)a3.r);
                                                                            bl2 = false;
                                                                            if (bl17) {
                                                                                boolean bl18 = this.s.equals(a3.s);
                                                                                bl2 = false;
                                                                                if (bl18) {
                                                                                    boolean bl19 = this.t.equals(a3.t);
                                                                                    bl2 = false;
                                                                                    if (bl19) {
                                                                                        boolean bl20 = j.a((Object)this.m, (Object)a3.m);
                                                                                        bl2 = false;
                                                                                        if (bl20) {
                                                                                            boolean bl21 = j.a((Object)this.v, (Object)a3.v);
                                                                                            bl2 = false;
                                                                                            if (bl21) {
                                                                                                bl2 = true;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return bl2;
    }

    public T g(int n2, int n3) {
        if (this.w) {
            return ((a)this.c()).g(n2, n3);
        }
        this.l = n2;
        this.k = n3;
        this.b = 512 | this.b;
        this.j();
        return (T)this;
    }

    public T h(int n2) {
        int n3;
        if (this.w) {
            return ((a)this.c()).h(n2);
        }
        this.i = n2;
        this.b = n3 = 128 | this.b;
        this.h = null;
        this.b = n3 & -65;
        this.j();
        return (T)this;
    }

    public int hashCode() {
        float f2 = this.c;
        int n2 = 527 + Float.floatToIntBits((float)f2);
        int n3 = this.g + n2 * 31;
        int n4 = j.e((Object)this.f, (int)n3);
        int n5 = this.i + n4 * 31;
        int n6 = j.e((Object)this.h, (int)n5);
        int n7 = this.q + n6 * 31;
        int n8 = j.e((Object)this.p, (int)n7);
        int n9 = this.j + n8 * 31;
        int n10 = this.k + n9 * 31;
        int n11 = this.l + n10 * 31;
        int n12 = this.n + n11 * 31;
        int n13 = this.o + n12 * 31;
        int n14 = this.x + n13 * 31;
        int n15 = this.y + n14 * 31;
        int n16 = j.e((Object)this.d, (int)n15);
        int n17 = j.e((Object)this.e, (int)n16);
        int n18 = j.e((Object)this.r, (int)n17);
        int n19 = j.e(this.s, (int)n18);
        int n20 = j.e(this.t, (int)n19);
        int n21 = j.e((Object)this.m, (int)n20);
        return j.e((Object)this.v, (int)n21);
    }

    public T i(com.bumptech.glide.e e2) {
        if (this.w) {
            return ((a)this.c()).i(e2);
        }
        Objects.requireNonNull((Object)e2, (String)"Argument must not be null");
        this.e = e2;
        this.b = 8 | this.b;
        this.j();
        return (T)this;
    }

    public final T j() {
        if (!this.u) {
            return (T)this;
        }
        throw new IllegalStateException("You cannot modify locked T, consider clone()");
    }

    public <Y> T k(d<Y> d2, Y y) {
        if (this.w) {
            return ((a)this.c()).k(d2, y);
        }
        Objects.requireNonNull(d2, (String)"Argument must not be null");
        Objects.requireNonNull(y, (String)"Argument must not be null");
        this.r.b.put(d2, y);
        this.j();
        return (T)this;
    }

    public T l(c c2) {
        if (this.w) {
            return ((a)this.c()).l(c2);
        }
        Objects.requireNonNull((Object)c2, (String)"Argument must not be null");
        this.m = c2;
        this.b = 1024 | this.b;
        this.j();
        return (T)this;
    }

    public T m(boolean bl) {
        if (this.w) {
            return ((a)this.c()).m(true);
        }
        this.j = bl ^ true;
        this.b = 256 | this.b;
        this.j();
        return (T)this;
    }

    public T n(g<Bitmap> g3, boolean bl) {
        if (this.w) {
            return ((a)this.c()).n(g3, bl);
        }
        k k2 = new k(g3, bl);
        this.o(Bitmap.class, g3, bl);
        this.o((Class<Y>)Drawable.class, (g<Y>)k2, bl);
        this.o((Class<Y>)BitmapDrawable.class, (g<Y>)k2, bl);
        this.o((Class<Y>)v5.c.class, (g<Y>)new v5.e(g3), bl);
        this.j();
        return (T)this;
    }

    public <Y> T o(Class<Y> class_, g<Y> g3, boolean bl) {
        int n2;
        int n3;
        if (this.w) {
            return ((a)this.c()).o(class_, g3, bl);
        }
        Objects.requireNonNull(class_, (String)"Argument must not be null");
        Objects.requireNonNull(g3, (String)"Argument must not be null");
        this.s.put(class_, g3);
        this.b = n2 = 2048 | this.b;
        this.o = true;
        this.b = n3 = n2 | 65536;
        this.z = false;
        if (bl) {
            this.b = n3 | 131072;
            this.n = true;
        }
        this.j();
        return (T)this;
    }

    public T p(boolean bl) {
        if (this.w) {
            return ((a)this.c()).p(bl);
        }
        this.A = bl;
        this.b = 1048576 | this.b;
        this.j();
        return (T)this;
    }
}

