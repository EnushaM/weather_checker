/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a6;

public interface b {
    public void a();

    public boolean b();

    public void c();

    public void clear();

    public boolean d();

    public boolean isRunning();
}

