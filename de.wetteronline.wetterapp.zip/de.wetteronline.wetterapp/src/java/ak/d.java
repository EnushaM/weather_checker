/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.swiperefreshlayout.widget.SwipeRefreshLayout
 *  java.lang.Object
 */
package ak;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import gr.v;
import kj.a;
import sr.m;

public final class d
extends m
implements rr.a<v> {
    public final /* synthetic */ a c;

    public d(a a2) {
        this.c = a2;
        super(0);
    }

    @Override
    public Object s() {
        ((SwipeRefreshLayout)this.c.g).setRefreshing(false);
        return v.a;
    }
}

