/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.swiperefreshlayout.widget.SwipeRefreshLayout
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  kj.a
 *  ma.e
 */
package ak;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import kj.a;
import ma.e;

public final class b
implements Runnable {
    public final /* synthetic */ int b;
    public final /* synthetic */ a c;

    public /* synthetic */ b(a a3, int n2) {
        this.b = n2;
        this.c = a3;
    }

    public final void run() {
        switch (this.b) {
            default: {
                break;
            }
            case 1: {
                a a3 = this.c;
                e.f((Object)a3, (String)"$this_with");
                ((SwipeRefreshLayout)a3.g).setRefreshing(false);
                return;
            }
            case 0: {
                a a4 = this.c;
                e.f((Object)a4, (String)"$this_with");
                ((SwipeRefreshLayout)a4.g).setRefreshing(true);
                return;
            }
        }
        a a5 = this.c;
        e.f((Object)a5, (String)"$this_with");
        ((SwipeRefreshLayout)a5.g).setRefreshing(false);
    }
}

