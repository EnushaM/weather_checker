/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ak.c
 *  android.webkit.DownloadListener
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 */
package ak;

import ak.c;
import android.webkit.DownloadListener;
import ma.e;

public final class a
implements DownloadListener {
    public final /* synthetic */ c b;

    public /* synthetic */ a(c c2) {
        this.b = c2;
    }

    public final void onDownloadStart(String string, String string2, String string3, String string4, long l3) {
        c c2 = this.b;
        e.f((Object)c2, (String)"this$0");
        e.e((Object)string, (String)"url");
        c2.z(string);
    }
}

