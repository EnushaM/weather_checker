/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ActivityNotFoundException
 *  android.content.ComponentCallbacks
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.net.Uri
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.ViewGroup
 *  android.webkit.DownloadListener
 *  android.webkit.WebChromeClient
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.FrameLayout
 *  android.widget.RelativeLayout
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.l
 *  androidx.swiperefreshlayout.widget.SwipeRefreshLayout
 *  androidx.swiperefreshlayout.widget.SwipeRefreshLayout$h
 *  bd.b
 *  de.wetteronline.components.app.webcontent.WoWebView
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 *  java.util.Objects
 *  ma.e
 *  os.g1
 *  ou.a
 *  pi.b
 *  pi.c
 *  pi.c$a
 *  pi.d
 *  qi.j0
 *  qi.k0
 *  qi.l
 *  qi.m0
 *  rh.b
 *  rk.a
 *  rm.c
 *  rm.f
 *  sr.e0
 *  sr.g
 *  tn.a
 *  ui.e
 *  vn.w
 *  w9.b
 *  wi.a
 *  wj.a
 */
package ak;

import ak.c;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import de.wetteronline.components.app.webcontent.WoWebView;
import de.wetteronline.components.fragments.Page;
import de.wetteronline.views.NoConnectionLayout;
import ds.g0;
import e.k;
import gr.v;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import kh.p;
import os.g1;
import pi.c;
import qi.j0;
import qi.k0;
import qi.l;
import qi.m0;
import rh.o0;
import sr.e0;
import vn.w;

public final class c
extends qm.a
implements SwipeRefreshLayout.h,
pi.c,
NoConnectionLayout.b,
rm.f {
    public static final a Companion = new Object(null){};
    public final /* synthetic */ bd.b R0;
    public final gr.g S0;
    public final gr.g T0;
    public final gr.g U0;
    public final gr.g V0;
    public final gr.g W0;
    public final gr.g X0;
    public final wj.a Y0;
    public kj.a Z0;
    public final gr.g a1;
    public final String b1;

    public c() {
        this.R0 = new bd.b(5);
        gr.h h3 = gr.h.b;
        this.S0 = tn.a.r((gr.h)h3, (rr.a)new rr.a<p>((ComponentCallbacks)this, null, null){
            public final /* synthetic */ ComponentCallbacks c;
            {
                this.c = componentCallbacks;
                super(0);
            }

            public final p s() {
                return g1.a((ComponentCallbacks)this.c).b(e0.a(p.class), null, null);
            }
        });
        this.T0 = tn.a.r((gr.h)h3, (rr.a)new rr.a<rm.c>((ComponentCallbacks)this, null, null){
            public final /* synthetic */ ComponentCallbacks c;
            {
                this.c = componentCallbacks;
                super(0);
            }

            public final rm.c s() {
                return g1.a((ComponentCallbacks)this.c).b(e0.a(rm.c.class), null, null);
            }
        });
        this.U0 = tn.a.r((gr.h)h3, (rr.a)new rr.a<pi.d>((ComponentCallbacks)this, null, null){
            public final /* synthetic */ ComponentCallbacks c;
            {
                this.c = componentCallbacks;
                super(0);
            }

            public final pi.d s() {
                return g1.a((ComponentCallbacks)this.c).b(e0.a(pi.d.class), null, null);
            }
        });
        this.V0 = tn.a.r((gr.h)h3, (rr.a)new rr.a<k0>((ComponentCallbacks)this, null, null){
            public final /* synthetic */ ComponentCallbacks c;
            {
                this.c = componentCallbacks;
                super(0);
            }

            public final k0 s() {
                return g1.a((ComponentCallbacks)this.c).b(e0.a(k0.class), null, null);
            }
        });
        this.W0 = tn.a.r((gr.h)h3, (rr.a)new rr.a<fn.j>((ComponentCallbacks)this, null, null){
            public final /* synthetic */ ComponentCallbacks c;
            {
                this.c = componentCallbacks;
                super(0);
            }

            public final fn.j s() {
                return g1.a((ComponentCallbacks)this.c).b(e0.a(fn.j.class), null, null);
            }
        });
        this.X0 = tn.a.r((gr.h)h3, (rr.a)new rr.a<ui.e>((ComponentCallbacks)this, null, null){
            public final /* synthetic */ ComponentCallbacks c;
            {
                this.c = componentCallbacks;
                super(0);
            }

            public final ui.e s() {
                return g1.a((ComponentCallbacks)this.c).b(e0.a(ui.e.class), null, null);
            }
        });
        this.Y0 = new wj.a((rr.p)new rr.p<String, String, v>((Object)this){

            public Object t0(Object object, Object object2) {
                String string = (String)object;
                String string2 = (String)object2;
                ma.e.f((Object)string, (String)"p0");
                ma.e.f((Object)string2, (String)"p1");
                c c2 = (c)this.c;
                Objects.requireNonNull((Object)c2);
                ma.e.f((Object)string, (String)"url");
                ma.e.f((Object)string2, (String)"subject");
                bj.b.z(gn.c0$i.c);
                FragmentActivity fragmentActivity = c2.w();
                if (fragmentActivity != null) {
                    ((fn.j)c2.W0.getValue()).k((Activity)fragmentActivity, string2, string);
                }
                return v.a;
            }
        });
        this.a1 = tn.a.s((rr.a)new rr.a<pi.a>(this){
            public final /* synthetic */ c c;
            {
                this.c = c2;
                super(0);
            }

            public Object s() {
                c c2 = this.c;
                FrameLayout frameLayout = (FrameLayout)c2.r1().e;
                ma.e.e((Object)frameLayout, (String)"binding.fullscreenContainer");
                c c3 = this.c;
                return new pi.a((ViewGroup)frameLayout, c3, c3.t1());
            }
        });
        this.b1 = "ticker";
    }

    public void A0() {
        ((SwipeRefreshLayout)this.r1().g).setRefreshing(false);
        ((SwipeRefreshLayout)this.r1().g).destroyDrawingCache();
        ((SwipeRefreshLayout)this.r1().g).clearAnimation();
        FragmentActivity fragmentActivity = this.w();
        rh.b b3 = fragmentActivity instanceof rh.b ? (rh.b)fragmentActivity : null;
        if (b3 != null) {
            b3.R((rm.f)this);
        }
        WoWebView woWebView = (WoWebView)this.r1().d;
        woWebView.pauseTimers();
        woWebView.onPause();
        ((Fragment)this).G = true;
    }

    @Override
    public void C0() {
        super.C0();
        FragmentActivity fragmentActivity = this.w();
        if (fragmentActivity != null) {
            fragmentActivity.invalidateOptionsMenu();
        }
        FragmentActivity fragmentActivity2 = this.w();
        rh.b b3 = fragmentActivity2 instanceof rh.b ? (rh.b)fragmentActivity2 : null;
        if (b3 != null) {
            b3.P((rm.f)this);
        }
        WoWebView woWebView = (WoWebView)this.r1().d;
        woWebView.resumeTimers();
        woWebView.onResume();
        this.Y0.b = false;
    }

    public void F0() {
        androidx.fragment.app.l.super.F0();
        WoWebView woWebView = (WoWebView)this.r1().d;
        woWebView.resumeTimers();
        woWebView.onResume();
    }

    public void G0(View view, Bundle bundle) {
        ma.e.f((Object)view, (String)"view");
        SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout)this.r1().g;
        swipeRefreshLayout.setColorSchemeResources(new int[]{2131099942, 2131099931});
        swipeRefreshLayout.setOnRefreshListener((SwipeRefreshLayout.h)this);
        WoWebView woWebView = (WoWebView)this.r1().d;
        ma.e.e((Object)woWebView, (String)"binding.contentWebView");
        this.t1().a((WebView)woWebView);
        woWebView.setWebViewClient((WebViewClient)new pi.b(woWebView.getContext(), (pi.c)this, this.t1()));
        woWebView.setWebChromeClient((WebChromeClient)((pi.a)((Object)this.a1.getValue())));
        woWebView.setDownloadListener((DownloadListener)new ak.a(this));
        woWebView.addJavascriptInterface((Object)this.Y0, "ANDROID");
        this.u1();
    }

    public boolean J(Page page, Bundle bundle) {
        c.a.a((pi.c)this, (Page)page, (Bundle)bundle);
        return false;
    }

    public void T() {
        Context context = this.C();
        if (context != null) {
            if (!l.a((Context)context)) {
                ((NoConnectionLayout)((Object)this.r1().f)).d(this);
            } else {
                ((NoConnectionLayout)((Object)this.r1().f)).f(this);
                ((WoWebView)this.r1().d).loadUrl("javascript:loadRefresh();");
                kj.a a2 = this.r1();
                ((SwipeRefreshLayout)a2.g).post((Runnable)new ak.b(a2, 0));
                SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout)a2.g;
                ma.e.e((Object)swipeRefreshLayout, (String)"swipeRefreshLayout");
                ak.d d2 = new ak.d(a2);
                ma.e.f((Object)swipeRefreshLayout, (String)"$this$postDelay");
                ma.e.f((Object)d2, (String)"block");
                swipeRefreshLayout.postDelayed((Runnable)new w9.b((rr.a)d2), 3000L);
            }
        }
        rm.c c2 = (rm.c)this.T0.getValue();
        String string = this.e0(2131820938);
        ma.e.e((Object)string, (String)"getString(R.string.ivw_ticker)");
        c2.d(string);
    }

    public void Y(WebView webView, String string) {
        if (!this.n0()) {
            return;
        }
        kj.a a2 = this.r1();
        ((NoConnectionLayout)((Object)a2.f)).e(webView);
        ((NoConnectionLayout)((Object)a2.f)).f(this);
        ((SwipeRefreshLayout)a2.g).post((Runnable)new ak.b(a2, 2));
        webView.clearHistory();
    }

    public void Z() {
        ma.e.f((Object)this, (String)"this");
    }

    @Override
    public String f0() {
        String string = ((Context)g1.a((ComponentCallbacks)this).b(e0.a(Context.class), null, null)).getString(2131820938);
        ma.e.e((Object)string, (String)"get<Context>().getString(R.string.ivw_ticker)");
        return string;
    }

    public boolean g0(WebView webView, String string) {
        boolean bl;
        block7 : {
            block6 : {
                String string2;
                block5 : {
                    ma.e.f((Object)webView, (String)"view");
                    Uri uri = Uri.parse((String)string);
                    if (uri == null) {
                        return false;
                    }
                    if (!ma.e.a((Object)uri.getScheme(), (Object)"wetteronline")) {
                        return false;
                    }
                    List list = uri.getPathSegments();
                    string2 = list == null ? null : (String)list.get(0);
                    if (!ma.e.a((Object)string2, (Object)"disqus")) break block5;
                    o0 o02 = o0.f;
                    Context context = this.C();
                    String string3 = context == null ? null : context.getPackageName();
                    Intent intent = o02.a(string3);
                    intent.putExtra("postId", uri.getQueryParameter("postId"));
                    this.d1(intent);
                    break block6;
                }
                boolean bl2 = ma.e.a((Object)string2, (Object)"uploader");
                bl = false;
                if (!bl2) break block7;
                String string4 = this.h0(2131821553, new Object[]{this.s1().a().b});
                ma.e.e((Object)string4, (String)"getString(R.string.upload_url_web, language)");
                this.z(string4);
            }
            bl = true;
        }
        return bl;
    }

    public boolean h(boolean bl) {
        return ((pi.a)((Object)this.a1.getValue())).h(bl);
    }

    @Override
    public String k1() {
        return this.b1;
    }

    @Override
    public Map<String, Object> n1() {
        return bj.b.n(new gr.j<String, String>("ticker_locale", m0.a((j0)this.s1().a())));
    }

    public void q0(Bundle bundle) {
        androidx.fragment.app.l.super.q0(bundle);
        this.X0(true);
    }

    @Override
    public void r() {
        this.u1();
    }

    public void r0(Menu menu, MenuInflater menuInflater) {
        ma.e.f((Object)menu, (String)"menu");
        ma.e.f((Object)menuInflater, (String)"inflater");
        ma.e.f((Object)menuInflater, (String)"menuInflater");
        Objects.requireNonNull((Object)this.R0);
        ma.e.f((Object)menuInflater, (String)"menuInflater");
        menuInflater.inflate(2131558401, menu);
    }

    public final kj.a r1() {
        kj.a a2 = this.Z0;
        if (a2 != null) {
            return a2;
        }
        rk.a.v();
        throw null;
    }

    public View s0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        SwipeRefreshLayout swipeRefreshLayout;
        FrameLayout frameLayout;
        NoConnectionLayout noConnectionLayout;
        ma.e.f((Object)layoutInflater, (String)"inflater");
        View view = layoutInflater.inflate(2131493148, viewGroup, false);
        int n2 = 2131296546;
        WoWebView woWebView = (WoWebView)k.m(view, n2);
        if (woWebView != null && (frameLayout = (FrameLayout)k.m(view, n2 = 2131296697)) != null && (noConnectionLayout = (NoConnectionLayout)((Object)k.m(view, n2 = 2131297011))) != null && (swipeRefreshLayout = (SwipeRefreshLayout)k.m(view, n2 = 2131297323)) != null) {
            kj.a a2;
            RelativeLayout relativeLayout = (RelativeLayout)view;
            this.Z0 = a2 = new kj.a(relativeLayout, woWebView, frameLayout, noConnectionLayout, swipeRefreshLayout, relativeLayout);
            RelativeLayout relativeLayout2 = this.r1().b();
            ma.e.e((Object)relativeLayout2, (String)"binding.root");
            return relativeLayout2;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n2)));
    }

    public final k0 s1() {
        return (k0)this.V0.getValue();
    }

    public void t(WebView webView, String string) {
        if (!this.n0()) {
            return;
        }
        kj.a a2 = this.r1();
        ((NoConnectionLayout)((Object)a2.f)).c(webView, string);
        ((SwipeRefreshLayout)a2.g).post((Runnable)new ak.b(a2, 1));
    }

    public final pi.d t1() {
        return (pi.d)this.U0.getValue();
    }

    public final void u1() {
        ((SwipeRefreshLayout)this.r1().g).post((Runnable)new f3.h(this));
        wi.a.c((g0)this, (rr.l)new rr.l<jr.d<? super v>, Object>(this, null){
            public int f;
            public final /* synthetic */ c g;
            {
                this.g = c2;
                super(1, d2);
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            public final Object h(Object var1_1) {
                block5 : {
                    block4 : {
                        block3 : {
                            block2 : {
                                var2_2 = kr.a.b;
                                var3_3 = this.f;
                                if (var3_3 == 0) break block2;
                                if (var3_3 != 1) throw new java.lang.IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                co.a.L((Object)var1_1);
                                break block3;
                            }
                            co.a.L((Object)var1_1);
                            if (!((p)this.g.S0.getValue()).c() && (var17_4 = this.g.C()) != null) {
                                var18_5 = ph.k.a;
                                this.f = 1;
                                var19_6 = ph.k.b;
                                var1_1 = var19_6 == null ? var18_5.a(var17_4, (jr.d)this) : var19_6;
                                if (var1_1 == var2_2) {
                                    return var2_2;
                                } else {
                                    ** GOTO lbl17
                                }
                            }
                            break block4;
                        }
                        var4_7 = (String)var1_1;
                        break block5;
                    }
                    var4_7 = null;
                }
                var5_8 = this.g;
                var7_9 = (WoWebView)var5_8.r1().d;
                var8_10 = lj.c.Companion;
                var9_11 = ((p)var5_8.S0.getValue()).c() != false ? "paid" : "free";
                var10_12 = var9_11;
                var11_13 = var5_8.s1().a();
                var12_14 = var5_8.C();
                var13_15 = var12_14 == null ? null : var12_14.getPackageName();
                var14_16 = var13_15;
                var15_17 = ((ui.e)var5_8.X0.getValue()).a();
                Objects.requireNonNull((Object)var8_10);
                ma.e.f((Object)var11_13, (String)"localization");
                var7_9.loadUrl(var8_10.d(var10_12, var11_13, var14_16, var4_7, var15_17, null));
                return v.a;
            }

            public Object y(Object object) {
                jr.d d2 = (jr.d)object;
                return new /* invalid duplicate definition of identical inner class */.h((Object)v.a);
            }
        });
    }

    public void v0() {
        androidx.fragment.app.l.super.v0();
        this.Z0 = null;
    }

    public void z(String string) {
        try {
            this.d1(new Intent("android.intent.action.VIEW", Uri.parse((String)string)));
            return;
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            w.I((Fragment)this, (int)2131821738, (int)0, (int)2);
            return;
        }
    }

    public boolean z0(MenuItem menuItem) {
        ma.e.f((Object)menuItem, (String)"item");
        FragmentActivity fragmentActivity = this.w();
        if (fragmentActivity == null) {
            return false;
        }
        k0 k02 = (k0)g1.a((ComponentCallbacks)this).b(e0.a(k0.class), null, null);
        ma.e.f((Object)fragmentActivity, (String)"<this>");
        ma.e.f((Object)menuItem, (String)"item");
        ma.e.f((Object)k02, (String)"tickerLocalization");
        boolean bl = this.R0.d((Activity)fragmentActivity, menuItem, k02);
        boolean bl2 = false;
        if (bl) {
            bl2 = true;
        }
        return bl2;
    }

}

