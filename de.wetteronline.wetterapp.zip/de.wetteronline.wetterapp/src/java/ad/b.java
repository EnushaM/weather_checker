/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.perf.config.RemoteConfigManager
 *  com.google.firebase.perf.session.gauges.GaugeManager
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  pc.b
 *  qc.c
 *  w7.g
 *  wa.c
 *  zc.b
 */
package ad;

import ad.a;
import com.google.firebase.perf.config.RemoteConfigManager;
import com.google.firebase.perf.session.gauges.GaugeManager;
import java.util.Objects;
import ld.j;
import w7.g;
import wa.c;

public final class b
implements fr.a {
    public final /* synthetic */ int a;
    public final a b;

    public b(a a2, int n2) {
        this.a = n2;
        switch (n2) {
            default: {
                break;
            }
            case 6: {
                this.b = a2;
                return;
            }
            case 5: {
                super();
                this.b = a2;
                return;
            }
            case 4: {
                super();
                this.b = a2;
                return;
            }
            case 3: {
                super();
                this.b = a2;
                return;
            }
            case 2: {
                super();
                this.b = a2;
                return;
            }
            case 1: {
                super();
                this.b = a2;
                return;
            }
        }
        super();
        this.b = a2;
    }

    public pc.b a() {
        switch (this.a) {
            default: {
                break;
            }
            case 4: {
                pc.b<j> b2 = this.b.c;
                Objects.requireNonNull(b2, (String)"Cannot return null from a non-@Nullable @Provides method");
                return b2;
            }
        }
        pc.b<g> b3 = this.b.d;
        Objects.requireNonNull(b3, (String)"Cannot return null from a non-@Nullable @Provides method");
        return b3;
    }

    public Object get() {
        switch (this.a) {
            default: {
                break;
            }
            case 5: {
                Objects.requireNonNull((Object)this.b);
                RemoteConfigManager remoteConfigManager = RemoteConfigManager.getInstance();
                Objects.requireNonNull((Object)remoteConfigManager, (String)"Cannot return null from a non-@Nullable @Provides method");
                return remoteConfigManager;
            }
            case 4: {
                return this.a();
            }
            case 3: {
                Objects.requireNonNull((Object)this.b);
                GaugeManager gaugeManager = GaugeManager.getInstance();
                Objects.requireNonNull((Object)gaugeManager, (String)"Cannot return null from a non-@Nullable @Provides method");
                return gaugeManager;
            }
            case 2: {
                qc.c c3 = this.b.b;
                Objects.requireNonNull((Object)c3, (String)"Cannot return null from a non-@Nullable @Provides method");
                return c3;
            }
            case 1: {
                c c4 = this.b.a;
                Objects.requireNonNull((Object)c4, (String)"Cannot return null from a non-@Nullable @Provides method");
                return c4;
            }
            case 0: {
                Objects.requireNonNull((Object)this.b);
                zc.b b2 = zc.b.e();
                Objects.requireNonNull((Object)b2, (String)"Cannot return null from a non-@Nullable @Provides method");
                return b2;
            }
        }
        return this.a();
    }
}

