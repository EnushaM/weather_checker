/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  ld.j
 *  pc.b
 *  qc.c
 *  w7.g
 *  wa.c
 */
package ad;

import ld.j;
import pc.b;
import qc.c;
import w7.g;

public class a {
    public final wa.c a;
    public final c b;
    public final b<j> c;
    public final b<g> d;

    public a(wa.c c2, c c3, b<j> b2, b<g> b3) {
        this.a = c2;
        this.b = c3;
        this.c = b2;
        this.d = b3;
    }
}

