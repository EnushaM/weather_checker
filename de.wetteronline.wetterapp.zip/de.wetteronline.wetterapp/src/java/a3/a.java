/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a3.b
 *  androidx.lifecycle.v0
 *  androidx.lifecycle.w0
 *  androidx.lifecycle.x
 *  java.io.FileDescriptor
 *  java.io.PrintWriter
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package a3;

import a3.b;
import androidx.lifecycle.v0;
import androidx.lifecycle.w0;
import androidx.lifecycle.x;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class a {
    public static <T extends x & w0> a b(T t) {
        return new b(t, ((w0)t).A());
    }

    @Deprecated
    public abstract void a(String var1, FileDescriptor var2, PrintWriter var3, String[] var4);
}

