/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.appcompat.app.n
 *  androidx.collection.e
 *  androidx.fragment.app.a
 *  androidx.lifecycle.LiveData
 *  androidx.lifecycle.f0
 *  androidx.lifecycle.g0
 *  androidx.lifecycle.s0
 *  androidx.lifecycle.u0
 *  androidx.lifecycle.u0$b
 *  androidx.lifecycle.u0$c
 *  androidx.lifecycle.u0$e
 *  androidx.lifecycle.v0
 *  androidx.lifecycle.x
 *  java.io.FileDescriptor
 *  java.io.PrintWriter
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.HashMap
 *  java.util.Objects
 */
package a3;

import androidx.appcompat.app.n;
import androidx.collection.e;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.f0;
import androidx.lifecycle.g0;
import androidx.lifecycle.s0;
import androidx.lifecycle.u0;
import androidx.lifecycle.v0;
import androidx.lifecycle.x;
import e.k;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Objects;

public class b
extends a3.a {
    public final x a;
    public final b b;

    public b(x x2, v0 v02) {
        this.a = x2;
        u0.b b2 = b.e;
        String string = b.class.getCanonicalName();
        if (string != null) {
            String string2 = n.a((String)"androidx.lifecycle.ViewModelProvider.DefaultKey:", (String)string);
            s0 s02 = (s0)v02.a.get((Object)string2);
            if (b.class.isInstance((Object)s02)) {
                if (b2 instanceof u0.e) {
                    ((u0.e)b2).b(s02);
                }
            } else {
                b b3 = b2 instanceof u0.c ? ((u0.c)b2).c(string2, b.class) : (b2).a(b.class);
                s02 = b3;
                s0 s03 = (s0)v02.a.put((Object)string2, (Object)s02);
                if (s03 != null) {
                    s03.b();
                }
            }
            this.b = (b)s02;
            return;
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    @Deprecated
    @Override
    public void a(String string, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] arrstring) {
        b b2 = this.b;
        if (b2.d.j() > 0) {
            printWriter.print(string);
            printWriter.println("Loaders:");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string);
            stringBuilder.append("    ");
            String string2 = stringBuilder.toString();
            if (b2.d.j() <= 0) {
                return;
            }
            a a2 = (Object)b2.d.k(0);
            printWriter.print(string);
            printWriter.print("  #");
            printWriter.print(b2.d.h(0));
            printWriter.print(": ");
            printWriter.println(a2.toString());
            printWriter.print(string2);
            printWriter.print("mId=");
            printWriter.print(0);
            printWriter.print(" mArgs=");
            printWriter.println(null);
            printWriter.print(string2);
            printWriter.print("mLoader=");
            printWriter.println(null);
            throw null;
        }
    }

    public String toString() {
        StringBuilder stringBuilder = androidx.fragment.app.a.a((int)128, (String)"LoaderManager{");
        stringBuilder.append(Integer.toHexString((int)System.identityHashCode((Object)this)));
        stringBuilder.append(" in ");
        k.e((Object)this.a, stringBuilder);
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }

    public static class b
    extends s0 {
        public static final u0.b e = new u0.b(){

            public <T extends s0> T a(Class<T> class_) {
                return (T)((Object)new b());
            }
        };
        public e<a3.b$a> d = new e();

        public void b() {
            if (this.d.j() <= 0) {
                e<a3.b$a> e2 = this.d;
                int n2 = e2.e;
                Object[] arrobject = e2.d;
                for (int i2 = 0; i2 < n2; ++i2) {
                    arrobject[i2] = null;
                }
                e2.e = 0;
                e2.b = false;
                return;
            }
            Objects.requireNonNull((Object)((Object)((Object)this.d.k(0))));
            throw null;
        }

    }

}

