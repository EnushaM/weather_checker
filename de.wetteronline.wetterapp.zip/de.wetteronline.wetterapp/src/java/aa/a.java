/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  com.google.android.material.appbar.AppBarLayout
 *  java.lang.Float
 *  java.lang.Object
 *  ma.f
 */
package aa;

import android.animation.ValueAnimator;
import com.google.android.material.appbar.AppBarLayout;
import ma.f;

public class a
implements ValueAnimator.AnimatorUpdateListener {
    public final /* synthetic */ f a;

    public a(AppBarLayout appBarLayout, f f2) {
        this.a = f2;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.a.o(((Float)valueAnimator.getAnimatedValue()).floatValue());
    }
}

