/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Object
 */
package aa;

import android.view.View;

public class c {
    public final View a;
    public int b;
    public int c;
    public int d;
    public int e;

    public c(View view) {
        this.a = view;
    }

    public void a() {
        View view = this.a;
        int n2 = this.d - (view.getTop() - this.b);
        view.offsetTopAndBottom(n2);
        View view2 = this.a;
        view2.offsetLeftAndRight(this.e - (view2.getLeft() - this.c));
    }

    public boolean b(int n2) {
        if (this.d != n2) {
            this.d = n2;
            this.a();
            return true;
        }
        return false;
    }
}

