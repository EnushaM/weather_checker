/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.ObjectAnimator
 *  android.animation.StateListAnimator
 *  android.content.res.Resources
 *  android.view.View
 *  java.lang.Object
 *  java.lang.String
 */
package aa;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.content.res.Resources;
import android.view.View;

public class d {
    public static final int[] a = new int[]{16843848};

    public static void a(View view, float f2) {
        int n2 = view.getResources().getInteger(2131361794);
        StateListAnimator stateListAnimator = new StateListAnimator();
        int[] arrn = new int[]{16842766, 2130969458, -2130969459};
        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat((Object)view, (String)"elevation", (float[])new float[]{0.0f});
        long l3 = n2;
        stateListAnimator.addState(arrn, (Animator)objectAnimator.setDuration(l3));
        stateListAnimator.addState(new int[]{16842766}, (Animator)ObjectAnimator.ofFloat((Object)view, (String)"elevation", (float[])new float[]{f2}).setDuration(l3));
        stateListAnimator.addState(new int[0], (Animator)ObjectAnimator.ofFloat((Object)view, (String)"elevation", (float[])new float[]{0.0f}).setDuration(0L));
        view.setStateListAnimator(stateListAnimator);
    }
}

