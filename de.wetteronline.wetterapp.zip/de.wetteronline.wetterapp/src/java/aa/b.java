/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  com.google.android.material.appbar.CollapsingToolbarLayout
 *  java.lang.Integer
 *  java.lang.Object
 */
package aa;

import android.animation.ValueAnimator;
import com.google.android.material.appbar.CollapsingToolbarLayout;

public class b
implements ValueAnimator.AnimatorUpdateListener {
    public final /* synthetic */ CollapsingToolbarLayout a;

    public b(CollapsingToolbarLayout collapsingToolbarLayout) {
        this.a = collapsingToolbarLayout;
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.a.setScrimAlpha(((Integer)valueAnimator.getAnimatedValue()).intValue());
    }
}

