/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a2;

public class a {
    public static a b = new a();
    public static String[] c = new String[]{"standard", "accelerate", "decelerate", "linear"};
    public String a = "identity";

    public String toString() {
        return this.a;
    }
}

