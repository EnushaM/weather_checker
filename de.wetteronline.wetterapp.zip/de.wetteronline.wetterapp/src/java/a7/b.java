/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  ma.e
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package a7;

import a7.c;
import java.util.ArrayList;
import java.util.List;
import ma.e;
import org.json.JSONArray;
import org.json.JSONObject;

public final class b {
    public final String a;
    public final String b;
    public final List<c> c;
    public final String d;

    public b(JSONObject jSONObject) {
        String string = jSONObject.getString("name");
        e.e((Object)string, (String)"component.getString(PARAMETER_NAME_KEY)");
        this.a = string;
        String string2 = jSONObject.optString("value");
        e.e((Object)string2, (String)"component.optString(PARAMETER_VALUE_KEY)");
        this.b = string2;
        String string3 = jSONObject.optString("path_type", "absolute");
        e.e((Object)string3, (String)"component.optString(Cons\u2026tants.PATH_TYPE_ABSOLUTE)");
        this.d = string3;
        ArrayList arrayList = new ArrayList();
        JSONArray jSONArray = jSONObject.optJSONArray("path");
        if (jSONArray != null) {
            int n2 = jSONArray.length();
            for (int i2 = 0; i2 < n2; ++i2) {
                JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                e.e((Object)jSONObject2, (String)"jsonPathArray.getJSONObject(i)");
                arrayList.add((Object)new c(jSONObject2));
            }
        }
        this.c = arrayList;
    }
}

