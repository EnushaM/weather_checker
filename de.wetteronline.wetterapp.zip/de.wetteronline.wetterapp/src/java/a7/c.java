/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  org.json.JSONObject
 */
package a7;

import ma.e;
import org.json.JSONObject;

public final class c {
    public final String a;
    public final int b;
    public final int c;
    public final String d;
    public final String e;
    public final String f;
    public final String g;
    public final int h;

    public c(JSONObject jSONObject) {
        String string = jSONObject.getString("class_name");
        e.e((Object)string, (String)"component.getString(PATH_CLASS_NAME_KEY)");
        this.a = string;
        this.b = jSONObject.optInt("index", -1);
        this.c = jSONObject.optInt("id");
        String string2 = jSONObject.optString("text");
        e.e((Object)string2, (String)"component.optString(PATH_TEXT_KEY)");
        this.d = string2;
        String string3 = jSONObject.optString("tag");
        e.e((Object)string3, (String)"component.optString(PATH_TAG_KEY)");
        this.e = string3;
        String string4 = jSONObject.optString("description");
        e.e((Object)string4, (String)"component.optString(PATH_DESCRIPTION_KEY)");
        this.f = string4;
        String string5 = jSONObject.optString("hint");
        e.e((Object)string5, (String)"component.optString(PATH_HINT_KEY)");
        this.g = string5;
        this.h = jSONObject.optInt("match_bitmask");
    }
}

