/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  android.widget.AdapterView
 *  android.widget.Button
 *  android.widget.CheckBox
 *  android.widget.DatePicker
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.RadioButton
 *  android.widget.RadioGroup
 *  android.widget.RatingBar
 *  android.widget.Spinner
 *  android.widget.Switch
 *  android.widget.TextView
 *  android.widget.TimePicker
 *  com.facebook.internal.e
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.NoSuchFieldException
 *  java.lang.NoSuchMethodException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 *  java.lang.reflect.Field
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 *  ma.e
 *  o7.a
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package a7;

import a7.d;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import o7.a;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class e {
    public static WeakReference<View> a;
    public static Method b;
    public static final e c;

    public static {
        c = new e();
        a = new WeakReference(null);
    }

    public static final List<View> a(View view) {
        ArrayList arrayList;
        block5 : {
            int n2;
            if (a.b(e.class)) {
                return null;
            }
            try {
                arrayList = new ArrayList();
                if (!(view instanceof ViewGroup)) break block5;
                n2 = ((ViewGroup)view).getChildCount();
            }
            catch (Throwable throwable) {
                a.a((Throwable)throwable, e.class);
                return null;
            }
            for (int i2 = 0; i2 < n2; ++i2) {
                arrayList.add((Object)((ViewGroup)view).getChildAt(i2));
            }
        }
        return arrayList;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static final int b(View view) {
        boolean bl;
        int n2;
        block17 : {
            block16 : {
                boolean bl2;
                if (a.b(e.class)) {
                    return 0;
                }
                n2 = view instanceof ImageView ? 2 : 0;
                if (view.isClickable()) {
                    n2 |= 32;
                }
                if (bl2 = a.b(e.class)) break block16;
                {
                    catch (Throwable throwable) {
                        a.a((Throwable)throwable, e.class);
                        return 0;
                    }
                }
                try {
                    e e2;
                    Class<?> class_;
                    Class<?> class_2;
                    boolean bl3;
                    ViewParent viewParent = view.getParent();
                    if (!(viewParent instanceof AdapterView) && ((class_ = (e2 = c).e("android.support.v4.view.NestedScrollingChild")) == null || !class_.isInstance((Object)viewParent)) && ((class_2 = e2.e("androidx.core.view.NestedScrollingChild")) == null || !(bl3 = class_2.isInstance((Object)viewParent)))) break block16;
                    bl = true;
                    break block17;
                }
                catch (Throwable throwable) {
                    a.a((Throwable)throwable, e.class);
                }
            }
            bl = false;
        }
        if (bl) {
            n2 |= 512;
        }
        if (view instanceof TextView) {
            n2 = 1 | (n2 | 1024);
            if (view instanceof Button) {
                n2 |= 4;
                if (view instanceof Switch) {
                    n2 |= 8192;
                } else if (view instanceof CheckBox) {
                    n2 |= 32768;
                }
            }
            if (!(view instanceof EditText)) return n2;
            return n2 | 2048;
        }
        if (!(view instanceof Spinner) && !(view instanceof DatePicker)) {
            if (view instanceof RatingBar) {
                return n2 | 65536;
            }
            if (view instanceof RadioGroup) {
                return n2 | 16384;
            }
            if (!(view instanceof ViewGroup)) return n2;
            boolean bl4 = c.m(view, (View)a.get());
            if (!bl4) return n2;
            return n2 | 64;
        }
        n2 |= 4096;
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final JSONObject c(View view) {
        if (a.b(e.class)) {
            return null;
        }
        try {
            ma.e.f((Object)view, (String)"view");
            if (ma.e.a((Object)view.getClass().getName(), (Object)"com.facebook.react.ReactRootView")) {
                a = new WeakReference((Object)view);
            }
            JSONObject jSONObject = new JSONObject();
            try {
                e.n(view, jSONObject);
                JSONArray jSONArray = new JSONArray();
                List<View> list = e.a(view);
                int n2 = list.size();
                for (int i2 = 0; i2 < n2; ++i2) {
                    jSONArray.put((Object)e.c((View)list.get(i2)));
                }
                jSONObject.put("childviews", (Object)jSONArray);
                return jSONObject;
            }
            catch (JSONException jSONException) {}
            return jSONObject;
        }
        catch (Throwable throwable) {
            a.a((Throwable)throwable, e.class);
            return null;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static final View.OnClickListener f(View view) {
        if (a.b(e.class)) {
            return null;
        }
        Field field = Class.forName((String)"android.view.View").getDeclaredField("mListenerInfo");
        ma.e.e((Object)field, (String)"Class.forName(\"android.v\u2026redField(\"mListenerInfo\")");
        field.setAccessible(true);
        Object object = field.get((Object)view);
        if (object == null) return null;
        Field field2 = Class.forName((String)"android.view.View$ListenerInfo").getDeclaredField("mOnClickListener");
        ma.e.e((Object)field2, (String)"Class.forName(\"android.v\u2026Field(\"mOnClickListener\")");
        field2.setAccessible(true);
        Object object2 = field2.get(object);
        if (object2 == null) throw new NullPointerException("null cannot be cast to non-null type android.view.View.OnClickListener");
        try {
            return (View.OnClickListener)object2;
        }
        catch (Throwable throwable) {
            a.a((Throwable)throwable, e.class);
            return null;
        }
        catch (ClassNotFoundException | IllegalAccessException | NoSuchFieldException throwable) {}
        return null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static final View.OnTouchListener g(View view) {
        Throwable throwable2222;
        block7 : {
            if (a.b(e.class)) {
                return null;
            }
            try {
                Field field = Class.forName((String)"android.view.View").getDeclaredField("mListenerInfo");
                ma.e.e((Object)field, (String)"Class.forName(\"android.v\u2026redField(\"mListenerInfo\")");
                field.setAccessible(true);
                Object object = field.get((Object)view);
                if (object == null) return null;
                Field field2 = Class.forName((String)"android.view.View$ListenerInfo").getDeclaredField("mOnTouchListener");
                ma.e.e((Object)field2, (String)"Class.forName(\"android.v\u2026Field(\"mOnTouchListener\")");
                field2.setAccessible(true);
                Object object2 = field2.get(object);
                if (object2 == null) throw new NullPointerException("null cannot be cast to non-null type android.view.View.OnTouchListener");
                return (View.OnTouchListener)object2;
            }
            catch (Throwable throwable2222) {
                break block7;
            }
            catch (IllegalAccessException illegalAccessException) {
                com.facebook.internal.e.w((String)"a7.e", (Exception)illegalAccessException);
                return null;
            }
            catch (ClassNotFoundException classNotFoundException) {
                com.facebook.internal.e.w((String)"a7.e", (Exception)classNotFoundException);
                return null;
            }
            catch (NoSuchFieldException noSuchFieldException) {
                com.facebook.internal.e.w((String)"a7.e", (Exception)noSuchFieldException);
                return null;
            }
        }
        a.a((Throwable)throwable2222, e.class);
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static final String h(View view) {
        CharSequence charSequence;
        block5 : {
            if (a.b(e.class)) {
                return null;
            }
            try {
                if (view instanceof EditText) {
                    charSequence = ((EditText)view).getHint();
                    break block5;
                }
                if (!(view instanceof TextView)) return "";
                charSequence = ((TextView)view).getHint();
            }
            catch (Throwable throwable) {
                a.a((Throwable)throwable, e.class);
                return null;
            }
        }
        if (charSequence == null) return "";
        String string = charSequence.toString();
        if (string == null) return "";
        return string;
    }

    public static final ViewGroup i(View view) {
        ViewGroup viewGroup;
        block4 : {
            ViewParent viewParent;
            ViewGroup viewGroup2;
            if (a.b(e.class)) {
                return null;
            }
            try {
                viewParent = view.getParent();
                boolean bl = viewParent instanceof ViewGroup;
                viewGroup = null;
                if (!bl) break block4;
            }
            catch (Throwable throwable) {
                a.a((Throwable)throwable, e.class);
                return null;
            }
            viewGroup = viewGroup2 = (ViewGroup)viewParent;
        }
        return viewGroup;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final String j(View view) {
        CharSequence charSequence;
        block11 : {
            int n2;
            int n3;
            int n4;
            block12 : {
                String string;
                if (a.b(e.class)) {
                    return null;
                }
                try {
                    if (view instanceof TextView) {
                        charSequence = ((TextView)view).getText();
                        if (view instanceof Switch) {
                            string = ((Switch)view).isChecked() ? "1" : "0";
                        }
                        break block11;
                    }
                    if (view instanceof Spinner) {
                        if (((Spinner)view).getCount() <= 0) return "";
                        Object object = ((Spinner)view).getSelectedItem();
                        if (object == null) return "";
                        charSequence = object.toString();
                        break block11;
                    }
                    boolean bl = view instanceof DatePicker;
                    n2 = 0;
                    if (bl) {
                        int n5 = ((DatePicker)view).getYear();
                        int n6 = ((DatePicker)view).getMonth();
                        int n7 = ((DatePicker)view).getDayOfMonth();
                        Object[] arrobject = new Object[]{n5, n6, n7};
                        charSequence = String.format((String)"%04d-%02d-%02d", (Object[])Arrays.copyOf((Object[])arrobject, (int)3));
                        ma.e.e((Object)charSequence, (String)"java.lang.String.format(format, *args)");
                        break block11;
                    }
                    if (view instanceof TimePicker) {
                        Integer n8 = ((TimePicker)view).getCurrentHour();
                        ma.e.e((Object)n8, (String)"view.currentHour");
                        int n9 = n8;
                        Integer n10 = ((TimePicker)view).getCurrentMinute();
                        ma.e.e((Object)n10, (String)"view.currentMinute");
                        int n11 = n10;
                        Object[] arrobject = new Object[]{n9, n11};
                        charSequence = String.format((String)"%02d:%02d", (Object[])Arrays.copyOf((Object[])arrobject, (int)2));
                        ma.e.e((Object)charSequence, (String)"java.lang.String.format(format, *args)");
                        break block11;
                    }
                    if (view instanceof RadioGroup) {
                        n4 = ((RadioGroup)view).getCheckedRadioButtonId();
                        n3 = ((RadioGroup)view).getChildCount();
                        break block12;
                    }
                    if (!(view instanceof RatingBar)) return "";
                    charSequence = String.valueOf((float)((RatingBar)view).getRating());
                    break block11;
                }
                catch (Throwable throwable) {
                    a.a((Throwable)throwable, e.class);
                    return null;
                }
                charSequence = string;
                break block11;
            }
            while (n2 < n3) {
                View view2 = ((RadioGroup)view).getChildAt(n2);
                ma.e.e((Object)view2, (String)"child");
                if (view2.getId() == n4 && view2 instanceof RadioButton) {
                    charSequence = ((RadioButton)view2).getText();
                    break block11;
                }
                ++n2;
            }
            return "";
        }
        if (charSequence == null) return "";
        String string = charSequence.toString();
        if (string == null) return "";
        return string;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static final void n(View view, JSONObject jSONObject) {
        Throwable throwable2222;
        block9 : {
            if (a.b(e.class)) {
                return;
            }
            try {
                String string = e.j(view);
                String string2 = e.h(view);
                Object object = view.getTag();
                CharSequence charSequence = view.getContentDescription();
                jSONObject.put("classname", (Object)view.getClass().getCanonicalName());
                jSONObject.put("classtypebitmask", e.b(view));
                jSONObject.put("id", view.getId());
                boolean bl = d.b(view);
                if (!bl) {
                    jSONObject.put("text", (Object)com.facebook.internal.e.c((String)com.facebook.internal.e.B((String)string), (String)""));
                } else {
                    jSONObject.put("text", (Object)"");
                    jSONObject.put("is_user_input", true);
                }
                jSONObject.put("hint", (Object)com.facebook.internal.e.c((String)com.facebook.internal.e.B((String)string2), (String)""));
                if (object != null) {
                    jSONObject.put("tag", (Object)com.facebook.internal.e.c((String)com.facebook.internal.e.B((String)object.toString()), (String)""));
                }
                if (charSequence != null) {
                    jSONObject.put("description", (Object)com.facebook.internal.e.c((String)com.facebook.internal.e.B((String)charSequence.toString()), (String)""));
                }
                jSONObject.put("dimension", (Object)c.d(view));
                return;
            }
            catch (Throwable throwable2222) {
                break block9;
            }
            catch (JSONException jSONException) {
                com.facebook.internal.e.w((String)"a7.e", (Exception)jSONException);
                return;
            }
        }
        a.a((Throwable)throwable2222, e.class);
    }

    public final JSONObject d(View view) {
        if (a.b((Object)this)) {
            return null;
        }
        try {
            JSONObject jSONObject;
            jSONObject = new JSONObject();
            try {
                jSONObject.put("top", view.getTop());
                jSONObject.put("left", view.getLeft());
                jSONObject.put("width", view.getWidth());
                jSONObject.put("height", view.getHeight());
                jSONObject.put("scrollx", view.getScrollX());
                jSONObject.put("scrolly", view.getScrollY());
                jSONObject.put("visibility", view.getVisibility());
            }
            catch (JSONException jSONException) {}
            return jSONObject;
        }
        catch (Throwable throwable) {
            a.a((Throwable)throwable, (Object)this);
            return null;
        }
    }

    public final Class<?> e(String string) {
        if (a.b((Object)this)) {
            return null;
        }
        try {
            Class class_ = Class.forName((String)string);
            return class_;
        }
        catch (Throwable throwable) {
            a.a((Throwable)throwable, (Object)this);
        }
        catch (ClassNotFoundException classNotFoundException) {}
        return null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final View k(float[] arrf, View view) {
        if (a.b((Object)this)) {
            return null;
        }
        try {
            this.l();
            Method method = b;
            if (method == null) return null;
            if (view == null) {
                return null;
            }
            if (method == null) throw new IllegalStateException("Required value was null.".toString());
            Object object = method.invoke(null, new Object[]{arrf, view});
            if (object == null) throw new NullPointerException("null cannot be cast to non-null type android.view.View");
            View view2 = (View)object;
            if (view2.getId() <= 0) return null;
            ViewParent viewParent = view2.getParent();
            if (viewParent == null) throw new NullPointerException("null cannot be cast to non-null type android.view.View");
            return (View)viewParent;
        }
        catch (Throwable throwable) {
            a.a((Throwable)throwable, (Object)this);
            return null;
        }
        catch (InvocationTargetException invocationTargetException) {}
        com.facebook.internal.e.w((String)"a7.e", (Exception)invocationTargetException);
        return null;
        catch (IllegalAccessException illegalAccessException) {}
        com.facebook.internal.e.w((String)"a7.e", (Exception)illegalAccessException);
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void l() {
        if (a.b((Object)this)) {
            return;
        }
        try {
            Method method = b;
            if (method != null) {
                return;
            }
            try {
                Method method2;
                Class class_ = Class.forName((String)"com.facebook.react.uimanager.TouchTargetHelper");
                ma.e.e((Object)class_, (String)"Class.forName(CLASS_TOUCHTARGETHELPER)");
                b = method2 = class_.getDeclaredMethod("findTouchTargetView", new Class[]{float[].class, ViewGroup.class});
                if (method2 != null) {
                    method2.setAccessible(true);
                    return;
                }
                throw new IllegalStateException("Required value was null.".toString());
            }
            catch (NoSuchMethodException noSuchMethodException) {
                com.facebook.internal.e.w((String)"a7.e", (Exception)noSuchMethodException);
                return;
            }
            catch (ClassNotFoundException classNotFoundException) {
                com.facebook.internal.e.w((String)"a7.e", (Exception)classNotFoundException);
                return;
            }
        }
        catch (Throwable throwable) {
            a.a((Throwable)throwable, (Object)this);
            return;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final boolean m(View var1_1, View var2_2) {
        block6 : {
            if (a.b((Object)this)) {
                return false;
            }
            var4_3 = ma.e.a((Object)var1_1.getClass().getName(), (Object)"com.facebook.react.views.view.ReactViewGroup");
            var5_4 = false;
            if (var4_3 == false) return var5_4;
            var6_5 = a.b((Object)this);
            var7_6 = null;
            if (!var6_5) break block6;
            var7_6 = null;
            ** GOTO lbl25
            {
                catch (Throwable var3_13) {
                    a.a((Throwable)var3_13, (Object)this);
                    return false;
                }
            }
        }
        try {
            var12_7 = new int[2];
            var1_1.getLocationOnScreen(var12_7);
            var13_8 = new float[]{var12_7[0], var12_7[1]};
            var7_6 = var13_8;
            ** GOTO lbl25
        }
        catch (Throwable var11_9) {
            a.a((Throwable)var11_9, (Object)this);
lbl25: // 3 sources:
            var8_10 = this.k(var7_6, var2_2);
            var5_4 = false;
            if (var8_10 == null) return var5_4;
            var9_11 = var8_10.getId();
            var10_12 = var1_1.getId();
            var5_4 = false;
            if (var9_11 != var10_12) return var5_4;
            return true;
        }
    }
}

