/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Locale
 *  ma.e
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package a7;

import a7.c;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import ma.e;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class a {
    public final String a;
    public final List<c> b;
    public final List<a7.b> c;
    public final String d;

    public a(String string, b b2, a a3, String string2, List<c> list, List<a7.b> list2, String string3, String string4, String string5) {
        e.f((Object)((Object)b2), (String)"method");
        e.f((Object)((Object)a3), (String)"type");
        this.a = string;
        this.b = list;
        this.c = list2;
        this.d = string5;
    }

    public static final a a(JSONObject jSONObject) throws JSONException, IllegalArgumentException {
        String string = jSONObject.getString("event_name");
        String string2 = jSONObject.getString("method");
        e.e((Object)string2, (String)"mapping.getString(\"method\")");
        Locale locale = Locale.ENGLISH;
        e.e((Object)locale, (String)"Locale.ENGLISH");
        String string3 = string2.toUpperCase(locale);
        e.e((Object)string3, (String)"(this as java.lang.String).toUpperCase(locale)");
        b b2 = b.valueOf(string3);
        String string4 = jSONObject.getString("event_type");
        e.e((Object)string4, (String)"mapping.getString(\"event_type\")");
        String string5 = string4.toUpperCase(locale);
        e.e((Object)string5, (String)"(this as java.lang.String).toUpperCase(locale)");
        a a3 = a.valueOf(string5);
        String string6 = jSONObject.getString("app_version");
        JSONArray jSONArray = jSONObject.getJSONArray("path");
        ArrayList arrayList = new ArrayList();
        int n2 = jSONArray.length();
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
            e.e((Object)jSONObject2, (String)"jsonPath");
            arrayList.add((Object)new c(jSONObject2));
        }
        String string7 = jSONObject.optString("path_type", "absolute");
        JSONArray jSONArray2 = jSONObject.optJSONArray("parameters");
        ArrayList arrayList2 = new ArrayList();
        if (jSONArray2 != null) {
            int n4 = jSONArray2.length();
            while (n3 < n4) {
                JSONObject jSONObject3 = jSONArray2.getJSONObject(n3);
                e.e((Object)jSONObject3, (String)"jsonParameter");
                arrayList2.add((Object)new a7.b(jSONObject3));
                ++n3;
            }
        }
        String string8 = jSONObject.optString("component_id");
        String string9 = jSONObject.optString("activity_name");
        e.e((Object)string, (String)"eventName");
        e.e((Object)string6, (String)"appVersion");
        e.e((Object)string8, (String)"componentId");
        e.e((Object)string7, (String)"pathType");
        e.e((Object)string9, (String)"activityName");
        a a4 = new a(string, b2, a3, string6, (List<c>)arrayList, (List<a7.b>)arrayList2, string8, string7, string9);
        return a4;
    }

    public static final class a
    extends Enum<a> {
        public static final /* synthetic */ a[] b;

        public static {
            a[] arra = new a[]{new a(), new a(), new a()};
            b = arra;
        }

        public static a valueOf(String string) {
            return (a)Enum.valueOf(a.class, (String)string);
        }

        public static a[] values() {
            return (a[])b.clone();
        }
    }

    public static final class b
    extends Enum<b> {
        public static final /* synthetic */ b[] b;

        public static {
            b[] arrb = new b[]{new b(), new b()};
            b = arrb;
        }

        public static b valueOf(String string) {
            return (b)Enum.valueOf(b.class, (String)string);
        }

        public static b[] values() {
            return (b[])b.clone();
        }
    }

}

