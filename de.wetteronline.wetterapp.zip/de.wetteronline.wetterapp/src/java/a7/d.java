/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  ma.e
 *  o7.a
 */
package a7;

import a7.e;
import android.view.View;
import android.widget.TextView;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import o7.a;

public final class d {
    public static final d a = new d();

    /*
     * Exception decompiling
     */
    public static final boolean b(View var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 5 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean a(TextView var1_1) {
        block12 : {
            block9 : {
                if (a.b((Object)this)) {
                    return false;
                }
                var3_2 = e.j((View)var1_1);
                ma.e.f((Object)"\\s", (String)"pattern");
                var4_3 = Pattern.compile((String)"\\s");
                ma.e.e((Object)var4_3, (String)"Pattern.compile(pattern)");
                ma.e.f((Object)var4_3, (String)"nativePattern");
                ma.e.f((Object)var3_2, (String)"input");
                ma.e.f((Object)"", (String)"replacement");
                var5_4 = var4_3.matcher((CharSequence)var3_2).replaceAll("");
                ma.e.e((Object)var5_4, (String)"nativePattern.matcher(in\u2026).replaceAll(replacement)");
                var6_5 = var5_4.length();
                var7_6 = false;
                if (var6_5 < 12) return var7_6;
                if (var6_5 <= 19) break block9;
                return false;
lbl18: // 2 sources:
                do {
                    if (var8_7 >= 0) {
                        block11 : {
                            block10 : {
                                var11_10 = var5_4.charAt(var8_7);
                                if (Character.isDigit((char)var11_10)) break block10;
                                return false;
                            }
                            var12_11 = Character.digit((int)var11_10, (int)10);
                            if (var12_11 < 0) break block11;
                            if (var10_9 && (var12_11 *= 2) > 9) {
                                var12_11 = 1 + var12_11 % 10;
                            }
                            break block12;
                        }
                        var13_12 = new StringBuilder();
                        var13_12.append("Char ");
                        var13_12.append(var11_10);
                        var13_12.append(" is not a decimal digit");
                        throw new IllegalArgumentException(var13_12.toString());
                    }
                    var17_13 = var9_8 % 10;
                    var7_6 = false;
                    if (var17_13 != 0) return var7_6;
                    return true;
                    catch (Throwable var2_14) {
                        a.a((Throwable)var2_14, (Object)this);
                        return false;
                    }
                    break;
                } while (true);
            }
            var8_7 = var6_5 - 1;
            var9_8 = 0;
            var10_9 = false;
            ** GOTO lbl18
        }
        var9_8 += var12_11;
        var10_9 ^= true;
        --var8_7;
        ** while (true)
    }
}

