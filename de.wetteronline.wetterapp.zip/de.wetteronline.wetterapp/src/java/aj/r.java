/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  aj.r$a
 *  aj.r$b
 *  aj.r$c
 *  aj.r$d
 *  aj.r$e
 *  aj.r$f
 *  aj.r$g
 *  aj.r$h
 *  java.lang.Object
 *  java.lang.String
 *  rh.l0
 *  rh.l0$a
 *  rr.a
 *  tn.a
 */
package aj;

import aj.r;
import rh.l0;

public final class r
implements l0 {
    public final gr.g b = tn.a.s((rr.a)new b(this));
    public final gr.g c = tn.a.s((rr.a)new c(this));
    public final gr.g d = tn.a.s((rr.a)new a(this));
    public final gr.g e = tn.a.s((rr.a)new f(this));
    public final gr.g f = tn.a.s((rr.a)new e(this));
    public final gr.g g = tn.a.s((rr.a)new g(this));
    public final gr.g h = tn.a.s((rr.a)new h(this));
    public final gr.g i = tn.a.s((rr.a)new d(this));

    public String q(int n2) {
        return l0.a.a((l0)this, (int)n2);
    }
}

