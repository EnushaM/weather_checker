/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  de.wetteronline.components.data.model.Wind
 *  java.lang.Object
 *  java.lang.String
 */
package aj;

import de.wetteronline.components.data.model.Wind;

public interface s {
    public String A(Wind var1);

    public String F(Wind var1);

    public int I(Wind var1);

    public int K(Wind var1, boolean var2);

    public String L(Wind var1);

    public boolean b(Wind var1);

    public String f(Wind var1);

    public int m(Wind var1, boolean var2);

    public String t(Wind var1);

    public String u(Wind var1);

    public int v(Wind var1);
}

