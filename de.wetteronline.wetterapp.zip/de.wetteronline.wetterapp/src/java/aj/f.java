/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  sr.g
 */
package aj;

import aj.q;
import sr.g;

public final class f
extends q {
    public static final f b = new f();

    public f() {
        super(2131821550, null);
    }
}

