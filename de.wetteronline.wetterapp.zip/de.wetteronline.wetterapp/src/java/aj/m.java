/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  dn.b
 *  dn.f
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.NoSuchElementException
 *  l9.y5
 *  ma.e
 *  rh.l0
 *  rh.l0$a
 *  ur.b
 */
package aj;

import aj.l;
import android.content.res.Resources;
import dn.f;
import gr.j;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import l9.y5;
import ma.e;
import rh.l0;
import ur.b;

public final class m
implements l,
l0 {
    public final dn.b b;
    public final Resources c;

    public m(dn.b b2, Resources resources) {
        e.f((Object)b2, (String)"fusedUnitPreferences");
        e.f((Object)resources, (String)"resources");
        this.b = b2;
        this.c = resources;
    }

    @Override
    public String E(Double d2) {
        if (d2 == null) {
            return "";
        }
        d2.doubleValue();
        Object[] arrobject = new Object[]{e.l((String)this.l(d2), (Object)"\u00b0")};
        return l0.a.b((l0)this, (int)2131821631, (Object[])arrobject);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public int G(double d2) {
        int[] arrn;
        int[] arrn2 = this.c.getIntArray(2130903049);
        e.e((Object)arrn2, (String)"resources.getIntArray(R.array.temperature_colors)");
        int n2 = this.b.a().ordinal();
        if (n2 != 0) {
            if (n2 != 1) throw new y5(1);
            arrn = this.c.getIntArray(2130903048);
        } else {
            arrn = this.c.getIntArray(2130903047);
        }
        e.e((Object)arrn, (String)"when (fusedUnitPreferenc\u2026nds_fahrenheit)\n        }");
        int n3 = this.y(d2);
        e.f((Object)arrn, (String)"$this$zip");
        e.f((Object)arrn2, (String)"other");
        int n4 = Math.min((int)arrn.length, (int)arrn2.length);
        ArrayList arrayList = new ArrayList(n4);
        for (int i2 = 0; i2 < n4; ++i2) {
            int n5 = arrn[i2];
            int n6 = arrn2[i2];
            arrayList.add(new j<Integer, Integer>(n5, n6));
        }
        for (j j2 : arrayList) {
            boolean bl = ((Number)j2.b).intValue() >= n3;
            if (!bl) continue;
            return ((Number)j2.c).intValue();
        }
        throw new NoSuchElementException("Collection contains no element matching the predicate.");
    }

    @Override
    public String l(double d2) {
        return String.valueOf((int)this.y(d2));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String n() {
        int n2;
        int n3 = this.b.a().ordinal();
        if (n3 != 0) {
            if (n3 != 1) throw new y5(1);
            n2 = 2131821539;
            return l0.a.a((l0)this, (int)n2);
        } else {
            n2 = 2131821537;
        }
        return l0.a.a((l0)this, (int)n2);
    }

    public String q(int n2) {
        return l0.a.a((l0)this, (int)n2);
    }

    @Override
    public String x(Double d2, Double d3) {
        if (d2 == null) {
            return "";
        }
        double d4 = d2;
        if (d3 == null) {
            return "";
        }
        double d5 = d3;
        Object[] arrobject = new Object[1];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.l(d5));
        stringBuilder.append("\u00b0 / ");
        stringBuilder.append(this.l(d4));
        stringBuilder.append('\u00b0');
        arrobject[0] = stringBuilder.toString();
        return l0.a.b((l0)this, (int)2131821631, (Object[])arrobject);
    }

    @Override
    public int y(Double d2) {
        if (d2 != null) {
            int n2 = this.b.a().ordinal();
            if (n2 != 0) {
                if (n2 == 1) {
                    return b.a((double)(32.0 + 1.8 * d2));
                }
                throw new y5(1);
            }
            return b.a((double)d2);
        }
        return 0;
    }

    @Override
    public String z(double d2) {
        return e.l((String)String.valueOf((int)this.y(d2)), (Object)this.n());
    }
}

