/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 */
package aj;

public interface l {
    public String E(Double var1);

    public int G(double var1);

    public String l(double var1);

    public String n();

    public String x(Double var1, Double var2);

    public int y(Double var1);

    public String z(double var1);
}

