/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  sr.g
 */
package aj;

import aj.q;
import sr.g;

public final class d
extends q {
    public static final d b = new d();

    public d() {
        super(2131821542, null);
    }
}

