/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  aj.k$c
 *  androidx.compose.ui.platform.m
 *  de.wetteronline.components.data.model.PrecipitationType
 *  dn.b
 *  dn.c
 *  hr.s
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.NumberFormat
 *  java.util.Iterator
 *  java.util.List
 *  l9.y5
 *  ma.e
 *  rh.l0
 *  rh.l0$a
 *  rr.a
 *  sr.g
 *  tn.a
 */
package aj;

import aj.j;
import aj.k;
import androidx.compose.ui.platform.m;
import de.wetteronline.components.data.model.Precipitation;
import de.wetteronline.components.data.model.PrecipitationType;
import hr.s;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.List;
import l9.y5;
import ma.e;
import rh.l0;
import sr.g;

public final class k
implements j,
l0 {
    public static final a Companion;
    public static final List<Float> d;
    public static final List<Float> e;
    public final dn.b b;
    public final gr.g c;

    public static {
        Float f2;
        Float f3;
        Float f4;
        Companion = new Object(null){

            public final String a(float f2) {
                String string = NumberFormat.getInstance().format((Object)Float.valueOf((float)f2));
                e.e((Object)string, (String)"getInstance().format(this)");
                return string;
            }

            public final String b(List<Float> list, double d2) {
                int n2;
                block4 : {
                    e.f(list, (String)"<this>");
                    if (d2 < (double)((Number)s.W(list)).floatValue()) {
                        return e.l((String)"< ", (Object)this.a(((Number)s.W(list)).floatValue()));
                    }
                    if (d2 >= (double)((Number)s.c0(list)).floatValue()) {
                        return e.l((String)"> ", (Object)this.a(((Number)s.c0(list)).floatValue()));
                    }
                    Iterator iterator = list.iterator();
                    n2 = 0;
                    while (iterator.hasNext()) {
                        boolean bl = d2 < (double)((Number)iterator.next()).floatValue();
                        if (!bl) {
                            ++n2;
                            continue;
                        }
                        break block4;
                    }
                    n2 = -1;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(this.a(((Number)list.get(n2 - 1)).floatValue()));
                stringBuilder.append('-');
                stringBuilder.append(this.a(((Number)list.get(n2)).floatValue()));
                return stringBuilder.toString();
            }
        };
        Float f5 = Float.valueOf((float)0.0f);
        Object[] arrobject = new Float[]{f5, Float.valueOf((float)0.02f), Float.valueOf((float)0.05f), Float.valueOf((float)0.1f), Float.valueOf((float)0.2f), f3 = Float.valueOf((float)0.5f), f2 = Float.valueOf((float)1.0f), f4 = Float.valueOf((float)2.0f)};
        d = tn.a.u((Object[])arrobject);
        Object[] arrobject2 = new Float[]{f5, f3, f2, f4, Float.valueOf((float)5.0f), Float.valueOf((float)10.0f), Float.valueOf((float)20.0f), Float.valueOf((float)50.0f)};
        e = tn.a.u((Object[])arrobject2);
    }

    public k(dn.b b2) {
        e.f((Object)b2, (String)"fusedUnitPreferences");
        this.b = b2;
        this.c = tn.a.s((rr.a)new c(this));
    }

    @Override
    public String B(Precipitation precipitation) {
        String string;
        Double d2 = precipitation.getProbability();
        if (d2 == null) {
            string = null;
        } else {
            d2.doubleValue();
            string = m.a((StringBuilder)new StringBuilder(), (int)((int)(precipitation.getProbability() * (double)100)), (String)" %");
        }
        if (string == null) {
            string = e.l((String)((String)this.c.getValue()), (Object)" %");
        }
        return string;
    }

    @Override
    public int C(PrecipitationType precipitationType) {
        int n2 = b.a[precipitationType.ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3 && n2 != 4) {
                    throw new y5(1);
                }
                return 2131231033;
            }
            return 2131231034;
        }
        return 2131231035;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String D(Precipitation precipitation, gj.b b2) {
        String string;
        int n2 = b2.ordinal();
        if (n2 != 0) {
            if (n2 != 1) throw new y5(1);
            string = l0.a.a((l0)this, (int)2131821549);
        } else {
            string = l0.a.a((l0)this, (int)2131821541);
        }
        String string2 = precipitation.getDuration();
        if (string2 != null) return l0.a.b((l0)this, (int)2131821633, (Object[])new Object[]{string2, string});
        string2 = (String)this.c.getValue();
        return l0.a.b((l0)this, (int)2131821633, (Object[])new Object[]{string2, string});
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String M(Precipitation precipitation) {
        String string;
        if (precipitation.getSnowHeight() != null) {
            String string2;
            double d2 = precipitation.getSnowHeight();
            Object[] arrobject = new Object[1];
            int n2 = this.b.b().ordinal();
            if (n2 != 0) {
                if (n2 != 1) throw new y5(1);
                StringBuilder stringBuilder = e.g.a(Companion.b(d, 0.0393700787 * (d2 * (double)10)), ' ');
                stringBuilder.append(l0.a.a((l0)this, (int)2131821544));
                string2 = stringBuilder.toString();
            } else {
                StringBuilder stringBuilder = e.g.a(Companion.b(e, d2), ' ');
                stringBuilder.append(l0.a.a((l0)this, (int)2131821538));
                string2 = stringBuilder.toString();
            }
            arrobject[0] = string2;
            return l0.a.b((l0)this, (int)2131821635, (Object[])arrobject);
        }
        if (precipitation.getRainfallAmount() == null) return null;
        double d3 = precipitation.getRainfallAmount();
        Object[] arrobject = new Object[1];
        int n3 = this.b.b().ordinal();
        if (n3 != 0) {
            if (n3 != 1) throw new y5(1);
            StringBuilder stringBuilder = e.g.a(Companion.b(d, d3 * 0.0393700787), ' ');
            stringBuilder.append(l0.a.a((l0)this, (int)2131821544));
            string = stringBuilder.toString();
        } else {
            StringBuilder stringBuilder = e.g.a(Companion.b(e, d3), ' ');
            stringBuilder.append(l0.a.a((l0)this, (int)2131821548));
            string = stringBuilder.toString();
        }
        arrobject[0] = string;
        return l0.a.b((l0)this, (int)2131821634, (Object[])arrobject);
    }

    public String q(int n2) {
        return l0.a.a((l0)this, (int)n2);
    }

}

