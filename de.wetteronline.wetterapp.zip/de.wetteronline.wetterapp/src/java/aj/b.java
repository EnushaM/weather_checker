/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  de.wetteronline.components.data.model.AirPressure
 *  java.lang.Object
 *  java.lang.String
 */
package aj;

import de.wetteronline.components.data.model.AirPressure;

public interface b {
    public String j(AirPressure var1);
}

