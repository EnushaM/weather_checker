/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  e0.t0
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  ma.e
 */
package aj;

import android.support.v4.media.b;
import e0.t0;
import ma.e;

public final class g {
    public final String a;
    public final boolean b;
    public final String c;

    public g(String string, boolean bl, String string2) {
        e.f((Object)string, (String)"description");
        e.f((Object)string2, (String)"title");
        this.a = string;
        this.b = bl;
        this.c = string2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof g)) {
            return false;
        }
        g g2 = (g)object;
        if (!e.a((Object)this.a, (Object)g2.a)) {
            return false;
        }
        if (this.b != g2.b) {
            return false;
        }
        return e.a((Object)this.c, (Object)g2.c);
    }

    public int hashCode() {
        int n2 = 31 * this.a.hashCode();
        int n3 = this.b ? 1 : 0;
        if (n3 != 0) {
            n3 = 1;
        }
        return 31 * (n2 + n3) + this.c.hashCode();
    }

    public String toString() {
        StringBuilder stringBuilder = b.a((String)"NowcastContent(description=");
        stringBuilder.append(this.a);
        stringBuilder.append(", isActiveWarning=");
        stringBuilder.append(this.b);
        stringBuilder.append(", title=");
        return t0.a((StringBuilder)stringBuilder, (String)this.c, (char)')');
    }
}

