/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  de.wetteronline.components.data.model.Precipitation
 *  de.wetteronline.components.data.model.PrecipitationType
 *  gj.b
 *  java.lang.Object
 *  java.lang.String
 */
package aj;

import de.wetteronline.components.data.model.Precipitation;
import de.wetteronline.components.data.model.PrecipitationType;
import gj.b;

public interface j {
    public String B(Precipitation var1);

    public int C(PrecipitationType var1);

    public String D(Precipitation var1, b var2);

    public String M(Precipitation var1);
}

