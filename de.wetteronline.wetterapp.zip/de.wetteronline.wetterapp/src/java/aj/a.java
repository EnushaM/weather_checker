/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  ma.e
 */
package aj;

import aj.q;
import android.support.v4.media.b;
import ma.e;

public final class a {
    public final String a;
    public final q b;

    public a(String string, q q2) {
        e.f((Object)string, (String)"value");
        this.a = string;
        this.b = q2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof a)) {
            return false;
        }
        a a2 = (a)object;
        if (!e.a((Object)this.a, (Object)a2.a)) {
            return false;
        }
        return e.a((Object)this.b, (Object)a2.b);
    }

    public int hashCode() {
        return 31 * this.a.hashCode() + this.b.hashCode();
    }

    public String toString() {
        StringBuilder stringBuilder = b.a((String)"AirPressureArgs(value=");
        stringBuilder.append(this.a);
        stringBuilder.append(", unit=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}

