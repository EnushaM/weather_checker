/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  de.wetteronline.components.data.model.Nowcast
 *  java.lang.Object
 */
package aj;

import aj.g;
import de.wetteronline.components.data.model.Nowcast;

public interface h {
    public g w(Nowcast var1);
}

