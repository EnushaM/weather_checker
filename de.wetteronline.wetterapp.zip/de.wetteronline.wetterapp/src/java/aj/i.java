/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  rh.l0
 *  rh.l0$a
 */
package aj;

import aj.g;
import aj.h;
import de.wetteronline.components.data.model.Nowcast;
import rh.l0;

public final class i
implements h,
l0 {
    public String q(int n2) {
        return l0.a.a((l0)this, (int)n2);
    }

    @Override
    public g w(Nowcast nowcast) {
        if (nowcast.getTrend() == null) {
            return null;
        }
        boolean bl = nowcast.getWarning() != null;
        if (bl) {
            return new g(nowcast.getWarning().getContent(), bl, nowcast.getWarning().getTitle());
        }
        return new g(nowcast.getTrend().getDescription(), bl, l0.a.a((l0)this, (int)2131821155));
    }
}

