/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  sr.g
 */
package aj;

import sr.g;

public abstract class q {
    public final int a;

    public q(int n2, g g2) {
        this.a = n2;
    }
}

