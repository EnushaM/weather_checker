/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  aj.p
 *  aj.r
 *  aj.t
 *  aj.u
 *  aj.v
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Observable
 *  java.util.Observer
 *  ma.e
 *  rh.l0
 *  rh.l0$a
 */
package aj;

import aj.p;
import aj.r;
import aj.t;
import aj.u;
import aj.v;
import java.util.Observable;
import java.util.Observer;
import ma.e;
import rh.l0;

public final class o
implements Observer {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ o(p p2) {
        this.a = 0;
        this.b = p2;
    }

    public /* synthetic */ o(t t2) {
        this.a = 1;
        this.b = t2;
    }

    public final void update(Observable observable, Object object) {
        switch (this.a) {
            default: {
                break;
            }
            case 0: {
                p p2 = (p)this.b;
                e.f((Object)p2, (String)"this$0");
                p2.b();
                return;
            }
        }
        t t2 = (t)this.b;
        e.f((Object)t2, (String)"this$0");
        t2.e = l0.a.a((l0)t2, (int)2131821638);
        t2.f = new v();
        t2.g = new r();
        t2.h = new u();
    }
}

