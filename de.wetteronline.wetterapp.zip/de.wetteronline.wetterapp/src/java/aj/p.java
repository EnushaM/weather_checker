/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.support.v4.media.b
 *  android.text.format.DateUtils
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.Arrays
 *  java.util.Date
 *  java.util.Locale
 *  java.util.Objects
 *  java.util.Observer
 *  java.util.concurrent.TimeUnit
 *  ma.e
 *  org.joda.time.DateTime
 *  org.joda.time.DateTimeZone
 *  org.joda.time.Days
 *  org.joda.time.LocalDate
 *  org.joda.time.chrono.ISOChronology
 *  org.joda.time.format.a
 *  qi.u
 *  qi.w
 *  rh.e
 *  rh.l0
 *  rh.l0$a
 *  rt.a
 *  rt.c
 *  rt.d
 *  rt.f
 *  rt.h
 *  tn.a
 *  wt.a
 */
package aj;

import aj.n;
import aj.o;
import android.support.v4.media.b;
import android.text.format.DateUtils;
import b2.a;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;
import java.util.Observer;
import java.util.concurrent.TimeUnit;
import jh.g;
import ma.e;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.chrono.ISOChronology;
import qi.u;
import qi.w;
import rh.l0;
import rt.c;
import rt.d;
import rt.f;
import rt.h;

public final class p
implements n,
l0 {
    public final w b;
    public final u c;
    public org.joda.time.format.a d;
    public org.joda.time.format.a e;
    public org.joda.time.format.a f;
    public final String g;
    public final String h;

    public p(w w2, u u2, rh.e e2) {
        e.f((Object)w2, (String)"localizationHelper");
        e.f((Object)u2, (String)"localeProvider");
        e.f((Object)e2, (String)"configurationChangedObservable");
        this.b = w2;
        this.c = u2;
        this.g = l0.a.a((l0)this, (int)2131820812);
        this.h = l0.a.a((l0)this, (int)2131821533);
        this.b();
        e2.addObserver((Observer)new o(this));
    }

    @Override
    public String H(int n2) {
        int n3 = (int)TimeUnit.SECONDS.toHours((long)Math.abs((int)n2));
        int n4 = (int)((long)Math.abs((int)n2) % TimeUnit.HOURS.toSeconds(1L) / TimeUnit.MINUTES.toSeconds(1L));
        Locale locale = Locale.ROOT;
        Object[] arrobject = new Object[]{n3, n4};
        String string = String.format((Locale)locale, (String)"%02d%02d", (Object[])Arrays.copyOf((Object[])arrobject, (int)2));
        e.e((Object)string, (String)"java.lang.String.format(locale, format, *args)");
        StringBuilder stringBuilder = b.a((String)"GMT");
        String string2 = n2 < 0 ? "-" : "+";
        return a.a(stringBuilder, string2, string);
    }

    @Override
    public String J(DateTime dateTime, DateTimeZone dateTimeZone) {
        block6 : {
            String string;
            block5 : {
                block4 : {
                    if (dateTime != null) break block4;
                    string = null;
                    break block5;
                }
                org.joda.time.format.a a2 = this.e;
                if (a2 == null) break block6;
                string = a2.j(dateTimeZone).d((f)dateTime);
            }
            if (string == null) {
                string = this.g;
            }
            return string;
        }
        e.n((String)"localDateFormatShort");
        throw null;
    }

    @Override
    public String a(DateTime dateTime, DateTimeZone dateTimeZone) {
        switch (dateTime.A(dateTimeZone).g()) {
            default: {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Somehow we couldn't map the datetime ");
                stringBuilder.append((Object)dateTime);
                stringBuilder.append(" with the timezone ");
                stringBuilder.append((Object)dateTimeZone);
                stringBuilder.append(" to a day of the week");
                tn.a.A((Throwable)new IllegalArgumentException(stringBuilder.toString()));
                return "";
            }
            case 7: {
                return l0.a.a((l0)this, (int)2131821664);
            }
            case 6: {
                return l0.a.a((l0)this, (int)2131821663);
            }
            case 5: {
                return l0.a.a((l0)this, (int)2131821661);
            }
            case 4: {
                return l0.a.a((l0)this, (int)2131821665);
            }
            case 3: {
                return l0.a.a((l0)this, (int)2131821667);
            }
            case 2: {
                return l0.a.a((l0)this, (int)2131821666);
            }
            case 1: 
        }
        return l0.a.a((l0)this, (int)2131821662);
    }

    public final void b() {
        this.d = wt.a.a((String)this.b.g());
        this.e = wt.a.a((String)this.b.d());
        org.joda.time.format.a a2 = wt.a.a((String)this.b.j());
        Locale locale = this.c.b();
        e.f((Object)a2, (String)"<this>");
        e.f((Object)locale, (String)"locale");
        e.f((Object)locale, (String)"<this>");
        if (e.a((Object)locale.getLanguage(), (Object)"ta")) {
            a2 = a2.i(Locale.ENGLISH);
        }
        this.f = a2;
    }

    @Override
    public String h(int n2) {
        boolean bl = true;
        boolean bl2 = 5 <= n2 && n2 <= 7 ? bl : false;
        if (bl2) {
            return l0.a.a((l0)this, (int)2131820913);
        }
        boolean bl3 = 11 <= n2 && n2 <= 13 ? bl : false;
        if (bl3) {
            return l0.a.a((l0)this, (int)2131820910);
        }
        if (17 > n2 || n2 > 19) {
            bl = false;
        }
        if (bl) {
            return l0.a.a((l0)this, (int)2131820911);
        }
        return l0.a.a((l0)this, (int)2131820912);
    }

    @Override
    public String k(DateTimeZone dateTimeZone) {
        e.f((Object)dateTimeZone, (String)"timeZone");
        return this.H((int)TimeUnit.MILLISECONDS.toSeconds((long)dateTimeZone.o(null)));
    }

    @Override
    public String o(DateTime dateTime, DateTimeZone dateTimeZone) {
        block6 : {
            String string;
            block5 : {
                block4 : {
                    if (dateTime != null) break block4;
                    string = null;
                    break block5;
                }
                org.joda.time.format.a a2 = this.d;
                if (a2 == null) break block6;
                string = a2.j(dateTimeZone).d((f)dateTime);
            }
            if (string == null) {
                string = this.g;
            }
            return string;
        }
        e.n((String)"localDateFormatFull");
        throw null;
    }

    @Override
    public String p(DateTime dateTime, DateTime dateTime2, DateTimeZone dateTimeZone) {
        DateTime dateTime3 = dateTime.A(dateTimeZone);
        LocalDate localDate = dateTime2.A(dateTimeZone).B();
        LocalDate localDate2 = dateTime3.B();
        int n2 = Days.e((int)c.a((rt.a)localDate.r()).h().c(localDate2.e(), localDate.e())).c();
        if (n2 != 0) {
            if (n2 != 1) {
                String string = g.b(dateTime3.e());
                e.e((Object)string, (String)"getDayLongnameUTC(dateLocal.toDate())");
                return string;
            }
            int n3 = dateTime3.j() / 6;
            String string = n3 != 0 ? (n3 != 1 ? (n3 != 2 ? (n3 != 3 ? g.b(dateTime3.e()) : l0.a.a((l0)this, (int)2131821594)) : l0.a.a((l0)this, (int)2131821593)) : l0.a.a((l0)this, (int)2131821595)) : l0.a.a((l0)this, (int)2131821596);
            e.e((Object)string, (String)"when (dateLocal.hourOfDa\u2026l.toDate())\n            }");
            return string;
        }
        int n4 = dateTime3.j() / 6;
        String string = n4 != 0 ? (n4 != 1 ? (n4 != 2 ? (n4 != 3 ? g.b(dateTime3.e()) : l0.a.a((l0)this, (int)2131821590)) : l0.a.a((l0)this, (int)2131821589)) : l0.a.a((l0)this, (int)2131821591)) : l0.a.a((l0)this, (int)2131821592);
        e.e((Object)string, (String)"when (dateLocal.hourOfDa\u2026l.toDate())\n            }");
        return string;
    }

    public String q(int n2) {
        return l0.a.a((l0)this, (int)n2);
    }

    @Override
    public String r(DateTime dateTime, DateTimeZone dateTimeZone) {
        e.f((Object)dateTimeZone, (String)"timeZone");
        LocalDate localDate = dateTime.A(dateTimeZone).B();
        LocalDate localDate2 = new LocalDate(System.currentTimeMillis(), (rt.a)ISOChronology.U((DateTimeZone)dateTimeZone));
        int n2 = 1;
        if (localDate.b((h)localDate2.g(n2)) <= 0) {
            n2 = 0;
        }
        if (n2 != 0) {
            String string = wt.a.a((String)"EEEE").j(dateTimeZone).d((f)dateTime);
            e.e((Object)string, (String)"{\n                DateTi\u2026print(date)\n            }");
            return string;
        }
        String string = DateUtils.getRelativeTimeSpanString((long)localDate.j().getTime(), (long)localDate2.j().getTime(), (long)86400000L).toString();
        Objects.requireNonNull((Object)string, (String)"null cannot be cast to non-null type java.lang.String");
        String string2 = string.toLowerCase(Locale.ROOT);
        e.e((Object)string2, (String)"(this as java.lang.Strin\u2026.toLowerCase(Locale.ROOT)");
        return string2;
    }

    @Override
    public String s(DateTime dateTime, DateTimeZone dateTimeZone) {
        block6 : {
            String string;
            block5 : {
                block4 : {
                    if (dateTime != null) break block4;
                    string = null;
                    break block5;
                }
                org.joda.time.format.a a2 = this.f;
                if (a2 == null) break block6;
                string = a2.j(dateTimeZone).d((f)dateTime);
            }
            if (string == null) {
                string = this.h;
            }
            return string;
        }
        e.n((String)"localTimeFormat");
        throw null;
    }
}

