/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  aj.t$c
 *  aj.t$d
 *  androidx.viewpager2.widget.d
 *  de.wetteronline.components.data.model.IntensityUnit
 *  de.wetteronline.components.data.model.Sock
 *  dn.b
 *  dn.n
 *  hr.m
 *  hr.s
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Map
 *  java.util.Objects
 *  java.util.Observer
 *  l9.y5
 *  ma.e
 *  o0.c
 *  rh.e
 *  rh.l0
 *  rh.l0$a
 *  rr.a
 *  sr.g
 *  tn.a
 */
package aj;

import aj.o;
import aj.r;
import aj.s;
import aj.t;
import aj.u;
import aj.v;
import de.wetteronline.components.data.model.IntensityUnit;
import de.wetteronline.components.data.model.Sock;
import de.wetteronline.components.data.model.Wind;
import dn.n;
import hr.m;
import java.util.Map;
import java.util.Objects;
import java.util.Observer;
import l9.y5;
import ma.e;
import rh.l0;
import sr.g;

public final class t
implements s,
l0 {
    public static final a Companion = new Object(null){};
    public final dn.b b;
    public final gr.g c;
    public final gr.g d;
    public String e;
    public v f;
    public r g;
    public u h;

    public t(dn.b b2, rh.e e2) {
        e.f((Object)b2, (String)"fusedUnitPreferences");
        e.f((Object)e2, (String)"configurationChangedObservable");
        this.b = b2;
        this.c = tn.a.s((rr.a)new d(this));
        this.d = tn.a.s((rr.a)new c(this));
        this.e = l0.a.a((l0)this, (int)2131821638);
        this.f = new v();
        this.g = new r();
        this.h = new u();
        e2.addObserver((Observer)new o(this));
    }

    public static final String k(Wind.Speed.WindUnitData windUnitData, t t2) {
        block7 : {
            String string;
            block5 : {
                boolean bl;
                String string2;
                u u2;
                String string3;
                block6 : {
                    block4 : {
                        u2 = t2.h;
                        string2 = e.l((String)"wind_description_", (Object)windUnitData.getIntensity().getDescriptionValue());
                        Objects.requireNonNull((Object)u2);
                        e.f((Object)string2, (String)"name");
                        if (u2.b.get((Object)string2) == null) break block4;
                        string = (String)u2.b.get((Object)string2);
                        break block5;
                    }
                    string3 = l0.a.c((l0)u2, (String)string2);
                    bl = string3.length() == 0;
                    if (!bl) break block6;
                    string = null;
                    break block5;
                }
                if (bl) break block7;
                u2.b.put((Object)string2, (Object)string3);
                string = string3;
            }
            if (string == null) {
                string = (String)t2.d.getValue();
            }
            return string;
        }
        throw new y5(1);
    }

    public static final String l(Wind wind, t t2, n n2) {
        Wind.Speed.WindUnitData windUnitData = t2.h(wind, n2);
        if (windUnitData == null) {
            return null;
        }
        String string = windUnitData.getMaxGust();
        if (string == null) {
            return null;
        }
        return t2.o(string, n2);
    }

    @Override
    public String A(Wind wind) {
        return this.j(wind, false);
    }

    @Override
    public String F(Wind wind) {
        return this.a(this.b.h());
    }

    @Override
    public int I(Wind wind) {
        if (this.n(wind)) {
            return 0;
        }
        return wind.getDirection();
    }

    @Override
    public int K(Wind wind, boolean bl) {
        Wind.Speed.WindUnitData windUnitData = this.h(wind, this.b.h());
        Sock sock = windUnitData == null ? null : windUnitData.getSock();
        int n2 = sock == null ? -1 : b.b[sock.ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                return 0;
            }
            if (bl) {
                return 2131231712;
            }
            return 2131231711;
        }
        if (bl) {
            return 2131231713;
        }
        return 2131231710;
    }

    @Override
    public String L(Wind wind) {
        String string;
        Wind.Speed.WindUnitData windUnitData = this.h(wind, this.b.h());
        if (windUnitData == null || (string = windUnitData.getWindSpeed()) == null) {
            string = "";
        }
        return string;
    }

    public final String a(n n2) {
        int n3 = n2.ordinal();
        if (n3 != 0) {
            if (n3 != 1) {
                if (n3 != 2) {
                    if (n3 != 3) {
                        if (n3 == 4) {
                            return (String)this.f.f.getValue();
                        }
                        throw new y5(1);
                    }
                    return (String)this.f.d.getValue();
                }
                return (String)this.f.e.getValue();
            }
            return (String)this.f.c.getValue();
        }
        return (String)this.f.b.getValue();
    }

    @Override
    public boolean b(Wind wind) {
        Wind.Speed.Intensity intensity;
        Wind.Speed.WindUnitData windUnitData = this.h(wind, this.b.h());
        IntensityUnit intensityUnit = windUnitData == null ? null : ((intensity = windUnitData.getIntensity()) == null ? null : intensity.getUnit());
        return intensityUnit == IntensityUnit.NAUTIC;
    }

    @Override
    public String f(Wind wind) {
        return this.j(wind, true);
    }

    public final Wind.Speed.WindUnitData h(Wind wind, n n2) {
        Wind.Speed speed = wind.getSpeed();
        if (speed == null) {
            return null;
        }
        int n3 = n2.ordinal();
        if (n3 != 0) {
            if (n3 != 1) {
                if (n3 != 2) {
                    if (n3 != 3) {
                        if (n3 == 4) {
                            return speed.getMilesPerHour();
                        }
                        throw new y5(1);
                    }
                    return speed.getBeaufort();
                }
                return speed.getKnots();
            }
            return speed.getKilometerPerHour();
        }
        return speed.getMeterPerSecond();
    }

    public final String j(Wind wind, boolean bl) {
        String string;
        String string2;
        Wind.Speed.WindUnitData windUnitData = this.h(wind, this.b.h());
        if (windUnitData == null) {
            return (String)this.c.getValue();
        }
        if (windUnitData.getIntensity().getDescriptionValue() == 0) {
            return t.k(windUnitData, this);
        }
        Object[] arrobject = new String[3];
        arrobject[0] = t.k(windUnitData, this);
        int n2 = wind.getDirection();
        boolean bl2 = n2 >= 0 && n2 <= 22;
        if (bl2) {
            string = (String)this.g.b.getValue();
        } else {
            boolean bl3 = 23 <= n2 && n2 <= 67;
            if (bl3) {
                string = (String)this.g.c.getValue();
            } else {
                boolean bl4 = 68 <= n2 && n2 <= 112;
                if (bl4) {
                    string = (String)this.g.d.getValue();
                } else {
                    boolean bl5 = 113 <= n2 && n2 <= 157;
                    if (bl5) {
                        string = (String)this.g.e.getValue();
                    } else {
                        boolean bl6 = 158 <= n2 && n2 <= 202;
                        if (bl6) {
                            string = (String)this.g.f.getValue();
                        } else {
                            boolean bl7 = 203 <= n2 && n2 <= 247;
                            if (bl7) {
                                string = (String)this.g.g.getValue();
                            } else {
                                boolean bl8 = 248 <= n2 && n2 <= 292;
                                if (bl8) {
                                    string = (String)this.g.h.getValue();
                                } else {
                                    boolean bl9 = 293 <= n2 && n2 <= 337;
                                    if (bl9) {
                                        string = (String)this.g.i.getValue();
                                    } else {
                                        boolean bl10 = false;
                                        if (338 <= n2) {
                                            bl10 = false;
                                            if (n2 <= 360) {
                                                bl10 = true;
                                            }
                                        }
                                        string = bl10 ? (String)this.g.b.getValue() : (String)this.d.getValue();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        arrobject[1] = string;
        if (bl) {
            StringBuilder stringBuilder = o0.c.a((char)'(');
            stringBuilder.append(this.o(windUnitData.getWindSpeed(), this.b.h()));
            stringBuilder.append(')');
            string2 = stringBuilder.toString();
        } else {
            string2 = null;
        }
        arrobject[2] = string2;
        return hr.s.b0((Iterable)m.N((Object[])arrobject), (CharSequence)" ", null, null, (int)0, null, null, (int)62);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public int m(Wind var1_1, boolean var2_2) {
        block15 : {
            block17 : {
                block16 : {
                    block14 : {
                        var3_3 = this.h(var1_1, this.b.h());
                        if (var3_3 != null) break block14;
                        var4_4 = null;
                        break block15;
                    }
                    var5_5 = var3_3.getIntensity();
                    var6_6 = var5_5.getUnit();
                    var7_7 = b.a[var6_6.ordinal()];
                    if (var7_7 == 1) break block16;
                    if (var7_7 != 2) throw new y5(1);
                    switch (var5_5.getValue()) {
                        default: {
                            ** GOTO lbl-1000
                        }
                        case 10: {
                            var9_8 = 2131231701;
                            ** break;
                        }
                        case 9: {
                            var9_8 = 2131231709;
                            ** break;
                        }
                        case 8: {
                            var9_8 = 2131231708;
                            ** break;
                        }
                        case 7: {
                            var9_8 = 2131231707;
                            ** break;
                        }
                        case 6: {
                            var9_8 = 2131231706;
                            ** break;
                        }
                        case 5: {
                            var9_8 = 2131231705;
                            ** break;
                        }
                        case 4: {
                            var9_8 = 2131231704;
                            ** break;
                        }
                        case 3: {
                            var9_8 = 2131231703;
                            ** break;
                        }
                        case 2: {
                            var9_8 = 2131231702;
                            ** break;
                        }
                        case 1: {
                            var9_8 = 2131231700;
                            ** break;
lbl44: // 10 sources:
                            break;
                        }
                    }
                    break block17;
                }
                var8_9 = var5_5.getValue();
                if (var8_9 != 0) {
                    var9_8 = var8_9 != 1 ? (var8_9 != 2 ? (var2_2 ? 2131231457 : 2131231454) : (var2_2 ? 2131231456 : 2131231453)) : (var2_2 ? 2131231458 : 2131231455);
                } else lbl-1000: // 2 sources:
                {
                    var9_8 = 2131231426;
                }
            }
            var4_4 = var9_8;
        }
        if (var4_4 != null) return var4_4;
        return 2131231426;
    }

    public final boolean n(Wind wind) {
        Wind.Speed.Intensity intensity;
        Wind.Speed.WindUnitData windUnitData = this.h(wind, this.b.h());
        return windUnitData != null && (intensity = windUnitData.getIntensity()) != null && intensity.getValue() == 0;
    }

    public final String o(String string, n n2) {
        StringBuilder stringBuilder = e.g.a(string, '\u00a0');
        stringBuilder.append(this.a(n2));
        return stringBuilder.toString();
    }

    public String q(int n2) {
        return l0.a.a((l0)this, (int)n2);
    }

    @Override
    public String t(Wind wind) {
        String string;
        Wind.Speed.WindUnitData windUnitData = this.h(wind, this.b.h());
        if (windUnitData == null || (string = windUnitData.getMaxGust()) == null) {
            string = "";
        }
        return string;
    }

    @Override
    public String u(Wind wind) {
        n n2 = this.b.h();
        n n3 = n.d;
        String string = t.l(wind, this, n2);
        if (string == null) {
            string = null;
        } else {
            int n4 = n2.ordinal();
            if (n4 != 0) {
                if (n4 != 2) {
                    if (n4 == 3) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append((Object)t.l(wind, this, n3));
                        stringBuilder.append(" (");
                        stringBuilder.append(string);
                        stringBuilder.append(')');
                        string = stringBuilder.toString();
                    }
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append((Object)t.l(wind, this, n3));
                    stringBuilder.append(" (");
                    stringBuilder.append(string);
                    stringBuilder.append(')');
                    string = stringBuilder.toString();
                }
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append((Object)t.l(wind, this, n3));
                stringBuilder.append(" (");
                stringBuilder.append(string);
                stringBuilder.append(')');
                string = stringBuilder.toString();
            }
        }
        if (string == null) {
            return null;
        }
        String string2 = this.e;
        return androidx.viewpager2.widget.d.a((Object[])new Object[]{string}, (int)1, (String)string2, (String)"java.lang.String.format(format, *args)");
    }

    @Override
    public int v(Wind wind) {
        if (this.n(wind)) {
            return 2131231022;
        }
        return 2131231038;
    }

}

