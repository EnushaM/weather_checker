/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  aj.c$a
 *  dn.b
 *  dn.c
 *  java.lang.Object
 *  java.lang.String
 *  java.text.DecimalFormat
 *  java.text.NumberFormat
 *  java.util.List
 *  java.util.Locale
 *  java.util.Objects
 *  l9.y5
 *  ma.e
 *  qi.u
 *  rh.l0
 *  rh.l0$a
 *  rr.a
 *  tn.a
 */
package aj;

import aj.b;
import aj.c;
import aj.d;
import aj.e;
import aj.f;
import aj.q;
import de.wetteronline.components.data.model.AirPressure;
import gr.g;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import l9.y5;
import qi.u;
import rh.l0;

public final class c
implements b,
l0 {
    public final dn.b b;
    public final u c;
    public final g d;

    public c(dn.b b2, u u2) {
        ma.e.f((Object)b2, (String)"fusedUnitPreferences");
        ma.e.f((Object)u2, (String)"localeProvider");
        this.b = b2;
        this.c = u2;
        this.d = tn.a.s((rr.a)a.c);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String j(AirPressure airPressure) {
        aj.a a2;
        if (airPressure == null) {
            return "";
        }
        ma.e.f((Object)airPressure, (String)"airPressure");
        int n2 = this.b.b().ordinal();
        if (n2 != 0) {
            if (n2 != 1) throw new y5(1);
            double d2 = airPressure.getInhg();
            NumberFormat numberFormat = NumberFormat.getInstance();
            Objects.requireNonNull((Object)numberFormat, (String)"null cannot be cast to non-null type java.text.DecimalFormat");
            DecimalFormat decimalFormat = (DecimalFormat)numberFormat;
            decimalFormat.setMaximumFractionDigits(2);
            String string = decimalFormat.format(d2);
            ma.e.e((Object)string, (String)"NumberFormat.getInstance\u20262 }\n        .format(this)");
            a2 = new aj.a(string, e.b);
        } else {
            a2 = ((List)this.d.getValue()).contains((Object)this.c.b().getLanguage()) ? new aj.a(airPressure.getMmhg(), f.b) : new aj.a(airPressure.getHpa(), d.b);
        }
        String string = a2.a;
        q q2 = a2.b;
        Object[] arrobject = new Object[]{string, l0.a.a((l0)this, (int)q2.a)};
        return l0.a.b((l0)this, (int)2131821630, (Object[])arrobject);
    }

    public String q(int n2) {
        return l0.a.a((l0)this, (int)n2);
    }
}

