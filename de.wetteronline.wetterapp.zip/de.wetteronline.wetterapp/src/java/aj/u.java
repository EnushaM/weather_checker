/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  rh.l0
 *  rh.l0$a
 */
package aj;

import java.util.LinkedHashMap;
import java.util.Map;
import rh.l0;

public final class u
implements l0 {
    public final Map<String, String> b = new LinkedHashMap();

    public String q(int n2) {
        return l0.a.a((l0)this, (int)n2);
    }
}

