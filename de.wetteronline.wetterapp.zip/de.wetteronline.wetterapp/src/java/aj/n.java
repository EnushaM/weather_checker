/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.joda.time.DateTime
 *  org.joda.time.DateTimeZone
 */
package aj;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

public interface n {
    public String H(int var1);

    public String J(DateTime var1, DateTimeZone var2);

    public String a(DateTime var1, DateTimeZone var2);

    public String h(int var1);

    public String k(DateTimeZone var1);

    public String o(DateTime var1, DateTimeZone var2);

    public String p(DateTime var1, DateTime var2, DateTimeZone var3);

    public String r(DateTime var1, DateTimeZone var2);

    public String s(DateTime var1, DateTimeZone var2);
}

