/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package ac;

import ac.b;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import java.util.Objects;
import ud.q;

public final class b
extends s<b, b> {
    private static final b DEFAULT_INSTANCE;
    public static final int FIREBASE_INSTANCE_ID_FIELD_NUMBER = 2;
    public static final int GOOGLE_APP_ID_FIELD_NUMBER = 1;
    private static volatile l0<b> PARSER;
    private int bitField0_;
    private String firebaseInstanceId_ = "";
    private String googleAppId_ = "";

    public static {
        b b3;
        DEFAULT_INSTANCE = b3 = new b();
        s.C(b.class, (s)b3);
    }

    public static void F(b b3, String string) {
        Objects.requireNonNull((Object)((Object)b3));
        Objects.requireNonNull((Object)string);
        b3.bitField0_ = 1 | b3.bitField0_;
        b3.googleAppId_ = string;
    }

    public static void G(b b3, String string) {
        Objects.requireNonNull((Object)((Object)b3));
        Objects.requireNonNull((Object)string);
        b3.bitField0_ = 2 | b3.bitField0_;
        b3.firebaseInstanceId_ = string;
    }

    public static b H() {
        return (b)DEFAULT_INSTANCE.v();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<b> l02 = PARSER;
                if (l02 != null) return l02;
                Class<b> class_ = b.class;
                // MONITORENTER : ac.b.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new b(null);
            }
            case 3: {
                return new b();
            }
            case 2: {
                Object[] arrobject = new Object[]{"bitField0_", "googleAppId_", "firebaseInstanceId_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1008\u0000\u0002\u1008\u0001", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class b
    extends s.a<b, b> {
        public b() {
            super((s)DEFAULT_INSTANCE);
        }

        public b(a a3) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

