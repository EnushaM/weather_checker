/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package ac;

import i9.d;
import x9.f;

public final class l
implements f {
    public static final /* synthetic */ l b;

    public static /* synthetic */ {
        b = new l();
    }

    public final void onSuccess(Object object) {
        String string = (String)object;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Starting InAppMessaging runtime with Installation ID ");
        stringBuilder.append(string);
        d.h(stringBuilder.toString());
    }
}

