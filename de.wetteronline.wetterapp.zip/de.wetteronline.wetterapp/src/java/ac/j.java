/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.m0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  com.google.protobuf.u
 *  com.google.protobuf.u$d
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.h;
import ac.i;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.m0;
import com.google.protobuf.s;
import com.google.protobuf.u;
import ud.q;

public final class j
extends s<j, a> {
    public static final int ACTIVATE_EVENT_TO_LOG_FIELD_NUMBER = 8;
    public static final int CLEAR_EVENT_TO_LOG_FIELD_NUMBER = 9;
    private static final j DEFAULT_INSTANCE;
    public static final int EXPERIMENT_ID_FIELD_NUMBER = 1;
    public static final int EXPERIMENT_START_TIME_MILLIS_FIELD_NUMBER = 3;
    public static final int ONGOING_EXPERIMENTS_FIELD_NUMBER = 13;
    public static final int OVERFLOW_POLICY_FIELD_NUMBER = 12;
    private static volatile l0<j> PARSER;
    public static final int SET_EVENT_TO_LOG_FIELD_NUMBER = 7;
    public static final int TIMEOUT_EVENT_TO_LOG_FIELD_NUMBER = 10;
    public static final int TIME_TO_LIVE_MILLIS_FIELD_NUMBER = 6;
    public static final int TRIGGER_EVENT_FIELD_NUMBER = 4;
    public static final int TRIGGER_TIMEOUT_MILLIS_FIELD_NUMBER = 5;
    public static final int TTL_EXPIRY_EVENT_TO_LOG_FIELD_NUMBER = 11;
    public static final int VARIANT_ID_FIELD_NUMBER = 2;
    private String activateEventToLog_ = "";
    private String clearEventToLog_ = "";
    private String experimentId_ = "";
    private long experimentStartTimeMillis_;
    private u.d<i> ongoingExperiments_ = m0.e;
    private int overflowPolicy_;
    private String setEventToLog_ = "";
    private long timeToLiveMillis_;
    private String timeoutEventToLog_ = "";
    private String triggerEvent_ = "";
    private long triggerTimeoutMillis_;
    private String ttlExpiryEventToLog_ = "";
    private String variantId_ = "";

    public static {
        j j2;
        DEFAULT_INSTANCE = j2 = new j();
        s.C(j.class, (s)j2);
    }

    public static j F() {
        return DEFAULT_INSTANCE;
    }

    public String G() {
        return this.experimentId_;
    }

    public long H() {
        return this.experimentStartTimeMillis_;
    }

    public long I() {
        return this.timeToLiveMillis_;
    }

    public String J() {
        return this.triggerEvent_;
    }

    public long K() {
        return this.triggerTimeoutMillis_;
    }

    public String L() {
        return this.variantId_;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<j> l02 = PARSER;
                if (l02 != null) return l02;
                Class<j> class_ = j.class;
                // MONITORENTER : ac.j.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new j();
            }
            case 2: {
                Object[] arrobject = new Object[]{"experimentId_", "variantId_", "experimentStartTimeMillis_", "triggerEvent_", "triggerTimeoutMillis_", "timeToLiveMillis_", "setEventToLog_", "activateEventToLog_", "clearEventToLog_", "timeoutEventToLog_", "ttlExpiryEventToLog_", "overflowPolicy_", "ongoingExperiments_", i.class};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\r\u0000\u0000\u0001\r\r\u0000\u0001\u0000\u0001\u0208\u0002\u0208\u0003\u0002\u0004\u0208\u0005\u0002\u0006\u0002\u0007\u0208\b\u0208\t\u0208\n\u0208\u000b\u0208\f\f\r\u001b", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<j, a> {
        public a(h h2) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

