/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  nc.a
 *  qc.c
 *  w7.e
 *  w7.f
 *  w7.g
 *  wa.c
 */
package ac;

import ac.m;
import com.criteo.publisher.e0.s;
import fr.a;
import h4.p;
import kc.j;
import kc.k;
import kc.k0;
import kc.l;
import kc.q0;
import kc.r0;
import w7.e;
import w7.f;
import w7.g;
import wa.c;

public final class n
implements a {
    public final /* synthetic */ int a;
    public final a<k0> b;
    public final a<r0> c;
    public final a<j> d;
    public final a<qc.c> e;
    public final a<l> f;
    public final a<k> g;

    public n(a a2, a a3, a a4, a a5, a a6, a a7, int n2) {
        this.a = n2;
        if (n2 != 1) {
            this.b = a2;
            this.c = a3;
            this.d = a4;
            this.e = a5;
            this.f = a6;
            this.g = a7;
            return;
        }
        super();
        this.b = a2;
        this.c = a3;
        this.d = a4;
        this.e = a5;
        this.f = a6;
        this.g = a7;
    }

    public Object get() {
        switch (this.a) {
            default: {
                break;
            }
            case 0: {
                k0 k02 = this.b.get();
                r0 r02 = this.c.get();
                j j3 = this.d.get();
                qc.c c3 = this.e.get();
                l l2 = this.f.get();
                k k2 = this.g.get();
                m m2 = new m(k02, r02, j3, c3, l2, k2);
                return m2;
            }
        }
        c c4 = (c)this.b.get();
        g g2 = (g)this.c.get();
        ab.a a2 = (ab.a)((Object)this.d.get());
        qc.c c5 = this.e.get();
        nc.a a3 = (nc.a)this.f.get();
        k k3 = this.g.get();
        f f2 = g2.a("FIREBASE_INAPPMESSAGING", byte[].class, (e)s.m);
        q0 q02 = new q0(new p(f2), a2, c4, c5, a3, k3);
        return q02;
    }
}

