/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.o;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import ud.q;

public final class w
extends s<w, a> {
    private static final w DEFAULT_INSTANCE;
    public static final int HEX_COLOR_FIELD_NUMBER = 2;
    private static volatile l0<w> PARSER;
    public static final int TEXT_FIELD_NUMBER = 1;
    private String hexColor_ = "";
    private String text_ = "";

    public static {
        w w2;
        DEFAULT_INSTANCE = w2 = new w();
        s.C(w.class, (s)w2);
    }

    public static w F() {
        return DEFAULT_INSTANCE;
    }

    public String G() {
        return this.hexColor_;
    }

    public String H() {
        return this.text_;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<w> l02 = PARSER;
                if (l02 != null) return l02;
                Class<w> class_ = w.class;
                // MONITORENTER : ac.w.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new w();
            }
            case 2: {
                Object[] arrobject = new Object[]{"text_", "hexColor_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0208\u0002\u0208", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<w, a> {
        public a(o o3) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

