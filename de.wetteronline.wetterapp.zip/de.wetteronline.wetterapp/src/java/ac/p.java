/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.o;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import ud.q;

public final class p
extends s<p, a> {
    public static final int ACTION_URL_FIELD_NUMBER = 1;
    private static final p DEFAULT_INSTANCE;
    private static volatile l0<p> PARSER;
    private String actionUrl_ = "";

    public static {
        p p2;
        DEFAULT_INSTANCE = p2 = new p();
        s.C(p.class, (s)p2);
    }

    public static p G() {
        return DEFAULT_INSTANCE;
    }

    public String F() {
        return this.actionUrl_;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<p> l02 = PARSER;
                if (l02 != null) return l02;
                Class<p> class_ = p.class;
                // MONITORENTER : ac.p.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new p();
            }
            case 2: {
                Object[] arrobject = new Object[]{"actionUrl_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0208", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<p, a> {
        public a(o o3) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

