/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.c;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import ud.q;

public final class e
extends s<e, a> {
    private static final e DEFAULT_INSTANCE;
    private static volatile l0<e> PARSER;
    public static final int VALUE_FIELD_NUMBER = 1;
    private int value_;

    public static {
        e e2;
        DEFAULT_INSTANCE = e2 = new e();
        s.C(e.class, (s)e2);
    }

    public static e F() {
        return DEFAULT_INSTANCE;
    }

    public int G() {
        return this.value_;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<e> l02 = PARSER;
                if (l02 != null) return l02;
                Class<e> class_ = e.class;
                // MONITORENTER : ac.e.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new e();
            }
            case 2: {
                Object[] arrobject = new Object[]{"value_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0004", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<e, a> {
        public a(c c3) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

