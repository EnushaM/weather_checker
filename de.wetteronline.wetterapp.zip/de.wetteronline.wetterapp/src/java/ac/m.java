/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ac.k
 *  ac.l
 *  com.google.firebase.inappmessaging.FirebaseInAppMessagingDisplay
 *  cq.c
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  kc.b
 *  kc.f0
 *  kc.f1
 *  kc.j
 *  kc.j0
 *  kc.k
 *  kc.k0
 *  kc.l
 *  kc.r0
 *  lp.d
 *  lp.g
 *  lp.o
 *  pp.a
 *  qc.c
 *  qp.a
 *  qp.b
 *  qp.c
 *  sp.a
 *  sp.b
 *  tp.h
 *  wp.b
 *  wp.d
 *  wp.g
 *  wp.i
 *  wp.l
 *  wp.o
 *  wp.q
 *  wp.t
 *  wp.t$a
 *  x9.f
 *  x9.j
 *  xu.a
 */
package ac;

import ac.k;
import ac.l;
import com.google.firebase.inappmessaging.FirebaseInAppMessagingDisplay;
import java.util.Objects;
import kc.f0;
import kc.f1;
import kc.j;
import kc.j0;
import kc.k0;
import kc.r0;
import qp.a;
import qp.c;
import sp.b;
import tp.h;
import wp.d;
import wp.g;
import wp.i;
import wp.o;
import wp.q;
import wp.t;
import x9.f;

public class m {
    public final kc.l a;
    public final kc.k b;
    public final qc.c c;
    public boolean d;
    public FirebaseInAppMessagingDisplay e;

    public m(k0 k02, r0 r02, j j2, qc.c c2, kc.l l3, kc.k k2) {
        Object object;
        lp.d d2;
        int n2;
        block3 : {
            lp.d d3;
            block2 : {
                wp.l l4;
                c c3;
                block0 : {
                    Object object2;
                    block1 : {
                        this.c = c2;
                        this.d = false;
                        this.a = l3;
                        this.b = k2;
                        c2.getId().g((f)l.b);
                        pp.a a3 = k02.a;
                        pp.a a4 = k02.j.b;
                        pp.a a5 = k02.b;
                        Objects.requireNonNull((Object)a3, (String)"source1 is null");
                        Objects.requireNonNull((Object)a4, (String)"source2 is null");
                        Objects.requireNonNull((Object)a5, (String)"source3 is null");
                        l4 = new wp.l((Object[])new xu.a[]{a3, a4, a5});
                        c3 = sp.a.a;
                        n2 = lp.d.b;
                        b.a((int)3, (String)"maxConcurrency");
                        b.a((int)n2, (String)"bufferSize");
                        if (!(l4 instanceof h)) break block0;
                        object2 = ((h)l4).call();
                        if (object2 != null) break block1;
                        d3 = g.c;
                        break block2;
                    }
                    d2 = new t.a(object2, c3);
                    break block3;
                }
                d3 = new i((lp.d)l4, c3, false, 3, n2);
            }
            d2 = d3;
        }
        f0 f02 = f0.c;
        qp.b b2 = sp.a.d;
        a a6 = sp.a.c;
        d d4 = new d(d2, (qp.b)f02, b2, a6, a6);
        lp.o o2 = k02.f.a;
        Objects.requireNonNull((Object)o2, (String)"scheduler is null");
        b.a((int)n2, (String)"bufferSize");
        q q3 = new q((lp.d)d4, o2, false, n2);
        j0 j02 = new j0(k02, 0);
        b.a((int)2, (String)"prefetch");
        Object object3 = q3 instanceof h ? ((object = ((h)q3).call()) == null ? g.c : new t.a(object, (c)j02)) : new wp.b((lp.d)q3, (c)j02, 2, 1);
        lp.o o3 = k02.f.b;
        Objects.requireNonNull((Object)o3, (String)"scheduler is null");
        b.a((int)n2, (String)"bufferSize");
        new q(object3, o3, false, n2).d((lp.g)new cq.c((qp.b)new k(this), sp.a.e, a6, (qp.b)o.b));
    }
}

