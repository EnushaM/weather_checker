/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.o;
import ac.p;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import ud.q;

public final class u
extends s<u, a> {
    public static final int ACTION_FIELD_NUMBER = 2;
    private static final u DEFAULT_INSTANCE;
    public static final int IMAGE_URL_FIELD_NUMBER = 1;
    private static volatile l0<u> PARSER;
    private p action_;
    private String imageUrl_ = "";

    public static {
        u u2;
        DEFAULT_INSTANCE = u2 = new u();
        s.C(u.class, (s)u2);
    }

    public static u G() {
        return DEFAULT_INSTANCE;
    }

    public p F() {
        p p2 = this.action_;
        if (p2 == null) {
            p2 = p.G();
        }
        return p2;
    }

    public String H() {
        return this.imageUrl_;
    }

    public boolean I() {
        return this.action_ != null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<u> l02 = PARSER;
                if (l02 != null) return l02;
                Class<u> class_ = u.class;
                // MONITORENTER : ac.u.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new u();
            }
            case 2: {
                Object[] arrobject = new Object[]{"imageUrl_", "action_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0208\u0002\t", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<u, a> {
        public a(o o3) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

