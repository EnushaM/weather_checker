/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.m0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  com.google.protobuf.u
 *  com.google.protobuf.u$d
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.c;
import ac.f;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.m0;
import com.google.protobuf.s;
import com.google.protobuf.u;
import ud.q;

public final class d
extends s<d, a> {
    public static final int COUNT_FIELD_NUMBER = 5;
    private static final d DEFAULT_INSTANCE;
    public static final int NAME_FIELD_NUMBER = 2;
    private static volatile l0<d> PARSER;
    public static final int PREVIOUS_TIMESTAMP_MILLIS_FIELD_NUMBER = 4;
    public static final int TIMESTAMP_MILLIS_FIELD_NUMBER = 3;
    public static final int TRIGGER_PARAMS_FIELD_NUMBER = 1;
    private int count_;
    private String name_ = "";
    private long previousTimestampMillis_;
    private long timestampMillis_;
    private u.d<f> triggerParams_ = m0.e;

    public static {
        d d3;
        DEFAULT_INSTANCE = d3 = new d();
        s.C(d.class, (s)d3);
    }

    public static d F() {
        return DEFAULT_INSTANCE;
    }

    public String G() {
        return this.name_;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<d> l02 = PARSER;
                if (l02 != null) return l02;
                Class<d> class_ = d.class;
                // MONITORENTER : ac.d.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new d();
            }
            case 2: {
                Object[] arrobject = new Object[]{"triggerParams_", f.class, "name_", "timestampMillis_", "previousTimestampMillis_", "count_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0001\u0000\u0001\u001b\u0002\u0208\u0003\u0002\u0004\u0002\u0005\u0004", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<d, a> {
        public a(c c3) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

