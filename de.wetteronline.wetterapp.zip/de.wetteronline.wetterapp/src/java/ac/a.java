/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.inappmessaging.b
 *  com.google.firebase.inappmessaging.b$a
 *  com.google.firebase.inappmessaging.c
 *  com.google.firebase.inappmessaging.c$a
 *  com.google.firebase.inappmessaging.d
 *  com.google.firebase.inappmessaging.d$a
 *  com.google.firebase.inappmessaging.f
 *  com.google.firebase.inappmessaging.f$a
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  com.google.protobuf.u$b
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.Objects
 */
package ac;

import ac.a;
import com.google.firebase.inappmessaging.b;
import com.google.firebase.inappmessaging.c;
import com.google.firebase.inappmessaging.d;
import com.google.firebase.inappmessaging.f;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import com.google.protobuf.u;
import java.util.Objects;
import ud.q;

public final class a
extends s<a, b> {
    public static final int CAMPAIGN_ID_FIELD_NUMBER = 2;
    public static final int CLIENT_APP_FIELD_NUMBER = 3;
    public static final int CLIENT_TIMESTAMP_MILLIS_FIELD_NUMBER = 4;
    private static final a DEFAULT_INSTANCE;
    public static final int DISMISS_TYPE_FIELD_NUMBER = 6;
    public static final int ENGAGEMENTMETRICS_DELIVERY_RETRY_COUNT_FIELD_NUMBER = 10;
    public static final int EVENT_TYPE_FIELD_NUMBER = 5;
    public static final int FETCH_ERROR_REASON_FIELD_NUMBER = 8;
    public static final int FIAM_SDK_VERSION_FIELD_NUMBER = 9;
    private static volatile l0<a> PARSER;
    public static final int PROJECT_NUMBER_FIELD_NUMBER = 1;
    public static final int RENDER_ERROR_REASON_FIELD_NUMBER = 7;
    private int bitField0_;
    private String campaignId_ = "";
    private ac.b clientApp_;
    private long clientTimestampMillis_;
    private int engagementMetricsDeliveryRetryCount_;
    private int eventCase_ = 0;
    private Object event_;
    private String fiamSdkVersion_ = "";
    private String projectNumber_ = "";

    public static {
        a a3;
        DEFAULT_INSTANCE = a3 = new a();
        s.C(a.class, (s)a3);
    }

    public static void F(a a3, long l2) {
        a3.bitField0_ = 8 | a3.bitField0_;
        a3.clientTimestampMillis_ = l2;
    }

    public static void G(a a3, c c3) {
        Objects.requireNonNull((Object)((Object)a3));
        a3.event_ = c3.b;
        a3.eventCase_ = 5;
    }

    public static void H(a a3, com.google.firebase.inappmessaging.b b3) {
        Objects.requireNonNull((Object)((Object)a3));
        a3.event_ = b3.b;
        a3.eventCase_ = 6;
    }

    public static void I(a a3, f f2) {
        Objects.requireNonNull((Object)((Object)a3));
        a3.event_ = f2.b;
        a3.eventCase_ = 7;
    }

    public static void J(a a3, String string) {
        Objects.requireNonNull((Object)((Object)a3));
        Objects.requireNonNull((Object)string);
        a3.bitField0_ = 1 | a3.bitField0_;
        a3.projectNumber_ = string;
    }

    public static void K(a a3, String string) {
        Objects.requireNonNull((Object)((Object)a3));
        Objects.requireNonNull((Object)string);
        a3.bitField0_ = 256 | a3.bitField0_;
        a3.fiamSdkVersion_ = string;
    }

    public static void L(a a3, String string) {
        Objects.requireNonNull((Object)((Object)a3));
        Objects.requireNonNull((Object)string);
        a3.bitField0_ = 2 | a3.bitField0_;
        a3.campaignId_ = string;
    }

    public static void M(a a3, ac.b b3) {
        Objects.requireNonNull((Object)((Object)a3));
        a3.clientApp_ = b3;
        a3.bitField0_ = 4 | a3.bitField0_;
    }

    public static b N() {
        return (b)DEFAULT_INSTANCE.v();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<a> l02 = PARSER;
                if (l02 != null) return l02;
                Class<a> class_ = a.class;
                // MONITORENTER : ac.a.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new b(null);
            }
            case 3: {
                return new a();
            }
            case 2: {
                Object[] arrobject = new Object[]{"event_", "eventCase_", "bitField0_", "projectNumber_", "campaignId_", "clientApp_", "clientTimestampMillis_", c.a.a, b.a.a, f.a.a, d.a.a, "fiamSdkVersion_", "engagementMetricsDeliveryRetryCount_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0001\n\u0001\u0001\u0001\n\n\u0000\u0000\u0000\u0001\u1008\u0000\u0002\u1008\u0001\u0003\u1009\u0002\u0004\u1002\u0003\u0005\u103f\u0000\u0006\u103f\u0000\u0007\u103f\u0000\b\u103f\u0000\t\u1008\b\n\u1004\t", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class b
    extends s.a<a, b> {
        public b() {
            super((s)DEFAULT_INSTANCE);
        }

        public b(a a3) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

