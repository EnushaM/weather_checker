/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  androidx.compose.runtime.b
 *  com.google.firebase.inappmessaging.FirebaseInAppMessagingDisplay
 *  com.google.firebase.inappmessaging.e
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Objects
 *  java.util.Set
 *  nc.a
 *  oc.h
 *  oc.m
 *  oc.o
 *  qp.b
 *  sd.b
 *  sd.c
 *  sd.d
 *  td.e
 */
package ac;

import ab.a;
import ac.d;
import ac.g;
import ac.m;
import android.text.TextUtils;
import com.google.firebase.inappmessaging.FirebaseInAppMessagingDisplay;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import kc.d1;
import kc.f1;
import kc.g1;
import kc.h1;
import kc.j;
import kc.l;
import kc.p;
import kc.q0;
import oc.h;
import oc.o;
import qp.b;
import sd.c;
import td.e;
import x9.w;

public final class k
implements b {
    public final /* synthetic */ int b;
    public final /* synthetic */ Object c;

    public /* synthetic */ k(m m2) {
        this.b = 0;
        this.c = m2;
    }

    public /* synthetic */ k(kc.b b2) {
        this.b = 3;
        this.c = b2;
    }

    public /* synthetic */ k(h1 h12) {
        this.b = 4;
        this.c = h12;
    }

    public /* synthetic */ k(c c3) {
        this.b = 2;
        this.c = c3;
    }

    public /* synthetic */ k(x9.k k2) {
        this.b = 1;
        this.c = k2;
    }

    public final void accept(Object object) {
        switch (this.b) {
            default: {
                break;
            }
            case 3: {
                kc.b b2 = (kc.b)this.c;
                e e2 = (e)object;
                Objects.requireNonNull((Object)b2);
                HashSet hashSet = new HashSet();
                Iterator iterator = e2.I().iterator();
                while (iterator.hasNext()) {
                    for (g g2 : ((c)iterator.next()).L()) {
                        if (TextUtils.isEmpty((CharSequence)g2.F().G())) continue;
                        hashSet.add((Object)g2.F().G());
                    }
                }
                if (hashSet.size() > 50) {
                    i9.d.h("Too many contextual triggers defined - limiting to 50");
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Updating contextual triggers for the following analytics events: ");
                stringBuilder.append((Object)hashSet);
                i9.d.g(stringBuilder.toString());
                b2.c.a((Set<String>)hashSet);
                return;
            }
            case 2: {
                c c3 = (c)this.c;
                Boolean bl = (Boolean)object;
                if (androidx.compose.runtime.b.g((int)c3.J(), (int)1)) {
                    Object[] arrobject = new Object[]{c3.M().H(), bl};
                    i9.d.h(String.format((String)"Already impressed campaign %s ? : %s", (Object[])arrobject));
                    return;
                }
                if (androidx.compose.runtime.b.g((int)c3.J(), (int)2)) {
                    Object[] arrobject = new Object[]{c3.H().H(), bl};
                    i9.d.h(String.format((String)"Already impressed experiment %s ? : %s", (Object[])arrobject));
                }
                return;
            }
            case 1: {
                ((x9.k)this.c).a.s(object);
                return;
            }
            case 0: {
                m m2 = (m)this.c;
                o o2 = (o)object;
                FirebaseInAppMessagingDisplay firebaseInAppMessagingDisplay = m2.e;
                if (firebaseInAppMessagingDisplay != null) {
                    h h2 = o2.a;
                    l l2 = m2.a;
                    String string = o2.b;
                    p p2 = new p(l2.a, l2.b, l2.c, l2.d, l2.e, l2.f, l2.g, l2.h, h2, string);
                    firebaseInAppMessagingDisplay.displayMessage(h2, (com.google.firebase.inappmessaging.e)p2);
                }
                return;
            }
        }
        h1 h12 = (h1)this.c;
        e e3 = (e)object;
        if (!h12.b) {
            if (h12.c) {
                int n2;
                h12.d = n2 = 1 + h12.d;
                if (n2 >= 5) {
                    h12.c = false;
                    h12.a.b("fresh_install", false);
                }
            }
            Iterator iterator = e3.I().iterator();
            while (iterator.hasNext()) {
                if (!((c)iterator.next()).I()) continue;
                h12.b = true;
                h12.a.b("test_device", true);
                i9.d.h("Setting this device as a test device");
                break;
            }
        }
    }
}

