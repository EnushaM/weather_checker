/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.inappmessaging.a
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.c;
import ac.d;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import ud.q;

public final class g
extends s<g, a> {
    private static final g DEFAULT_INSTANCE;
    public static final int EVENT_FIELD_NUMBER = 2;
    public static final int FIAM_TRIGGER_FIELD_NUMBER = 1;
    private static volatile l0<g> PARSER;
    private int conditionCase_ = 0;
    private Object condition_;

    public static {
        g g2;
        DEFAULT_INSTANCE = g2 = new g();
        s.C(g.class, (s)g2);
    }

    public d F() {
        if (this.conditionCase_ == 2) {
            return (d)((Object)this.condition_);
        }
        return d.F();
    }

    public com.google.firebase.inappmessaging.a G() {
        if (this.conditionCase_ == 1) {
            com.google.firebase.inappmessaging.a a3 = com.google.firebase.inappmessaging.a.a((int)((Integer)this.condition_));
            if (a3 == null) {
                a3 = com.google.firebase.inappmessaging.a.f;
            }
            return a3;
        }
        return com.google.firebase.inappmessaging.a.c;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<g> l02 = PARSER;
                if (l02 != null) return l02;
                Class<g> class_ = g.class;
                // MONITORENTER : ac.g.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new g();
            }
            case 2: {
                Object[] arrobject = new Object[]{"condition_", "conditionCase_", d.class};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\u0002\u0001\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001?\u0000\u0002<\u0000", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<g, a> {
        public a(c c3) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

