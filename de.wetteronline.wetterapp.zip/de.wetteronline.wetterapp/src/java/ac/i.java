/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.h;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import ud.q;

public final class i
extends s<i, a> {
    private static final i DEFAULT_INSTANCE;
    public static final int EXPERIMENT_ID_FIELD_NUMBER = 1;
    private static volatile l0<i> PARSER;
    private String experimentId_ = "";

    public static {
        i i2;
        DEFAULT_INSTANCE = i2 = new i();
        s.C(i.class, (s)i2);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<i> l02 = PARSER;
                if (l02 != null) return l02;
                Class<i> class_ = i.class;
                // MONITORENTER : ac.i.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new i();
            }
            case 2: {
                Object[] arrobject = new Object[]{"experimentId_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0208", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<i, a> {
        public a(h h2) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

