/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.o;
import ac.p;
import ac.r;
import ac.w;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import ud.q;

public final class v
extends s<v, a> {
    public static final int ACTION_BUTTON_FIELD_NUMBER = 4;
    public static final int ACTION_FIELD_NUMBER = 5;
    public static final int BACKGROUND_HEX_COLOR_FIELD_NUMBER = 6;
    public static final int BODY_FIELD_NUMBER = 2;
    private static final v DEFAULT_INSTANCE;
    public static final int IMAGE_URL_FIELD_NUMBER = 3;
    private static volatile l0<v> PARSER;
    public static final int TITLE_FIELD_NUMBER = 1;
    private r actionButton_;
    private p action_;
    private String backgroundHexColor_ = "";
    private w body_;
    private String imageUrl_ = "";
    private w title_;

    public static {
        v v2;
        DEFAULT_INSTANCE = v2 = new v();
        s.C(v.class, (s)v2);
    }

    public static v J() {
        return DEFAULT_INSTANCE;
    }

    public p F() {
        p p2 = this.action_;
        if (p2 == null) {
            p2 = p.G();
        }
        return p2;
    }

    public r G() {
        r r3 = this.actionButton_;
        if (r3 == null) {
            r3 = r.G();
        }
        return r3;
    }

    public String H() {
        return this.backgroundHexColor_;
    }

    public w I() {
        w w2 = this.body_;
        if (w2 == null) {
            w2 = w.F();
        }
        return w2;
    }

    public String K() {
        return this.imageUrl_;
    }

    public w L() {
        w w2 = this.title_;
        if (w2 == null) {
            w2 = w.F();
        }
        return w2;
    }

    public boolean M() {
        return this.action_ != null;
    }

    public boolean N() {
        return this.body_ != null;
    }

    public boolean O() {
        return this.title_ != null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<v> l02 = PARSER;
                if (l02 != null) return l02;
                Class<v> class_ = v.class;
                // MONITORENTER : ac.v.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new v();
            }
            case 2: {
                Object[] arrobject = new Object[]{"title_", "body_", "imageUrl_", "actionButton_", "action_", "backgroundHexColor_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001\t\u0002\t\u0003\u0208\u0004\t\u0005\t\u0006\u0208", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<v, a> {
        public a(o o3) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

