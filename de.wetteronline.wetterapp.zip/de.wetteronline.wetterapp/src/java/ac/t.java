/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.o;
import ac.q;
import ac.s;
import ac.u;
import ac.v;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;

public final class t
extends com.google.protobuf.s<t, a> {
    public static final int BANNER_FIELD_NUMBER = 1;
    public static final int CARD_FIELD_NUMBER = 4;
    private static final t DEFAULT_INSTANCE;
    public static final int IMAGE_ONLY_FIELD_NUMBER = 3;
    public static final int MODAL_FIELD_NUMBER = 2;
    private static volatile l0<t> PARSER;
    private int messageDetailsCase_ = 0;
    private Object messageDetails_;

    public static {
        t t2;
        DEFAULT_INSTANCE = t2 = new t();
        com.google.protobuf.s.C(t.class, (com.google.protobuf.s)t2);
    }

    public static t H() {
        return DEFAULT_INSTANCE;
    }

    public q F() {
        if (this.messageDetailsCase_ == 1) {
            return (q)((Object)this.messageDetails_);
        }
        return q.I();
    }

    public s G() {
        if (this.messageDetailsCase_ == 4) {
            return (s)((Object)this.messageDetails_);
        }
        return s.H();
    }

    public u I() {
        if (this.messageDetailsCase_ == 3) {
            return (u)((Object)this.messageDetails_);
        }
        return u.G();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public int J() {
        int n3 = this.messageDetailsCase_;
        int n4 = 4;
        if (n3 == 0) return 5;
        if (n3 == 1) return 1;
        if (n3 == 2) return 2;
        if (n3 == 3) return 3;
        if (n3 == n4) return n4;
        return 0;
    }

    public v K() {
        if (this.messageDetailsCase_ == 2) {
            return (v)((Object)this.messageDetails_);
        }
        return v.J();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<t> l02 = PARSER;
                if (l02 != null) return l02;
                Class<t> class_ = t.class;
                // MONITORENTER : ac.t.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((com.google.protobuf.s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new t();
            }
            case 2: {
                Object[] arrobject = new Object[]{"messageDetails_", "messageDetailsCase_", q.class, v.class, u.class, s.class};
                return new ud.q((g0)DEFAULT_INSTANCE, "\u0000\u0004\u0001\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001<\u0000\u0002<\u0000\u0003<\u0000\u0004<\u0000", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<t, a> {
        public a(o o3) {
            super((com.google.protobuf.s)DEFAULT_INSTANCE);
        }
    }

}

