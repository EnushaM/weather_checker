/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.o;
import ac.p;
import ac.r;
import ac.w;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import ud.q;

public final class s
extends com.google.protobuf.s<s, a> {
    public static final int BACKGROUND_HEX_COLOR_FIELD_NUMBER = 5;
    public static final int BODY_FIELD_NUMBER = 2;
    private static final s DEFAULT_INSTANCE;
    public static final int LANDSCAPE_IMAGE_URL_FIELD_NUMBER = 4;
    private static volatile l0<s> PARSER;
    public static final int PORTRAIT_IMAGE_URL_FIELD_NUMBER = 3;
    public static final int PRIMARY_ACTION_BUTTON_FIELD_NUMBER = 6;
    public static final int PRIMARY_ACTION_FIELD_NUMBER = 7;
    public static final int SECONDARY_ACTION_BUTTON_FIELD_NUMBER = 8;
    public static final int SECONDARY_ACTION_FIELD_NUMBER = 9;
    public static final int TITLE_FIELD_NUMBER = 1;
    private String backgroundHexColor_ = "";
    private w body_;
    private String landscapeImageUrl_ = "";
    private String portraitImageUrl_ = "";
    private r primaryActionButton_;
    private p primaryAction_;
    private r secondaryActionButton_;
    private p secondaryAction_;
    private w title_;

    public static {
        s s2;
        DEFAULT_INSTANCE = s2 = new s();
        com.google.protobuf.s.C(s.class, (com.google.protobuf.s)s2);
    }

    public static s H() {
        return DEFAULT_INSTANCE;
    }

    public String F() {
        return this.backgroundHexColor_;
    }

    public w G() {
        w w2 = this.body_;
        if (w2 == null) {
            w2 = w.F();
        }
        return w2;
    }

    public String I() {
        return this.landscapeImageUrl_;
    }

    public String J() {
        return this.portraitImageUrl_;
    }

    public p K() {
        p p2 = this.primaryAction_;
        if (p2 == null) {
            p2 = p.G();
        }
        return p2;
    }

    public r L() {
        r r3 = this.primaryActionButton_;
        if (r3 == null) {
            r3 = r.G();
        }
        return r3;
    }

    public p M() {
        p p2 = this.secondaryAction_;
        if (p2 == null) {
            p2 = p.G();
        }
        return p2;
    }

    public r N() {
        r r3 = this.secondaryActionButton_;
        if (r3 == null) {
            r3 = r.G();
        }
        return r3;
    }

    public w O() {
        w w2 = this.title_;
        if (w2 == null) {
            w2 = w.F();
        }
        return w2;
    }

    public boolean P() {
        return this.body_ != null;
    }

    public boolean Q() {
        return this.primaryAction_ != null;
    }

    public boolean R() {
        return this.primaryActionButton_ != null;
    }

    public boolean S() {
        return this.secondaryAction_ != null;
    }

    public boolean T() {
        return this.secondaryActionButton_ != null;
    }

    public boolean U() {
        return this.title_ != null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<s> l02 = PARSER;
                if (l02 != null) return l02;
                Class<s> class_ = s.class;
                // MONITORENTER : ac.s.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((com.google.protobuf.s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new s();
            }
            case 2: {
                Object[] arrobject = new Object[]{"title_", "body_", "portraitImageUrl_", "landscapeImageUrl_", "backgroundHexColor_", "primaryActionButton_", "primaryAction_", "secondaryActionButton_", "secondaryAction_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\t\u0000\u0000\u0001\t\t\u0000\u0000\u0000\u0001\t\u0002\t\u0003\u0208\u0004\u0208\u0005\u0208\u0006\t\u0007\t\b\t\t\t", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<s, a> {
        public a(o o3) {
            super((com.google.protobuf.s)DEFAULT_INSTANCE);
        }
    }

}

