/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.g0
 *  com.google.protobuf.l0
 *  com.google.protobuf.s
 *  com.google.protobuf.s$a
 *  com.google.protobuf.s$b
 *  com.google.protobuf.s$f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package ac;

import ac.o;
import ac.w;
import com.google.protobuf.g0;
import com.google.protobuf.l0;
import com.google.protobuf.s;
import ud.q;

public final class r
extends s<r, a> {
    public static final int BUTTON_HEX_COLOR_FIELD_NUMBER = 2;
    private static final r DEFAULT_INSTANCE;
    private static volatile l0<r> PARSER;
    public static final int TEXT_FIELD_NUMBER = 1;
    private String buttonHexColor_ = "";
    private w text_;

    public static {
        r r3;
        DEFAULT_INSTANCE = r3 = new r();
        s.C(r.class, (s)r3);
    }

    public static r G() {
        return DEFAULT_INSTANCE;
    }

    public String F() {
        return this.buttonHexColor_;
    }

    public w H() {
        w w2 = this.text_;
        if (w2 == null) {
            w2 = w.F();
        }
        return w2;
    }

    public boolean I() {
        return this.text_ != null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object w(s.f f2, Object object, Object object2) {
        switch (f2.ordinal()) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 6: {
                l0<r> l02 = PARSER;
                if (l02 != null) return l02;
                Class<r> class_ = r.class;
                // MONITORENTER : ac.r.class
                s.b b3 = PARSER;
                if (b3 == null) {
                    PARSER = b3 = new s.b((s)DEFAULT_INSTANCE);
                }
                // MONITOREXIT : class_
                return b3;
            }
            case 5: {
                return DEFAULT_INSTANCE;
            }
            case 4: {
                return new a(null);
            }
            case 3: {
                return new r();
            }
            case 2: {
                Object[] arrobject = new Object[]{"text_", "buttonHexColor_"};
                return new q((g0)DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\t\u0002\u0208", arrobject);
            }
            case 1: {
                return null;
            }
            case 0: 
        }
        return (byte)1;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    public static final class a
    extends s.a<r, a> {
        public a(o o3) {
            super((s)DEFAULT_INSTANCE);
        }
    }

}

