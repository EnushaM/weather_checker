/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.view.Window
 *  androidx.activity.ComponentActivity
 *  androidx.compose.ui.platform.ComposeView
 *  androidx.lifecycle.w0
 *  e.h
 *  e.k
 *  e0.r
 *  java.lang.Object
 *  java.lang.String
 *  ma.e
 *  rr.p
 */
package b;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.compose.ui.platform.ComposeView;
import androidx.lifecycle.w0;
import e.h;
import e.k;
import e0.r;
import ma.e;
import rr.p;

public final class a {
    public static final ViewGroup.LayoutParams a = new ViewGroup.LayoutParams(-2, -2);

    public static void a(ComponentActivity componentActivity, r r3, p p2, int n2) {
        w0 w02;
        View view = ((ViewGroup)componentActivity.getWindow().getDecorView().findViewById(16908290)).getChildAt(0);
        ComposeView composeView = view instanceof ComposeView ? (ComposeView)view : null;
        if (composeView != null) {
            composeView.setParentCompositionContext(null);
            composeView.setContent(p2);
            return;
        }
        ComposeView composeView2 = new ComposeView((Context)componentActivity, null, 0);
        composeView2.setParentCompositionContext(null);
        composeView2.setContent(p2);
        View view2 = componentActivity.getWindow().getDecorView();
        e.e((Object)view2, (String)"window.decorView");
        if (k.n((View)view2) == null) {
            view2.setTag(2131297445, (Object)componentActivity);
        }
        if ((w02 = (w0)view2.getTag(2131297447)) == null) {
            ViewParent viewParent = view2.getParent();
            while (w02 == null && viewParent instanceof View) {
                View view3 = (View)viewParent;
                w02 = (w0)view3.getTag(2131297447);
                viewParent = view3.getParent();
            }
        }
        if (w02 == null) {
            view2.setTag(2131297447, (Object)componentActivity);
        }
        if (h.n((View)view2) == null) {
            view2.setTag(2131297446, (Object)componentActivity);
        }
        componentActivity.setContentView((View)composeView2, a);
    }
}

